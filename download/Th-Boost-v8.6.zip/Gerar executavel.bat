@echo off
setlocal
title Gerar executavel do Th Boost
cd /d "%~dp0"

net session >nul 2>&1
if errorlevel 1 (
  powershell -NoProfile -Command "Start-Process -FilePath '%~f0' -Verb RunAs"
  exit /b
)

rem Procura um Python que funcione de verdade (o "python" falso da Microsoft Store nao conta)
set "PY="
py -3 -c "import sys" >nul 2>&1 && set "PY=py -3"
if not defined PY python -c "import sys" >nul 2>&1 && set "PY=python"
if not defined PY (
  echo.
  echo  Python nao encontrado neste computador.
  echo.
  echo  Como resolver ^(2 minutos^):
  echo    1^) Abra https://www.python.org/downloads/ e baixe o Python.
  echo    2^) No instalador, MARQUE a caixa "Add python.exe to PATH" e clique em Install Now.
  echo    3^) Feche esta janela e abra este arquivo de novo.
  echo.
  echo  Se o Windows falou "Python nao foi encontrado" ou abriu a Microsoft Store, e normal:
  echo  e so um atalho falso. Depois de instalar pelo site, ele passa a funcionar.
  echo.
  pause
  exit /b 1
)

echo  Instalando as ferramentas ^(psutil e pyinstaller^)...
%PY% -m pip install --upgrade psutil pyinstaller
if errorlevel 1 (
  echo  Nao consegui instalar. Verifique a internet.
  pause
  exit /b 1
)

echo.
echo  Gerando o Th Boost.exe ^(pode demorar um minuto^)...
set "ICONE="
if exist "%~dp0Th Boost.ico" set "ICONE=--icon "%~dp0Th Boost.ico""
%PY% -m PyInstaller --noconfirm --clean --onefile --windowed --uac-admin %ICONE% --name "Th Boost" th_boost.py
if errorlevel 1 (
  echo.
  echo  Deu erro ao gerar. Mande o texto acima para quem te ajuda.
  pause
  exit /b 1
)

copy /y "dist\Th Boost.exe" "%~dp0Th Boost.exe" >nul
echo.
echo  Pronto! O arquivo "Th Boost.exe" esta nesta pasta.
echo  Se for usar o FPS, deixe o PresentMon.exe na mesma pasta do Th Boost.exe.
echo  Pode apagar as pastas build e dist e o arquivo Th Boost.spec.
echo.
pause
exit /b 0
