@echo off
setlocal
title Th Boost
cd /d "%~dp0"

rem Pede permissao de Administrador (necessario para overclock, plano de energia, RAM e renovar IP)
net session >nul 2>&1
if errorlevel 1 (
  powershell -NoProfile -Command "Start-Process -FilePath '%~f0' -Verb RunAs -WindowStyle Minimized"
  exit /b
)

rem Procura um Python que funcione de verdade (o "python" falso da Microsoft Store nao conta)
set "PY="
py -3 -c "import sys" >nul 2>&1 && set "PY=py -3"
if not defined PY python -c "import sys" >nul 2>&1 && set "PY=python"
if not defined PY (
  echo.
  echo  Python nao encontrado neste computador.
  echo.
  echo  Como resolver ^(2 minutos^):
  echo    1^) Abra https://www.python.org/downloads/ e baixe o Python.
  echo    2^) No instalador, MARQUE a caixa "Add python.exe to PATH" e clique em Install Now.
  echo    3^) Feche esta janela e abra o Th Boost de novo.
  echo.
  echo  Se o Windows falou "Python nao foi encontrado" ou abriu a Microsoft Store, e normal:
  echo  e so um atalho falso. Depois de instalar pelo site, ele passa a funcionar.
  echo.
  pause
  exit /b 1
)

rem Instala o psutil so na primeira vez
%PY% -c "import psutil" >nul 2>&1
if errorlevel 1 (
  echo  Instalando o psutil ^(so na primeira vez^)...
  %PY% -m pip install psutil
  %PY% -c "import psutil" >nul 2>&1
  if errorlevel 1 (
    echo.
    echo  Nao consegui instalar o psutil. Verifique a internet e tente de novo.
    pause
    exit /b 1
  )
)

rem Abre sem a janela preta do console
set "PYW="
if "%PY%"=="py -3" (
  where pyw >nul 2>&1 && set "PYW=pyw -3"
) else (
  where pythonw >nul 2>&1 && set "PYW=pythonw"
)
if defined PYW (
  start "" %PYW% "%~dp0th_boost.py"
) else (
  %PY% "%~dp0th_boost.py"
)
exit /b 0
