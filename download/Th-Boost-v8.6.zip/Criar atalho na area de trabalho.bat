@echo off
setlocal
title Criar atalho do Th Boost
cd /d "%~dp0"

if not exist "%~dp0Abrir Th Boost.bat" (
  echo.
  echo  Este arquivo precisa ficar dentro da pasta do Th Boost, junto do "Abrir Th Boost.bat".
  echo.
  pause
  exit /b 1
)

powershell -NoProfile -ExecutionPolicy Bypass -Command "$d=[Environment]::GetFolderPath('Desktop'); $s=(New-Object -ComObject WScript.Shell).CreateShortcut((Join-Path $d 'Th Boost.lnk')); $s.TargetPath='%~dp0Abrir Th Boost.bat'; $s.WorkingDirectory='%~dp0'; $s.WindowStyle=7; $s.Description='Th Boost'; if (Test-Path '%~dp0Th Boost.ico') { $s.IconLocation='%~dp0Th Boost.ico,0' }; $s.Save()"
if errorlevel 1 (
  echo.
  echo  Nao consegui criar o atalho. Tente clicar com o botao direito em "Abrir Th Boost.bat",
  echo  Enviar para, Area de trabalho ^(criar atalho^).
  echo.
  pause
  exit /b 1
)

echo.
echo  Pronto! O atalho "Th Boost" foi criado na area de trabalho, com o icone Th azul.
echo.
pause
exit /b 0
