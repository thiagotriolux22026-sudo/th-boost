"""
Th Boost v9.6 - painel de otimizacao e monitoramento para Windows (preto e azul, ou a cor que voce escolher).

Instalar:    pip install psutil
Executar:    python th_boost.py   (abra como Administrador para overclock, plano de energia, FPS e renovar IP)
             ou de dois cliques em "Abrir Th Boost.bat"
Gerar .exe:  de dois cliques em "Gerar executavel.bat"
             (ou: pip install pyinstaller  e  pyinstaller --onefile --windowed --uac-admin th_boost.py)

A janela abre como um aplicativo do Microsoft Edge (ou do Google Chrome), sem barra de enderecos.
O programa fica so no seu computador (127.0.0.1) e fecha sozinho quando a janela e fechada.
Atualizacao: de vez em quando ele le github.com/thiagotriolux22026-sudo/th-boost (versao.json) para avisar
quando o dono publicou uma versao nova. Nada do computador e enviado.

FPS: na pagina "FPS na tela", "Instalar contador" baixa o PresentMon oficial (conferido) com um clique.
"""

import base64
import collections
import ctypes
import glob
import hashlib
import io
import json
import math
import os
import re
import secrets
import shutil
import subprocess
import sys
import tempfile
import threading
import time
import urllib.error
import urllib.parse
import urllib.request
import webbrowser
import zipfile
from datetime import datetime
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

import psutil

APP_NAME = "Th Boost"
IS_WIN = os.name == "nt"
USUARIO = os.environ.get("USERNAME", "").upper()
PRESENTMON_ARGS = ["--output_stdout", "--stop_existing_session"]
# v9.1: o PresentMon 2.x usa "--", o 1.x usa "-"; se um jeito não der cabeçalho, tenta o outro
PRESENTMON_VARIANTES = (PRESENTMON_ARGS, ["-output_stdout", "-stop_existing_session"])
PLANO_ALTO_DESEMPENHO = "8c5e7fda-e8bf-4a96-9a85-a6e23a8c635c"
SERVIDOR_PING = "8.8.8.8"
FONTE = "Segoe UI"


# Processos do sistema que nunca têm a prioridade alterada
PROTEGIDOS = {
    "explorer.exe", "ctfmon.exe", "sihost.exe", "shellexperiencehost.exe",
    "startmenuexperiencehost.exe", "searchhost.exe",
}
# v9.1: o Modo Leve não baixa a prioridade de quem precisa de tempo certo: voz, áudio, gravação/transmissão, controles e
# sobreposições de FPS. Baixar esses causa voz picotando, áudio estalando, gravação perdendo quadros e controle sem resposta.
PROTEGIDOS_LEVE = frozenset({
    "discord.exe", "discordptb.exe", "discordcanary.exe", "teamspeak.exe", "ts3client_win64.exe", "ts3client_win32.exe",
    "mumble.exe", "voicemod.exe", "voicemeeter.exe", "voicemeeterpro.exe", "voicemeeter8.exe", "voicemeeter8x64.exe",
    "obs64.exe", "obs32.exe", "streamlabs obs.exe", "streamlabs desktop.exe", "xsplit.core.exe", "nvcontainer.exe",
    "nvidia share.exe", "nvidia overlay.exe", "amdrsserv.exe", "radeonsoftware.exe", "rtss.exe", "msiafterburner.exe",
    "steam.exe", "steamwebhelper.exe", "lghub.exe", "lghub_agent.exe", "lghub_system_tray.exe", "razer synapse 3.exe",
    "razercentralservice.exe", "icue.exe", "steelseriesgg.exe", "ds4windows.exe", "x360ce.exe", "wallpaper64.exe",
    "wallpaper32.exe", "spotify.exe", "audiodg.exe", "fxsound.exe", "nahimic.exe", "sonic studio 3.exe"})



# ---------------- funções de sistema ----------------

def executar(cmd, timeout=20):
    """Roda um comando sem abrir janela. Devolve (código, saída)."""
    flags = subprocess.CREATE_NO_WINDOW if IS_WIN else 0
    try:
        r = subprocess.run(cmd, capture_output=True, text=True, errors="replace",
                           timeout=timeout, creationflags=flags)
        return r.returncode, (r.stdout + r.stderr).strip()
    except (OSError, subprocess.SubprocessError) as erro:
        return 1, str(erro)


def e_admin():
    if not IS_WIN:
        return False
    try:
        return ctypes.windll.shell32.IsUserAnAdmin() != 0
    except OSError:
        return False


def tamanho_pasta(caminho):
    total = 0
    for raiz, _, arquivos in os.walk(caminho):
        for nome in arquivos:
            try:
                total += os.path.getsize(os.path.join(raiz, nome))
            except OSError:
                pass
    return total


def limpar_temporarios():
    """Apaga temporários do usuário e do Windows. Devolve bytes liberados (aprox.)."""
    pastas = {tempfile.gettempdir()}
    if os.environ.get("LOCALAPPDATA"):
        pastas.add(os.path.join(os.environ["LOCALAPPDATA"], "Temp"))
    if IS_WIN:
        pastas.add(os.path.join(os.environ.get("SystemRoot", r"C:\Windows"), "Temp"))
    liberado = 0
    for base in pastas:
        try:
            nomes = os.listdir(base)
        except OSError:
            continue
        for nome in nomes:
            caminho = os.path.join(base, nome)
            try:
                if os.path.isdir(caminho) and not os.path.islink(caminho):
                    tam = tamanho_pasta(caminho)
                    shutil.rmtree(caminho, ignore_errors=True)
                else:
                    tam = os.path.getsize(caminho)
                    os.remove(caminho)
                liberado += tam
            except OSError:
                pass  # arquivo em uso: pula
    return liberado


def esvaziar_lixeira():
    """Esvazia a lixeira de todas as unidades pela API do Windows. Devolve (ok, mensagem)."""
    if not IS_WIN:
        return False, "Disponível só no Windows."
    SHERB_NOCONFIRMATION, SHERB_NOPROGRESSUI, SHERB_NOSOUND = 0x1, 0x2, 0x4
    shell32 = ctypes.windll.shell32
    shell32.SHEmptyRecycleBinW.argtypes = [ctypes.c_void_p, ctypes.c_wchar_p, ctypes.c_ulong]
    shell32.SHEmptyRecycleBinW.restype = ctypes.c_long
    # HRESULT 0 = sucesso; -2147418113 (0x8000FFFF) = lixeira já vazia
    resultado = shell32.SHEmptyRecycleBinW(None, None,
                                           SHERB_NOCONFIRMATION | SHERB_NOPROGRESSUI | SHERB_NOSOUND)
    if resultado in (0, -2147418113):
        return True, "Lixeira esvaziada." if resultado == 0 else "A lixeira já estava vazia."
    return False, f"Não foi possível esvaziar a lixeira (código {resultado & 0xFFFFFFFF:#x})."


def disco_sistema():
    if IS_WIN:
        return os.environ.get("SystemDrive", "C:") + "\\"
    return os.path.abspath(os.sep)


class _Luid(ctypes.Structure):
    _fields_ = [("LowPart", ctypes.c_ulong), ("HighPart", ctypes.c_long)]


class _LuidAtributos(ctypes.Structure):
    _fields_ = [("Luid", _Luid), ("Attributes", ctypes.c_ulong)]


class _Privilegios(ctypes.Structure):
    _fields_ = [("PrivilegeCount", ctypes.c_ulong), ("Privileges", _LuidAtributos * 1)]


def _ativar_privilegio(nome):
    """Liga um privilégio do token atual (precisa de Administrador). True se conseguiu."""
    advapi, k32 = ctypes.windll.advapi32, ctypes.windll.kernel32
    token = ctypes.c_void_p()
    if not advapi.OpenProcessToken(k32.GetCurrentProcess(), 0x0020 | 0x0008, ctypes.byref(token)):
        return False  # TOKEN_ADJUST_PRIVILEGES | TOKEN_QUERY
    try:
        luid = _Luid()
        if not advapi.LookupPrivilegeValueW(None, nome, ctypes.byref(luid)):
            return False
        novo = _Privilegios(1, (_LuidAtributos * 1)(_LuidAtributos(luid, 0x2)))  # SE_PRIVILEGE_ENABLED
        k32.SetLastError(0)
        advapi.AdjustTokenPrivileges(token, False, ctypes.byref(novo), 0, None, None)
        return k32.GetLastError() == 0
    finally:
        k32.CloseHandle(token)


def _comando_memoria(cmd):
    """Manda um comando ao gerenciador de memória do Windows. True se deu certo.
    3 = gravar páginas alteradas, 4 = limpar standby, 5 = limpar standby de baixa prioridade."""
    valor = ctypes.c_int(cmd)
    return ctypes.windll.ntdll.NtSetSystemInformation(0x50, ctypes.byref(valor), ctypes.sizeof(valor)) == 0


def _limpar_cache_arquivos():
    """Esvazia o cache de arquivos do sistema (precisa de Administrador)."""
    k32 = ctypes.windll.kernel32
    k32.SetSystemFileCacheSize.argtypes = [ctypes.c_size_t, ctypes.c_size_t, ctypes.c_ulong]
    k32.SetSystemFileCacheSize.restype = ctypes.c_bool
    return bool(k32.SetSystemFileCacheSize(ctypes.c_size_t(-1), ctypes.c_size_t(-1), 0))


def liberar_ram(evitar=None):
    """v9.1: libera memória SÓ quando ela está apertada, e sem prejudicar o que está rodando.
    Antes, esvaziava a memória de TODOS os programas (inclusive do jogo e do áudio) e o cache de arquivos: o Windows
    tinha que recarregar tudo do disco depois, o que dava travadinhas. Agora:
      - com memória folgada (mais de 25% livre), não faz nada: memória "parada" no cache deixa o PC mais rápido, não mais lento;
      - apertada: esvazia só programas em segundo plano do seu usuário (nunca o da frente, jogos, voz, áudio, gravação)
        e limpa só a parte de baixa prioridade do cache (standby). O cache de arquivos não é mais jogado fora.
    Devolve (bytes_liberados, mensagem)."""
    if not IS_WIN:
        return 0, "Disponível só no Windows."
    vm = psutil.virtual_memory()
    livre = 100 - vm.percent
    if livre >= 25:
        return 0, (f"A memória está folgada ({livre:.0f}% livre). Limpar agora não deixaria nada mais rápido: "
                   "o Windows usa a memória sobrando como cache, e isso ajuda.")
    k32, psapi = ctypes.windll.kernel32, ctypes.windll.psapi
    k32.OpenProcess.restype = ctypes.c_void_p
    k32.OpenProcess.argtypes = [ctypes.c_ulong, ctypes.c_bool, ctypes.c_ulong]
    k32.CloseHandle.argtypes = [ctypes.c_void_p]
    psapi.EmptyWorkingSet.argtypes = [ctypes.c_void_p]
    antes = vm.available
    poupar = set(evitar or ())
    frente = pid_em_primeiro_plano()
    if frente:
        poupar.add(frente)
    for p in psutil.process_iter(["pid", "name", "username"]):
        try:
            nome = (p.info["name"] or "").lower()
            if (p.pid in poupar or p.pid in (0, 4, os.getpid()) or nome in PROTEGIDOS or nome in PROTEGIDOS_LEVE
                    or (p.info["username"] or "").split("\\")[-1].upper() != USUARIO):
                continue
            h = k32.OpenProcess(0x0100 | 0x0400, False, p.pid)  # SET_QUOTA | QUERY_INFORMATION
            if h:
                psapi.EmptyWorkingSet(h)
                k32.CloseHandle(h)
        except (psutil.Error, OSError):
            continue
    admin = e_admin()
    if admin:
        _ativar_privilegio("SeProfileSingleProcessPrivilege")
        _ativar_privilegio("SeIncreaseQuotaPrivilege")
        for cmd in (3, 5):  # grava as páginas alteradas e limpa só o standby de BAIXA prioridade
            _comando_memoria(cmd)
    liberado = max(0, psutil.virtual_memory().available - antes)
    mb = liberado / 1048576
    return liberado, (f"Memória estava apertada ({livre:.0f}% livre): ~{mb:.0f} MB liberados de programas em segundo plano. "
                      "O programa que você está usando e o jogo não foram mexidos.")


def abrir_link(url):
    """v9.1: abre um site no navegador da pessoa. Com o Th Boost como Administrador, abrir direto deixaria o navegador
    também como Administrador (inseguro e sem as contas da pessoa); pelo explorer.exe ele abre normal."""
    if not isinstance(url, str) or not url.startswith("https://"):
        raise ValueError("link inválido")
    if IS_WIN and e_admin():
        try:
            subprocess.Popen(["explorer.exe", url])
            return True
        except OSError:
            pass
    return webbrowser.open(url)


def plano_alto_desempenho():
    cod, _ = executar(["powercfg", "/setactive", PLANO_ALTO_DESEMPENHO])
    return cod == 0


def renovar_ip():
    executar(["ipconfig", "/release"], timeout=30)
    cod, _ = executar(["ipconfig", "/renew"], timeout=60)
    return cod == 0


def medir_ping(host=SERVIDOR_PING):
    """Latência em ms até o servidor, ou None se não respondeu."""
    if not IS_WIN:
        return None
    _, saida = executar(["ping", "-n", "1", "-w", "1500", host], timeout=5)
    m = re.search(r"(?:tempo|time)\s*[=<]\s*(\d+)\s*ms", saida, re.IGNORECASE)
    return int(m.group(1)) if m else None


def ler_gpu():
    """Dados da GPU NVIDIA pelo nvidia-smi. Devolve None se não houver."""
    campos = ("name,temperature.gpu,utilization.gpu,memory.used,memory.total,"
              "power.limit,power.default_limit,power.min_limit,power.max_limit")
    cod, saida = executar(["nvidia-smi", f"--query-gpu={campos}", "--format=csv,noheader,nounits"], timeout=8)
    if cod != 0 or not saida:
        return None
    v = [x.strip() for x in saida.splitlines()[0].split(",")]
    if len(v) != 9:
        return None

    def num(x):
        try:
            return float(x)
        except ValueError:
            return None

    chaves = ["temp", "uso", "vram_usada", "vram_total", "limite", "padrao", "min", "max"]
    g = {"nome": v[0]}
    for chave, valor in zip(chaves, v[1:]):
        g[chave] = num(valor)
    return g


def aplicar_limite_gpu(watts):
    cod, _ = executar(["nvidia-smi", "-pl", str(watts)])
    return cod == 0


def temp_cpu():
    """Temperatura da CPU. No Windows a psutil não expõe isso, então devolve None."""
    if not hasattr(psutil, "sensors_temperatures"):
        return None
    try:
        temps = psutil.sensors_temperatures()
    except Exception:
        return None
    for lista in temps.values():
        if lista:
            return lista[0].current
    return None


def pid_em_primeiro_plano():
    if not IS_WIN:
        return -1
    user32 = ctypes.windll.user32
    user32.GetForegroundWindow.restype = ctypes.c_void_p
    user32.GetWindowThreadProcessId.argtypes = [ctypes.c_void_p, ctypes.POINTER(ctypes.c_ulong)]
    pid = ctypes.c_ulong(0)
    user32.GetWindowThreadProcessId(user32.GetForegroundWindow(), ctypes.byref(pid))
    return pid.value


def pasta_do_programa():
    """Pasta onde está o .py (ou o .exe gerado), independente de onde o atalho foi aberto."""
    if getattr(sys, "frozen", False):
        return os.path.dirname(sys.executable)
    return os.path.dirname(os.path.abspath(__file__))


def caminho_presentmon():
    """Procura o PresentMon na pasta do programa, na pasta atual e no PATH. v9.1: aceita o nome do download
    (PresentMon-2.3.0-x64.exe) além de PresentMon.exe."""
    for pasta in (pasta_do_programa(), os.getcwd()):
        caminho = os.path.join(pasta, "PresentMon.exe")
        if os.path.isfile(caminho):
            return caminho
        try:
            achados = [a for a in sorted(glob.glob(os.path.join(pasta, "PresentMon*.exe")), reverse=True)
                       if not re.search(r"service|setup|install", os.path.basename(a), re.I)]
        except OSError:
            achados = []
        if achados:
            return achados[0]
    return shutil.which("PresentMon.exe")


def presentmon_colunas(partes):
    """Cabeçalho do CSV do PresentMon -> (coluna do app, do PID ou None, do tempo do quadro em ms) ou None.
    1.x: MsBetweenPresents; 2.x: FrameTime (os dois em milissegundos). Função pura."""
    if "Application" not in partes:
        return None
    for nome in ("MsBetweenPresents", "FrameTime", "MsBetweenDisplayChange", "DisplayedTime"):
        if nome in partes:
            return partes.index("Application"), (partes.index("ProcessID") if "ProcessID" in partes else None), partes.index(nome)
    return None


def fps_estat(quadros, agora, pid_frente=None):
    """v9.2: (fps do último segundo, app, "1% mais baixo" dos últimos 10 s, tempo médio do quadro em ms). Função pura.
    O 1% mais baixo é o FPS dos piores quadros (as travadinhas): quanto mais perto do FPS normal, mais liso o jogo."""
    fps, app = fps_da_janela(quadros, agora, pid_frente)
    if fps is None:
        return None, "", None, None
    ms = [q[3] for q in quadros if q[1] == app and agora - q[0] <= 10 and q[3] > 0]
    ms_rec = [q[3] for q in quadros if q[1] == app and agora - q[0] <= 1.0 and q[3] > 0]
    medio = sum(ms_rec) / len(ms_rec) if ms_rec else None
    baixo = None
    if len(ms) >= 30:
        ms.sort()
        p99 = ms[min(len(ms) - 1, int(len(ms) * 0.99))]
        baixo = round(1000.0 / p99) if p99 > 0 else None
    return fps, app, baixo, (round(medio, 1) if medio else None)


def fps_da_janela(quadros, agora, pid_frente=None, janela=1.0):
    """quadros: deque de (hora, app, pid, ms). Devolve (fps, app) do jogo na frente; se ele não desenhou nada, o app com
    mais quadros (sem o dwm, que é a própria área de trabalho). Função pura."""
    por = {}
    for t, app, pid, ms in quadros:
        if agora - t <= janela and ms > 0:
            por.setdefault((app, pid), []).append(ms)
    if not por:
        return None, ""
    candidatos = [k for k in por if pid_frente is not None and k[1] == pid_frente]
    if not candidatos:
        candidatos = sorted((k for k in por if k[0].lower() != "dwm.exe"), key=lambda k: -len(por[k])) or list(por)
    k = candidatos[0]
    media = sum(por[k]) / len(por[k])
    return (round(1000.0 / media) if media > 0 else None), k[0]


def formatar_velocidade(bps):
    unidades = ["B/s", "KB/s", "MB/s", "GB/s"]
    i = 0
    while bps >= 1024 and i < len(unidades) - 1:
        bps /= 1024
        i += 1
    return f"{bps:.1f} {unidades[i]}"


# ---------------- jogos instalados (Steam, Epic e as outras lojas: veja jogos_lojas) ----------------

EXCLUIR_JOGOS = ("redistributable", "redist", "steamworks", "proton", "linux runtime",
                 "directx", "vc_redist", "dotnet", "easyanticheat", "battleye")


def _steam_registro():
    """v9.1: pasta da Steam pelo registro (Steam instalada em D:\\Steam, por exemplo)."""
    if not IS_WIN:
        return []
    achados = []
    try:
        import winreg as _w
        for raiz, caminho, nome in ((_w.HKEY_CURRENT_USER, r"Software\Valve\Steam", "SteamPath"),
                                    (_w.HKEY_LOCAL_MACHINE, r"SOFTWARE\WOW6432Node\Valve\Steam", "InstallPath"),
                                    (_w.HKEY_LOCAL_MACHINE, r"SOFTWARE\Valve\Steam", "InstallPath")):
            try:
                with _w.OpenKey(raiz, caminho) as k:
                    v = str(_w.QueryValueEx(k, nome)[0]).replace("/", "\\")
                if v and os.path.isdir(v) and v.lower() not in [a.lower() for a in achados]:
                    achados.append(v)
            except OSError:
                continue
    except ImportError:
        pass
    return achados


def _pastas_steam():
    raizes = _raizes_steam()
    if not raizes:
        return []
    base = raizes[0]
    pastas = [os.path.join(base, "steamapps")]
    try:  # bibliotecas extras (ex.: outro HD)
        with open(os.path.join(base, "steamapps", "libraryfolders.vdf"), encoding="utf-8", errors="replace") as f:
            for caminho in re.findall(r'"path"\s+"([^"]+)"', f.read()):
                pastas.append(os.path.join(caminho.replace("\\\\", "\\"), "steamapps"))
    except OSError:
        pass
    return [p for p in dict.fromkeys(pastas) if os.path.isdir(p)]


def _valor_acf(texto, chave):
    m = re.search(r'"%s"\s+"([^"]*)"' % chave, texto)
    return m.group(1) if m else ""


def _jogos_steam():
    jogos = []
    for pasta in _pastas_steam():
        for arq in glob.glob(os.path.join(pasta, "appmanifest_*.acf")):
            try:
                with open(arq, encoding="utf-8", errors="replace") as f:
                    texto = f.read()
            except OSError:
                continue
            nome, appid, instalado = _valor_acf(texto, "name"), _valor_acf(texto, "appid"), _valor_acf(texto, "installdir")
            if nome and appid:
                jogo_pasta = os.path.join(pasta, "common", instalado) if instalado and not re.search(r"[\\/]|\.\.", instalado) else ""
                jogos.append({"nome": nome, "origem": "Steam", "appid": appid, "pasta": jogo_pasta,
                              "abrir": f"steam://rungameid/{appid}"})
    return jogos


def _jogos_epic():
    pasta = os.path.join(os.environ.get("ProgramData", r"C:\ProgramData"),
                         "Epic", "EpicGamesLauncher", "Data", "Manifests")
    jogos = []
    for arq in glob.glob(os.path.join(pasta, "*.item")):
        try:
            with open(arq, encoding="utf-8", errors="replace") as f:
                dados = json.load(f)
        except (OSError, ValueError):
            continue
        nome, app = dados.get("DisplayName"), dados.get("AppName")
        if nome and app and dados.get("bIsApplication", True):
            jogos.append({"nome": nome, "origem": "Epic", "pasta": str(dados.get("InstallLocation") or ""),
                          "abrir": f"com.epicgames.launcher://apps/{app}?action=launch&silent=true"})
    return jogos


def detectar_jogos():
    """Lista os jogos instalados (Steam, Epic, Riot, Roblox, FiveM, Xbox, EA, Ubisoft, GOG...), sem programas auxiliares."""
    if not IS_WIN:
        return []
    return jogos_detectar_tudo()


def lancar_jogo(abrir):
    """Abre o jogo: por um endereço do launcher (steam://, uplay://...), pelo .exe, ou pelo launcher com argumentos. True se conseguiu."""
    if not IS_WIN:
        return False
    try:
        if isinstance(abrir, (list, tuple)):
            exe = abrir[0] if abrir else ""
            if not isinstance(exe, str) or not exe.lower().endswith(".exe") or not os.path.isfile(exe):
                return False
            subprocess.Popen([str(x) for x in abrir], cwd=os.path.dirname(exe), close_fds=True,
                             creationflags=0x00000008 | 0x00000200)  # DETACHED_PROCESS | CREATE_NEW_PROCESS_GROUP
            return True
        os.startfile(abrir)
        return True
    except (OSError, ValueError):
        return False


# ---------------- capas dos jogos ----------------

def _raizes_steam():
    raizes = list(_steam_registro())  # v9.1: primeiro onde a Steam diz que está (pode ser D:\\Steam)
    for raiz in (os.environ.get("ProgramFiles(x86)", r"C:\Program Files (x86)"),
                 os.environ.get("ProgramFiles", r"C:\Program Files")):
        c = os.path.join(raiz, "Steam")
        if os.path.isdir(c) and c.lower() not in [r.lower() for r in raizes]:
            raizes.append(c)
    return raizes


def pasta_capas():
    caminho = os.path.join(pasta_do_programa(), "capas")
    try:
        os.makedirs(caminho, exist_ok=True)
        return caminho
    except OSError:
        return tempfile.gettempdir()


def _capa_no_computador(appid):
    """Procura a capa que a própria Steam já guardou no PC."""
    for raiz in _raizes_steam():
        cache = os.path.join(raiz, "appcache", "librarycache")
        candidatos = [os.path.join(cache, f"{appid}_header.jpg"),
                      os.path.join(cache, f"{appid}_library_600x900.jpg"),
                      os.path.join(cache, str(appid), "header.jpg"),
                      os.path.join(cache, str(appid), "library_600x900.jpg")]
        for caminho in candidatos:
            if os.path.isfile(caminho):
                return caminho
    return None


def capa_do_jogo(jogo):
    """Caminho da imagem do jogo: usa a do PC, senão baixa da Steam. None se não houver."""
    appid = jogo.get("appid")
    if not appid:
        return icone_do_jogo(jogo)  # fora da Steam: usa o ícone do programa do jogo
    local = _capa_no_computador(appid)
    if local:
        return local
    destino = os.path.join(pasta_capas(), f"{appid}.jpg")
    if os.path.isfile(destino):
        return destino
    url = f"https://cdn.cloudflare.steamstatic.com/steam/apps/{appid}/header.jpg"
    try:
        with urllib.request.urlopen(url, timeout=10) as resposta, open(destino, "wb") as arq:
            shutil.copyfileobj(resposta, arq)
        return destino if os.path.getsize(destino) > 1000 else None
    except Exception:
        try:
            os.remove(destino)
        except OSError:
            pass
        return None



# ---------------- coleta em segundo plano ----------------

class Monitor(threading.Thread):
    """Coleta GPU, rede, FPS e prioridades em segundo plano, para a janela não travar."""

    def __init__(self):
        super().__init__(daemon=True)
        self.dados = {"gpu": None, "gpu_lida": False, "fps": None, "app": "", "fps_erro": "", "fps1": None, "fps_ms": None,
                      "down": 0.0, "up": 0.0}
        self.overlay = False  # v9.2: FPS na tela ligado (lê a placa de vídeo mesmo com a janela do Th Boost fechada)
        self.modo_leve = False
        self.forcar = False
        self.fps_ligado = False
        self.proc_fps = None
        self.alterados = set()  # PIDs cuja prioridade foi mexida
        self.fixos = set()  # PIDs cuja prioridade é cuidada pela sessão de jogo (o Modo Leve não mexe)
        self.ocioso = False  # sem janela aberta (modo segundo plano): só mantém as prioridades
        self.trava = threading.Lock()
        self.quadros = collections.deque()
        self.jogando = False  # v9.1: durante uma sessão de jogo o Th Boost lê menos coisas (sobra mais CPU para o jogo)
        self._dono = {}  # pid -> (hora de criação, é do seu usuário?) para não perguntar ao Windows a cada 4 s
        self.protege = set()  # v9.2: a janelinha do FPS na tela (o Modo Leve não baixa a prioridade dela)
        self._lim = collections.deque(maxlen=5)  # v9.5: últimas leituras (CPU, núcleo mais usado, GPU)
        self._religar_fps = False

    def run(self):
        ultimo_gpu = ultimo_prio = ultimo_cpu_ov = 0.0
        ultimo_rede = time.time()
        rede_antes = psutil.net_io_counters()
        while True:
            agora = time.time()
            if self.ocioso:  # ninguém olhando os números: não gasta CPU lendo GPU e rede
                rede_antes, ultimo_rede = psutil.net_io_counters(), agora
            if (not self.ocioso or self.overlay) and agora - ultimo_gpu > (2.0 if self.overlay else 5.0 if self.jogando else 1.5):
                self.dados["gpu"] = ler_gpu()
                self.dados["gpu_lida"] = True
                ultimo_gpu = agora
            if (self.overlay or not self.ocioso) and agora - ultimo_cpu_ov >= 0.9:  # v9.2: CPU % do FPS na tela (sempre por esta linha)
                ultimo_cpu_ov = agora
                try:  # v9.5: por núcleo, para saber quem segura o FPS (processador ou placa de vídeo)
                    nucleos = psutil.cpu_percent(interval=None, percpu=True) or []
                    tot = sum(nucleos) / len(nucleos) if nucleos else None
                    self.dados["cpu_ov"] = tot
                    self._lim.append((tot, max(nucleos) if nucleos else None, (self.dados.get("gpu") or {}).get("uso")))
                    self.dados["gargalo"] = gargalo(list(self._lim))
                except Exception:
                    self.dados["cpu_ov"] = None
            if not self.ocioso and agora - ultimo_rede >= 1:
                rede_agora = psutil.net_io_counters()
                dt = agora - ultimo_rede
                self.dados["down"] = (rede_agora.bytes_recv - rede_antes.bytes_recv) / dt
                self.dados["up"] = (rede_agora.bytes_sent - rede_antes.bytes_sent) / dt
                rede_antes, ultimo_rede = rede_agora, agora
            if (self.modo_leve or self.alterados) and (self.forcar or agora - ultimo_prio > (6 if self.jogando else 4)):
                self.forcar = False
                ultimo_prio = agora
                self.aplicar_prioridades(self.modo_leve)
            time.sleep(1.0 if self.ocioso else 0.4)

    def ligar_fps(self, ligar):
        self.dados["fps_erro"] = ""
        self.fps_ligado = ligar
        if ligar and self.proc_fps is None:
            self._religar_fps = False
            threading.Thread(target=self._ler_presentmon, daemon=True).start()
        elif ligar:
            self._religar_fps = True  # o leitor antigo ainda está fechando: abre outro assim que ele terminar
        elif self.proc_fps is not None:
            self._religar_fps = False
            try:
                self.proc_fps.terminate()
            except OSError:
                pass

    def _ler_presentmon(self):
        """v9.1: funciona com o PresentMon 1.x e 2.x, mostra o FPS do jogo que está na frente e nunca fica preso."""
        caminho = caminho_presentmon()
        if caminho is None:
            self.dados["fps_erro"] = ("PresentMon não encontrado. Baixe em github.com/GameTechDev/PresentMon e coloque o "
                                      ".exe dentro da pasta do Th Boost.")
            self.fps_ligado = False
            return
        flags = subprocess.CREATE_NO_WINDOW if IS_WIN else 0
        recebeu = False
        try:
            for args in PRESENTMON_VARIANTES:
                if not self.fps_ligado:
                    break
                try:
                    proc = subprocess.Popen([caminho] + args, stdout=subprocess.PIPE, stderr=subprocess.DEVNULL,
                                            text=True, encoding="utf-8", errors="replace", creationflags=flags)
                except OSError:
                    self.dados["fps_erro"] = "Não foi possível iniciar o PresentMon."
                    break
                self.proc_fps = proc
                colunas, ultimo = None, 0.0
                for linha in proc.stdout:
                    if not self.fps_ligado:
                        break
                    partes = linha.strip().split(",")
                    if colunas is None:
                        colunas = presentmon_colunas(partes)
                        continue
                    try:
                        app = partes[colunas[0]]
                        pid = int(partes[colunas[1]]) if colunas[1] is not None else None
                        ms = float(partes[colunas[2]])
                    except (IndexError, ValueError):
                        continue
                    recebeu = True
                    agora = time.time()
                    self.quadros.append((agora, app, pid, ms))
                    while self.quadros and agora - self.quadros[0][0] > 10:
                        self.quadros.popleft()
                    if agora - ultimo >= 0.5:  # atualiza a tela 2x por segundo
                        ultimo = agora
                        fps, nome, baixo, ms_q = fps_estat(self.quadros, agora, pid_em_primeiro_plano())
                        self.dados["fps"] = fps
                        self.dados["app"] = nome.replace(".exe", "")
                        self.dados["fps1"] = baixo
                        self.dados["fps_ms"] = ms_q
                try:
                    proc.terminate()
                    proc.wait(timeout=3)
                except (OSError, subprocess.SubprocessError):
                    pass
                if colunas is not None or not self.fps_ligado:
                    break  # este jeito funcionou (ou a pessoa desligou): não tenta o outro
            if self.fps_ligado:  # parou sozinho, sem o usuário desligar
                self.dados["fps_erro"] = (("PresentMon parou. " if recebeu else "PresentMon não iniciou. ")
                                          + ("Abra o Th Boost como Administrador." if not e_admin()
                                             else "Feche outros contadores de FPS (Afterburner/RTSS) e tente de novo."))
        except Exception:
            self.dados["fps_erro"] = "O contador de FPS falhou. Desligue e ligue de novo."
        finally:
            self.proc_fps = None
            self.dados["fps"] = None
            self.dados["fps1"] = self.dados["fps_ms"] = None
            self.quadros.clear()
            if self._religar_fps:  # desligou e ligou de novo rápido
                self._religar_fps = False
                self.fps_ligado = True
                self.dados["fps_erro"] = ""
                threading.Thread(target=self._ler_presentmon, daemon=True).start()
            else:
                self.fps_ligado = False

    def aplicar_prioridades(self, leve):
        """Modo leve: app em foco com prioridade alta; o resto do seu usuário com prioridade baixa."""
        if not IS_WIN or not USUARIO:
            return
        with self.trava:
            if not leve:
                for pid in self.alterados:
                    try:
                        psutil.Process(pid).nice(psutil.NORMAL_PRIORITY_CLASS)
                    except (psutil.Error, OSError):
                        pass
                self.alterados.clear()
                return
            frente = pid_em_primeiro_plano()
            vistos = set()
            for p in psutil.process_iter(["pid", "name", "create_time"]):
                try:
                    nome = (p.info["name"] or "").lower()
                    vistos.add(p.pid)
                    if p.pid in (0, 4, os.getpid()) or nome in PROTEGIDOS or nome in PROTEGIDOS_LEVE or p.pid in self.fixos \
                            or p.pid in self.protege or nome.startswith("presentmon"):  # v9.2: o contador e o FPS na tela
                        continue
                    criado = p.info.get("create_time")
                    dono = self._dono.get(p.pid)
                    if dono is None or dono[0] != criado:
                        dono = (criado, p.username().split("\\")[-1].upper() == USUARIO)
                        self._dono[p.pid] = dono
                    if not dono[1]:
                        continue  # só mexe nos programas do seu usuário
                    alvo = psutil.ABOVE_NORMAL_PRIORITY_CLASS if p.pid == frente else psutil.BELOW_NORMAL_PRIORITY_CLASS
                    atual = p.nice()
                    if p.pid not in self.alterados and atual != psutil.NORMAL_PRIORITY_CLASS:
                        continue  # v9.1: quem já tinha outra prioridade (escolhida por você ou pelo programa) fica como está
                    if atual != alvo:
                        p.nice(alvo)
                    self.alterados.add(p.pid)
                except (psutil.Error, OSError):
                    continue
            for pid in [x for x in self._dono if x not in vistos]:  # programas que fecharam
                self._dono.pop(pid, None)
            self.alterados &= vistos



# ---------------- ajustes do Windows (reversíveis, com backup do valor original) ----------------

try:
    import winreg
except ImportError:  # fora do Windows
    winreg = None


class Registro:
    """Camada fina sobre o registro do Windows (nos testes é trocada por uma versão falsa)."""

    def _raiz(self, nome):
        return winreg.HKEY_CURRENT_USER if nome == "HKCU" else winreg.HKEY_LOCAL_MACHINE

    def _abrir(self, raiz, caminho, acesso):
        return winreg.OpenKey(self._raiz(raiz), caminho, 0, acesso | winreg.KEY_WOW64_64KEY)

    def ler(self, raiz, caminho, nome):
        try:
            with self._abrir(raiz, caminho, winreg.KEY_READ) as chave:
                return winreg.QueryValueEx(chave, nome)[0]
        except OSError:
            return None

    def escrever(self, raiz, caminho, nome, valor, tipo):
        tipos = {"dword": winreg.REG_DWORD, "sz": winreg.REG_SZ, "bin": winreg.REG_BINARY}
        with winreg.CreateKeyEx(self._raiz(raiz), caminho, 0,
                                winreg.KEY_SET_VALUE | winreg.KEY_WOW64_64KEY) as chave:
            winreg.SetValueEx(chave, nome, 0, tipos[tipo], valor)

    def apagar(self, raiz, caminho, nome):
        try:
            with self._abrir(raiz, caminho, winreg.KEY_SET_VALUE) as chave:
                winreg.DeleteValue(chave, nome)
        except OSError:
            pass

    def valores(self, raiz, caminho):
        """Lista de (nome, valor) de uma chave. Vazia se a chave não existe."""
        itens = []
        try:
            with self._abrir(raiz, caminho, winreg.KEY_READ) as chave:
                i = 0
                while True:
                    try:
                        nome, valor, _ = winreg.EnumValue(chave, i)
                    except OSError:
                        break
                    itens.append((nome, valor))
                    i += 1
        except OSError:
            pass
        return itens

    def subchaves(self, raiz, caminho):
        nomes = []
        try:
            with self._abrir(raiz, caminho, winreg.KEY_READ) as chave:
                i = 0
                while True:
                    try:
                        nomes.append(winreg.EnumKey(chave, i))
                    except OSError:
                        break
                    i += 1
        except OSError:
            pass
        return nomes

    def existe(self, raiz, caminho):
        try:
            with self._abrir(raiz, caminho, winreg.KEY_READ):
                return True
        except OSError:
            return False


REG = Registro() if winreg else None
ARQ_BACKUP = os.path.join(pasta_do_programa(), "ajustes_backup.json")
TRAVA_AJ = threading.RLock()
_BACKUP = None


def _backup():
    global _BACKUP
    if _BACKUP is None:
        for arq in (ARQ_BACKUP, ARQ_BACKUP + ".bak"):  # v9.1: arquivo estragado (queda de energia) -> usa a cópia anterior
            try:
                with open(arq, encoding="utf-8") as f:
                    dados = json.load(f)
            except (OSError, ValueError):
                continue
            if isinstance(dados, dict):
                _BACKUP = dados
                break
        if _BACKUP is None:
            _BACKUP = {}
    return _BACKUP


def _guardar_backup():
    """v9.1: grava num temporário e troca de uma vez; a versão anterior fica em .bak."""
    try:
        texto = json.dumps(_BACKUP or {}, ensure_ascii=False, indent=1)
        tmp = ARQ_BACKUP + ".tmp"
        with open(tmp, "w", encoding="utf-8") as f:
            f.write(texto)
            f.flush()
            os.fsync(f.fileno())
        if os.path.isfile(ARQ_BACKUP):
            try:
                shutil.copyfile(ARQ_BACKUP, ARQ_BACKUP + ".bak")
            except OSError:
                pass
        os.replace(tmp, ARQ_BACKUP)
    except (OSError, TypeError, ValueError):
        pass  # sem permissão de escrita: o backup fica só na memória desta execução


def _para_json(valor):
    return {"hex": valor.hex()} if isinstance(valor, (bytes, bytearray)) else valor


def _de_json(valor):
    return bytes.fromhex(valor["hex"]) if isinstance(valor, dict) and "hex" in valor else valor


def powershell(script, tempo=60):
    return executar(["powershell", "-NoProfile", "-NonInteractive", "-ExecutionPolicy", "Bypass",
                     "-Command", script], timeout=tempo)


class Ajuste:
    """Base: um ajuste que se liga e se desfaz. estado(): True ligado, False desligado, None indisponível."""
    precisa_admin = True

    def __init__(self, id, grupo, titulo, desc, risco="baixo", rec=False, nota="", ext=False, sup=False, so_mesa=False, fps=False):
        self.id, self.grupo, self.titulo, self.desc = id, grupo, titulo, desc
        self.risco, self.rec, self.nota = risco, rec, nota
        self.ext = ext  # entra na Otimização Extrema (além dos recomendados)
        self.sup = sup  # entra só na Otimização Suprema (acima da Extrema)
        self.so_mesa = so_mesa  # não é aplicado sozinho em notebook (gasta bateria)
        self.fps = fps  # aparece na lista "Ajustes de FPS" da página Jogos

    def estado(self):
        return None

    def ligar(self):
        raise NotImplementedError

    def desligar(self):
        raise NotImplementedError

    def disponivel(self):
        return REG is not None

    def info(self):
        return {"id": self.id, "grupo": self.grupo, "titulo": self.titulo, "desc": self.desc,
                "risco": self.risco, "rec": self.rec, "ext": self.ext, "sup": self.sup, "fps": self.fps, "nota": self.nota,
                "admin": self.precisa_admin}


class AjusteReg(Ajuste):
    """Valores do registro. Cada item: (raiz, caminho, nome, tipo, valor_ligado, valor_padrao_do_windows)."""

    def __init__(self, id, grupo, titulo, desc, itens, depois=None, ausente_ligado=False, **kw):
        super().__init__(id, grupo, titulo, desc, **kw)
        self.itens = itens
        self.depois = depois
        self.ausente_ligado = ausente_ligado  # v9.1: o Windows já vem com isto ligado quando o valor não existe
        self.precisa_admin = any(i[0] == "HKLM" or (i[0] == "HKCU" and i[1].lower().startswith("software\\policies"))
                                 for i in itens)

    def estado(self):
        if REG is None:
            return None
        for raiz, caminho, nome, tipo, ligado, _ in self.itens:
            atual = REG.ler(raiz, caminho, nome)
            if atual is None and self.ausente_ligado:
                continue
            if atual is None or str(atual) != str(ligado):
                return False
        return True

    def ligar(self):
        with TRAVA_AJ:
            bk = _backup()
            if self.id not in bk and not self.estado():  # guarda como estava antes de mexer
                bk[self.id] = [[r, c, n, t, _para_json(REG.ler(r, c, n))] for r, c, n, t, _, _ in self.itens]
                _guardar_backup()
            for raiz, caminho, nome, tipo, ligado, _ in self.itens:
                REG.escrever(raiz, caminho, nome, ligado, tipo)
        if self.depois:
            self.depois(True)

    def desligar(self):
        with TRAVA_AJ:
            bk = _backup()
            antigos = {(r, c, n): _de_json(v) for r, c, n, t, v in bk.get(self.id, [])}
            tem_backup = self.id in bk
            for raiz, caminho, nome, tipo, _, padrao in self.itens:
                valor = antigos.get((raiz, caminho, nome)) if tem_backup else padrao
                if valor is None:
                    REG.apagar(raiz, caminho, nome)
                else:
                    REG.escrever(raiz, caminho, nome, valor, tipo)
            if tem_backup:
                del bk[self.id]
                _guardar_backup()
        if self.depois:
            self.depois(False)


class AjusteServico(Ajuste):
    """Desliga serviços do Windows (início 'desativado'). Desfazer devolve o tipo de início de antes."""
    CHAVE = r"SYSTEM\CurrentControlSet\Services\%s"

    def __init__(self, id, grupo, titulo, desc, servicos, padroes=None, **kw):
        self.legado = kw.pop("legado", False)
        super().__init__(id, grupo, titulo, desc, **kw)
        self.servicos = servicos if isinstance(servicos, (list, tuple)) else [servicos]
        self.padroes = padroes or {}  # início padrão do Windows por serviço: (tipo, atrasado). Se faltar: manual

    def _existentes(self):
        return [s for s in self.servicos if REG is not None and REG.existe("HKLM", self.CHAVE % s)]

    def disponivel(self):
        if getattr(self, "legado", False):  # v9.1: ajuste antigo: só aparece se estiver ligado, para dar para desfazer
            return bool(self._existentes()) and self.estado() is True
        return bool(self._existentes())

    def estado(self):
        lista = self._existentes()
        if not lista:
            return None
        return all(REG.ler("HKLM", self.CHAVE % s, "Start") == 4 for s in lista)

    def rodando(self):
        """Serviços deste ajuste que estão rodando agora (desligar o início não para quem já está rodando)."""
        res = []
        for s in self._existentes():
            try:
                if psutil.win_service_get(s).status() == "running":
                    res.append(s)
            except Exception:
                continue
        return res

    def parar_agora(self):
        """Para os serviços que seguem rodando. Devolve quantos o Windows aceitou parar."""
        n = 0
        for s in self.rodando():
            cod, _ = executar(["sc", "stop", s])
            n += 1 if cod == 0 else 0
        return n

    def ligar(self):
        with TRAVA_AJ:
            bk = _backup()
            if self.id not in bk and not self.estado():
                bk[self.id] = {s: [REG.ler("HKLM", self.CHAVE % s, "Start"),
                                   REG.ler("HKLM", self.CHAVE % s, "DelayedAutostart")] for s in self._existentes()}
                _guardar_backup()
        recusados = []
        for s in self._existentes():
            cod, _ = executar(["sc", "config", s, "start=", "disabled"])
            if cod != 0 or REG.ler("HKLM", self.CHAVE % s, "Start") != 4:
                try:  # v9.1: serviços por usuário (modelos) só mudam pelo registro
                    REG.escrever("HKLM", self.CHAVE % s, "Start", 4, "dword")
                except OSError:
                    pass
            if REG.ler("HKLM", self.CHAVE % s, "Start") != 4:
                recusados.append(s)
                continue
            executar(["sc", "stop", s])
        if recusados:
            try:
                self.desligar()  # v9.1: tudo ou nada: os que já tinham mudado voltam como eram
            except OSError:
                pass
            raise OSError("o Windows não deixou desligar: " + ", ".join(recusados))

    def desligar(self):
        with TRAVA_AJ:
            bk = _backup()
            antigos = bk.get(self.id, {})
        for s in self._existentes():
            inicio, atrasado = antigos.get(s) or self.padroes.get(s, (3, None))
            if inicio is None:
                inicio, atrasado = self.padroes.get(s, (3, None))
            if inicio == 2:
                modo = "delayed-auto" if atrasado == 1 else "auto"
            elif inicio == 4:
                modo = "disabled"
            else:
                modo = "demand"
            cod, _ = executar(["sc", "config", s, "start=", modo])
            if cod != 0 or REG.ler("HKLM", self.CHAVE % s, "Start") != inicio:
                try:
                    REG.escrever("HKLM", self.CHAVE % s, "Start", inicio, "dword")
                except OSError:
                    pass
            if inicio == 2:
                executar(["sc", "start", s])
        with TRAVA_AJ:
            if self.id in _backup():
                del _backup()[self.id]
                _guardar_backup()


class AjusteHibernacao(Ajuste):
    def estado(self):
        if REG is None:
            return None
        atual = REG.ler("HKLM", r"SYSTEM\CurrentControlSet\Control\Power", "HibernateEnabled")
        return None if atual is None else atual == 0

    def ligar(self):
        executar(["powercfg", "/hibernate", "off"])

    def desligar(self):
        executar(["powercfg", "/hibernate", "on"])


class AjusteNagle(Ajuste):
    """Desliga o algoritmo de Nagle nas placas de rede que estão em uso (menos latência em jogos online)."""
    BASE = r"SYSTEM\CurrentControlSet\Services\Tcpip\Parameters\Interfaces"

    def _em_uso(self):
        usadas = []
        for guid in REG.subchaves("HKLM", self.BASE):
            caminho = self.BASE + "\\" + guid
            for campo in ("DhcpIPAddress", "IPAddress"):
                v = REG.ler("HKLM", caminho, campo)
                lista = v if isinstance(v, (list, tuple)) else [v]
                if any(isinstance(x, str) and x.strip() and not x.startswith("0.0.0.0") for x in lista):
                    usadas.append(caminho)
                    break
        return usadas

    def estado(self):
        if REG is None:
            return None
        placas = self._em_uso()
        if not placas:
            return None
        return all(REG.ler("HKLM", c, "TcpAckFrequency") == 1 and REG.ler("HKLM", c, "TCPNoDelay") == 1
                   for c in placas)

    def ligar(self):
        with TRAVA_AJ:
            bk = _backup()
            antes = bk.setdefault(self.id, {})
            for c in self._em_uso():
                if c not in antes:  # v9.1: guarda o que cada placa tinha, para o desfazer voltar exatamente
                    antes[c] = [REG.ler("HKLM", c, "TcpAckFrequency"), REG.ler("HKLM", c, "TCPNoDelay")]
            _guardar_backup()
        for c in self._em_uso():
            REG.escrever("HKLM", c, "TcpAckFrequency", 1, "dword")
            REG.escrever("HKLM", c, "TCPNoDelay", 1, "dword")

    def desligar(self):
        with TRAVA_AJ:
            antes = _backup().get(self.id)
        if isinstance(antes, dict) and antes:
            for c, valores in antes.items():
                for nome, v in zip(("TcpAckFrequency", "TCPNoDelay"), valores if isinstance(valores, list) else [None, None]):
                    if isinstance(v, int):
                        REG.escrever("HKLM", c, nome, v, "dword")
                    else:
                        REG.apagar("HKLM", c, nome)
        else:  # ligado por uma versão antiga, sem backup
            for c in self._em_uso():
                for nome in ("TcpAckFrequency", "TCPNoDelay"):
                    REG.apagar("HKLM", c, nome)
        with TRAVA_AJ:
            _backup().pop(self.id, None)
            _guardar_backup()


def dx_config_ler(texto):
    """'A=1;B=0;' -> {'A': '1', 'B': '0'} (mantém a ordem). Função pura."""
    res = {}
    for parte in (texto or "").split(";"):
        if "=" in parte:
            k, v = parte.split("=", 1)
            if k.strip():
                res[k.strip()] = v.strip()
    return res


def dx_config_texto(d):
    return "".join(f"{k}={v};" for k, v in d.items())


class AjusteDxJanela(Ajuste):
    """Otimizações para jogos em janela (Windows 11 22H2 ou mais novo). O valor do registro guarda outras opções do
    DirectX juntas (HDR automático, VRR...), então só a parte SwapEffectUpgradeEnable é trocada."""
    precisa_admin = False
    CAMINHO, NOME, CHAVE = r"Software\Microsoft\DirectX\UserGpuPreferences", "DirectXUserGlobalSettings", "SwapEffectUpgradeEnable"

    def disponivel(self):
        if REG is None:
            return False
        try:
            return sys.getwindowsversion().build >= 22621
        except AttributeError:
            return False

    def estado(self):
        if not self.disponivel():
            return None
        return dx_config_ler(REG.ler("HKCU", self.CAMINHO, self.NOME)).get(self.CHAVE) == "1"

    def ligar(self):
        atual = REG.ler("HKCU", self.CAMINHO, self.NOME)
        with TRAVA_AJ:
            bk = _backup()
            if self.id not in bk:
                bk[self.id] = {"antes": dx_config_ler(atual).get(self.CHAVE)}
                _guardar_backup()
        d = dx_config_ler(atual)
        d[self.CHAVE] = "1"
        REG.escrever("HKCU", self.CAMINHO, self.NOME, dx_config_texto(d), "sz")

    def desligar(self):
        with TRAVA_AJ:
            antes = (_backup().get(self.id) or {}).get("antes")
        d = dx_config_ler(REG.ler("HKCU", self.CAMINHO, self.NOME))
        if antes is None:
            d.pop(self.CHAVE, None)
        else:
            d[self.CHAVE] = antes
        REG.escrever("HKCU", self.CAMINHO, self.NOME, dx_config_texto(d), "sz")
        with TRAVA_AJ:
            _backup().pop(self.id, None)
            _guardar_backup()


class AjusteTarefas(Ajuste):
    """Desliga tarefas agendadas de telemetria, que acordam o disco e o processador em segundo plano.
    Perguntar o estado de cada tarefa ao Windows é lento, então o Th Boost lembra quais ele mesmo desligou."""

    def __init__(self, id, grupo, titulo, desc, tarefas, **kw):
        super().__init__(id, grupo, titulo, desc, **kw)
        self.tarefas = tarefas

    def estado(self):
        if REG is None:
            return None
        return bool(_backup().get(self.id))

    def ligar(self):
        feitas = []
        for t in self.tarefas:
            cod, _ = executar(["schtasks", "/Change", "/TN", t, "/Disable"])
            if cod == 0:
                feitas.append(t)
        if feitas:
            with TRAVA_AJ:
                _backup()[self.id] = feitas
                _guardar_backup()

    def desligar(self):
        with TRAVA_AJ:
            feitas = list(_backup().get(self.id) or [])
        for t in feitas:
            executar(["schtasks", "/Change", "/TN", t, "/Enable"])
        with TRAVA_AJ:
            _backup().pop(self.id, None)
            _guardar_backup()


class AjusteMemoriaComprimida(Ajuste):
    """Desliga a compressão de memória do Windows. Só faz sentido com bastante RAM (16 GB ou mais): o processador
    deixa de gastar tempo comprimindo páginas. Como o estado vem do PowerShell (lento), o Th Boost lembra o que ele mesmo mudou."""

    def disponivel(self):
        return REG is not None and psutil.virtual_memory().total >= 15 * 1024 ** 3

    def estado(self):
        if REG is None:
            return None
        return bool(_backup().get(self.id))

    AVISO = ("o Windows precisa do serviço SysMain (Superfetch) ligado para mudar a compressão de memória. "
             "Desfaça o ajuste “Superfetch (SysMain)” e tente de novo.")

    def ligar(self):
        cod, _ = powershell("Start-Service SysMain -ErrorAction SilentlyContinue; Disable-MMAgent -MemoryCompression", tempo=40)
        if cod != 0:
            raise OSError(self.AVISO)
        with TRAVA_AJ:
            _backup()[self.id] = True
            _guardar_backup()

    def desligar(self):
        cod, _ = powershell("Start-Service SysMain -ErrorAction SilentlyContinue; Enable-MMAgent -MemoryCompression", tempo=40)
        if cod != 0:  # v9.1: antes dizia "desfeito" mesmo quando o Windows recusava
            raise OSError(self.AVISO)
        with TRAVA_AJ:
            _backup().pop(self.id, None)
            _guardar_backup()


class AjustePotencia(Ajuste):
    """Uma configuração do plano de energia ativo (powercfg). Ler o estado é rápido: vem direto do registro do plano.
    Padrão do Windows quando ninguém mexeu: valor 1 (ligado) tanto na tomada quanto na bateria."""

    def __init__(self, id, grupo, titulo, desc, subgrupo, config, **kw):
        super().__init__(id, grupo, titulo, desc, **kw)
        self.subgrupo, self.config = subgrupo, config

    def _plano(self):
        g = REG.ler("HKLM", r"SYSTEM\CurrentControlSet\Control\Power\User\PowerSchemes", "ActivePowerScheme")
        return g.lower() if isinstance(g, str) and re.fullmatch(_GUID, g) else None

    def _valores(self, plano):
        base = rf"SYSTEM\CurrentControlSet\Control\Power\User\PowerSchemes\{plano}\{self.subgrupo}\{self.config}"
        return REG.ler("HKLM", base, "ACSettingIndex"), REG.ler("HKLM", base, "DCSettingIndex")

    def estado(self):
        if REG is None:
            return None
        plano = self._plano()
        if not plano:
            return None
        ac, dc = self._valores(plano)
        # em PC de mesa só existe o valor da tomada; em notebook a bateria também precisa estar em 0
        return ac == 0 and (dc == 0 or (dc is None and not tem_bateria()))

    def ligar(self):
        plano = self._plano()
        if not plano:
            return
        with TRAVA_AJ:
            if self.id not in _backup() and not self.estado():  # guarda como estava antes de mexer
                ac, dc = self._valores(plano)
                _backup()[self.id] = {"ac": ac if isinstance(ac, int) else 1, "dc": dc if isinstance(dc, int) else 1}
                _guardar_backup()
        self._definir(0, 0)

    def desligar(self):
        with TRAVA_AJ:
            antes = _backup().pop(self.id, None)
            _guardar_backup()
        ok = lambda v: v if isinstance(v, int) and not isinstance(v, bool) and 0 <= v <= 10 else 1
        self._definir(ok((antes or {}).get("ac")), ok((antes or {}).get("dc")))

    def _definir(self, ac, dc):
        executar(["powercfg", "/setacvalueindex", "SCHEME_CURRENT", self.subgrupo, self.config, str(ac)])
        executar(["powercfg", "/setdcvalueindex", "SCHEME_CURRENT", self.subgrupo, self.config, str(dc)])
        executar(["powercfg", "/setactive", "SCHEME_CURRENT"])


# ---- mouse: aplica na hora, sem precisar sair do Windows ----

def _aplicar_aceleracao(desligada):
    if not IS_WIN:
        return
    try:
        valores = (ctypes.c_int * 3)(*((0, 0, 0) if desligada else (6, 10, 1)))
        ctypes.windll.user32.SystemParametersInfoW.argtypes = [ctypes.c_uint, ctypes.c_uint, ctypes.c_void_p, ctypes.c_uint]
        ctypes.windll.user32.SystemParametersInfoW(0x0004, 0, ctypes.byref(valores), 3)  # SPI_SETMOUSE
    except Exception:
        pass


def _aplicar_teclado(_ligado=None):
    """Aplica na hora o tempo de espera e a velocidade de repetição das teclas, lidos do registro (sem sair do Windows)."""
    if not IS_WIN or REG is None:
        return
    try:
        atraso = max(0, min(3, int(REG.ler("HKCU", r"Control Panel\Keyboard", "KeyboardDelay") or 1)))
        vel = max(0, min(31, int(REG.ler("HKCU", r"Control Panel\Keyboard", "KeyboardSpeed") or 31)))
        fn = ctypes.windll.user32.SystemParametersInfoW
        fn.argtypes = [ctypes.c_uint, ctypes.c_uint, ctypes.c_void_p, ctypes.c_uint]
        fn(0x0017, atraso, None, 3)  # SPI_SETKEYBOARDDELAY
        fn(0x000B, vel, None, 3)  # SPI_SETKEYBOARDSPEED
    except Exception:
        pass


def definir_velocidade_mouse(v):
    """Velocidade do ponteiro de 1 a 20 (10 é o padrão do Windows, o '6/11' do painel)."""
    v = max(1, min(20, int(v)))
    REG.escrever("HKCU", r"Control Panel\Mouse", "MouseSensitivity", str(v), "sz")
    if IS_WIN:
        try:
            ctypes.windll.user32.SystemParametersInfoW.argtypes = [ctypes.c_uint, ctypes.c_uint, ctypes.c_void_p, ctypes.c_uint]
            ctypes.windll.user32.SystemParametersInfoW(0x0071, 0, ctypes.c_void_p(v), 3)  # SPI_SETMOUSESPEED
        except Exception:
            pass
    return v


def velocidade_mouse():
    if REG is None:
        return None
    try:
        return int(REG.ler("HKCU", r"Control Panel\Mouse", "MouseSensitivity") or 10)
    except (TypeError, ValueError):
        return 10


# ---------------- catálogo ----------------

SP = r"SOFTWARE\Microsoft\Windows NT\CurrentVersion\Multimedia\SystemProfile"
CDM = r"Software\Microsoft\Windows\CurrentVersion\ContentDeliveryManager"


def _montar_catalogo():
    c = []
    R = AjusteReg
    # ----- Windows -----
    c += [
        R("game_dvr", "windows", "Gravação em segundo plano desligada",
          "Para a captura automática de vídeo do Windows (Game DVR), que gasta CPU e GPU enquanto você joga.",
          [("HKCU", r"System\GameConfigStore", "GameDVR_Enabled", "dword", 0, 1),
           ("HKCU", r"Software\Microsoft\Windows\CurrentVersion\GameDVR", "AppCaptureEnabled", "dword", 0, 1)], rec=True),
        R("transparencia", "windows", "Transparência desligada",
          "Tira o efeito de vidro do menu e da barra de tarefas. Alivia a placa de vídeo em computadores fracos.",
          [("HKCU", r"Software\Microsoft\Windows\CurrentVersion\Themes\Personalize", "EnableTransparency", "dword", 0, 1)], rec=True),
        R("animacoes", "windows", "Animações de janelas e da barra desligadas",
          "Janelas abrem e fecham na hora, sem efeito de movimento.",
          [("HKCU", r"Control Panel\Desktop\WindowMetrics", "MinAnimate", "sz", "0", "1"),
           ("HKCU", r"Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced", "TaskbarAnimations", "dword", 0, 1)],
          rec=True, nota="Vale ao entrar de novo no Windows."),
        R("menus_rapidos", "windows", "Menus instantâneos",
          "Tira o atraso de meio segundo para abrir os menus.",
          [("HKCU", r"Control Panel\Desktop", "MenuShowDelay", "sz", "0", "400")], rec=True),
        R("prioridade_jogos", "windows", "Prioridade máxima para jogos (MMCSS)",
          "Dá mais prioridade às tarefas que os jogos registram no agendador multimídia do Windows (MMCSS). "
          "Poucos jogos usam isso, então o ganho costuma ser pequeno; não atrapalha.",
          [("HKLM", SP + r"\Tasks\Games", "Priority", "dword", 6, 2),
           ("HKLM", SP + r"\Tasks\Games", "Scheduling Category", "sz", "High", "Medium"),
           ("HKLM", SP + r"\Tasks\Games", "SFIO Priority", "sz", "High", "Normal")], ext=True),
        R("desligar_rapido", "windows", "Desligar o Windows mais rápido",
          "Reduz a espera para fechar programas travados ao desligar ou reiniciar.",
          [("HKCU", r"Control Panel\Desktop", "WaitToKillAppTimeout", "sz", "5000", None),
           ("HKCU", r"Control Panel\Desktop", "HungAppTimeout", "sz", "2000", None)], rec=True),
        R("extensoes", "windows", "Mostrar a extensão dos arquivos",
          "Mostra o .exe, .pdf, .jpg no nome dos arquivos. Ajuda a perceber arquivos disfarçados.",
          [("HKCU", r"Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced", "HideFileExt", "dword", 0, 1)]),
        R("hags", "windows", "Agendamento de GPU por hardware",
          "Deixa a placa de vídeo gerenciar a própria memória. Ajuda em algumas placas e atrapalha em outras.",
          [("HKLM", r"SYSTEM\CurrentControlSet\Control\GraphicsDrivers", "HwSchMode", "dword", 2, 1)],
          risco="medio", nota="Precisa reiniciar o PC."),
        R("efeitos_visuais", "windows", "Efeitos visuais no mínimo",
          "Arrastar janelas sem sombra, seleção sem transição e sem a prévia ao passar o mouse na barra de tarefas. Menos trabalho para o processador e a placa de vídeo.",
          [("HKCU", r"Control Panel\Desktop", "DragFullWindows", "sz", "0", "1"),
           ("HKCU", r"Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced", "ListviewAlphaSelect", "dword", 0, 1),
           ("HKCU", r"Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced", "ListviewShadow", "dword", 0, 1),
           ("HKCU", r"Software\Microsoft\Windows\DWM", "EnableAeroPeek", "dword", 0, 1)],
          ext=True, nota="Vale ao entrar de novo no Windows."),
        R("fundo_apps", "windows", "Apps da Loja parados em segundo plano",
          "Impede que Email, Clima, Notícias e outros apps da Microsoft Store rodem escondidos. Eles só atualizam quando você abre.",
          [("HKCU", r"Software\Microsoft\Windows\CurrentVersion\BackgroundAccessApplications", "GlobalUserDisabled", "dword", 1, 0),
           ("HKCU", r"Software\Microsoft\Windows\CurrentVersion\Search", "BackgroundAppGlobalToggle", "dword", 0, 1)],
          ext=True, nota="Notificações desses apps só chegam com eles abertos."),
        R("inicio_sem_atraso", "windows", "Programas de início sem espera",
          "O Windows espera alguns segundos antes de abrir os programas da inicialização. Isto tira essa espera.",
          [("HKCU", r"Software\Microsoft\Windows\CurrentVersion\Explorer\Serialize", "StartupDelayInMSec", "dword", 0, None)],
          ext=True, nota="Vale ao entrar de novo no Windows."),
        R("desligar_servicos", "windows", "Serviços fecham mais rápido ao desligar",
          "Dá 2 segundos (em vez de 5) para cada serviço terminar quando o PC desliga ou reinicia.",
          [("HKLM", r"SYSTEM\CurrentControlSet\Control", "WaitToKillServiceTimeout", "sz", "2000", None)],
          ext=True, nota="Vale no próximo desligamento."),
        R("ntfs_acesso", "windows", "Disco com menos gravações",
          "O Windows anota a hora em que cada arquivo foi aberto, e isso gera gravações extras no disco o tempo todo. Isto desliga essa anotação.",
          [("HKLM", r"SYSTEM\CurrentControlSet\Control\FileSystem", "NtfsDisableLastAccessUpdate", "dword", 1, 2147483650)],
          ext=True, nota="Vale depois de reiniciar."),
        R("modo_jogo", "windows", "Modo de Jogo do Windows ligado",
          "Pede ao Windows para deixar o jogo em primeiro lugar e adiar atualizações e tarefas enquanto você joga.",
          [("HKCU", r"Software\Microsoft\GameBar", "AllowAutoGameMode", "dword", 1, None),
           ("HKCU", r"Software\Microsoft\GameBar", "AutoGameModeEnabled", "dword", 1, None)], ext=True, ausente_ligado=True,
          nota="O Windows 10 e 11 já vêm com ele ligado; aqui ele aparece desligado só se alguém desligou."),
        R("visual_minimo", "windows", "Visual do Windows no modo desempenho",
          "Liga o “Ajustar para obter o melhor desempenho” do Windows: sem fade de menus, sem rolagem suave e sem sombra no ponteiro. O Windows fica mais seco, porém mais ágil, sobretudo em PCs fracos.",
          [("HKCU", r"Control Panel\Desktop", "UserPreferencesMask", "bin", bytes.fromhex("9012038010000000"), bytes.fromhex("9e3e078012000000"))],
          sup=True, nota="Vale ao entrar de novo no Windows."),
        AjusteMemoriaComprimida("mmagent", "windows", "Compressão de memória desligada",
                                "Com 16 GB de RAM ou mais, o Windows não precisa comprimir a memória, e o processador fica livre para o jogo. Só aparece em PCs com bastante memória.",
                                sup=True, nota="Vale depois de reiniciar o PC."),
        R("widgets", "windows", "Widgets e Chat da barra de tarefas desligados",
          "Tira os Widgets (clima e notícias) e o ícone de Chat, que mantêm processos rodando. Só tem efeito no Windows 11.",
          [("HKCU", r"Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced", "TaskbarDa", "dword", 0, 1),
           ("HKCU", r"Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced", "TaskbarMn", "dword", 0, 1)],
          ext=True, nota="Em algumas versões do Windows 11 o próprio Windows bloqueia esta mudança."),
    ]
    # ----- Energia -----
    c += [
        AjusteHibernacao("hibernacao", "energia", "Hibernação desligada",
                         "Apaga o arquivo de hibernação e libera vários GB no disco. A suspensão continua funcionando."),
        R("inicio_rapido", "energia", "Inicialização rápida do Windows desligada",
          "Faz o desligar ser completo. Resolve lentidão e travamentos que só passam ao reiniciar.",
          [("HKLM", r"SYSTEM\CurrentControlSet\Control\Session Manager\Power", "HiberbootEnabled", "dword", 0, 1)],
          nota="Vale no próximo desligamento."),
    ]
    # ----- Mouse e teclado -----
    c += [
        R("mouse_acel", "mouse", "Aceleração do ponteiro desligada",
          "Tira o 'Aprimorar precisão do ponteiro'. O mouse anda sempre a mesma distância, ideal para mira em jogos.",
          [("HKCU", r"Control Panel\Mouse", "MouseSpeed", "sz", "0", "1"),
           ("HKCU", r"Control Panel\Mouse", "MouseThreshold1", "sz", "0", "6"),
           ("HKCU", r"Control Panel\Mouse", "MouseThreshold2", "sz", "0", "10")],
          depois=lambda ligado: _aplicar_aceleracao(ligado), rec=True),
        R("teclas_aderencia", "mouse", "Avisos de acessibilidade desligados",
          "Acaba com a janelinha de Teclas de Aderência que aparece ao apertar Shift 5 vezes no meio do jogo.",
          [("HKCU", r"Control Panel\Accessibility\StickyKeys", "Flags", "sz", "506", "510"),
           ("HKCU", r"Control Panel\Accessibility\Keyboard Response", "Flags", "sz", "122", "126"),
           ("HKCU", r"Control Panel\Accessibility\ToggleKeys", "Flags", "sz", "58", "62")], rec=True),
        R("teclado_rapido", "mouse", "Repetição de teclas mais rápida",
          "O teclado começa a repetir a letra segurada sem esperar.",
          [("HKCU", r"Control Panel\Keyboard", "KeyboardDelay", "sz", "0", "1")],
          depois=_aplicar_teclado, ext=True, nota="Vale na hora; alguns programas só notam ao abrir de novo."),
        AjustePotencia("mouse_usb", "mouse", "Suspensão seletiva de USB desligada",
                       "O Windows desliga portas USB paradas para economizar energia. Isso pode fazer o mouse (principalmente o sem fio) "
                       "demorar para acordar e perder o primeiro movimento. Desligar a suspensão deixa o mouse sempre pronto.",
                       "2a737441-1930-4402-8d77-b2bebba308a3", "48e6b7a6-50f5-4782-a5d4-53bb8f07e226",
                       nota="Em notebook gasta um pouco mais de bateria."),
    ]
    # ----- Serviços -----
    S = AjusteServico
    c += [
        S("svc_diagtrack", "servicos", "Telemetria (DiagTrack)", "Envia dados de uso para a Microsoft o tempo todo.", "DiagTrack", padroes={"DiagTrack": (2, None)}, rec=True),
        S("svc_dmwappush", "servicos", "Mensagens push da telemetria", "Serviço auxiliar da telemetria.", "dmwappushservice", rec=True),
        S("svc_wersvc", "servicos", "Relatório de erros do Windows", "Prepara e envia relatórios quando um programa fecha com erro.", "WerSvc", rec=True),
        S("svc_mapsbroker", "servicos", "Mapas baixados", "Atualiza mapas offline que quase ninguém usa.", "MapsBroker", padroes={"MapsBroker": (2, 1)}, rec=True),
        S("svc_retaildemo", "servicos", "Modo demonstração de loja", "Só serve para computadores de vitrine.", "RetailDemoService", rec=True),
        S("svc_wmpnetwork", "servicos", "Compartilhamento do Media Player", "Compartilha músicas e vídeos pela rede.", "WMPNetworkSvc", rec=True),
        S("svc_fax", "servicos", "Fax", "Serviço de fax, sem uso hoje em dia.", "Fax", rec=True),
        S("svc_sysmain", "servicos", "Superfetch (SysMain)",
          "Pré-carrega programas na memória. Em SSD quase não ajuda e consome disco e RAM. Em HD mecânico, deixe ligado.", "SysMain", padroes={"SysMain": (2, None)}),
        S("svc_dosvc", "servicos", "Serviço de entrega de atualizações desligado (versão antiga)",
          "Versões antigas do Th Boost desligavam este serviço inteiro, o que pode atrapalhar downloads da Microsoft Store e do Game Pass. "
          "Desfaça aqui; o ajuste novo “Não repassar atualizações para outros PCs” faz isso do jeito certo.",
          "DoSvc", padroes={"DoSvc": (2, 1)}, legado=True),
        S("svc_trkwks", "servicos", "Rastreamento de atalhos (TrkWks)",
          "Procura arquivos que mudaram de lugar na rede para consertar atalhos. Quase ninguém usa.", "TrkWks", padroes={"TrkWks": (2, None)}, ext=True),
        S("svc_pcasvc", "servicos", "Assistente de compatibilidade (PcaSvc)",
          "Monitora programas antigos para sugerir ajustes de compatibilidade. Sem ele, o aviso de 'este programa pode não funcionar' deixa de aparecer.",
          "PcaSvc", padroes={"PcaSvc": (2, None)}, ext=True),
        S("svc_diaghub", "servicos", "Coletor de diagnóstico", "Coleta dados técnicos para ferramentas de diagnóstico do Windows.",
          "diagnosticshub.standardcollector.service", ext=True),
        S("svc_raros", "servicos", "Serviços que quase ninguém usa",
          "Telefone, carteira digital, roteador AllJoyn, pagamentos por aproximação, Windows Insider, registro remoto, descoberta de rede (LLTD) e o painel de relatórios de erro. Nenhum deles faz falta num PC de jogo.",
          ["PhoneSvc", "WalletService", "AJRouter", "SEMgrSvc", "wisvc", "RemoteRegistry", "lltdsvc", "wercplsupport"],
          padroes={"RemoteRegistry": (4, None)}, sup=True),
        S("svc_lfsvc", "servicos", "Localização", "Desliga o serviço de localização do Windows.", "lfsvc"),
        S("svc_wsearch", "servicos", "Pesquisa do Windows (indexação)",
          "Para de indexar os arquivos. Alivia o disco, mas a busca do Iniciar fica mais lenta.", "WSearch", padroes={"WSearch": (2, 1)}, risco="medio"),
        S("svc_spooler", "servicos", "Impressão (Spooler)",
          "Só desligue se você não usa impressora. Ligado de novo, volta a imprimir.", "Spooler", padroes={"Spooler": (2, None)}, risco="medio"),
        S("svc_tablet", "servicos", "Teclado de toque e caneta",
          "Desliga o teclado virtual e a caneta. Junto param também o histórico da área de transferência (Win+V), o painel de "
          "emojis (Win+.) e a digitação por voz. Não use em tablets e notebooks com tela de toque.", "TabletInputService", risco="medio"),
        S("svc_xbox", "servicos", "Serviços do Xbox",
          "Quebra o login do Xbox e do Game Pass e o salvamento na nuvem de alguns jogos. Só desligue se não usa.",
          ["XblAuthManager", "XblGameSave", "XboxNetApiSvc", "XboxGipSvc"], risco="medio"),
        S("svc_usuario", "servicos", "Serviços por usuário (contas, contatos e sincronização)",
          "O Windows cria uma cópia de vários serviços para cada usuário (sincronização de contas, contatos, mensagens e dispositivos conectados), e cada cópia vira um processo. Desligados, o app Email e Calendário do Windows deixa de sincronizar sozinho, e param também o Vincular ao Celular, o Compartilhamento por Proximidade e a gravação de clipes pela Game Bar.",
          ["OneSyncSvc", "CDPUserSvc", "CDPSvc", "UnistoreSvc", "UserDataSvc", "PimIndexMaintenanceSvc", "MessagingService", "BcastDVRUserService"],
          padroes={"OneSyncSvc": (2, None), "CDPUserSvc": (2, None), "CDPSvc": (2, None)}, sup=True,
          nota="Os processos por usuário só somem depois de reiniciar o PC."),
        S("svc_ssdp", "servicos", "Descoberta de aparelhos na rede (SSDP e UPnP)",
          "Faz o PC procurar e anunciar TVs, caixas de som e impressoras na rede. Desligado, a internet funciona igual; só deixa de aparecer para aparelhos que usam DLNA ou UPnP.",
          ["SSDPSRV", "upnphost"], sup=True),
        S("svc_bluetooth", "servicos", "Bluetooth",
          "Só desligue se não usa fone, mouse, teclado ou controle por Bluetooth. Ligado de novo, volta a funcionar.", ["bthserv", "BthAvctpSvc"], risco="medio"),
        S("svc_biometria", "servicos", "Impressão digital e reconhecimento facial (Windows Hello)",
          "Só desligue se não entra no Windows com digital ou rosto.", "WbioSrvc", risco="medio"),
        S("svc_server", "servicos", "Compartilhamento de pastas com a rede (Servidor)",
          "Só desligue se você não compartilha pastas nem impressoras com outros computadores. Os acessos que você faz a outros PCs continuam funcionando.",
          "LanmanServer", padroes={"LanmanServer": (2, None)}, risco="medio"),
        R("svc_juntar", "servicos", "Juntar os serviços do Windows em menos processos",
          "Desde o Windows 10 cada serviço roda em um processo svchost separado quando o PC tem mais de 3,5 GB de memória. Isto volta ao método antigo, com vários serviços por processo: a lista de processos fica bem menor. O ganho de memória é pequeno, e se um serviço travar pode derrubar os que dividem o processo com ele.",
          [("HKLM", r"SYSTEM\CurrentControlSet\Control", "SvcHostSplitThresholdInKB", "dword", 268435456, 3670016)],
          risco="medio", nota="Precisa reiniciar o PC. Dá para desfazer aqui."),
    ]
    # ----- Privacidade -----
    DC = r"SOFTWARE\Policies\Microsoft\Windows\DataCollection"
    cdm = [("HKCU", CDM, n, "dword", 0, 1) for n in (
        "SubscribedContent-338388Enabled", "SubscribedContent-338389Enabled", "SubscribedContent-353694Enabled",
        "SubscribedContent-353696Enabled", "SubscribedContent-310093Enabled", "SubscribedContent-338393Enabled",
        "SilentInstalledAppsEnabled", "SystemPaneSuggestionsEnabled", "SoftLandingEnabled")]
    c += [
        R("p_telemetria", "privacidade", "Telemetria no mínimo",
          "Pede ao Windows para enviar o mínimo de dados à Microsoft. No Windows Home o mínimo possível ainda é enviado.",
          [("HKLM", DC, "AllowTelemetry", "dword", 0, None)], rec=True),
        R("p_anuncio_id", "privacidade", "ID de publicidade desligado",
          "Impede que os apps usem um número seu para mostrar anúncios personalizados.",
          [("HKCU", r"Software\Microsoft\Windows\CurrentVersion\AdvertisingInfo", "Enabled", "dword", 0, 1)], rec=True),
        R("p_historico", "privacidade", "Histórico de atividades desligado",
          "Para de guardar e enviar o histórico do que você abre e faz no computador.",
          [("HKLM", r"SOFTWARE\Policies\Microsoft\Windows\System", "EnableActivityFeed", "dword", 0, None),
           ("HKLM", r"SOFTWARE\Policies\Microsoft\Windows\System", "PublishUserActivities", "dword", 0, None),
           ("HKLM", r"SOFTWARE\Policies\Microsoft\Windows\System", "UploadUserActivities", "dword", 0, None)], rec=True),
        R("p_sugestoes", "privacidade", "Sugestões e anúncios no Windows desligados",
          "Tira as dicas, os anúncios no menu Iniciar e a instalação silenciosa de apps patrocinados.",
          cdm, rec=True),
        R("p_pesquisa_web", "privacidade", "Pesquisa da web no Iniciar desligada",
          "A busca do Iniciar procura só no seu computador, sem mandar o que você digita para a internet.",
          [("HKCU", r"Software\Microsoft\Windows\CurrentVersion\Search", "BingSearchEnabled", "dword", 0, 1),
           ("HKCU", r"Software\Policies\Microsoft\Windows\Explorer", "DisableSearchBoxSuggestions", "dword", 1, None)], rec=True),
        R("p_erros", "privacidade", "Relatório de erros desligado",
          "Não envia à Microsoft o relatório quando um programa trava.",
          [("HKLM", r"SOFTWARE\Microsoft\Windows\Windows Error Reporting", "Disabled", "dword", 1, None)], rec=True),
        R("p_feedback", "privacidade", "Pedidos de feedback desligados",
          "Para de perguntar o que você achou do Windows.",
          [("HKCU", r"Software\Microsoft\Siuf\Rules", "NumberOfSIUFInPeriod", "dword", 0, None)], rec=True),
        AjusteTarefas("p_tarefas", "privacidade", "Tarefas de telemetria desligadas",
                      "Desliga as tarefas agendadas que analisam seu PC em segundo plano e enviam dados (como o CompatTelRunner, que costuma pesar no disco e no processador).",
                      [r"\Microsoft\Windows\Application Experience\Microsoft Compatibility Appraiser",
                       r"\Microsoft\Windows\Application Experience\ProgramDataUpdater",
                       r"\Microsoft\Windows\Customer Experience Improvement Program\Consolidator",
                       r"\Microsoft\Windows\Customer Experience Improvement Program\UsbCeip",
                       r"\Microsoft\Windows\DiskDiagnostic\Microsoft-Windows-DiskDiagnosticDataCollector",
                       r"\Microsoft\Windows\Feedback\Siuf\DmClient",
                       r"\Microsoft\Windows\Feedback\Siuf\DmClientOnScenarioDownload"], ext=True),
        R("p_localizacao", "privacidade", "Localização do sistema desligada",
          "Nenhum app descobre onde você está. Mapas e clima deixam de se ajustar sozinhos.",
          [("HKLM", r"SOFTWARE\Microsoft\Windows\CurrentVersion\CapabilityAccessManager\ConsentStore\location",
            "Value", "sz", "Deny", "Allow")]),
        R("p_copilot", "privacidade", "Copilot desligado",
          "Esconde o assistente Copilot do Windows. Em algumas versões novas pode não ter efeito.",
          [("HKCU", r"Software\Policies\Microsoft\Windows\WindowsCopilot", "TurnOffWindowsCopilot", "dword", 1, None)]),
    ]
    # ----- Jogos (FPS) -----
    c += [
        R("fps_dvr_politica", "jogos", "Captura de tela do Windows bloqueada",
          "Além de desligar a gravação em segundo plano, bloqueia por regra do Windows o Game DVR. Nenhum programa liga ele sozinho de novo.",
          [("HKLM", r"SOFTWARE\Policies\Microsoft\Windows\GameDVR", "AllowGameDVR", "dword", 0, None)], rec=True, fps=True),
        R("fps_gamebar", "jogos", "Game Bar fora do caminho",
          "Tira o painel de boas-vindas e a integração do controle com a Game Bar do Xbox, que abrem janelas no meio do jogo.",
          [("HKCU", r"Software\Microsoft\GameBar", "UseNexusForGameBarEnabled", "dword", 0, None),
           ("HKCU", r"Software\Microsoft\GameBar", "ShowStartupPanel", "dword", 0, None)], rec=True, fps=True),
        R("fps_energia_throttle", "jogos", "Sem economia de energia nos programas",
          "O Windows reduz a velocidade de programas que ele julga “em segundo plano”. Isto desliga essa freada, o que ajuda quem joga e grava ou transmite ao mesmo tempo.",
          [("HKLM", r"SYSTEM\CurrentControlSet\Control\Power\PowerThrottling", "PowerThrottlingOff", "dword", 1, None)],
          sup=True, so_mesa=True, fps=True, nota="Em notebook gasta mais bateria. Vale depois de reiniciar."),
        AjusteDxJanela("fps_janela", "jogos", "Otimizações para jogos em janela",
                       "Recurso do próprio Windows 11: jogos em janela ou em janela sem bordas (DirectX 10 e 11) passam a usar o mesmo "
                       "caminho rápido da tela cheia. Menos atraso, e o G-Sync/FreeSync funciona também em janela.",
                       rec=True, fps=True, nota="Vale ao abrir o jogo de novo. Só aparece no Windows 11."),
        R("fps_vbs", "jogos", "Isolamento de núcleo (VBS) desligado",
          "O Windows roda uma camada de segurança por virtualização que pode custar de 5% a 10% de FPS em alguns jogos. Desligar devolve esse desempenho, mas reduz a proteção do Windows contra certos ataques.",
          [("HKLM", r"SYSTEM\CurrentControlSet\Control\DeviceGuard\Scenarios\HypervisorEnforcedCodeIntegrity", "Enabled", "dword", 0, None)],
          risco="medio", fps=True, nota="Só use em PC de jogo. Precisa reiniciar. Dá para desfazer aqui."),
    ]
    # ----- Rede -----
    c += [
        R("do_p2p", "rede", "Não repassar atualizações para outros PCs",
          "O Windows usa a sua internet para enviar pedaços de atualizações a outros computadores (Otimização de Entrega). "
          "Isto desliga só o repasse, pela regra oficial do Windows: as suas atualizações, a Microsoft Store e o Game Pass continuam baixando normalmente.",
          [("HKLM", r"SOFTWARE\Policies\Microsoft\Windows\DeliveryOptimization", "DODownloadMode", "dword", 0, None)], rec=True),
        R("rede_throttle", "rede", "Sem limite de rede para multimídia",
          "Tira o limite que o Windows coloca na rede enquanto toca áudio ou vídeo. Só muda algo em downloads muito rápidos com música tocando; "
          "não melhora o ping.",
          [("HKLM", SP, "NetworkThrottlingIndex", "dword", 0xFFFFFFFF, 10),
           ("HKLM", SP, "SystemResponsiveness", "dword", 0, 20)], ext=True),
        AjusteNagle("rede_nagle", "rede", "Sem atraso de confirmação no TCP (Nagle)",
                    "Faz o Windows confirmar pacotes TCP na hora. Só ajuda em jogos que usam TCP (alguns MMOs e jogos antigos); "
                    "a maioria dos jogos online usa UDP e o ping não muda.", ext=True),
    ]
    return c


CATALOGO = _montar_catalogo()
POR_ID = {a.id: a for a in CATALOGO}


def catalogo_publico():
    """Lista que a tela recebe. Serviços que não existem neste Windows ficam de fora."""
    return [a.info() for a in CATALOGO if a.disponivel() or REG is None]


def estados_ajustes():
    res = {}
    for a in CATALOGO:
        try:
            res[a.id] = a.estado()
        except Exception:
            res[a.id] = None
    return res


_RESTAURACAO = {"feita": False, "falhou": 0.0}


def ponto_restauracao():
    """Cria um ponto de restauração do Windows (um por execução basta). True = existe um ponto desta execução.
    v9.1: levanta o limite de 1 ponto por dia durante a criação e só se dá por feito quando o Windows criou mesmo."""
    if not IS_WIN:
        return False
    if _RESTAURACAO["feita"]:
        return True
    if time.time() - _RESTAURACAO["falhou"] < 600:  # falhou há pouco (Proteção do Sistema desligada): não espera de novo
        return False
    ok, _ = criar_ponto_manual("Th Boost")
    if ok:
        _RESTAURACAO["feita"] = True
    else:
        _RESTAURACAO["falhou"] = time.time()
    return ok


# ---------------- planos de energia ----------------

PLANOS_CONHECIDOS = {
    "equilibrado": ("381b4222-f694-41f0-9685-ff5bb260df2e", "Equilibrado"),
    "alto": ("8c5e7fda-e8bf-4a96-9a85-a6e23a8c635c", "Alto desempenho"),
    "economia": ("a1841308-3541-4fab-bc81-f71556f20b4a", "Economia de energia"),
    "maximo": ("e9a42b02-d5df-448d-aa00-03f14749eb61", "Desempenho máximo"),
}
_GUID = r"[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}"


def listar_planos():
    cod, saida = executar(["powercfg", "/list"])
    planos = []
    if cod == 0:
        for linha in saida.splitlines():
            m = re.search(rf"({_GUID})\s+\(([^)]*)\)\s*(\*)?", linha)
            if m:
                planos.append({"guid": m.group(1).lower(), "nome": m.group(2).strip(), "ativo": bool(m.group(3))})
    return planos


def plano_existente(chave, planos=None):
    """Acha o plano pelo código padrão, pelo código que o Th Boost criou antes ou pelo nome (o Windows copia o nome do modelo)."""
    planos = listar_planos() if planos is None else planos
    guid, nome = PLANOS_CONHECIDOS[chave]
    por_guid = {p["guid"]: p for p in planos}
    criado = (_backup().get("_planos") or {}).get(chave)
    for g in (guid, criado):
        if g and g in por_guid:
            return por_guid[g]
    for p in planos:
        if p["nome"].strip().lower() == nome.lower():
            return p
    return None


def ativar_plano(chave):
    """Ativa um plano pelo nome conhecido. Se o Windows não tiver o plano, cria uma cópia a partir do modelo (uma vez só)."""
    if chave not in PLANOS_CONHECIDOS:
        return "Plano desconhecido."
    guid, nome = PLANOS_CONHECIDOS[chave]
    achado = plano_existente(chave)
    if achado:
        guid = achado["guid"]
    else:
        cod, saida = executar(["powercfg", "-duplicatescheme", guid])
        m = re.search(_GUID, saida or "")
        if cod != 0 or not m:
            return f"Este computador não tem o plano {nome} e não foi possível criá-lo."
        guid = m.group(0).lower()
        with TRAVA_AJ:
            _backup().setdefault("_planos", {})[chave] = guid
            _guardar_backup()
    cod, _ = executar(["powercfg", "/setactive", guid])
    return f"Plano {nome} ativado." if cod == 0 else "Não foi possível trocar o plano (abra como Administrador)."


# ---------------- DNS ----------------

DNS_OPCOES = {"google": ("8.8.8.8", "8.8.4.4"), "cloudflare": ("1.1.1.1", "1.0.0.1")}
DNS_OPCOES_V6 = {"google": ("2001:4860:4860::8888", "2001:4860:4860::8844"),
                 "cloudflare": ("2606:4700:4700::1111", "2606:4700:4700::1001")}
_PS_REDE_ATIVA = ("Get-NetIPConfiguration | Where-Object { $_.IPv4DefaultGateway -ne $null -and "
                  "$_.NetAdapter.Status -eq 'Up' } | Select-Object -First 1")  # v9.1: lê e muda sempre a mesma placa
_RX_IPV4 = r"\d{1,3}(?:\.\d{1,3}){3}"


def dns_interpretar(saida):
    """Uma linha 'servidores|servidores fixos no registro|dhcp' por placa -> {'modo', 'servidores', 'dhcp'}. Função pura.
    Sem servidores fixos no registro = o DNS vem do roteador (automático)."""
    linha = next((l for l in (saida or "").splitlines() if "|" in l), "")
    partes = (linha.split("|") + ["", "", ""])[:3]
    servidores = re.findall(_RX_IPV4, partes[0])
    fixos = re.findall(_RX_IPV4, partes[1])
    dhcp = partes[2].strip().lower() in ("enabled", "true", "1")
    modo = "outro"
    for nome, par in DNS_OPCOES.items():
        if servidores[:2] == list(par):
            modo = nome
    if modo == "outro" and not fixos and dhcp:
        modo = "auto"
    return {"modo": modo, "servidores": servidores[:2], "dhcp": dhcp, "fixos": fixos[:4]}


def dns_atual():
    script = (_PS_REDE_ATIVA + " | ForEach-Object { "
              "$s = ($_.DNSServer | Where-Object { $_.AddressFamily -eq 2 } | ForEach-Object { $_.ServerAddresses }) -join ','; "
              "$p = 'HKLM:\\SYSTEM\\CurrentControlSet\\Services\\Tcpip\\Parameters\\Interfaces\\' + $_.NetAdapter.InterfaceGuid; "
              "$f = (Get-ItemProperty -Path $p -Name NameServer -ErrorAction SilentlyContinue).NameServer; "
              "$d = (Get-NetIPInterface -InterfaceIndex $_.InterfaceIndex -AddressFamily IPv4 -ErrorAction SilentlyContinue).Dhcp; "
              "\"$s|$f|$d\" }")
    cod, saida = powershell(script, tempo=30)
    info = dns_interpretar(saida if cod == 0 else "")
    with TRAVA_AJ:
        antes = _backup().get("_dns_antes")
    if isinstance(antes, dict) and antes.get("fixos") and info["modo"] in ("google", "cloudflare"):
        info["antes"] = antes["fixos"][:2]  # dá para voltar ao DNS que você usava (por exemplo um filtro da família)
    return info


def dns_trocar(modo):
    if modo not in ("auto", "antes") and modo not in DNS_OPCOES:
        return "Opção de DNS desconhecida."
    info = dns_atual()
    if modo in DNS_OPCOES and info["modo"] not in DNS_OPCOES:
        with TRAVA_AJ:  # v9.1: guarda o DNS de antes (uma vez), para dar para voltar
            bk = _backup()
            if "_dns_antes" not in bk:
                bk["_dns_antes"] = {"fixos": info["fixos"], "auto": info["modo"] == "auto"}
                _guardar_backup()
    if modo == "antes":
        with TRAVA_AJ:
            antes = _backup().get("_dns_antes") or {}
        fixos = [x for x in antes.get("fixos") or [] if re.fullmatch(_RX_IPV4, x)]
        if not fixos:
            modo = "auto"
        else:
            cod, _ = powershell(_PS_REDE_ATIVA + " | ForEach-Object { Set-DnsClientServerAddress -InterfaceIndex $_.InterfaceIndex "
                                "-ResetServerAddresses; Set-DnsClientServerAddress -InterfaceIndex $_.InterfaceIndex "
                                "-ServerAddresses (" + ",".join(f"'{x}'" for x in fixos[:4]) + ") }", tempo=40)
            executar(["ipconfig", "/flushdns"])
            if cod == 0:
                with TRAVA_AJ:
                    _backup().pop("_dns_antes", None)
                    _guardar_backup()
                return "DNS de antes de volta (" + ", ".join(fixos[:2]) + ")."
            return "Não foi possível trocar o DNS (abra como Administrador)."
    if modo == "auto":
        if not info["dhcp"] and info["servidores"]:
            return ("Este PC usa IP fixo: no automático ele ficaria sem DNS e sem internet. "
                    "Escolha Google ou Cloudflare, ou mude o IP para automático nas configurações de rede do Windows.")
        acao = "-ResetServerAddresses"
        acao6 = None
    else:
        acao = "-ServerAddresses ('%s','%s')" % DNS_OPCOES[modo]
        acao6 = "-ServerAddresses ('%s','%s','%s','%s')" % (DNS_OPCOES[modo] + DNS_OPCOES_V6[modo])
    cod, _ = powershell(_PS_REDE_ATIVA + " | ForEach-Object { Set-DnsClientServerAddress -InterfaceIndex $_.InterfaceIndex "
                        + acao + " }", tempo=40)
    if cod == 0 and acao6:  # também o IPv6, senão o DNS do provedor continua valendo por ele (sem IPv6, só ignora)
        powershell(_PS_REDE_ATIVA + " | ForEach-Object { Set-DnsClientServerAddress -InterfaceIndex $_.InterfaceIndex "
                   + acao6 + " -ErrorAction SilentlyContinue }", tempo=40)
    executar(["ipconfig", "/flushdns"])
    if cod == 0 and modo == "auto":
        with TRAVA_AJ:
            _backup().pop("_dns_antes", None)
            _guardar_backup()
    nomes = {"auto": "automático", "google": "Google (8.8.8.8)", "cloudflare": "Cloudflare (1.1.1.1)"}
    return f"DNS: {nomes[modo]}." if cod == 0 else "Não foi possível trocar o DNS (abra como Administrador)."


def resetar_rede():
    """Devolve (texto, precisa_reiniciar). v9.1: o 'netsh int ip reset' costuma dar 'acesso negado' em uma chave mesmo como
    Administrador, mas o resto é feito; com o winsock resetado, basta reiniciar."""
    if not e_admin():
        return "Resetar a rede precisa de Administrador. Abra o Th Boost pelo atalho.", False
    a, _ = executar(["netsh", "winsock", "reset"], timeout=40)
    b, _ = executar(["netsh", "int", "ip", "reset"], timeout=40)
    if a == 0 and b == 0:
        return "Rede reiniciada. Reinicie o computador para terminar.", True
    if a == 0 or b == 0:
        return "Rede reiniciada (uma parte o Windows protege, isso é normal). Reinicie o computador para terminar.", True
    return "O Windows não deixou resetar a rede agora.", False


# ---------------- programas que abrem com o Windows ----------------

_RUN = r"Software\Microsoft\Windows\CurrentVersion\Run"
_APROVADO = r"Software\Microsoft\Windows\CurrentVersion\Explorer\StartupApproved"
FONTES_INICIO = [
    ("HKCU", _RUN, "HKCU", _APROVADO + r"\Run", "Usuário"),
    ("HKLM", _RUN, "HKLM", _APROVADO + r"\Run", "Todos os usuários"),
    ("HKLM", r"SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Run", "HKLM", _APROVADO + r"\Run32", "Todos (32 bits)"),
    # v9.1: atalhos na pasta Inicializar (o Gerenciador de Tarefas usa estas mesmas marcas para ligar/desligar)
    ("PASTA", r"%APPDATA%\Microsoft\Windows\Start Menu\Programs\Startup", "HKCU", _APROVADO + r"\StartupFolder", "Pasta Inicializar"),
    ("PASTA", r"%ProgramData%\Microsoft\Windows\Start Menu\Programs\StartUp", "HKLM", _APROVADO + r"\StartupFolder",
     "Pasta Inicializar (todos)"),
]


def _itens_pasta_inicio(caminho):
    pasta = os.path.expandvars(caminho)
    try:
        nomes = os.listdir(pasta)
    except OSError:
        return []
    return [(n, os.path.join(pasta, n)) for n in nomes
            if not n.lower().startswith("desktop.ini") and os.path.isfile(os.path.join(pasta, n))]


def listar_inicio():
    itens = []
    if REG is None:
        return itens
    for n, (raiz, caminho, raiz_ap, caminho_ap, origem) in enumerate(FONTES_INICIO):
        aprovados = {n_.lower(): v for n_, v in REG.valores(raiz_ap, caminho_ap)}
        fonte = _itens_pasta_inicio(caminho) if raiz == "PASTA" else REG.valores(raiz, caminho)
        for nome, comando in fonte:
            if not isinstance(comando, str):
                continue
            marca = aprovados.get(nome.lower())
            desligado = bool(marca and isinstance(marca, (bytes, bytearray)) and len(marca) > 0 and marca[0] & 1)
            itens.append({"id": f"{n}|{nome}", "nome": nome, "comando": comando[:160], "origem": origem,
                          "ligado": not desligado})
    return sorted(itens, key=lambda i: i["nome"].lower())


def definir_inicio(id, ligar):
    existentes = {i["id"]: i for i in listar_inicio()}
    if id not in existentes:
        return "Programa não encontrado."
    n, nome = id.split("|", 1)
    raiz, caminho, raiz_ap, caminho_ap, _ = FONTES_INICIO[int(n)]
    if ligar:
        marca = b"\x02" + b"\x00" * 11
    else:
        agora = int((time.time() + 11644473600) * 10_000_000)  # hora atual no formato FILETIME do Windows
        marca = b"\x03\x00\x00\x00" + agora.to_bytes(8, "little")
    REG.escrever(raiz_ap, caminho_ap, nome, marca, "bin")
    return f"{nome}: {'vai abrir' if ligar else 'não abre mais'} com o Windows."


# ---------------- remover apps que vêm com o Windows ----------------

APPS = [
    ("Microsoft.BingNews", "Notícias", "baixo"), ("Microsoft.BingWeather", "Clima", "baixo"),
    ("Microsoft.GetHelp", "Obter Ajuda", "baixo"), ("Microsoft.Getstarted", "Dicas", "baixo"),
    ("Microsoft.MicrosoftOfficeHub", "Atalho do Office", "baixo"),
    ("Microsoft.MicrosoftSolitaireCollection", "Paciência (Solitaire)", "baixo"),
    ("Microsoft.People", "Pessoas", "baixo"), ("Microsoft.WindowsFeedbackHub", "Central de Comentários", "baixo"),
    ("Microsoft.YourPhone", "Vincular ao Celular", "baixo"), ("Microsoft.ZuneVideo", "Filmes e TV", "baixo"),
    ("Microsoft.SkypeApp", "Skype", "baixo"), ("Microsoft.MixedReality.Portal", "Realidade Mista", "baixo"),
    ("Microsoft.Microsoft3DViewer", "Visualizador 3D", "baixo"), ("Microsoft.Print3D", "Imprimir 3D", "baixo"),
    ("Clipchamp.Clipchamp", "Clipchamp", "baixo"), ("Microsoft.Todos", "Microsoft To Do", "medio"),
    ("Microsoft.PowerAutomateDesktop", "Power Automate", "baixo"), ("MicrosoftTeams", "Teams (versão pessoal)", "baixo"),
    ("Microsoft.549981C3F5F10", "Cortana", "baixo"), ("Microsoft.ZuneMusic", "Media Player / Groove", "medio"),
    ("king.com.CandyCrushSaga", "Candy Crush Saga", "baixo"), ("king.com.CandyCrushSodaSaga", "Candy Crush Soda", "baixo"),
    # v9.1: estes podem ter sido instalados por você (com downloads e login dentro): só saem se você marcar um por um
    ("SpotifyAB.SpotifyMusic", "Spotify", "medio"), ("BytedancePte.Ltd.TikTok", "TikTok", "medio"),
    ("Disney.37853FC22B2CE", "Disney+", "medio"), ("4DF9E0F8.Netflix", "Netflix", "medio"),
    ("Facebook.Facebook", "Facebook", "medio"), ("Facebook.InstagramBeta", "Instagram", "medio"),
    ("AmazonVideo.PrimeVideo", "Prime Video", "medio"),
    ("Microsoft.XboxApp", "Xbox (app antigo)", "medio"), ("Microsoft.GamingApp", "Xbox (Game Pass)", "medio"),
    ("Microsoft.XboxGamingOverlay", "Xbox Game Bar", "medio"),
]
APPS_POR_NOME = {a[0]: a for a in APPS}


def listar_apps_info():
    """Apps da lista segura que estão instalados. Devolve (lista, erro). v9.1: antes um erro parecia 'Windows já limpo'."""
    if not IS_WIN:
        return [], ""
    todos = e_admin()
    cod, saida = powershell("Get-AppxPackage" + (" -AllUsers" if todos else "") + " | Select-Object -ExpandProperty Name", tempo=90)
    if cod != 0:
        return [], "O Windows não respondeu a lista de apps agora. Tente de novo em alguns segundos."
    instalados = {linha.strip() for linha in saida.splitlines()}
    lista = [{"nome": n, "titulo": t, "risco": r} for n, t, r in APPS if n in instalados]
    return lista, ("" if todos else "Mostrando só os apps da sua conta. Para remover, abra o Th Boost como Administrador.")


def listar_apps():
    return listar_apps_info()[0]


def remover_apps(nomes):
    """Remove só apps da lista segura. Devolve a quantidade removida."""
    feitos = 0
    for nome in nomes:
        if nome not in APPS_POR_NOME:
            continue
        cod, _ = powershell(f"Get-AppxPackage -AllUsers -Name '{nome}' | Remove-AppxPackage -AllUsers", tempo=180)
        feitos += 1 if cod == 0 else 0
    return feitos


# ---------------- limpeza profunda e Otimização Extrema ----------------
#
# Regras que valem para tudo daqui:
#  - só se apaga o CONTEÚDO de pastas de cache e de lixo conhecidas (nunca a pasta em si, nunca documentos);
#  - atalhos e junções do Windows nunca são seguidos (assim nada fora da pasta é tocado);
#  - cookies, senhas, históricos e downloads dos navegadores não são mexidos: só o cache;
#  - cada ajuste guarda o valor original (ajustes_backup.json) e o que a Otimização Extrema fez fica em
#    extremo_estado.json, para o botão "Desfazer tudo".

ARQ_EXTREMO = os.path.join(pasta_do_programa(), "extremo_estado.json")
NOME_PLANO_EXT = "Th Boost Extremo"
NOME_PLANO_SUP = "Th Boost Suprema"
TRAVA_EXT = threading.RLock()
_EXT_MEM = {}


def tam_texto(b):
    mb = b / 1048576
    if mb >= 1024:
        return f"{mb / 1024:.1f} GB".replace(".", ",")
    if mb >= 1:
        return f"{mb:.0f} MB"
    return f"{b / 1024:.0f} KB" if b >= 1024 else "0 MB"


# ---------- caminhos e apagador seguro ----------

_VARS_PROIBIDAS = ("USERPROFILE", "APPDATA", "LOCALAPPDATA", "PROGRAMDATA", "SYSTEMROOT", "WINDIR", "PROGRAMFILES",
                   "PROGRAMFILES(X86)", "SYSTEMDRIVE", "HOMEDRIVE", "PUBLIC", "ALLUSERSPROFILE", "HOME")
_NOMES_PROIBIDOS = {"users", "windows", "program files", "program files (x86)", "programdata", "system32", "usr", "etc",
                    "bin", "home", "var", "root"}


def _env(nome):
    v = os.environ.get(nome, "").strip()
    return v if v and os.path.isabs(v) else ""


def _junta(base, *partes):
    return os.path.join(base, *partes) if base else ""


def _norm(p):
    return os.path.normcase(os.path.normpath(p))


def _caminho_seguro(p):
    """Recusa raízes de unidade e pastas inteiras do sistema ou do usuário: só pastas específicas."""
    if not p or not os.path.isabs(p):
        return False
    n = _norm(p)
    partes = [x for x in re.split(r"[\\/]+", n) if x]
    if len(partes) < 2 or (len(partes) == 2 and partes[1] in _NOMES_PROIBIDOS):
        return False
    for v in _VARS_PROIBIDAS:
        x = os.environ.get(v)
        if x and _norm(x) == n:
            return False
    return True


def _atributo_ligacao(st):
    """Junção ou atalho simbólico do Windows (FILE_ATTRIBUTE_REPARSE_POINT)."""
    return bool(getattr(st, "st_file_attributes", 0) & 0x400)


def _e_ligacao(caminho):
    try:
        return os.path.islink(caminho) or _atributo_ligacao(os.lstat(caminho))
    except OSError:
        return True  # na dúvida, não mexe


def _remover_arquivo(caminho):
    try:
        os.remove(caminho)
        return True
    except PermissionError:
        try:
            os.chmod(caminho, 0o666)  # arquivo marcado como somente leitura
            os.remove(caminho)
            return True
        except OSError:
            return False
    except OSError:
        return False


# v9.1: caches de shader das placas de vídeo nunca são apagados (mesmo dentro do Temp): sem eles o jogo recompila
# tudo e dá travadinhas nas primeiras partidas
PASTAS_PRESERVAR = {"nv_cache", "dxcache", "glcache", "d3dscache", "vkcache", "nvidia\\dxcache"}


def _percorrer(pasta, apagar, ext=None, dias=None, idade_min=0, parar=None, _nivel=0):
    """Soma (e, se pedido, apaga) os arquivos de uma pasta. Pula o que está em uso. Devolve bytes."""
    total = 0
    if _nivel > 40:
        return 0
    try:
        entradas = list(os.scandir(pasta))
    except OSError:
        return 0
    agora = time.time()
    for e in entradas:
        if parar and parar():
            break
        try:
            st = e.stat(follow_symlinks=False)
            if e.is_symlink() or _atributo_ligacao(st):
                continue  # nunca segue atalhos nem junções
            if e.is_dir(follow_symlinks=False):
                if e.name.lower() in PASTAS_PRESERVAR:
                    continue
                total += _percorrer(e.path, apagar, ext, dias, idade_min, parar, _nivel + 1)
                # pasta vazia só some se for antiga: um programa pode ter acabado de criá-la para usar daqui a pouco
                if apagar and agora - st.st_mtime >= max(idade_min, (dias or 0) * 86400):
                    try:
                        os.rmdir(e.path)
                    except OSError:
                        pass
                continue
            if ext and not e.name.lower().endswith(ext):
                continue
            idade = agora - st.st_mtime
            if (dias and idade < dias * 86400) or (idade_min and idade < idade_min):
                continue
            if apagar:
                if _remover_arquivo(e.path):
                    total += st.st_size
            else:
                total += st.st_size
        except OSError:
            continue
    return total


def _casa(parte, nome):
    if parte == "*":
        return True
    if parte.endswith("*"):
        return nome.lower().startswith(parte[:-1].lower())
    return nome.lower() == parte.lower()


def _resolver(spec):
    """spec = (pasta_base, parte, parte...). Uma parte pode ser '*' ou 'prefixo*'. Devolve pastas reais e seguras."""
    base, partes = spec[0], spec[1:]
    if not base or not os.path.isabs(base):
        return []
    atuais = [base]
    for parte in partes:
        novos = []
        for b in atuais:
            if "*" in parte:
                try:
                    with os.scandir(b) as it:
                        for e in it:
                            if e.is_dir(follow_symlinks=False) and _casa(parte, e.name):
                                novos.append(e.path)
                except OSError:
                    pass
            else:
                novos.append(os.path.join(b, parte))
        atuais = novos
    achadas = []
    for p in atuais:
        try:
            if os.path.isdir(p) and not _e_ligacao(p) and _caminho_seguro(p):
                achadas.append(p)
        except OSError:
            pass
    return achadas


# ---------- o que pode ser limpo ----------

def _cat(id, nome, grupo, pastas, admin=False, arquivos=(), **filtros):
    return {"id": id, "nome": nome, "grupo": grupo, "pastas": [p for p in pastas if p and p[0]],
            "admin": admin, "arquivos": [a for a in arquivos if a], **filtros}


def _pastas_cache(base, *nomes):
    return [(base,) + tuple(n) for n in nomes] if base else []


def categorias():
    """Lista de categorias de limpeza. Tudo aqui é cache ou lixo que o próprio programa recria sozinho."""
    L, A, D = _env("LOCALAPPDATA"), _env("APPDATA"), _env("PROGRAMDATA")
    R = _env("SYSTEMROOT") or _env("WINDIR")
    U = tempfile.gettempdir()
    j = _junta
    c = []
    # --- arquivos temporários ---
    c.append(_cat("temp_usuario", "Temporários do usuário", "temp", [(U,), (j(L, "Temp"),)], idade_min=600))
    c.append(_cat("temp_windows", "Temporários do Windows", "temp", [(j(R, "Temp"),)], admin=True, idade_min=600))
    c.append(_cat("inet_cache", "Cache de internet do Windows", "temp",
                  [(j(L, "Microsoft", "Windows", "INetCache"),)]))
    c.append(_cat("pacotes_temp", "Temporários de apps da Loja", "temp", [(j(L, "Packages"), "*", "TempState")]))
    # --- navegadores: só o cache (cookies, senhas e histórico não são tocados) ---
    cr = ("Cache", "Code Cache", "GPUCache", "DawnGraphiteCache", "DawnWebGPUCache")
    for ident, nome, base in (
            ("chrome", "Google Chrome", j(L, "Google", "Chrome", "User Data")),
            ("edge", "Microsoft Edge", j(L, "Microsoft", "Edge", "User Data")),
            ("brave", "Brave", j(L, "BraveSoftware", "Brave-Browser", "User Data")),
            ("vivaldi", "Vivaldi", j(L, "Vivaldi", "User Data"))):
        pastas = _pastas_cache(base, *[("*", n) for n in cr], ("GrShaderCache",), ("ShaderCache",))
        c.append(_cat(ident, nome, "nav", pastas))
    for ident, nome, pasta in (("opera", "Opera", "Opera Stable"), ("opera_gx", "Opera GX", "Opera GX Stable")):
        pastas = []
        for raiz in (A, L):
            pastas += _pastas_cache(j(raiz, "Opera Software", pasta), ("Cache",), ("Code Cache",), ("GPUCache",))
        c.append(_cat(ident, nome, "nav", pastas))
    c.append(_cat("firefox", "Mozilla Firefox", "nav",
                  _pastas_cache(j(L, "Mozilla", "Firefox", "Profiles"), ("*", "cache2"), ("*", "startupCache"))))
    # --- caches de programas ---
    el = ("Cache", "Code Cache", "GPUCache")
    pastas = []
    for nome in ("discord", "discordptb", "discordcanary"):
        pastas += _pastas_cache(j(A, nome), *[(n,) for n in el])
    c.append(_cat("discord", "Discord", "apps", pastas))
    c.append(_cat("teams", "Microsoft Teams", "apps",
                  _pastas_cache(j(A, "Microsoft", "Teams"), *[(n,) for n in el + ("tmp", "blob_storage")])))
    c.append(_cat("slack", "Slack", "apps", _pastas_cache(j(A, "Slack"), *[(n,) for n in el])))
    c.append(_cat("whatsapp", "WhatsApp Desktop", "apps", _pastas_cache(j(A, "WhatsApp"), *[(n,) for n in el])))
    c.append(_cat("vscode", "Visual Studio Code", "apps",
                  _pastas_cache(j(A, "Code"), *[(n,) for n in el + ("CachedData", "logs")])))
    c.append(_cat("steam_web", "Steam (navegador interno)", "apps", [(j(L, "Steam", "htmlcache"),)]))
    c.append(_cat("epic", "Epic Games Launcher", "apps",
                  _pastas_cache(j(L, "EpicGamesLauncher", "Saved"), ("webcache*",), ("Logs",))))
    c.append(_cat("nvidia_instalador", "Restos do instalador da NVIDIA", "apps",
                  [(j(D, "NVIDIA Corporation", "Downloader"),)], admin=True))
    # --- Windows ---
    c.append(_cat("wu_download", "Atualizações já baixadas do Windows", "win",
                  [(j(R, "SoftwareDistribution", "Download"),)], admin=True, pular_se="reinicio"))
    c.append(_cat("entrega_otimizada", "Cache da Entrega Otimizada", "win",
                  [(j(R, "ServiceProfiles", "NetworkService", "AppData", "Local", "Microsoft", "Windows",
                      "DeliveryOptimization", "Cache"),)], admin=True))
    c.append(_cat("relatorios_usuario", "Relatórios de erros (usuário)", "win",
                  [(j(L, "Microsoft", "Windows", "WER"),), (j(L, "CrashDumps"),)]))
    c.append(_cat("relatorios_sistema", "Relatórios de erros do Windows", "win",
                  [(j(D, "Microsoft", "Windows", "WER", "ReportArchive"),),
                   (j(D, "Microsoft", "Windows", "WER", "ReportQueue"),),
                   (j(D, "Microsoft", "Windows", "WER", "Temp"),)], admin=True))
    c.append(_cat("dumps_sistema", "Despejos de memória de falhas", "win",
                  [(j(R, "Minidump"),), (j(R, "LiveKernelReports"),)], admin=True, arquivos=[j(R, "MEMORY.DMP")]))
    c.append(_cat("logs_cbs", "Registros antigos de instalação", "win", [(j(R, "Logs", "CBS"),)],
                  admin=True, ext=(".log", ".cab"), dias=7))
    # --- só na Otimização Suprema (sup=True) ---
    SD = (os.environ.get("SystemDrive") or "C:") + os.sep
    c.append(_cat("logs_windows_antigos", "Registros do Windows com mais de 30 dias", "win",
                  [(j(R, "Logs", "WindowsUpdate"),), (j(R, "Logs", "DISM"),), (j(R, "Panther"),)],
                  admin=True, ext=(".log", ".etl"), dias=30, sup=True))
    c.append(_cat("instaladores_driver", "Pacotes de driver já instalados (NVIDIA e AMD)", "apps",
                  [(j(SD, "NVIDIA", "DisplayDriver"),), (j(SD, "AMD"),)], admin=True, sup=True))
    c.append(_cat("cache_loja", "Cache da Microsoft Store", "apps",
                  [(j(L, "Packages", "Microsoft.WindowsStore_8wekyb3d8bbwe", "LocalCache"),)], sup=True))
    c.append(_cat("cache_adobe", "Cache de mídia da Adobe", "apps",
                  [(j(A, "Adobe", "Common", "Media Cache Files"),), (j(A, "Adobe", "Common", "Media Cache"),)], sup=True))
    c.append(_cat("logs_onedrive", "Registros do OneDrive", "apps", [(j(L, "Microsoft", "OneDrive", "logs"),)], sup=True))
    return c


ROTULOS_GRUPO = {"temp": "Temporários", "nav": "Navegadores", "apps": "Caches de programas", "win": "Limpeza do Windows"}
NOMES_PASSO_LIMPEZA = {"temp": "Limpeza: arquivos temporários", "nav": "Limpeza: navegadores",
                       "apps": "Limpeza: caches de programas", "win": "Limpeza: lixo do Windows"}


def reinicio_pendente():
    if REG is None:
        return False
    return any(REG.existe("HKLM", c) for c in (
        r"SOFTWARE\Microsoft\Windows\CurrentVersion\WindowsUpdate\Auto Update\RebootRequired",
        r"SOFTWARE\Microsoft\Windows\CurrentVersion\Component Based Servicing\RebootPending"))


def limpar_grupo(grupo, apenas_medir=False, parar=None, sup=False):
    """Limpa (ou só mede) um grupo de categorias. Devolve {'bytes', 'itens', 'pulados'}.
    sup=True inclui as categorias extras da Otimização Suprema."""
    itens, pulados, total = [], [], 0
    vistos = set()
    adm = e_admin()
    for cat in categorias():
        if cat["grupo"] != grupo or (cat.get("sup") and not sup):
            continue
        if parar and parar():
            break
        if cat["admin"] and not adm:
            pulados.append({"nome": cat["nome"], "motivo": "admin"})
            continue
        if cat.get("pular_se") == "reinicio" and reinicio_pendente():
            pulados.append({"nome": cat["nome"], "motivo": "reinicio"})
            continue
        b = 0
        for spec in cat["pastas"]:
            for pasta in _resolver(spec):
                if _norm(pasta) in vistos:
                    continue
                vistos.add(_norm(pasta))
                b += _percorrer(pasta, not apenas_medir, cat.get("ext"), cat.get("dias"),
                                cat.get("idade_min", 0), parar)
        for arq in cat["arquivos"]:
            try:
                if os.path.isfile(arq) and not _e_ligacao(arq) and _caminho_seguro(arq):
                    tam = os.path.getsize(arq)
                    if apenas_medir or _remover_arquivo(arq):
                        b += tam
            except OSError:
                pass
        total += b
        if b:
            itens.append({"id": cat["id"], "nome": cat["nome"], "bytes": b})
    return {"bytes": total, "itens": itens, "pulados": pulados}


# ---------- programas e processos que pesam ----------

PROCESSOS_DISPENSAVEIS = {
    "compattelrunner.exe": "análise de telemetria", "gamebarpresencewriter.exe": "Game Bar",
    "yourphone.exe": "Vincular ao Celular", "phoneexperiencehost.exe": "Vincular ao Celular",
    "widgets.exe": "Widgets", "widgetservice.exe": "Widgets", "hxtsr.exe": "Email e Calendário",
    "cortana.exe": "Cortana", "skypebackgroundhost.exe": "Skype", "skypeapp.exe": "Skype",
}


def fechar_dispensaveis():
    """Fecha processos de segundo plano que o Windows abre sozinho e quase ninguém usa. Devolve os nomes."""
    alvos, nomes = [], set()
    for p in psutil.process_iter(["name"]):
        nome = (p.info.get("name") or "").lower()
        if nome in PROCESSOS_DISPENSAVEIS:
            try:
                p.terminate()
                alvos.append(p)
                nomes.add(PROCESSOS_DISPENSAVEIS[nome])
            except (psutil.Error, OSError):
                pass
    if alvos:
        _, vivos = psutil.wait_procs(alvos, timeout=2)
        for p in vivos:
            try:
                p.kill()
            except (psutil.Error, OSError):
                pass
    return sorted(nomes)


# Programas que abrem sozinhos com o Windows mas não fazem falta: launchers, atualizadores e chats.
# Antivírus, drivers de áudio/vídeo/touchpad e o OneDrive ficam de fora de propósito.
INICIO_DISPENSAVEL = re.compile(
    r"^(spotify|discord|steam|epicgameslauncher|epic games launcher|battle\.net|battlenet|origin|eadm|ea desktop|"
    r"eabackgroundservice|ubisoft connect|uplay|skype|teams|microsoftteams|com\.squirrel\.teams[\w.]*|zoom|zoomit|"
    r"adobegcinvoker[\w-]*|adobe creative cloud|ccxprocess|adobeaamupdater[\w-]*|acrobat[\w ]*|itunes ?helper|"
    r"ipodservice|googlechromeautolaunch[\w-]*|microsoftedgeautolaunch[\w-]*|ccleaner[\w ]*|utorrent|bittorrent|"
    r"qbittorrent|sunjavaupdatesched|cortana|yourphone)\b", re.IGNORECASE)


# Só na Suprema: atualizadores e programas de fabricante que não fazem falta ao jogar (continuam instalados)
INICIO_SUPREMO = re.compile(
    r"^(googleupdate[\w .-]*|microsoftedgeupdate[\w .-]*|jusched|java update scheduler|cyberlink[\w .-]*|"
    r"hp ?support[\w .-]*|supportassist[\w .-]*|dell ?update[\w .-]*|lenovo ?(vantage|welcome)[\w .-]*|"
    r"msiafterburner ?updater|nvidia geforce experience|geforce experience)\b", re.IGNORECASE)


def itens_inicio_dispensaveis(sup=False):
    return [i for i in listar_inicio() if i["ligado"] and (INICIO_DISPENSAVEL.match(i["nome"])
                                                           or (sup and INICIO_SUPREMO.match(i["nome"])))]


# ---------- disco, plano de energia e comandos longos ----------

def disco_e_ssd():
    """True (SSD), False (HD) ou None (não deu para saber) para a unidade do Windows."""
    letra = (os.environ.get("SystemDrive") or "C:")[:1]
    if not letra.isalpha():
        return None
    cod, saida = powershell("$d=(Get-Partition -DriveLetter %s).DiskNumber; (Get-PhysicalDisk | Where-Object "
                            "{ [int]$_.DeviceId -eq $d }).MediaType" % letra.upper(), tempo=40)
    if cod != 0:
        return None
    s = saida.strip().upper()
    return True if "SSD" in s else (False if "HDD" in s else None)


def tem_bateria():
    try:
        return psutil.sensors_battery() is not None
    except (AttributeError, OSError):
        return False


def _executar_longo(cmd, limite, parar=None):
    """Roda um comando demorado e deixa interromper (botão Parar/Pular). Devolve (código, saída);
    código -1 = interrompido por você, -2 = passou do tempo limite (v9.1: antes os dois diziam "pulado por você")."""
    flags = subprocess.CREATE_NO_WINDOW if IS_WIN else 0
    try:
        p = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, errors="replace",
                             creationflags=flags)
    except OSError as erro:
        return 1, str(erro)
    inicio = time.time()
    while True:
        try:
            saida, _ = p.communicate(timeout=0.5)
            return p.returncode, (saida or "").strip()
        except subprocess.TimeoutExpired:
            por_voce = bool(parar and parar())
            if por_voce or time.time() - inicio > limite:
                p.kill()
                try:
                    p.communicate(timeout=5)
                except (subprocess.SubprocessError, OSError):
                    pass
                return (-1, "interrompido") if por_voce else (-2, "tempo esgotado")


_CPMINCORES = "0cc5b647-c1df-4637-891a-dec35c318583"
_CPMAXCORES = "943c8cb6-6f93-4227-ad87-e9a3ccbf8bc2"
# valores do plano de energia: (grupo, configuração, valor) aplicados só na tomada. Em notebook o plano é copiado do
# Equilibrado, então na bateria ele economiza como antes.
AJUSTES_PLANO_EXT = [
    ("54533251-82be-4824-96c1-47b60b740d00", "893dee8e-2bef-41e0-89c6-b55d0929964c", 100),  # processador: mínimo 100%
    ("54533251-82be-4824-96c1-47b60b740d00", "bc5038f7-23e0-4960-96da-33abaf5935ec", 100),  # processador: máximo 100%
    ("54533251-82be-4824-96c1-47b60b740d00", "0cc5b647-c1df-4637-891a-dec35c318583", 100),  # núcleos sempre acordados
    ("54533251-82be-4824-96c1-47b60b740d00", "be337238-0d82-4146-a960-4f3749d470c7", 2),    # turbo agressivo
    ("54533251-82be-4824-96c1-47b60b740d00", "94d3a615-a899-4ac5-ae2b-e4d8f634367f", 1),    # ventoinha ativa
    ("501a4d13-42af-4429-9fd1-a8218c268e20", "ee12f906-d277-404b-b6da-e5fa1a576df5", 0),    # PCIe sem economia
    ("2a737441-1930-4402-8d77-b2bebba308a3", "48e6b7a6-50f5-4782-a5d4-53bb8f07e226", 0),    # USB sem suspensão
    ("0012ee47-9041-4b5d-9b77-535fba8b1442", "6738e2c4-e8a5-4a42-b16a-e040e769756e", 0),    # disco nunca desliga
    ("19cbb8fa-5279-450e-9fac-8a3d5fedd0c1", "12bbebe6-58d6-4636-95bb-3217ef867c1a", 0),    # Wi-Fi sem economia
]


# a mais, só na Suprema (o Windows ignora o que o computador não tem)
AJUSTES_PLANO_SUP = [
    ("54533251-82be-4824-96c1-47b60b740d00", "45bcc044-d885-43e2-8605-ee0ec6e96b59", 100),  # turbo: política de 100%
    ("54533251-82be-4824-96c1-47b60b740d00", "36687f9e-e3a5-4dbf-b1dc-15eb381c6863", 0),    # preferência: desempenho
    ("54533251-82be-4824-96c1-47b60b740d00", "943c8cb6-6f93-4227-ad87-e9a3ccbf8bc2", 100),  # núcleos: limite máximo 100%
    ("e276e160-7cb0-43c6-b20b-73f5dce39954", "a1662ab2-9d34-4e53-ba8b-2639b9e20857", 3),    # placa de vídeo no máximo
    ("2a737441-1930-4402-8d77-b2bebba308a3", "d4e98f31-5ffe-4ce1-be31-1b38b384c009", 0),    # USB: hub sem suspensão
    ("238c9fa8-0aad-41ed-83f4-97be242c8f20", "29f6c1db-86da-48c5-9fdb-f2b67b1f44da", 0),    # nunca suspender sozinho
]


def criar_plano_extremo(sup=False):
    """Cria (ou reaproveita) o plano 'Th Boost Extremo' (ou 'Suprema') e ativa. Devolve (ok, texto, guid, guid_anterior)."""
    planos = listar_planos()
    ativo = next((p["guid"] for p in planos if p["ativo"]), None)
    nome_novo = NOME_PLANO_SUP if sup else NOME_PLANO_EXT
    nomes_nossos = (NOME_PLANO_SUP.lower(), NOME_PLANO_EXT.lower())
    existente = next((p for p in planos if p["nome"].strip().lower() == nome_novo.lower()), None) \
        or next((p for p in planos if p["nome"].strip().lower() in nomes_nossos), None)
    if existente:
        guid = existente["guid"]
        if existente["nome"].strip().lower() != nome_novo.lower():
            executar(["powercfg", "-changename", guid, nome_novo, "Criado pelo Th Boost"])
    else:
        guid = None
        origens = (PLANOS_CONHECIDOS["maximo"][0], PLANOS_CONHECIDOS["alto"][0], PLANOS_CONHECIDOS["equilibrado"][0])
        if tem_bateria():  # v9.1: em notebook a cópia sai do Equilibrado, então na bateria ele continua economizando
            origens = (PLANOS_CONHECIDOS["equilibrado"][0],) + origens[:2]
        for origem in origens:
            cod, saida = executar(["powercfg", "-duplicatescheme", origem])
            m = re.search(_GUID, saida or "")
            if cod == 0 and m:
                guid = m.group(0).lower()
                break
        if not guid:
            return False, "Não foi possível criar o plano de energia (o Windows recusou).", None, ativo
        executar(["powercfg", "-changename", guid, nome_novo, "Criado pelo Th Boost (Otimização " + ("Suprema" if sup else "Extrema") + ")"])
    x3d = cpu_x3d_duplo()
    for sub, cfg, valor in AJUSTES_PLANO_EXT + (AJUSTES_PLANO_SUP if sup else []):  # o que o Windows não conhece é ignorado
        if x3d and cfg in (_CPMINCORES, _CPMAXCORES):
            continue  # Ryzen X3D de 2 blocos: o driver da AMD precisa "estacionar" núcleos para mandar o jogo ao bloco com V-Cache
        executar(["powercfg", "/setacvalueindex", guid, sub, cfg, str(valor)])
    cod, _ = executar(["powercfg", "/setactive", guid])
    if cod != 0:
        return False, "Plano criado, mas o Windows não deixou ativar.", guid, ativo
    return True, f"Plano “{nome_novo}” ativado (processador sempre pronto, sem economia de energia na tomada).", \
        guid, (None if ativo == guid else ativo)


def restaurar_plano(guid_extremo, guid_anterior):
    planos = {p["guid"] for p in listar_planos()}
    alvo = guid_anterior if guid_anterior in planos else PLANOS_CONHECIDOS["equilibrado"][0]
    cod, _ = executar(["powercfg", "/setactive", alvo])
    if guid_extremo and guid_extremo in planos and guid_extremo != alvo:
        executar(["powercfg", "/delete", guid_extremo])
    return cod == 0


def pasta_windows_old():
    p = os.path.join(disco_sistema(), "Windows.old")
    return p if os.path.isdir(p) and not _e_ligacao(p) else None


# ---------- o que a Otimização Extrema fez (para o Desfazer) ----------

def _ext_tem_algo(d):
    return bool(d and (d.get("ajustes") or d.get("inicio") or d.get("plano") or d.get("gpu")))


def _ext_ler():
    with TRAVA_EXT:
        if _EXT_MEM:
            return dict(_EXT_MEM)
        try:
            with open(ARQ_EXTREMO, encoding="utf-8") as f:
                d = json.load(f)
            return d if isinstance(d, dict) else {}
        except (OSError, ValueError):
            return {}


def _ext_gravar(d):
    with TRAVA_EXT:
        _EXT_MEM.clear()
        _EXT_MEM.update(d)
        try:
            if d:
                with open(ARQ_EXTREMO, "w", encoding="utf-8") as f:
                    json.dump(d, f, ensure_ascii=False, indent=1)
            elif os.path.exists(ARQ_EXTREMO):
                os.remove(ARQ_EXTREMO)
        except OSError:
            pass  # sem permissão de escrita: o registro fica só na memória desta execução


class ExtremoMixin:
    """Parte do Nucleo responsável pela Otimização Extrema. Os passos rodam em uma thread e a tela acompanha pelo estado."""

    def ext_iniciar_estado(self):
        prev = _ext_ler()
        self.ext = {"ativo": False, "parando": False, "fracao": 0.0, "passo": "", "passos": [], "mb": 0.0,
                    "opcoes": {"dism": True, "apps": False, "busca": False, "winold": False, "nivel": "extrema"},
                    "antes": None, "depois": None, "resumo": None,
                    "fim": 0, "desfazer": _ext_tem_algo(prev),
                    "analise": {"estado": "nenhuma", "total_mb": 0.0, "itens": [], "winold_gb": 0.0, "nivel": "extrema"}}
        self.ext_pular = False
        self.reinicio_ate = 0.0

    def ext_snapshot(self):
        e = self.ext
        d = dict(e)
        d["passos"] = [dict(p) for p in e["passos"]]
        d["opcoes"] = dict(e["opcoes"])
        d["analise"] = dict(e["analise"])
        d["analise"]["itens"] = list(e["analise"]["itens"])
        d["reinicio"] = max(0, int(self.reinicio_ate - time.time())) if self.reinicio_ate else 0
        return d

    # ----- análise (só mede, não apaga nada) -----

    def ext_analisar(self, nivel="extrema"):
        a = self.ext["analise"]
        if a["estado"] == "rodando" or self.ext["ativo"]:
            return
        sup = nivel == "suprema"

        def tarefa():
            a["estado"] = "rodando"
            itens, total = [], 0
            try:
                for g in ("temp", "nav", "apps", "win"):
                    r = limpar_grupo(g, apenas_medir=True, parar=lambda: self.fechando, sup=sup)
                    total += r["bytes"]
                    itens += [{"nome": i["nome"], "mb": round(i["bytes"] / 1048576, 1), "grupo": g} for i in r["itens"]]
                itens.sort(key=lambda i: -i["mb"])
                wo = pasta_windows_old()
                gb = 0.0
                if wo:  # a pasta que sobra de uma atualização do Windows: mede com limite de tempo
                    fim = time.time() + 25
                    gb = round(_percorrer(wo, False, parar=lambda: self.fechando or time.time() > fim) / 1024 ** 3, 1)
                a.update({"itens": itens[:8], "total_mb": round(total / 1048576, 1), "estado": "pronto",
                          "winold_gb": gb, "nivel": nivel})
            except Exception:
                a["estado"] = "erro"

        a["estado"] = "rodando"
        threading.Thread(target=tarefa, daemon=True).start()

    # ----- medidas de antes e depois -----

    def _medidas(self):
        mem = psutil.virtual_memory()
        try:
            livre = psutil.disk_usage(disco_sistema()).free / 1024 ** 3
        except OSError:
            livre = None
        try:
            inicio = len([i for i in listar_inicio() if i["ligado"]])
        except Exception:
            inicio = None
        try:
            processos = len(psutil.pids())
        except Exception:
            processos = None
        try:
            servicos = sum(1 for sv in psutil.win_service_iter() if sv.status() == "running") if IS_WIN else None
        except Exception:
            servicos = None
        return {"ram_livre": round(mem.available / 1024 ** 3, 2), "ram_pct": round(mem.percent, 1),
                "disco_livre": None if livre is None else round(livre, 2), "inicio": inicio,
                "processos": processos, "servicos": servicos}

    # ----- plano dos passos -----

    def _ext_plano(self, opcoes):
        sup = opcoes.get("nivel") == "suprema"
        P = []
        P.append(("restauracao", "Ponto de restauração", self._x_restauracao, True))
        P.append(("processos", "Fechando o que pesa em segundo plano", self._x_processos, False))
        for g in ("temp", "nav", "apps", "win"):
            P.append(("l_" + g, NOMES_PASSO_LIMPEZA[g], (lambda ctx, g=g: self._x_limpar(ctx, g)), False))
        P.append(("lixeira", "Esvaziando a lixeira", self._x_lixeira, False))
        if opcoes.get("winold"):
            P.append(("winold", "Removendo o Windows.old", self._x_winold, True))
        if opcoes.get("dism"):
            P.append(("dism", "Componentes antigos do Windows", self._x_dism, True))
        for g, nome in (("windows", "Ajustes do Windows"), ("mouse", "Mouse e teclado"),
                        ("servicos", "Serviços desnecessários"), ("privacidade", "Privacidade e telemetria"),
                        ("rede", "Rede e latência"), ("jogos", "Ajustes de FPS para jogos")):
            P.append(("aj_" + g, nome, (lambda ctx, g=g: self._x_ajustes(ctx, g)), False))
        P.append(("inicio", "Programas que abrem com o Windows", self._x_inicio, False))
        if sup:
            P.append(("gpu", "Seus jogos usam a placa de vídeo forte", self._x_gpu_jogos, False))
        P.append(("energia", "Plano de energia Suprema" if sup else "Plano de energia Extremo", self._x_energia, True))
        P.append(("disco", "Disco: manutenção do SSD", self._x_disco, True))
        if opcoes.get("apps"):
            P.append(("apps", "Removendo apps inúteis do Windows", self._x_apps, True))
        P.append(("dns", "Rede: limpando o DNS", self._x_dns, False))
        P.append(("ram", "Liberando a RAM", self._x_ram, False))
        return P

    def ext_iniciar(self, opcoes):
        if self.ext["ativo"] or self.otim["ativo"]:
            return self.msg("Já estou otimizando, aguarde.")
        if REG is None:
            return self.msg("A Otimização Extrema só funciona no Windows. Aqui você vê apenas uma prévia.")
        opc = {"dism": bool(opcoes.get("dism", True)), "apps": bool(opcoes.get("apps", False)),
               "busca": bool(opcoes.get("busca", False)), "winold": bool(opcoes.get("winold", False)),
               "nivel": "suprema" if opcoes.get("nivel") == "suprema" else "extrema"}
        passos = self._ext_plano(opc)
        self.ext.update({"ativo": True, "parando": False, "fracao": 0.02, "passo": "Preparando...", "mb": 0.0,
                         "opcoes": opc, "antes": None, "depois": None, "resumo": None})
        self.ext["passos"] = [{"id": p[0], "nome": p[1], "estado": "pendente", "texto": "", "mb": 0.0} for p in passos]
        self.ext_pular = False
        self.msg("Otimização Suprema iniciada..." if opc["nivel"] == "suprema" else "Otimização Extrema iniciada...")
        threading.Thread(target=self._ext_rodar, args=(passos,), daemon=True).start()

    def ext_parar(self):
        if self.ext["ativo"]:
            self.ext["parando"] = True
            self.ext_pular = True
            self.msg("Parando a Otimização Extrema...")

    def _ext_rodar(self, passos):
        E = self.ext
        adm = e_admin()
        opc = E["opcoes"]
        ctx = {"ajustes": [], "inicio": [], "plano": None, "apps": 0, "mb": 0.0, "fechados": [], "ssd": "?",
               "hibernacao": False, "servicos": 0, "ajustes_n": 0, "trim": None, "dism": None, "reinicio": False,
               "sup": opc.get("nivel") == "suprema", "busca": bool(opc.get("busca")), "gpu": [], "winold": None}
        self._xctx = ctx
        try:
            E["antes"] = self._medidas()
            n = len(passos)
            for i, (pid, nome, func, precisa_adm) in enumerate(passos):
                P = E["passos"][i]
                if E["parando"] or self.fechando:
                    for outro in E["passos"][i:]:
                        outro.update(estado="pulado", texto="Interrompido")
                    break
                if precisa_adm and not adm:
                    P.update(estado="pulado", texto="Precisa de Administrador")
                    E["fracao"] = (i + 1) / n
                    continue
                E["passo"] = nome + "..."
                E["fracao"] = max(0.02, i / n)
                P["estado"] = "rodando"
                inicio = time.time()
                try:
                    texto, estado, mb = func(ctx)
                except Exception as erro:
                    texto, estado, mb = f"Erro: {erro}", "erro", 0.0
                time.sleep(max(0.0, 0.6 - (time.time() - inicio)))  # cada passo fica à vista por um instante
                ctx["mb"] += mb
                E["mb"] = round(ctx["mb"], 1)
                P.update(estado=estado, texto=texto, mb=round(mb, 1))
                E["fracao"] = (i + 1) / n
                self._ext_guardar(ctx)
            E["depois"] = self._medidas()
            E["resumo"] = self._ext_resumo(ctx)
        except Exception as erro:
            self.msg(f"A Otimização Extrema parou por um erro: {erro}")
        finally:
            parou = E["parando"]
            E["passo"] = "Pronto"
            E["fracao"] = 1.0
            E["ativo"] = False
            E["parando"] = False
            E["desfazer"] = _ext_tem_algo(_ext_ler())
            self.atualizar_aj()
            E["fim"] += 1
            r = E["resumo"] or {}
            nome_otim = "Otimização Suprema" if ctx["sup"] else "Otimização Extrema"
            self.msg((f"{nome_otim} interrompida. " if parou else f"{nome_otim} concluída: ")
                     + f"{tam_texto(ctx['mb'] * 1048576)} liberados, {r.get('ajustes', 0)} ajuste(s), "
                       f"{r.get('inicio', 0)} programa(s) fora da inicialização.")
            self.estat_otimizacao(ctx["mb"], "suprema" if ctx["sup"] else "extrema", parou)

    def _ext_resumo(self, ctx):
        a, d = self.ext["antes"] or {}, self.ext["depois"] or {}
        ram = max(0.0, (d.get("ram_livre") or 0) - (a.get("ram_livre") or 0))
        return {"nivel": "suprema" if ctx["sup"] else "extrema", "gpu": len(ctx["gpu"]), "winold": ctx["winold"],
                "processos": [a.get("processos"), d.get("processos")], "servicos_rodando": [a.get("servicos"), d.get("servicos")],
                "limpo_mb": round(ctx["mb"], 1), "ram_gb": round(ram, 2), "ajustes": ctx["ajustes_n"],
                "servicos": ctx["servicos"], "inicio": len(ctx["inicio"]), "apps": ctx["apps"],
                "fechados": ctx["fechados"], "plano": bool(ctx["plano"]), "trim": ctx["trim"],
                "dism": ctx["dism"], "hibernacao": ctx["hibernacao"],
                "reiniciar": bool(ctx["ajustes_n"] or ctx["plano"] or ctx["inicio"] or ctx["hibernacao"] or ctx["dism"] or ctx["gpu"])}

    def _ext_guardar(self, ctx):
        """Anota o que foi feito, para o Desfazer, a cada passo (se o programa fechar no meio, nada se perde)."""
        prev = _ext_ler()
        plano = prev.get("plano")
        if ctx["plano"]:
            anterior = (plano or {}).get("anterior") or ctx["plano"].get("anterior")
            plano = {"extremo": ctx["plano"]["extremo"], "anterior": anterior}
        novo = {"quando": datetime.now().strftime("%d/%m/%Y %H:%M"),
                "ajustes": list(dict.fromkeys(list(prev.get("ajustes", [])) + ctx["ajustes"])),
                "inicio": list(dict.fromkeys(list(prev.get("inicio", [])) + ctx["inicio"])),
                "gpu": list(dict.fromkeys(list(prev.get("gpu", [])) + ctx["gpu"])),
                "plano": plano}
        if _ext_tem_algo(novo):
            _ext_gravar(novo)
            self.ext["desfazer"] = True

    # ----- cada passo devolve (texto, estado, megabytes_liberados) -----

    def _x_restauracao(self, ctx):
        if ponto_restauracao():
            return "Ponto de restauração do Windows criado.", "ok", 0.0
        return ("Sem ponto novo (o Windows só cria um por dia ou a Proteção do Sistema está desligada). "
                "O Desfazer do Th Boost continua valendo."), "pulado", 0.0

    def _x_processos(self, ctx):
        nomes = fechar_dispensaveis()
        ctx["fechados"] = nomes
        return ("Fechei: " + ", ".join(nomes) + ".") if nomes else "Nada pesado rodando escondido.", "ok", 0.0

    def _x_limpar(self, ctx, grupo):
        texto, b = self._limpar_texto(grupo, sup=ctx["sup"])
        return texto, "ok", b / 1048576

    def _x_lixeira(self, ctx):
        ok, texto = esvaziar_lixeira()
        return texto, ("ok" if ok else "erro"), 0.0

    def _x_dism(self, ctx):
        if reinicio_pendente():
            ctx["dism"] = "adiado"
            return "Adiado: há um reinício pendente. Reinicie o PC e rode de novo para esta parte.", "pulado", 0.0
        self.ext_pular = False
        antes = psutil.disk_usage(disco_sistema()).free
        cod, _ = _executar_longo(["Dism.exe", "/Online", "/Cleanup-Image", "/StartComponentCleanup"], 1500,
                                 lambda: self.ext["parando"] or self.ext_pular or self.fechando)
        self.ext_pular = self.ext["parando"]
        if cod == -1:
            ctx["dism"] = "pulado"
            return "Pulado por você. Dá para rodar de novo depois.", "pulado", 0.0
        if cod == -2:
            ctx["dism"] = "adiado"
            return "Demorou mais de 25 minutos e eu parei para não travar a otimização. Dá para rodar de novo depois.", "pulado", 0.0
        if cod != 0:
            ctx["dism"] = "adiado"
            return "O Windows adiou esta limpeza (pode haver uma atualização pendente).", "pulado", 0.0
        ctx["dism"] = "ok"
        livre = max(0, psutil.disk_usage(disco_sistema()).free - antes)
        return "Versões antigas de componentes do Windows removidas.", "ok", livre / 1048576

    def _x_winold(self, ctx):
        pasta = pasta_windows_old()
        if not pasta:
            ctx["winold"] = "nenhuma"
            return "Não existe a pasta Windows.old neste PC.", "ok", 0.0
        if reinicio_pendente():
            ctx["winold"] = "adiado"
            return "Adiado: há um reinício pendente. Reinicie o PC e rode de novo para esta parte.", "pulado", 0.0
        antes = psutil.disk_usage(disco_sistema()).free
        parar = lambda: self.ext["parando"] or self.ext_pular or self.fechando
        self.ext_pular = False
        # toma posse da pasta (pelo código do grupo Administradores, que não depende do idioma) e apaga
        _executar_longo(["icacls", pasta, "/setowner", "*S-1-5-32-544", "/T", "/C", "/Q"], 900, parar)
        _executar_longo(["icacls", pasta, "/grant", "*S-1-5-32-544:(OI)(CI)F", "/T", "/C", "/Q"], 900, parar)
        cod, _ = _executar_longo(["cmd", "/c", "rd", "/s", "/q", pasta], 1800, parar)
        self.ext_pular = self.ext["parando"]
        if cod in (-1, -2):
            ctx["winold"] = "pulado"
            return (("Pulado por você." if cod == -1 else "Demorou demais e eu parei.")
                    + " A pasta ficou como estava (parte pode ter sido apagada)."), "pulado", 0.0
        livre = max(0, psutil.disk_usage(disco_sistema()).free - antes)
        if pasta_windows_old() and os.listdir(pasta):
            ctx["winold"] = "parcial"
            return f"Apaguei parte do Windows.old ({tam_texto(livre)}); o resto está em uso. Tente de novo depois de reiniciar.", "ok", livre / 1048576
        ctx["winold"] = "ok"
        return "Windows.old removido. (Não dá mais para voltar à versão anterior do Windows.)", "ok", livre / 1048576

    def _x_ajustes(self, ctx, grupo):
        itens = [a for a in CATALOGO if a.grupo == grupo and (a.rec or a.ext or (ctx["sup"] and a.sup))
                 and a.risco != "medio" and a.disponivel()]
        if ctx["sup"] and tem_bateria():
            itens = [a for a in itens if not a.so_mesa]
        if grupo == "servicos" and ctx["busca"]:  # escolha da pessoa na tela: indexação de arquivos desligada
            ws = POR_ID.get("svc_wsearch")
            if ws and ws.disponivel():
                itens.append(ws)
        if grupo == "servicos":  # o Superfetch só atrapalha em SSD; em HD mecânico ajuda
            ssd = self._ssd(ctx)
            itens = [a for a in itens if a.id != "svc_sysmain"]
            sm = POR_ID.get("svc_sysmain")
            if sm and ssd is True and sm.disponivel():
                itens.append(sm)
        feitos = ja = sem_adm = falhas = 0
        e_adm = e_admin()
        for a in itens:
            try:
                est = a.estado()
            except Exception:
                est = None
            if est is None:
                continue
            if est is True:
                ja += 1
                continue
            if a.precisa_admin and not e_adm:
                sem_adm += 1
                continue
            try:
                a.ligar()
                ok = a.estado() is True
            except OSError:
                ok = False  # serviço que o Windows recusa: o ajuste volta sozinho como era (tudo ou nada)
            if ok:
                feitos += 1
                ctx["ajustes"].append(a.id)
                ctx["ajustes_n"] += 1
                if grupo == "servicos":
                    ctx["servicos"] += 1
            else:
                falhas += 1
        partes = [f"{feitos} aplicado(s)"]
        if ja:
            partes.append(f"{ja} já estava(m) assim")
        if sem_adm:
            partes.append(f"{sem_adm} precisa(m) de Administrador")
        if falhas:
            partes.append(f"{falhas} o Windows não aceitou")
        estado = "ok" if (feitos or ja or not falhas) else "erro"
        if not feitos and not ja and sem_adm and not falhas:
            estado = "pulado"
        return ", ".join(partes) + ".", estado, 0.0

    def _ssd(self, ctx):
        if ctx["ssd"] == "?":
            ctx["ssd"] = disco_e_ssd()
        return ctx["ssd"]

    def _x_gpu_jogos(self, ctx):
        todos = []
        for j in list(self.jogos):
            if j.get("pasta") or j.get("exes"):
                todos += exes_da_entrada(j)
        todos = list(dict.fromkeys(todos))
        if not todos:
            return "Nenhum jogo encontrado neste PC para ajustar.", "ok", 0.0
        feitos = gpu_alto_aplicar(todos)
        ctx["gpu"] = list(dict.fromkeys(ctx["gpu"] + feitos))
        return (f"{len(feitos)} programa(s) de jogos agora usam a placa de vídeo de alto desempenho."
                if feitos else "Seus jogos já usam a placa de vídeo de alto desempenho."), "ok", 0.0

    def _x_inicio(self, ctx):
        alvos = itens_inicio_dispensaveis(ctx["sup"])
        feitos = []
        for i in alvos:
            try:
                definir_inicio(i["id"], False)
                feitos.append(i)
            except OSError:
                pass
        ctx["inicio"] = [i["id"] for i in feitos]
        if not feitos:
            return "Nenhum programa pesado abrindo com o Windows.", "ok", 0.0
        nomes = ", ".join(i["nome"] for i in feitos[:6]) + (f" e mais {len(feitos) - 6}" if len(feitos) > 6 else "")
        return f"Não abrem mais sozinhos: {nomes}.", "ok", 0.0

    def _x_energia(self, ctx):
        ok, texto, guid, anterior = criar_plano_extremo(ctx["sup"])
        if guid and ok:
            ctx["plano"] = {"extremo": guid, "anterior": anterior}
        mb = 0.0
        h = POR_ID.get("hibernacao")
        if h and not tem_bateria() and h.estado() is False:  # em PC de mesa a hibernação só ocupa disco
            try:
                tam = os.path.getsize(os.path.join(disco_sistema(), "hiberfil.sys"))
            except OSError:
                tam = 0
            h.ligar()
            if h.estado() is True:
                ctx["ajustes"].append("hibernacao")
                ctx["ajustes_n"] += 1
                ctx["hibernacao"] = True
                mb = tam / 1048576
                texto += f" Hibernação desligada (liberou {tam_texto(tam)})." if tam else " Hibernação desligada."
        return texto, ("ok" if ok else "erro"), mb

    def _x_disco(self, ctx):
        ssd = self._ssd(ctx)
        if ssd is None:
            return "Não consegui saber se o disco é SSD ou HD, então deixei como está.", "pulado", 0.0
        if ssd is False:
            return "O disco é HD mecânico: desfragmentar leva horas, então fica de fora. Use a Desfragmentação do Windows à noite.", "pulado", 0.0
        letra = (os.environ.get("SystemDrive") or "C:")[:2]
        cod, _ = executar(["defrag", letra, "/L"], timeout=600)
        ctx["trim"] = cod == 0
        return ("TRIM enviado ao SSD (ele reaproveita os espaços livres)." if cod == 0
                else "O Windows não aceitou o TRIM agora."), ("ok" if cod == 0 else "erro"), 0.0

    def _x_apps(self, ctx):
        instalados = [a["nome"] for a in listar_apps() if a["risco"] == "baixo"]
        if not instalados:
            return "Nenhum app inútil instalado.", "ok", 0.0
        feitos = remover_apps(instalados)
        ctx["apps"] = feitos
        return f"{feitos} de {len(instalados)} app(s) removido(s). Voltam pela Microsoft Store.", "ok", 0.0

    def _x_dns(self, ctx):
        return self.t_dns(), "ok", 0.0

    def _x_ram(self, ctx):
        b, texto = liberar_ram()
        return texto, "ok", 0.0

    # ----- desfazer -----

    def ext_desfazer(self):
        if self.ext["ativo"] or self.otim["ativo"]:
            return self.msg("Espere a otimização terminar para desfazer.")
        self.msg("Desfazendo a Otimização Extrema...")
        self.em_fundo(self._ext_desfazer_agora)

    def _ext_desfazer_agora(self):
        est = _ext_ler()
        if not _ext_tem_algo(est):
            _ext_gravar({})
            self.ext["desfazer"] = False
            return "Não há nada da Otimização Extrema para desfazer."
        adm = e_admin()
        devolvidos, restante = 0, []
        for ident in est.get("ajustes", []):
            a = POR_ID.get(ident)
            if a is None:
                continue
            if a.precisa_admin and not adm:
                restante.append(ident)
                continue
            try:
                a.desligar()
                devolvidos += 1
            except OSError:
                restante.append(ident)
        inicio = 0
        for ident in est.get("inicio", []):
            try:
                definir_inicio(ident, True)
                inicio += 1
            except OSError:
                pass
        gpus = gpu_alto_remover(est.get("gpu") or []) if est.get("gpu") else 0
        plano = est.get("plano") or {}
        plano_ok = False
        if plano.get("extremo") and adm:
            plano_ok = restaurar_plano(plano["extremo"], plano.get("anterior"))
        plano_pendente = bool(plano.get("extremo")) and not plano_ok
        resto = {"quando": est.get("quando"), "ajustes": restante, "inicio": [], "gpu": [], "plano": plano if plano_pendente else None}
        _ext_gravar(resto if _ext_tem_algo(resto) else {})
        self.atualizar_aj()
        self.ext["desfazer"] = _ext_tem_algo(_ext_ler())
        self.ext["resumo"] = None
        texto = f"Otimização desfeita: {devolvidos} ajuste(s) e {inicio} programa(s) da inicialização devolvidos"
        if gpus:
            texto += f", {gpus} perfil(is) de placa de vídeo"
        texto += ", plano de energia de antes de volta." if plano_ok else "."
        if restante or plano_pendente:
            texto += " Parte precisa de Administrador: abra o Th Boost pelo atalho e desfaça de novo."
        return texto

    # ----- reiniciar o PC -----

    def reiniciar_pc(self):
        if not IS_WIN:
            return self.msg("Disponível só no Windows.")
        cod, _ = executar(["shutdown", "/r", "/t", "20", "/c", "Th Boost: reiniciando para concluir a otimização."])
        if cod == 0:
            self.reinicio_ate = time.time() + 20
            self.msg("O PC reinicia em 20 segundos. Salve o que estiver aberto.")
        else:
            self.msg("Não consegui agendar o reinício. Reinicie pelo menu Iniciar.")

    def reiniciar_cancelar(self):
        executar(["shutdown", "/a"])
        self.reinicio_ate = 0.0
        self.msg("Reinício cancelado.")


# ---------------- jogos: perfil por jogo, "Otimizar antes de jogar" e vigia automático ----------------
#
# O que realmente aumenta o FPS (e o que o Th Boost faz aqui):
#  - tirar peso de segundo plano (programas, serviços do Windows Update, indexação) enquanto o jogo roda;
#  - plano de energia de desempenho e RAM livre;
#  - dizer ao Windows para usar a placa de vídeo de ALTO desempenho no jogo (decisivo em notebook com 2 placas);
#  - prioridade alta ao processo do jogo;
#  - ajustes de Windows que tiram trabalho do jogo (Game DVR, Game Bar, MMCSS, mouse).
# Nada aqui inventa FPS: o ganho depende do PC. Tudo que muda é desfeito ao terminar a sessão ou pelo botão da tela.

_GPU_CHAVE = r"Software\Microsoft\DirectX\UserGpuPreferences"
_FSO_CHAVE = r"Software\Microsoft\Windows NT\CurrentVersion\AppCompatFlags\Layers"
_FSO_FLAG = "DISABLEDXMAXIMIZEDWINDOWEDMODE"
_IGNORAR_EXE = re.compile(
    r"(unins|crash|report|redist|vcredist|vc_redist|dxsetup|dotnet|install|setup|easyanticheat|eac_|beservice|battleye|"
    r"patcher|helper|cefsubprocess|ue4prereq|prereq|updater|webhelper|errorreporter|benchmark|configtool|"
    r"launcher_|notification_helper|vulkan|zip|7z)", re.IGNORECASE)

# pacote de ajustes de FPS (ids do catálogo) que o "Otimizar antes de jogar" liga, se ainda estiverem desligados
FPS_PACOTE = ["modo_jogo", "game_dvr", "fps_dvr_politica", "fps_gamebar", "fps_janela", "prioridade_jogos", "mouse_acel",
              "do_p2p"]  # v9.1: saíram os de rede que não mudam o ping (continuam na lista para quem quiser)
# lista completa mostrada na página Jogos (inclui os de risco médio, que só ligam por escolha da pessoa)
FPS_LISTA = FPS_PACOTE + ["rede_throttle", "rede_nagle", "fps_energia_throttle", "hags", "fps_vbs"]
# serviços que podem ser parados só enquanto o jogo roda (voltam sozinhos ao terminar a sessão)
SERVICOS_PAUSA = [("wuauserv", "Windows Update"), ("BITS", "Transferência em segundo plano"),
                  ("DoSvc", "Entrega de atualizações"), ("WSearch", "Indexação de arquivos")]
PRE_PADRAO = {"fechar": True, "ram": True, "energia": True, "ajustes": True, "gpu": True, "pausar": True,
              "leve": True, "prioridade": True, "fso": False, "abrir": True}
PLANO_BOM = re.compile(r"alto desempenho|high performance|desempenho m[aá]ximo|ultimate|th boost", re.IGNORECASE)
MAX_EXES = 6


# ---------- executáveis do jogo ----------

def _exe_valido(exe):
    return (isinstance(exe, str) and 8 < len(exe) < 300 and os.path.isabs(exe) and exe.lower().endswith(".exe")
            and not re.search(r"[;\"<>|*?]", exe))


def exes_do_jogo(pasta, limite=MAX_EXES):
    """Os programas principais (.exe) de um jogo: os maiores da pasta, sem instaladores nem ajudantes."""
    if not pasta or not os.path.isabs(pasta) or not os.path.isdir(pasta) or _e_ligacao(pasta):
        return []
    achados = []
    base_n = _norm(pasta)
    pilha = [(pasta, 0)]
    visitadas = 0
    while pilha and visitadas < 500:
        atual, nivel = pilha.pop()
        visitadas += 1
        try:
            entradas = list(os.scandir(atual))
        except OSError:
            continue
        for e in entradas:
            try:
                if e.is_symlink():
                    continue
                if e.is_dir(follow_symlinks=False):
                    if nivel < 4 and not _atributo_ligacao(e.stat(follow_symlinks=False)):
                        pilha.append((e.path, nivel + 1))
                elif e.name.lower().endswith(".exe") and not _IGNORAR_EXE.search(e.name):
                    tam = e.stat(follow_symlinks=False).st_size
                    if tam >= 1_000_000 and _norm(e.path).startswith(base_n):
                        achados.append((tam, e.path))
            except OSError:
                continue
    achados.sort(reverse=True)
    return [c for _, c in achados[:limite]]


# ---------- placa de vídeo de alto desempenho e tela cheia, por jogo (desfazíveis) ----------

def gpu_alto_aplicar(exes):
    """Diz ao Windows para usar a GPU de alto desempenho nestes jogos. Devolve os que mudaram."""
    if REG is None:
        return []
    feitos = []
    with TRAVA_AJ:
        bk = _backup().setdefault("_gpu_pref", {})
        for exe in exes:
            if not _exe_valido(exe):
                continue
            atual = REG.ler("HKCU", _GPU_CHAVE, exe)
            if isinstance(atual, str) and "GpuPreference=2" in atual:
                continue
            bk.setdefault(exe, atual)  # None = não existia
            REG.escrever("HKCU", _GPU_CHAVE, exe, "GpuPreference=2;", "sz")
            feitos.append(exe)
        if not bk:
            _backup().pop("_gpu_pref", None)
        _guardar_backup()
    return feitos


def gpu_alto_remover(exes=None):
    """Devolve a preferência de GPU de antes. exes=None desfaz todas as que o Th Boost mexeu. Devolve a quantidade."""
    if REG is None:
        return 0
    with TRAVA_AJ:
        bk = _backup().get("_gpu_pref") or {}
        alvo = list(bk) if exes is None else [e for e in exes if e in bk]
        for exe in alvo:
            antes = bk.pop(exe)
            if antes is None:
                REG.apagar("HKCU", _GPU_CHAVE, exe)
            else:
                REG.escrever("HKCU", _GPU_CHAVE, exe, antes, "sz")
        if not bk:
            _backup().pop("_gpu_pref", None)
        _guardar_backup()
    return len(alvo)


def fso_desligar(exes):
    """Desliga as 'otimizações de tela cheia' do Windows para estes jogos (ajuda alguns jogos a parar de engasgar)."""
    if REG is None:
        return []
    feitos = []
    with TRAVA_AJ:
        bk = _backup().setdefault("_fso", {})
        for exe in exes:
            if not _exe_valido(exe):
                continue
            atual = REG.ler("HKCU", _FSO_CHAVE, exe)
            partes = str(atual).split() if atual else []
            if _FSO_FLAG in partes:
                continue
            bk.setdefault(exe, atual)
            novo = " ".join((["~"] if "~" not in partes else []) + partes + [_FSO_FLAG])
            REG.escrever("HKCU", _FSO_CHAVE, exe, novo, "sz")
            feitos.append(exe)
        if not bk:
            _backup().pop("_fso", None)
        _guardar_backup()
    return feitos


def fso_restaurar(exes=None):
    if REG is None:
        return 0
    with TRAVA_AJ:
        bk = _backup().get("_fso") or {}
        alvo = list(bk) if exes is None else [e for e in exes if e in bk]
        for exe in alvo:
            antes = bk.pop(exe)
            if antes is None:
                REG.apagar("HKCU", _FSO_CHAVE, exe)
            else:
                REG.escrever("HKCU", _FSO_CHAVE, exe, antes, "sz")
        if not bk:
            _backup().pop("_fso", None)
        _guardar_backup()
    return len(alvo)


# ---------- taxa de atualização e placas de vídeo ----------

def info_monitor():
    """Resolução, taxa de atualização atual e máxima do monitor, e as placas de vídeo (lido pelo Windows)."""
    cod, saida = powershell("Get-CimInstance Win32_VideoController | Select-Object Name,CurrentRefreshRate,MaxRefreshRate,"
                            "CurrentHorizontalResolution,CurrentVerticalResolution | ConvertTo-Json -Compress", tempo=30)
    if cod != 0 or not saida.strip():
        return None
    try:
        dados = json.loads(saida)
    except ValueError:
        return None
    if isinstance(dados, dict):
        dados = [dados]
    placas, hz, hz_max, res = [], 0, 0, ""
    for d in dados if isinstance(dados, list) else []:
        if not isinstance(d, dict):
            continue
        nome = str(d.get("Name") or "").strip()
        if nome:
            placas.append(nome)
        atual = int(d.get("CurrentRefreshRate") or 0)
        if atual and not hz:
            hz, res = atual, f"{d.get('CurrentHorizontalResolution') or '?'}x{d.get('CurrentVerticalResolution') or '?'}"
        hz_max = max(hz_max, int(d.get("MaxRefreshRate") or 0), atual)
    if not hz:
        return None
    return {"hz": hz, "hz_max": hz_max, "res": res, "placas": placas[:4]}


# ---------- a sessão de jogo ----------

class JogosMixin:
    """Parte do Nucleo que cuida do 'Otimizar antes de jogar'. Roda os passos numa thread; a tela acompanha pelo estado."""

    def jogos_iniciar_estado(self):
        self.pre = {"ativo": False, "fracao": 0.0, "passo": "", "jogo": "", "passos": [], "resumo": None, "fim": 0,
                    "opcoes": dict(PRE_PADRAO)}
        self.sessao = None
        self.monitor = {"estado": "nenhum", "dados": None}
        self._pre_pular = False
        salvo = CONFIG.get("pre_opcoes")
        if isinstance(salvo, dict):
            for k in PRE_PADRAO:
                if isinstance(salvo.get(k), bool):
                    self.pre["opcoes"][k] = salvo[k]

    def pre_snapshot(self):
        p = dict(self.pre)
        p["passos"] = [dict(x) for x in self.pre["passos"]]
        p["opcoes"] = dict(self.pre["opcoes"])
        return p

    def sessao_snapshot(self):
        s = self.sessao
        if not s:
            return None
        return {"jogo": s["jogo"], "desde": int(time.time() - s["inicio"]), "pid": bool(s.get("pid")),
                "parados": [n for _, n in s.get("servicos_nomes", [])], "plano": bool(s.get("plano_anterior")),
                "aguardando": bool(s.get("aguardando")), "auto": bool(s.get("auto"))}

    # ----- leitura do monitor (só quando a página Jogos é aberta) -----

    def monitor_ler(self):
        if self.monitor["estado"] == "lendo":
            return
        self.monitor["estado"] = "lendo"

        def tarefa():
            try:
                self.monitor["dados"] = info_monitor()
                self.monitor["estado"] = "pronto"
            except Exception:
                self.monitor["estado"] = "erro"
        threading.Thread(target=tarefa, daemon=True).start()

    # ----- opções -----

    def pre_definir_opcoes(self, novas):
        for k, v in novas.items():
            if k in PRE_PADRAO and isinstance(v, bool):
                self.pre["opcoes"][k] = v
        CONFIG["pre_opcoes"] = dict(self.pre["opcoes"])
        salvar_config()

    # ----- plano dos passos -----

    def _pre_plano(self, j, op):
        P = []
        if op["fechar"]:
            P.append(("processos", "Fechando o que pesa em segundo plano", self._p_processos))
        if op["ram"]:
            P.append(("ram", "Liberando a RAM", self._p_ram))
        if op["energia"]:
            P.append(("energia", "Plano de energia de desempenho", self._p_energia))
        if op["ajustes"]:
            P.append(("ajustes", "Ajustes de FPS do Windows", self._p_ajustes))
        if op["gpu"] and j and j.get("pasta"):
            P.append(("gpu", "Placa de vídeo de alto desempenho no jogo", self._p_gpu))
        if op["pausar"]:
            P.append(("pausar", "Pausando o Windows Update e a indexação", self._p_pausar))
        if op["leve"]:
            P.append(("leve", "Dando prioridade ao jogo", self._p_leve))
        return P

    def pre_iniciar(self, i=None, opcoes=None, auto=False, pid=None):
        """Roda a otimização antes de jogar. i = índice do jogo (ou None para só otimizar o PC)."""
        if self.pre["ativo"] or self.ext["ativo"] or self.otim["ativo"]:
            return self.msg("Já estou otimizando, aguarde.")
        if self.sessao:  # uma sessão nova por cima perderia o que a anterior precisa devolver (serviços, plano de energia)
            return self.msg("Já existe uma sessão de jogo ativa. Toque em “Terminar sessão” para devolver tudo ao normal antes de começar outra.")
        j = self.jogo(i) if i is not None else None
        if i is not None and not j:
            return
        op = dict(self.pre["opcoes"])
        op.update({k: v for k, v in (opcoes or {}).items() if k in PRE_PADRAO and isinstance(v, bool)})
        passos = self._pre_plano(j, op)
        nome = j["nome"] if j else ""
        self.pre.update({"ativo": True, "fracao": 0.02, "passo": "Preparando...", "jogo": nome, "resumo": None})
        self.pre["passos"] = [{"id": p[0], "nome": p[1], "estado": "pendente", "texto": "", "mb": 0.0} for p in passos]
        self._pre_pular = False
        self.msg(f"Otimizando para jogar{(' ' + nome) if nome else ''}...")
        threading.Thread(target=self._pre_rodar, args=(j, op, passos, auto, pid), daemon=True).start()

    def _pre_rodar(self, j, op, passos, auto, pid):
        E = self.pre
        adm = e_admin()
        ctx = {"jogo": j, "op": op, "ajustes": 0, "plano_anterior": None, "servicos": [], "gpu": 0, "fechados": [],
               "ram_mb": 0.0, "leve_antes": self.mon.modo_leve, "adm": adm, "pid": pid}
        sessao_ok = False
        try:
            antes = self._medidas()
            n = max(1, len(passos))
            for k, (pid_, nome, func) in enumerate(passos):
                P = E["passos"][k]
                E["passo"] = nome + "..."
                E["fracao"] = max(0.02, k / n)
                P["estado"] = "rodando"
                inicio = time.time()
                try:
                    texto, estado = func(ctx)
                except Exception as erro:
                    texto, estado = f"Erro: {erro}", "erro"
                time.sleep(max(0.0, 0.45 - (time.time() - inicio)))
                P.update(estado=estado, texto=texto)
                E["fracao"] = (k + 1) / n
            depois = self._medidas()
            ram = max(0.0, (depois.get("ram_livre") or 0) - (antes.get("ram_livre") or 0))
            E["resumo"] = {"ajustes": ctx["ajustes"], "fechados": ctx["fechados"], "plano": bool(ctx["plano_anterior"]),
                           "pausados": [n_ for _, n_ in ctx["servicos"]], "gpu": ctx["gpu"], "ram_gb": round(ram, 2),
                           "ram_livre": depois.get("ram_livre"), "processos": [antes.get("processos"), depois.get("processos")],
                           "jogo": E["jogo"], "leve": bool(op["leve"])}
            sessao_ok = True
        except Exception as erro:
            self.msg(f"A otimização para jogar parou por um erro: {erro}")
        finally:
            E["passo"] = "Pronto"
            E["fracao"] = 1.0
            E["ativo"] = False
            E["fim"] += 1
        if not sessao_ok:
            self._sessao_restaurar_parcial(ctx)
            return
        self._sessao_abrir(ctx, j, op, auto, pid)

    # ----- passos -----

    def _p_processos(self, ctx):
        nomes = fechar_dispensaveis()
        ctx["fechados"] = nomes
        return (("Fechei: " + ", ".join(nomes) + ".") if nomes else "Nada pesado rodando escondido."), "ok"

    def _p_ram(self, ctx):
        poupar = {p.pid for p in self._pids_do_jogo((ctx["jogo"] or {}).get("pasta"))}  # o jogo já aberto não é mexido
        if ctx.get("pid"):
            poupar.add(ctx["pid"])
        b, texto = liberar_ram(evitar=poupar)
        ctx["ram_mb"] = b / 1048576
        return texto, "ok"

    def _p_energia(self, ctx):
        if REG is None:
            return "Só funciona no Windows.", "pulado"
        txt, anterior, estado = plano_para_jogar()
        if anterior:
            ctx["plano_anterior"] = anterior
            self._sessao_guardar(ctx)
            return txt + " Volta ao normal quando a sessão terminar.", "ok"
        return txt, estado

    def _p_ajustes(self, ctx):
        if REG is None:
            return "Só funciona no Windows.", "pulado"
        feitos = ja = sem_adm = 0
        for ident in FPS_PACOTE:
            a = POR_ID.get(ident)
            if a is None or not a.disponivel():
                continue
            try:
                est = a.estado()
            except Exception:
                est = None
            if est is None:
                continue
            if est is True:
                ja += 1
                continue
            if a.precisa_admin and not ctx["adm"]:
                sem_adm += 1
                continue
            try:
                a.ligar()
                if a.estado() is True:
                    feitos += 1
            except OSError:
                pass
        ctx["ajustes"] = feitos
        self.atualizar_aj()
        partes = [f"{feitos} ligado(s)", f"{ja} já estava(m) ligado(s)"]
        if sem_adm:
            partes.append(f"{sem_adm} precisa(m) de Administrador")
        return ", ".join(partes) + ". Ficam ligados; dá para desligar na lista de ajustes de FPS.", "ok"

    def _p_gpu(self, ctx):
        j = ctx["jogo"]
        exes = exes_da_entrada(j)
        if not exes:
            return "Não achei o programa do jogo na pasta dele.", "pulado"
        feitos = gpu_alto_aplicar(exes)
        ctx["gpu"] = len(exes)
        txt = f"{len(exes)} programa(s) do jogo usam a placa de vídeo de alto desempenho."
        if ctx["op"]["fso"]:
            f = fso_desligar(exes)
            txt += f" Otimização de tela cheia desligada em {len(f)}." if f else " Otimização de tela cheia já estava desligada."
        return txt, "ok"

    def _p_pausar(self, ctx):
        if not ctx["adm"]:
            return "Precisa de Administrador.", "pulado"
        parados, recusados = [], []
        for svc, nome in SERVICOS_PAUSA:
            cod, saida = executar(["sc", "query", svc])
            if cod == 0 and re.search(r"RUNNING|EM EXECU", saida or "", re.IGNORECASE):
                c2, _ = executar(["sc", "stop", svc], timeout=30)
                if c2 == 0:  # v9.1: só conta (e só religa depois) o que o Windows deixou parar
                    parados.append((svc, nome))
                else:
                    recusados.append(nome)
        ctx["servicos"] = parados
        self._sessao_guardar(ctx)  # se o PC desligar no meio do jogo, o Th Boost religa estes serviços na próxima vez
        txt = (("Pausei: " + ", ".join(n for _, n in parados) + ". Voltam quando a sessão terminar.") if parados
               else ("Nada disso estava rodando." if not recusados else ""))
        if recusados:
            txt += (" " if txt else "") + "O Windows não deixou pausar: " + ", ".join(recusados) + "."
        return txt, "ok"

    def _p_leve(self, ctx):
        if not self.mon.modo_leve:
            self.mon.modo_leve = True
            self.mon.forcar = True
        return "Os outros programas ficam com prioridade menor e o jogo em foco com prioridade alta.", "ok"

    # ----- sessão: dura enquanto o jogo roda e devolve tudo ao terminar -----

    # ----- v9.1: a sessão fica gravada; se o Th Boost ou o PC fecharem no meio, tudo volta na próxima vez -----

    def _sessao_guardar(self, ctx_ou_s):
        d = ctx_ou_s or {}
        servicos = d.get("servicos_nomes", d.get("servicos")) or []
        if d.get("plano_anterior") or servicos:
            j = d.get("jogo")
            CONFIG["sessao_pendente"] = {"plano_anterior": d.get("plano_anterior"),
                                         "servicos": [[a, b] for a, b in servicos],
                                         "jogo": (j.get("nome") if isinstance(j, dict) else j) or "",
                                         "pasta": d.get("pasta") or ((j or {}).get("pasta") if isinstance(j, dict) else "") or "",
                                         "t": time.time()}
        else:
            CONFIG.pop("sessao_pendente", None)
        salvar_config()

    def sessao_retomar(self):
        """Chamado ao abrir. Se a última sessão não terminou: continua (o jogo ainda está aberto) ou devolve tudo."""
        p = CONFIG.get("sessao_pendente")
        if not isinstance(p, dict) or self.sessao:
            return
        servicos = [tuple(x) for x in (p.get("servicos") or [])
                    if isinstance(x, list) and len(x) == 2 and all(isinstance(y, str) for y in x)
                    and any(x[0] == a for a, _ in SERVICOS_PAUSA)]  # só religa serviços que o próprio Th Boost pausa
        plano = p.get("plano_anterior") if isinstance(p.get("plano_anterior"), str) and re.fullmatch(_GUID, p.get("plano_anterior") or "") else None
        if plano:
            ativo = next((x for x in listar_planos() if x["ativo"]), None)
            velha = not isinstance(p.get("t"), (int, float)) or time.time() - p["t"] > 14 * 86400
            if velha or (ativo and not PLANO_BOM.search(ativo["nome"])):
                plano = None  # você já trocou o plano depois (ou faz muito tempo): não mexe
        pasta = p.get("pasta") if isinstance(p.get("pasta"), str) else ""
        s = {"jogo": str(p.get("jogo") or ""), "inicio": time.time(), "pid": None, "auto": True, "pasta": pasta,
             "plano_anterior": plano, "servicos_nomes": servicos, "leve_antes": self.mon.modo_leve, "leve": False,
             "aguardando": False}
        if pasta and self._pids_do_jogo(pasta):
            self.sessao = s
            self.msg(f"{s['jogo'] or 'O jogo'} ainda está aberto: continuo cuidando da sessão e devolvo tudo quando fechar.")
            threading.Thread(target=self._sessao_vigiar, args=(s,), daemon=True).start()
            return
        self.sessao = s
        self.sessao_fim("A última sessão de jogo não terminou direito (o Th Boost ou o PC fecharam)")

    def _sessao_abrir(self, ctx, j, op, auto, pid):
        s = {"jogo": ctx["jogo"]["nome"] if ctx["jogo"] else "", "inicio": time.time(), "pid": pid, "auto": auto,
             "pasta": (ctx["jogo"] or {}).get("pasta") or "", "plano_anterior": ctx["plano_anterior"],
             "servicos_nomes": ctx["servicos"], "leve_antes": ctx["leve_antes"], "leve": bool(op["leve"]),
             "aguardando": False}
        tem_algo = s["plano_anterior"] or s["servicos_nomes"] or (op["leve"] and not s["leve_antes"])
        if not tem_algo and not j:
            self.msg("Pronto para jogar! Nada precisou voltar ao normal depois.")
            return
        self.sessao = s
        self._sessao_guardar(s)
        if j and op["abrir"] and not pid:
            s["aguardando"] = True
            self.msg(f"Abrindo {j['nome']}..." if lancar_jogo(j["abrir"]) else f"Não consegui abrir {j['nome']}.")
        else:
            self.msg("Pronto para jogar! Quando terminar, o Th Boost devolve tudo ao normal.")
        threading.Thread(target=self._sessao_vigiar, args=(s,), daemon=True).start()

    def _pids_do_jogo(self, pasta):
        if not pasta:
            return []
        base = _norm(pasta).rstrip("\\/") + os.sep
        achados = []
        for p in psutil.process_iter(["pid", "exe"]):
            try:
                exe = p.info.get("exe")
                if exe and _norm(exe).startswith(base):
                    achados.append(p)
            except (psutil.Error, OSError):
                continue
        return achados

    def _sessao_vigiar(self, s):
        """Espera o jogo abrir, dá prioridade alta a ele e, quando fechar, devolve tudo ao normal."""
        espera = time.time()
        visto, ausentes = False, 0
        while not self.fechando and self.sessao is s:
            self.mon.jogando = True
            procs = self._pids_do_jogo(s["pasta"]) if s["pasta"] else []
            if not procs and not s["pasta"] and s.get("pid"):  # v9.1: jogo sem pasta conhecida: acompanha pelo programa
                try:
                    procs = [psutil.Process(s["pid"])] if psutil.pid_exists(s["pid"]) else []
                except (psutil.Error, OSError):
                    procs = []
            if procs:
                visto, ausentes = True, 0
                s["aguardando"] = False
                if s.get("prioridade_ok") != len(procs):
                    for p in procs:
                        try:
                            p.nice(psutil.HIGH_PRIORITY_CLASS)
                            self.mon.fixos.add(p.pid)
                        except (psutil.Error, OSError):
                            pass
                    s["prioridade_ok"] = len(procs)
            elif visto:
                ausentes += 1
                if ausentes >= 2:
                    break
            elif s["pasta"] and time.time() - espera > 240:
                self.msg(f"Não vi {s['jogo'] or 'o jogo'} abrir. Encerrei a sessão e devolvi tudo ao normal.")
                break
            elif not s["pasta"] and not s.get("pid"):
                return  # sessão manual (sem jogo): fica até a pessoa terminar pelo botão
            time.sleep(3)
        if self.sessao is s:
            self.sessao_fim("O jogo fechou")

    def sessao_fim(self, motivo="Sessão terminada"):
        s = self.sessao
        if not s:
            return
        self.sessao = None
        self.mon.fixos.clear()
        self.mon.jogando = False
        CONFIG.pop("sessao_pendente", None)
        salvar_config()
        feitos = []
        if s.get("servicos_nomes") and e_admin():
            for svc, nome in s["servicos_nomes"]:
                executar(["sc", "start", svc], timeout=30)
            feitos.append("serviços de volta")
        fps = getattr(self, "modo_fps", False) and getattr(self, "_fps_antes", None) is not None
        if fps:  # v9.2: o Modo FPS On continua ligado: ele fica com o plano e o Modo Leve e devolve tudo quando for desligado
            if s.get("plano_anterior") and not self._fps_antes.get("plano"):
                self._fps_antes["plano"] = s["plano_anterior"]
            if s.get("leve"):
                self._fps_antes["leve"] = bool(s.get("leve_antes"))
            feitos.append("o Modo FPS On continua ligado")
        else:
            if s.get("plano_anterior"):
                planos = {p["guid"] for p in listar_planos()}
                alvo = s["plano_anterior"] if s["plano_anterior"] in planos else PLANOS_CONHECIDOS["equilibrado"][0]
                executar(["powercfg", "/setactive", alvo])
                feitos.append("plano de energia de antes")
            if s.get("leve") and not s.get("leve_antes"):
                self.mon.modo_leve = False
                self.mon.forcar = True
                feitos.append("prioridades normais")
        self.msg(f"{motivo}. " + (("De volta ao normal: " + ", ".join(feitos) + ".") if feitos else "Nada precisou voltar."))

    def _sessao_restaurar_parcial(self, ctx):
        """A otimização parou no meio por erro: devolve o que já tinha sido mexido."""
        if ctx["servicos"] and e_admin():
            for svc, _ in ctx["servicos"]:
                executar(["sc", "start", svc], timeout=30)
        if ctx["plano_anterior"]:
            executar(["powercfg", "/setactive", ctx["plano_anterior"]])
        CONFIG.pop("sessao_pendente", None)
        salvar_config()

    # ----- desfazer os perfis por jogo -----

    def jogos_perfis(self):
        """Quantos programas de jogo têm preferência de placa de vídeo / tela cheia mexidas pelo Th Boost."""
        with TRAVA_AJ:
            bk = _backup()
            return {"gpu": len(bk.get("_gpu_pref") or {}), "fso": len(bk.get("_fso") or {})}

    def jogos_desfazer_perfis(self):
        a = gpu_alto_remover()
        b = fso_restaurar()
        return f"Perfis de jogo desfeitos: {a} de placa de vídeo e {b} de tela cheia voltaram ao que eram."

    # ----- vigia: otimiza sozinho quando um jogo abre -----

    def _jogo_aberto(self):
        """Percorre os programas abertos uma vez só e devolve (posição do jogo, programa) do primeiro jogo da lista que está rodando."""
        bases = []
        for idx, j in enumerate(list(self.jogos)):
            pasta = j.get("pasta")
            if pasta:
                bases.append((_norm(pasta).rstrip("\\/") + os.sep, idx))
        if not bases:
            return None
        for p in psutil.process_iter(["pid", "exe"]):
            try:
                exe = p.info.get("exe")
                if not exe:
                    continue
                n = _norm(exe)
                for base, idx in bases:
                    if n.startswith(base):
                        return idx, p
            except (psutil.Error, OSError):
                continue
        return None

    def _vigiar_jogos(self):
        ultimo = {"pid": None, "t": 0}
        while not self.fechando:
            time.sleep(5)
            try:
                if (not CONFIG.get("auto_jogo") or self.sessao or self.pre["ativo"] or self.ext["ativo"]
                        or self.otim["ativo"] or not self.jogos):
                    continue
                achou = self._jogo_aberto()
                if achou:
                    idx, proc = achou
                    if ultimo["pid"] != proc.pid:
                        ultimo.update(pid=proc.pid, t=time.time())
                        self.msg(f"Vi {self.jogos[idx]['nome']} abrindo: otimizando sozinho...")
                        self.pre_iniciar(idx, {"abrir": False}, auto=True, pid=proc.pid)
            except Exception:
                continue


# ---------------- jogos de TODAS as lojas e launchers (não só Steam e Epic) ----------------
#
# A lista junta, nesta ordem de prioridade (o primeiro que aparecer ganha, sem repetir):
#  1. Steam e Epic (leem os arquivos que a própria loja guarda);
#  2. launchers com formato próprio: Riot (VALORANT, League of Legends), Roblox, FiveM e RAGE MP (GTA RP),
#     Rockstar (GTA V), Ubisoft, EA, GOG, Xbox / Microsoft Store e Minecraft;
#  3. programas instalados (registro do Windows) de empresas de jogos, de jogos conhecidos ou em pastas "Games";
#  4. jogos que o próprio Windows (Game Bar) já reconheceu neste PC;
#  5. os que a pessoa adicionou escolhendo o .exe.
# Aqui só se LÊ o computador: nada é alterado. Quem manda no que aparece é a pessoa:
# dá para adicionar um jogo que faltou e tirar da lista o que não é jogo (e trazer de volta depois).

_EDITORAS_JOGOS = re.compile(
    r"riot games|blizzard|electronic arts|\bea games\b|ubisoft|activision|bethesda|rockstar|take-two|2k games|2k sports|"
    r"cd projekt|square enix|bandai namco|capcom|\bsega\b|konami|mihoyo|cognosphere|hoyoverse|mojang|innersloth|gaijin|"
    r"wargaming|netease|tencent|krafton|pubg|nexon|garena|moonton|proxima beta|level infinite|paradox interactive|"
    r"focus entertainment|embracer|warner bros\.? games|\bthq\b|devolver|team17|obsidian entertainment|larian|"
    r"gearbox|respawn|id software|kuro games|hypergryph|com2us|smilegate|pearl abyss|studio wildcard", re.IGNORECASE)
_NOMES_JOGOS = re.compile(
    r"valorant|league of legends|roblox|fivem|minecraft|fortnite|counter-strike|dota ?2|apex legends|call of duty|warzone|"
    r"overwatch|diablo|world of warcraft|hearthstone|genshin|honkai|zenless|wuthering|lost ark|path of exile|"
    r"escape from tarkov|\brust\b|pubg|battlegrounds|rainbow six|far cry|assassin'?s creed|grand theft auto|\bgta\b|"
    r"red dead|cyberpunk|witcher|elden ring|forza|the sims|\bfifa\b|ea sports|rocket league|among us|fall guys|free fire|"
    r"ragnarok|\btibia\b|black desert|albion online|\bosu!|terraria|stardew|warframe|teamfight|legends of runeterra|"
    r"lunar client|badlion|rage ?mp|alt:?v|garry'?s mod|left 4 dead|team fortress|half-life|portal|the finals|helldivers|"
    r"palworld|valheim|sea of thieves|dead by daylight|rocketleague|brawlhalla|krunker|slither|league client", re.IGNORECASE)
# launchers, antitrapaça e utilitários: nunca entram como "jogo", mesmo quando a empresa é de jogos
_NAO_E_JOGO = re.compile(
    r"^(steam|steam client|epic games launcher|epic online services|battle\.net|ea app|ea desktop|origin|ubisoft connect|"
    r"uplay|gog galaxy|riot client|riot vanguard|xbox|xbox app|gaming services|discord|overwolf|playnite|"
    r"easy anti-?cheat|battleye|faceit|geforce|nvidia|amd software|radeon|directx|vulkan|microsoft visual c\+\+|"
    r"rockstar games launcher|rockstar games social club|bethesda\.net launcher|minecraft launcher updater)\b|"
    r"redistributable|redist\b|runtime|sdk\b|update for|hotfix|uninstall|desinstal|wallpaper|server\b|dedicated server|"
    r"benchmark|mod ?manager|crash ?report|\bdlc\b|soundtrack|trilha sonora", re.IGNORECASE)
# programas que o Windows às vezes marca como jogo mas não são
_EXE_NAO_JOGO = re.compile(
    r"^(chrome|msedge|firefox|brave|opera|iexplore|explorer|notepad|code|devenv|discord|teams|ms-teams|slack|zoom|skype|"
    r"spotify|steam|steamwebhelper|epicgameslauncher|battle\.net|obs64|obs32|obs|vlc|winword|excel|powerpnt|outlook|"
    r"onedrive|python|pythonw|node|java|javaw|cmd|powershell|conhost|setup|installer|unins\d*|uninstall)\.exe$", re.IGNORECASE)
_PRIORIDADE_ORIGEM = ("Steam", "Epic")
MAX_JOGOS_MANUAIS = 60
MAX_JOGOS_LISTA = 300


def _env_loja(nome, padrao=""):
    return os.environ.get(nome) or padrao


def _chave_jogo(nome):
    """Nome sem acento, símbolos e espaços: serve para não repetir o mesmo jogo vindo de duas lojas."""
    return re.sub(r"[^a-z0-9]+", "", str(nome).lower())


def _discos():
    """Raízes das unidades do PC (C:\\, D:\\...), sem CD e sem unidades de rede."""
    saida = []
    try:
        for p in psutil.disk_partitions(all=False):
            opts = (p.opts or "").lower()
            if "cdrom" in opts or "remote" in opts or not p.mountpoint:
                continue
            saida.append(p.mountpoint)
    except Exception:
        pass
    if IS_WIN and not saida:
        saida = [f"{l}:\\" for l in "CDEFGH" if os.path.isdir(f"{l}:\\")]
    return saida


def _reg_valores(raiz, caminho):
    """Valores de uma chave do registro, com os nomes em minúsculas. Vazio se não existe."""
    if REG is None:
        return {}
    try:
        return {str(n).lower(): v for n, v in REG.valores(raiz, caminho)}
    except Exception:
        return {}


def _reg_sub(raiz, caminho):
    if REG is None:
        return []
    try:
        return list(REG.subchaves(raiz, caminho))
    except Exception:
        return []


def _pasta_texto(valor):
    """Caminho vindo do registro ou de arquivo: tira aspas, barra no fim e converte / em \\. '' se não for pasta."""
    if not isinstance(valor, str):
        return ""
    v = valor.strip().strip('"').strip()
    if not v or len(v) > 300 or re.search(r"[<>|*?\"]", v):
        return ""
    v = os.path.normpath(v)
    return v if os.path.isabs(v) and os.path.isdir(v) else ""


def _exe_texto(valor):
    """Caminho de um .exe vindo do registro (aceita aspas e ',0' do ícone). '' se não existir."""
    if not isinstance(valor, str):
        return ""
    v = valor.strip()
    m = re.match(r'^"([^"]+)"', v)
    v = m.group(1) if m else re.sub(r",\s*-?\d+\s*$", "", v).strip()
    v = v.strip().strip('"')
    if not v.lower().endswith(".exe") or len(v) > 300 or re.search(r"[<>|*?\"]", v):
        return ""
    v = os.path.normpath(v)
    return v if os.path.isabs(v) and os.path.isfile(v) else ""


def _exe_principal(pasta):
    achados = exes_do_jogo(pasta, 1) if pasta else []
    return achados[0] if achados else ""


def _pasta_estreita(pasta, exe):
    """Pasta ampla demais (C:\\ ou C:\\Games) vira só a pasta do .exe, para não confundir jogos vizinhos."""
    n = _norm(pasta).rstrip("\\/") if pasta else ""
    partes = [x for x in re.split(r"[\\/]+", n) if x]
    if pasta and len(partes) >= 3:
        return pasta
    return os.path.dirname(exe) if exe else ""


def _jogo(nome, origem, pasta="", abrir=None, exe="", extras=None):
    nome = re.sub(r"\s+", " ", str(nome)).strip()
    if not nome or not abrir:
        return None
    j = {"nome": nome[:80], "origem": origem, "pasta": pasta or "", "abrir": abrir}
    if exe:
        j["exe"] = exe
    if extras:
        j["exes"] = [e for e in extras if e]
    return j


def _limpar_nome_pasta(nome):
    nome = re.sub(r"[_]+", " ", str(nome))
    return re.sub(r"\s+", " ", nome).strip()


def _nome_do_exe(exe):
    """Nome de um jogo a partir do arquivo (hollow_knight.exe -> Hollow Knight)."""
    nome = _limpar_nome_pasta(os.path.splitext(os.path.basename(exe))[0])
    return nome.title() if nome.islower() else nome


# ---------- Riot: VALORANT, League of Legends e os outros ----------

_RIOT_NOMES = {"valorant": "VALORANT", "league_of_legends": "League of Legends", "bacon": "Legends of Runeterra",
               "lion": "2XKO"}


def _cliente_riot():
    base = os.path.join(_env_loja("ProgramData", r"C:\ProgramData"), "Riot Games", "RiotClientInstalls.json")
    try:
        with open(base, encoding="utf-8") as f:
            d = json.load(f)
        if isinstance(d, dict):
            for k in ("rc_default", "rc_live", "rc_beta"):
                c = d.get(k)
                if isinstance(c, str) and os.path.isfile(c):
                    return os.path.normpath(c)
    except (OSError, ValueError):
        pass
    for raiz in _discos():
        c = os.path.join(raiz, "Riot Games", "Riot Client", "RiotClientServices.exe")
        if os.path.isfile(c):
            return c
    return ""


def _jogos_riot():
    cliente = _cliente_riot()
    jogos, vistos = [], set()
    base = os.path.join(_env_loja("ProgramData", r"C:\ProgramData"), "Riot Games", "Metadata")
    for arq in glob.glob(os.path.join(base, "*", "*.product_settings.yaml")):
        produto, _, patch = os.path.basename(os.path.dirname(arq)).partition(".")
        if not produto or produto == "riot_client" or produto in vistos:
            continue
        try:
            with open(arq, encoding="utf-8", errors="replace") as f:
                texto = f.read()
        except OSError:
            continue
        m = re.search(r'^\s*product_install_full_path:\s*"?([^"\r\n]+?)"?\s*$', texto, re.M)
        pasta = _pasta_texto(m.group(1)) if m else ""
        if not pasta:
            continue
        vistos.add(produto)
        nome = _RIOT_NOMES.get(produto) or _limpar_nome_pasta(produto).title()
        exe = _exe_principal(pasta)
        if cliente:
            abrir = [cliente, f"--launch-product={produto}", f"--launch-patchline={patch or 'live'}"]
        else:
            abrir = [exe] if exe else None
        j = _jogo(nome, "Riot", pasta, abrir, exe)
        if j:
            jogos.append(j)
    if "valorant" not in vistos and cliente:  # sem os arquivos de controle, mas com a pasta padrão
        for raiz in _discos():
            pasta = os.path.join(raiz, "Riot Games", "VALORANT")
            if os.path.isdir(pasta):
                j = _jogo("VALORANT", "Riot", pasta, [cliente, "--launch-product=valorant", "--launch-patchline=live"], _exe_principal(pasta))
                if j:
                    jogos.append(j)
                break
    return jogos


# ---------- Roblox ----------

def _jogos_roblox():
    la = _env_loja("LOCALAPPDATA")
    if not la:
        return []
    jogos = []
    for pasta_base, launcher in ((os.path.join(la, "Roblox"), ""), (os.path.join(la, "Bloxstrap"), os.path.join(la, "Bloxstrap", "Bloxstrap.exe")),
                                 (os.path.join(la, "Fishstrap"), os.path.join(la, "Fishstrap", "Fishstrap.exe"))):
        player = sorted(glob.glob(os.path.join(pasta_base, "Versions", "*", "RobloxPlayerBeta.exe")), key=lambda p: os.path.getmtime(p), reverse=True)
        if not player:
            continue
        # o Roblox abre pelo site: a pessoa clica em Jogar lá e o Th Boost já vigia o programa do jogo
        abrir = [launcher] if launcher and os.path.isfile(launcher) else "https://www.roblox.com/games"
        j = _jogo("Roblox", "Roblox", pasta_base, abrir, player[0])
        if j:
            jogos.append(j)
            break
    if not jogos:
        loja = os.path.join(la, "Packages", "ROBLOXCORPORATION.ROBLOX_55nm5eh3cm0pr")
        if os.path.isdir(loja):  # versão da Microsoft Store: a pasta do programa fica protegida, então só abre
            j = _jogo("Roblox", "Roblox", "", r"shell:AppsFolder\ROBLOXCORPORATION.ROBLOX_55nm5eh3cm0pr!App")
            if j:
                jogos.append(j)
    return jogos


# ---------- GTA RP: FiveM e RAGE MP ----------

def _jogos_gta_rp():
    jogos = []
    la = _env_loja("LOCALAPPDATA")
    if la:
        exe = os.path.join(la, "FiveM", "FiveM.exe")
        if os.path.isfile(exe):
            j = _jogo("GTA RP (FiveM)", "FiveM", os.path.dirname(exe), [exe], exe)
            if j:
                jogos.append(j)
    for raiz in _discos():
        for sub in ("RAGEMP", "RAGE MP", "ragemp"):
            pasta = os.path.join(raiz, sub)
            for nome_exe in ("updater.exe", "ragemp_v.exe"):
                exe = os.path.join(pasta, nome_exe)
                if os.path.isfile(exe):
                    j = _jogo("GTA RP (RAGE MP)", "RAGE MP", pasta, [exe], exe)
                    if j:
                        jogos.append(j)
                    break
            else:
                continue
            break
        if any(x["origem"] == "RAGE MP" for x in jogos):
            break
    return jogos


# ---------- Rockstar (GTA V, Red Dead) ----------

_ROCKSTAR_NOMES = {"gtav": "Grand Theft Auto V", "grand theft auto v": "Grand Theft Auto V", "gta v": "Grand Theft Auto V",
                   "rdr2": "Red Dead Redemption 2", "red dead redemption 2": "Red Dead Redemption 2",
                   "gta iv": "Grand Theft Auto IV", "gta san andreas": "GTA San Andreas"}


def _jogos_rockstar():
    jogos = []
    for chave in (r"SOFTWARE\WOW6432Node\Rockstar Games", r"SOFTWARE\Rockstar Games"):
        for sub in _reg_sub("HKLM", chave):
            if re.search(r"launcher|social ?club|installer", sub, re.IGNORECASE):
                continue
            v = _reg_valores("HKLM", chave + "\\" + sub)
            pasta = _pasta_texto(v.get("installfolder") or v.get("install dir") or "")
            if not pasta:
                continue
            play = sorted(glob.glob(os.path.join(pasta, "Play*.exe")))
            exe = play[0] if play else _exe_principal(pasta)
            j = _jogo(_ROCKSTAR_NOMES.get(sub.lower()) or sub, "Rockstar", pasta, [exe] if exe else None, exe)
            if j:
                jogos.append(j)
    return jogos


# ---------- Ubisoft, EA e GOG ----------

def _jogos_ubisoft():
    jogos = []
    for chave in (r"SOFTWARE\WOW6432Node\Ubisoft\Launcher\Installs", r"SOFTWARE\Ubisoft\Launcher\Installs"):
        for ident in _reg_sub("HKLM", chave):
            v = _reg_valores("HKLM", chave + "\\" + ident)
            pasta = _pasta_texto(v.get("installdir") or "")
            if not pasta:
                continue
            exe = _exe_principal(pasta)
            abrir = f"uplay://launch/{ident}/0" if ident.isdigit() else ([exe] if exe else None)
            j = _jogo(os.path.basename(pasta), "Ubisoft", pasta, abrir, exe)
            if j:
                jogos.append(j)
    return jogos


def _jogos_ea():
    jogos = []
    for chave in (r"SOFTWARE\WOW6432Node\EA Games", r"SOFTWARE\EA Games", r"SOFTWARE\WOW6432Node\Electronic Arts"):
        for sub in _reg_sub("HKLM", chave):
            v = _reg_valores("HKLM", chave + "\\" + sub)
            pasta = _pasta_texto(v.get("install dir") or v.get("installdir") or "")
            if not pasta:
                continue
            exe = _exe_principal(pasta)
            j = _jogo(sub, "EA", pasta, [exe] if exe else None, exe)
            if j:
                jogos.append(j)
    return jogos


def _jogos_gog():
    jogos = []
    chave = r"SOFTWARE\WOW6432Node\GOG.com\Games"
    for ident in _reg_sub("HKLM", chave):
        v = _reg_valores("HKLM", chave + "\\" + ident)
        pasta = _pasta_texto(v.get("path") or "")
        exe = _exe_texto(v.get("exe") or "") or _exe_principal(pasta)
        j = _jogo(v.get("gamename") or os.path.basename(pasta or ""), "GOG", pasta, [exe] if exe else None, exe)
        if j and pasta:
            jogos.append(j)
    return jogos


# ---------- Xbox / Microsoft Store ----------

_B32 = "0123456789abcdefghjkmnpqrstvwxyz"


def _hash_editora(editora):
    """O trecho final do nome de família de um app da Microsoft Store (ex.: 8wekyb3d8bbwe), a partir do Publisher."""
    h = hashlib.sha256(editora.encode("utf-16-le")).digest()[:8]
    bits = int.from_bytes(h, "big") << 1
    return "".join(_B32[(bits >> (60 - 5 * i)) & 31] for i in range(13))


def _app_do_manifesto(pasta_conteudo):
    """'shell:AppsFolder\\Nome_hash!Id' de um jogo da Xbox, lendo o appxmanifest.xml. '' se não der."""
    arq = os.path.join(pasta_conteudo, "appxmanifest.xml")
    try:
        if os.path.getsize(arq) > 2_000_000:
            return ""
        import xml.etree.ElementTree as ET
        raiz = ET.parse(arq).getroot()
    except Exception:
        return ""
    ident = app = None
    for el in raiz.iter():
        marca = el.tag.rsplit("}", 1)[-1]
        if marca == "Identity" and ident is None:
            ident = el.attrib
        elif marca == "Application" and app is None:
            app = el.attrib.get("Id")
    if not ident or not app or not ident.get("Name") or not ident.get("Publisher"):
        return ""
    if not re.fullmatch(r"[A-Za-z0-9.\-]+", ident["Name"]) or not re.fullmatch(r"[A-Za-z0-9.\-]+", app):
        return ""
    return "shell:AppsFolder\\%s_%s!%s" % (ident["Name"], _hash_editora(ident["Publisher"]), app)


def _jogos_xbox():
    jogos = []
    for raiz in _discos():
        base = os.path.join(raiz, "XboxGames")
        if not os.path.isdir(base):
            continue
        try:
            pastas = sorted(os.scandir(base), key=lambda e: e.name.lower())
        except OSError:
            continue
        for e in pastas[:80]:
            try:
                if not e.is_dir(follow_symlinks=False):
                    continue
            except OSError:
                continue
            conteudo = os.path.join(e.path, "Content")
            if not os.path.isdir(conteudo):
                continue
            exe = _exe_principal(conteudo)
            abrir = _app_do_manifesto(conteudo) or ([exe] if exe else None)
            j = _jogo(_limpar_nome_pasta(e.name), "Xbox", e.path, abrir, exe)
            if j:
                jogos.append(j)
    return jogos


# ---------- Minecraft ----------

def _jogos_minecraft():
    la, ap = _env_loja("LOCALAPPDATA"), _env_loja("APPDATA")
    pf = _env_loja("ProgramFiles(x86)", r"C:\Program Files (x86)")
    launcher = os.path.join(pf, "Minecraft Launcher", "MinecraftLauncher.exe")
    loja_java = os.path.join(la, "Packages", "Microsoft.4297127D64EC6_8wekyb3d8bbwe") if la else ""
    jogos = []
    # o programa que de fato roda o jogo (Java) fica na pasta "runtime" do launcher
    java = ""
    for base in (os.path.join(loja_java, "LocalCache", "Local", "runtime") if loja_java else "", os.path.join(ap, ".minecraft", "runtime") if ap else ""):
        if base and os.path.isdir(base):
            for raiz, subs, arqs in os.walk(base):
                if raiz[len(base):].count(os.sep) >= 6:
                    subs[:] = []
                if "javaw.exe" in arqs:
                    java = os.path.join(raiz, "javaw.exe")
                    break
            if java:
                break
    # sobe até a pasta "runtime" para cobrir qualquer versão de Java que o launcher baixar
    pasta = ""
    if java:
        corte = java.lower().rfind(os.sep + "runtime" + os.sep)
        pasta = java[:corte + len("runtime") + 1] if corte > 0 else os.path.dirname(java)
    if os.path.isfile(launcher):
        j = _jogo("Minecraft", "Minecraft", pasta or os.path.dirname(launcher), [launcher], launcher, [java])
    elif loja_java and os.path.isdir(loja_java):
        j = _jogo("Minecraft", "Minecraft", pasta, r"shell:AppsFolder\Microsoft.4297127D64EC6_8wekyb3d8bbwe!Minecraft", "", [java])
    else:
        j = None
    if j:
        jogos.append(j)
    if la and os.path.isdir(os.path.join(la, "Packages", "Microsoft.MinecraftUWP_8wekyb3d8bbwe")):
        j = _jogo("Minecraft Bedrock", "Minecraft", "", r"shell:AppsFolder\Microsoft.MinecraftUWP_8wekyb3d8bbwe!App")
        if j:
            jogos.append(j)
    return jogos


# ---------- programas instalados (registro do Windows) ----------

_CHAVES_UNINSTALL = (("HKLM", r"SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall"),
                     ("HKLM", r"SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall"),
                     ("HKCU", r"SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall"))


def _e_pasta_de_jogos(pasta):
    return bool(re.search(r"[\\/](games|jogos)[\\/]", pasta + os.sep, re.IGNORECASE))


def _origem_pela_editora(editora):
    e = editora.lower()
    if "blizzard" in e:
        return "Battle.net"
    if "electronic arts" in e or e.strip() in ("ea", "ea games"):
        return "EA"
    if "ubisoft" in e:
        return "Ubisoft"
    if "riot" in e:
        return "Riot"
    if "rockstar" in e:
        return "Rockstar"
    if "mihoyo" in e or "cognosphere" in e or "hoyoverse" in e:
        return "HoYoverse"
    return "Instalado"


def _jogos_instalados():
    jogos, vistos = [], set()
    for raiz, caminho in _CHAVES_UNINSTALL:
        for sub in _reg_sub(raiz, caminho):
            if len(jogos) >= 120:
                return jogos
            v = _reg_valores(raiz, caminho + "\\" + sub)
            nome = str(v.get("displayname") or "").strip()
            if not nome or v.get("systemcomponent") == 1 or v.get("parentkeyname") or v.get("releasetype"):
                continue
            if _NAO_E_JOGO.search(nome):
                continue
            editora = str(v.get("publisher") or "")
            pasta = _pasta_texto(v.get("installlocation") or "")
            exe_icone = _exe_texto(v.get("displayicon") or "")
            if not pasta and exe_icone:
                pasta = os.path.dirname(exe_icone)
            if not pasta or not os.path.isdir(pasta):
                continue
            e_jogo = bool(_EDITORAS_JOGOS.search(editora) or _NOMES_JOGOS.search(nome) or _e_pasta_de_jogos(pasta))
            if not e_jogo:
                continue
            chave = _chave_jogo(nome)
            if chave in vistos:
                continue
            vistos.add(chave)
            exe = _exe_principal(pasta) or (exe_icone if not _EXE_NAO_JOGO.search(os.path.basename(exe_icone or "")) else "")
            if not exe:
                continue
            j = _jogo(nome, _origem_pela_editora(editora), _pasta_estreita(pasta, exe), [exe], exe)
            if j:
                jogos.append(j)
    return jogos


# ---------- jogos que o Windows (Game Bar) já reconheceu ----------

def _jogos_windows():
    jogos = []
    base = r"System\GameConfigStore\Children"
    for sub in _reg_sub("HKCU", base)[:200]:
        v = _reg_valores("HKCU", base + "\\" + sub)
        exe = _exe_texto(v.get("matchedexefullpath") or "")
        if not exe or _EXE_NAO_JOGO.search(os.path.basename(exe)) or _IGNORAR_EXE.search(os.path.basename(exe)):
            continue
        if re.search(r"[\\/](windows|system32|syswow64)[\\/]", exe, re.IGNORECASE):
            continue
        pasta = os.path.dirname(exe)
        nome = _limpar_nome_pasta(os.path.basename(pasta)) if len(re.split(r"[\\/]+", pasta)) > 3 else ""
        if not nome or re.fullmatch(r"(bin|binaries|win64|x64|x86|game|release|retail)", nome, re.IGNORECASE):
            nome = _nome_do_exe(exe)
        if _NAO_E_JOGO.search(nome):
            continue
        j = _jogo(nome, "Windows", pasta, [exe], exe)
        if j:
            jogos.append(j)
    return jogos


# ---------- jogos adicionados pela pessoa ----------

def _exe_manual_valido(exe):
    return (isinstance(exe, str) and 8 < len(exe) < 300 and os.path.isabs(exe) and exe.lower().endswith(".exe")
            and not re.search(r"[;\"<>|*?]", exe) and os.path.isfile(exe)
            and not re.search(r"[\\/](windows|system32|syswow64)[\\/]", exe, re.IGNORECASE))


def _jogos_manuais():
    jogos = []
    for item in (CONFIG.get("jogos_manuais") or [])[:MAX_JOGOS_MANUAIS]:
        if not isinstance(item, dict) or not _exe_manual_valido(item.get("exe")):
            continue
        exe = os.path.normpath(item["exe"])
        j = _jogo(item.get("nome") or _nome_do_exe(exe), "Adicionado", os.path.dirname(exe), [exe], exe)
        if j:
            j["manual"] = True
            jogos.append(j)
    return jogos


def jogo_manual_adicionar(exe, nome=""):
    """Guarda um jogo escolhido pela pessoa. Devolve (ok, texto)."""
    if not _exe_manual_valido(exe):
        return False, "Escolha o programa do jogo (um arquivo .exe que exista)."
    exe = os.path.normpath(exe)
    lista = [i for i in (CONFIG.get("jogos_manuais") or []) if isinstance(i, dict)]
    if any(_norm(i.get("exe", "")) == _norm(exe) for i in lista):
        return False, "Esse jogo já está na lista."
    if len(lista) >= MAX_JOGOS_MANUAIS:
        return False, "A lista de jogos adicionados está cheia."
    nome = re.sub(r"[\x00-\x1f<>]", "", str(nome or "")).strip()[:60] or _nome_do_exe(exe)
    lista.append({"nome": nome, "exe": exe})
    CONFIG["jogos_manuais"] = lista
    ocultos = [c for c in (CONFIG.get("jogos_ocultos") or []) if c != _chave_jogo(nome)]
    CONFIG["jogos_ocultos"] = ocultos
    salvar_config()
    return True, nome


def jogo_tirar_da_lista(jogo):
    """Tira um jogo da lista: o que foi adicionado à mão é apagado; o detectado fica escondido (dá para trazer de volta)."""
    if jogo.get("manual"):
        CONFIG["jogos_manuais"] = [i for i in (CONFIG.get("jogos_manuais") or [])
                                   if not (isinstance(i, dict) and _norm(i.get("exe", "")) == _norm(jogo.get("exe", "")))]
    else:
        ocultos = [c for c in (CONFIG.get("jogos_ocultos") or []) if isinstance(c, str)]
        chave = _chave_jogo(jogo["nome"])
        if chave not in ocultos:
            ocultos.append(chave)
        CONFIG["jogos_ocultos"] = ocultos[:300]
    salvar_config()


def escolher_exe_do_jogo():
    """Abre a janela do Windows para escolher o .exe do jogo. '' se a pessoa cancelar."""
    if not IS_WIN:
        return ""
    script = ("Add-Type -AssemblyName System.Windows.Forms; Add-Type -AssemblyName System.Drawing; "
              "$f=New-Object System.Windows.Forms.Form; $f.TopMost=$true; $f.ShowInTaskbar=$false; $f.StartPosition='CenterScreen'; "
              "$f.Size=New-Object System.Drawing.Size(1,1); $f.Opacity=0; $f.Show(); "
              "$d=New-Object System.Windows.Forms.OpenFileDialog; $d.Title='Escolha o programa do jogo (.exe)'; "
              "$d.Filter='Programas (*.exe)|*.exe'; $d.CheckFileExists=$true; "
              "if($d.ShowDialog($f) -eq 'OK'){[Console]::OutputEncoding=[Text.Encoding]::UTF8; Write-Output $d.FileName}; $f.Close()")
    cod, saida = executar(["powershell", "-STA", "-NoProfile", "-NonInteractive", "-ExecutionPolicy", "Bypass", "-Command", script], timeout=600)
    if cod != 0:
        return ""
    linhas = [x.strip() for x in saida.splitlines() if x.strip()]
    return linhas[-1] if linhas else ""


# ---------- junta tudo ----------

def _fontes_de_jogos():
    return [_jogos_steam, _jogos_epic, _jogos_riot, _jogos_roblox, _jogos_gta_rp, _jogos_rockstar, _jogos_ubisoft,
            _jogos_ea, _jogos_gog, _jogos_xbox, _jogos_minecraft, _jogos_instalados, _jogos_windows, _jogos_manuais]


def _mesma_pasta(a, b):
    return a == b or a.startswith(b + os.sep) or b.startswith(a + os.sep)


def jogos_detectar_tudo():
    """Lista única de jogos, sem repetir, sem launchers e sem os que a pessoa tirou da lista."""
    ocultos = {c for c in (CONFIG.get("jogos_ocultos") or []) if isinstance(c, str)}
    nomes, pastas, exes, lista = set(), [], set(), []
    for fonte in _fontes_de_jogos():
        try:
            achados = fonte() or []
        except Exception:
            achados = []
        for j in achados:
            chave = _chave_jogo(j["nome"])
            if not chave or chave in nomes:
                continue
            if not j.get("manual") and (chave in ocultos or any(t in j["nome"].lower() for t in EXCLUIR_JOGOS)
                                         or _NAO_E_JOGO.search(j["nome"])):
                continue
            pasta_n = _norm(j["pasta"]) if j.get("pasta") else ""
            exe_n = _norm(j["exe"]) if j.get("exe") else ""
            if not j.get("manual"):
                if exe_n and exe_n in exes:
                    continue
                if pasta_n and any(_mesma_pasta(pasta_n, p) for p in pastas):
                    continue
            nomes.add(chave)
            if pasta_n:
                pastas.append(pasta_n)
            if exe_n:
                exes.add(exe_n)
            j["chave"] = chave
            lista.append(j)
            if len(lista) >= MAX_JOGOS_LISTA:
                return sorted(lista, key=lambda g: g["nome"].lower())
    return sorted(lista, key=lambda g: g["nome"].lower())


def exes_da_entrada(jogo):
    """Os programas de um jogo que o Th Boost ajusta: os extras conhecidos e os maiores da pasta."""
    achados = [e for e in (jogo.get("exes") or []) if _exe_valido(e) and os.path.isfile(e)]
    achados += exes_do_jogo(jogo.get("pasta"))
    return list(dict.fromkeys(achados))


def icone_do_jogo(jogo):
    """Imagem (ícone do programa) de um jogo fora da Steam. None se não der. Fica guardada na pasta de capas."""
    exe = jogo.get("exe") or ""
    if not IS_WIN or not exe or not os.path.isfile(exe):
        return None
    destino = os.path.join(pasta_capas(), "ic_" + hashlib.md5(_norm(exe).encode("utf-8", "replace")).hexdigest()[:12] + ".png")
    if os.path.isfile(destino) and os.path.getsize(destino) > 100:
        return destino
    b64 = lambda s: base64.b64encode(s.encode("utf-8")).decode("ascii")
    script = ("Add-Type -AssemblyName System.Drawing; "
              f"$e=[Text.Encoding]::UTF8.GetString([Convert]::FromBase64String('{b64(exe)}')); "
              f"$o=[Text.Encoding]::UTF8.GetString([Convert]::FromBase64String('{b64(destino)}')); "
              "$i=[System.Drawing.Icon]::ExtractAssociatedIcon($e); "
              "if($i){$i.ToBitmap().Save($o,[System.Drawing.Imaging.ImageFormat]::Png)}")
    executar(["powershell", "-NoProfile", "-NonInteractive", "-ExecutionPolicy", "Bypass", "-Command", script], timeout=30)
    return destino if os.path.isfile(destino) and os.path.getsize(destino) > 100 else None


# ---------------- manutenção: Correções, Backup, diagnóstico e estatísticas do Dashboard ----------------
#
# Regras:
#  - nada daqui apaga arquivos pessoais; o backup só COPIA (nunca apaga nem muda a origem);
#  - cada correção é um comando conhecido do próprio Windows (SFC, DISM, chkdsk...), com confirmação na tela;
#  - tudo o que vem da tela é só um identificador: o programa procura o caminho/comando na própria lista.

# ---------- correções ----------

CORRECOES = [
    # id, nome, descrição, admin, demora, reinicia, confirmação (None = roda direto)
    ("sfc", "Reparar arquivos do Windows", "Verifica os arquivos do sistema e conserta os que estiverem danificados (SFC). Resolve travamentos e erros estranhos.",
     True, "5 a 20 min", False, None),
    ("dism", "Reparar a imagem do Windows", "Baixa do Windows Update as peças originais para consertar o sistema (DISM). Use se o SFC não conseguiu consertar. Precisa de internet.",
     True, "10 a 30 min", True, None),
    ("chkdsk", "Verificar o disco", "Procura erros no sistema de arquivos sem precisar reiniciar. Não apaga nada.",
     True, "2 a 15 min", False, None),
    ("chkdsk_agendar", "Reparar o disco ao reiniciar", "Marca o disco para ser consertado no próximo reinício. O reinício demora mais uma vez só.",
     True, "rápido", True, "Agendar o reparo do disco?|O Windows vai verificar e consertar o disco na próxima vez que o PC ligar, o que pode demorar de alguns minutos a uma hora. Não desligue o PC durante isso."),
    ("wu", "Consertar o Windows Update", "Zera os arquivos temporários do Windows Update quando as atualizações travam, falham ou ficam em 0%.",
     True, "1 min", True, "Consertar o Windows Update?|As atualizações já baixadas serão baixadas de novo. Nada é perdido."),
    ("icones", "Reconstruir ícones e miniaturas", "Corrige ícones em branco, errados ou miniaturas que não aparecem. A barra de tarefas some por alguns segundos.",
     False, "10 s", False, "Reconstruir os ícones?|A barra de tarefas e a área de trabalho vão piscar e voltar em alguns segundos. Salve o que estiver aberto."),
    ("explorer", "Reiniciar o Explorer", "Destrava a barra de tarefas, o menu Iniciar e a área de trabalho quando ficam congelados.",
     False, "5 s", False, "Reiniciar o Explorer?|A barra de tarefas e a área de trabalho somem por alguns segundos e voltam. Seus programas continuam abertos."),
    ("som", "Consertar o áudio", "Reinicia os serviços de som do Windows. Resolve “sem dispositivo de áudio” e som que sumiu.",
     True, "10 s", False, None),
    ("spooler", "Destravar a impressão", "Limpa a fila de impressão presa e reinicia o serviço de impressão.",
     True, "10 s", False, "Destravar a impressão?|Trabalhos de impressão que estiverem na fila serão cancelados."),
    ("hora", "Acertar o relógio", "Sincroniza data e hora com a internet. Resolve sites com erro de certificado por causa da hora errada.",
     True, "5 s", False, None),
    ("loja", "Reparar a Microsoft Store", "Limpa o cache da Loja. Resolve downloads parados e Loja que não abre. A Loja abre sozinha ao terminar.",
     False, "30 s", False, None),
    ("rede", "Consertar a internet", "Limpa o DNS, renova o IP e reinicia a pilha de rede do Windows. Use quando a internet some ou trava.",
     True, "30 s", True, "Consertar a internet?|A conexão cai por alguns segundos e é preciso reiniciar o PC depois. Redes Wi-Fi salvas continuam salvas."),
]
CORRECOES_POR_ID = {c[0]: c for c in CORRECOES}

# sites oficiais (só estes endereços são abertos; a tela manda apenas o identificador)
LINKS_OFICIAIS = {
    "vcredist": ("Visual C++ (faltando DLL, jogo não abre)", "Microsoft", "https://aka.ms/vs/17/release/vc_redist.x64.exe"),
    "directx": ("DirectX (erros d3dx9, xinput)", "Microsoft", "https://www.microsoft.com/download/details.aspx?id=35"),
    "dotnet": (".NET (programas que pedem o .NET)", "Microsoft", "https://dotnet.microsoft.com/download/dotnet"),
    "nvidia": ("Driver da placa NVIDIA", "NVIDIA", "https://www.nvidia.com/Download/index.aspx"),
    "amd": ("Driver da placa AMD", "AMD", "https://www.amd.com/en/support/download/drivers.html"),
    "intel": ("Driver Intel (vídeo e rede)", "Intel", "https://www.intel.com/content/www/us/en/download-center/home.html"),
}


def correcoes_publico():
    out = []
    for ident, nome, desc, adm, demora, reinicia, conf in CORRECOES:
        t, _, p = (conf or "").partition("|")
        out.append({"id": ident, "nome": nome, "desc": desc, "admin": adm, "demora": demora, "reinicia": reinicia,
                    "conf": [t, p] if conf else None})
    return out


def links_publico():
    return [{"id": k, "nome": v[0], "site": v[1]} for k, v in LINKS_OFICIAIS.items()]


# ---------- backup ----------

PASTAS_BACKUP = [("docs", "Documentos", "Personal", "Documents"), ("desktop", "Área de Trabalho", "Desktop", "Desktop"),
                 ("imagens", "Imagens", "My Pictures", "Pictures"), ("videos", "Vídeos", "My Video", "Videos"),
                 ("musicas", "Músicas", "My Music", "Music"),
                 ("downloads", "Downloads", "{374DE290-123F-4565-9164-39C4925E467B}", "Downloads")]
BACKUP_PADRAO = ["docs", "desktop", "imagens"]
PASTA_BACKUP_NOME = "Th Boost Backup"
ARQ_REGISTRO_BACKUP = "th_boost_backup.json"
_SEM_COPIA = re.compile(r"^(~\$.*|thumbs\.db|desktop\.ini|.*\.thboost-tmp)$", re.IGNORECASE)
ATRIB_NUVEM = 0x1000 | 0x40000 | 0x400000  # arquivo só na nuvem (OneDrive): copiar baixaria tudo, então é pulado


def pasta_do_usuario(valor_registro, padrao):
    c = ""
    if REG is not None:
        v = REG.ler("HKCU", r"Software\Microsoft\Windows\CurrentVersion\Explorer\User Shell Folders", valor_registro)
        if isinstance(v, str) and v.strip():
            c = os.path.expandvars(v)
    if not c or not os.path.isabs(c):
        base = _env("USERPROFILE")
        c = os.path.join(base, padrao) if base else ""
    return c if c and os.path.isabs(c) else ""


def pastas_de_backup():
    res = []
    for ident, nome, reg, padrao in PASTAS_BACKUP:
        c = pasta_do_usuario(reg, padrao)
        res.append({"id": ident, "nome": nome, "caminho": c, "existe": bool(c and os.path.isdir(c))})
    return res


def destinos_de_backup():
    """Unidades onde dá para guardar o backup (não lista CD/DVD nem unidades de rede)."""
    sistema = (os.environ.get("SystemDrive") or "C:").upper()
    res = []
    try:
        particoes = psutil.disk_partitions(all=False)
    except (OSError, RuntimeError):
        particoes = []
    for p in particoes:
        opts = (p.opts or "").lower()
        if "cdrom" in opts or not p.fstype or "remote" in opts:
            continue
        letra = (p.mountpoint or p.device or "")[:2].upper()
        if not re.fullmatch(r"[A-Z]:", letra) and not os.environ.get("TOTIMIZE_BACKUP_TESTE"):
            continue
        try:
            u = psutil.disk_usage(p.mountpoint)
        except OSError:
            continue
        res.append({"id": letra, "montagem": p.mountpoint, "livre_gb": round(u.free / 1024 ** 3, 1),
                    "total_gb": round(u.total / 1024 ** 3, 1), "removivel": "removable" in opts,
                    "sistema": letra == sistema})
    return res


def _lp(caminho):
    """Caminhos longos no Windows (mais de 260 caracteres) precisam do prefixo especial."""
    if IS_WIN and len(caminho) > 240 and not caminho.startswith("\\\\?\\"):
        return "\\\\?\\" + os.path.abspath(caminho)
    return caminho


def _pontos_restauracao():
    """Lista de pontos de restauração do Windows (do mais novo ao mais velho)."""
    cod, saida = powershell("Get-ComputerRestorePoint | Select-Object SequenceNumber,Description,CreationTime | "
                            "ConvertTo-Json -Compress", tempo=40)
    if cod != 0 or not saida.strip():
        return []
    try:
        dados = json.loads(saida)
    except ValueError:
        return []
    if isinstance(dados, dict):
        dados = [dados]
    res = []
    for d in dados if isinstance(dados, list) else []:
        if not isinstance(d, dict):
            continue
        t = str(d.get("CreationTime") or "")
        try:
            quando = datetime.strptime(t[:14], "%Y%m%d%H%M%S")
        except ValueError:
            continue
        res.append({"n": d.get("SequenceNumber"), "nome": str(d.get("Description") or "")[:80],
                    "quando": quando.strftime("%d/%m/%Y %H:%M"), "ts": quando.timestamp()})
    return sorted(res, key=lambda r: -r["ts"])[:12]


def criar_ponto_manual(descricao="Th Boost (manual)"):
    """Cria um ponto de restauração agora. O Windows normalmente só deixa criar um por dia: a trava é levantada só durante a criação."""
    if REG is None:
        return False, "Só funciona no Windows."
    chave = r"SOFTWARE\Microsoft\Windows NT\CurrentVersion\SystemRestore"
    antigo = REG.ler("HKLM", chave, "SystemRestorePointCreationFrequency")
    try:
        REG.escrever("HKLM", chave, "SystemRestorePointCreationFrequency", 0, "dword")
    except OSError:
        pass
    try:
        desc = re.sub(r"[^\w ()\-]", "", descricao)[:60] or "Th Boost"
        cod, saida = powershell(f"Checkpoint-Computer -Description '{desc}' -RestorePointType MODIFY_SETTINGS", tempo=240)
    finally:
        try:
            if antigo is None:
                REG.apagar("HKLM", chave, "SystemRestorePointCreationFrequency")
            else:
                REG.escrever("HKLM", chave, "SystemRestorePointCreationFrequency", antigo, "dword")
        except OSError:
            pass
    return cod == 0, saida


# ---------- o que a tela de Dashboard e o diagnóstico leem ----------

def nome_do_processador():
    if REG is None:
        return ""
    v = REG.ler("HKLM", r"HARDWARE\DESCRIPTION\System\CentralProcessor\0", "ProcessorNameString")
    return re.sub(r"\s+", " ", v).strip() if isinstance(v, str) else ""


def _por_pct(valor, pontos):
    """Interpola linearmente: pontos = [(entrada, nota), ...] em ordem crescente de entrada."""
    if valor <= pontos[0][0]:
        return pontos[0][1]
    for (x0, y0), (x1, y1) in zip(pontos, pontos[1:]):
        if valor <= x1:
            return y0 + (y1 - y0) * (valor - x0) / max(1e-9, x1 - x0)
    return pontos[-1][1]


class ManutencaoMixin:
    """Estatísticas, tarefas com passos (Correções, Backup, Espaço), diagnóstico e pontuação."""

    # ===== estatísticas que o Dashboard mostra =====

    def estat_iniciar_estado(self):
        e = CONFIG.get("stats") if isinstance(CONFIG.get("stats"), dict) else {}
        self.stats = {"mb": float(e.get("mb") or 0), "otimizacoes": int(e.get("otimizacoes") or 0),
                      "extremas": int(e.get("extremas") or 0), "supremas": int(e.get("supremas") or 0),
                      "correcoes": int(e.get("correcoes") or 0), "procs": int(e.get("procs") or 0), "ultima": str(e.get("ultima") or ""),
                      "ultima_tipo": str(e.get("ultima_tipo") or "")}

    def _estat_gravar(self):
        CONFIG["stats"] = dict(self.stats)
        salvar_config()

    def estat_otimizacao(self, mb, tipo, interrompida=False):
        s = self.stats
        s["mb"] += max(0.0, float(mb or 0))
        if not interrompida:
            if tipo == "suprema":
                s["supremas"] += 1
            elif tipo == "extrema":
                s["extremas"] += 1
            else:
                s["otimizacoes"] += 1
            s["ultima"] = datetime.now().strftime("%d/%m/%Y %H:%M")
            s["ultima_tipo"] = tipo
        self._estat_gravar()

    def estat_limpeza(self, b):
        self.stats["mb"] += max(0.0, b / 1048576)
        self._estat_gravar()

    # ===== tarefas com passos =====

    def trab_iniciar_estado(self):
        vazio = lambda: {"ativo": False, "parando": False, "fracao": 0.0, "passo": "", "titulo": "", "id": "",
                         "passos": [], "resumo": None, "fim": 0}
        self.trab = {"correcao": vazio(), "backup": vazio(), "espaco": vazio(), "processos": vazio()}
        self.diag = {"estado": "nenhum", "quando": 0.0, "lento": {}}
        self.pontos = {"estado": "nenhum", "itens": [], "quando": 0.0}
        self.espaco = {"pastas": [], "arquivos": [], "quando": ""}
        self._prog_proc = {}
        self._proc_ofertados = set()
        self.estat_iniciar_estado()

    def trab_snapshot(self):
        res = {}
        for k, t in self.trab.items():
            d = dict(t)
            d["passos"] = [dict(p) for p in t["passos"]]
            res[k] = d
        return res

    def _pesado_ocupado(self):
        return (self.otim["ativo"] or self.ext["ativo"] or self.pre["ativo"] or self.trab["correcao"]["ativo"]
                or self.trab["processos"]["ativo"])

    def trab_iniciar(self, chave, ident, titulo, passos, ctx=None):
        T = self.trab[chave]
        if T["ativo"]:
            self.msg("Já tem uma tarefa desse tipo rodando. Aguarde terminar.")
            return False
        T.update(ativo=True, parando=False, fracao=0.02, passo="Preparando...", titulo=titulo, id=ident, resumo=None)
        T["passos"] = [{"id": p[0], "nome": p[1], "estado": "pendente", "texto": ""} for p in passos]
        threading.Thread(target=self._trab_rodar, args=(chave, passos, ctx or {}), daemon=True).start()
        return True

    def trab_parar(self, chave):
        if chave in self.trab and self.trab[chave]["ativo"]:
            self.trab[chave]["parando"] = True
            self.msg("Parando...")

    def _trab_rodar(self, chave, passos, ctx):
        T = self.trab[chave]
        adm = e_admin()
        ctx["parar"] = lambda: T["parando"] or self.fechando
        n = max(1, len(passos))
        textos, piores = [], "ok"
        try:
            for i, (pid, nome, func, precisa_adm) in enumerate(passos):
                P = T["passos"][i]
                if T["parando"] or self.fechando:
                    for outro in T["passos"][i:]:
                        outro.update(estado="pulado", texto="Interrompido")
                    break
                if precisa_adm and not adm:
                    P.update(estado="pulado", texto="Precisa de Administrador. Feche e abra o Th Boost pelo atalho.")
                    textos.append(P["texto"])
                    piores = "pulado" if piores == "ok" else piores
                    continue
                T["passo"] = nome + "..."
                T["fracao"] = max(0.02, i / n)
                P["estado"] = "rodando"
                ctx["prog"] = (lambda f, i=i: T.__setitem__("fracao", max(0.02, min(0.99, (i + max(0.0, min(1.0, f))) / n))))
                inicio = time.time()
                try:
                    texto, estado = func(ctx)
                except Exception as erro:
                    texto, estado = f"Erro: {erro}", "erro"
                time.sleep(max(0.0, 0.5 - (time.time() - inicio)))
                P.update(estado=estado, texto=texto)
                textos.append(texto)
                if estado == "erro":
                    piores = "erro"
                elif estado == "pulado" and piores == "ok":
                    piores = "pulado"
                T["fracao"] = (i + 1) / n
            T["resumo"] = {"estado": piores, "texto": textos[-1] if textos else "", "textos": textos,
                           "reiniciar": bool(ctx.get("reiniciar")), "interrompido": bool(T["parando"]),
                           "dados": ctx.get("resumo") or {}}
        except Exception as erro:
            T["resumo"] = {"estado": "erro", "texto": f"Parou por um erro: {erro}", "textos": [], "reiniciar": False,
                           "interrompido": False, "dados": {}}
        finally:
            T["passo"] = "Pronto"
            T["fracao"] = 1.0
            T["ativo"] = False
            T["parando"] = False
            T["fim"] += 1
            if chave == "correcao":
                self.stats["correcoes"] += 1
                self._estat_gravar()

    # ===== correções =====

    def correcao_iniciar(self, ident):
        c = CORRECOES_POR_ID.get(ident)
        if c is None:
            raise ValueError("correção desconhecida")
        if REG is None:
            return self.msg("As correções só funcionam no Windows.")
        if self._pesado_ocupado():
            return self.msg("Espere a otimização em andamento terminar.")
        passos = getattr(self, "_c_" + ident)()
        self.trab_iniciar("correcao", ident, c[1], passos, {"ident": ident})
        self.msg(f"{c[1]}: começando...")

    def _c_sfc(self):
        return [("sfc", "Verificando os arquivos do Windows", self._cx_sfc, True)]

    def _cx_sfc(self, ctx):
        cod, saida = _executar_longo(["sfc", "/scannow"], 3600, ctx["parar"])
        if cod in (-1, -2):
            return ("Interrompido." if cod == -1 else "Passou de 1 hora e eu parei.") + " Dá para rodar de novo quando quiser.", "pulado"
        t = (saida or "").replace("\x00", "").lower()
        if re.search(r"did not find any integrity|n.o encontrou nenhuma viola", t):
            return "Nenhum arquivo do Windows estava danificado.", "ok"
        if re.search(r"unable to fix|n.o p.de (reparar|corrigir)|n.o foi poss.vel (reparar|corrigir)|n.o conseguiu (reparar|corrigir)", t):
            return ("Há arquivos danificados que o SFC não conseguiu consertar. Rode “Reparar a imagem do Windows” e depois "
                    "este de novo."), "erro"
        if re.search(r"successfully repaired|reparou com .xito|reparados com .xito|os reparou|corrigiu", t):
            ctx["reiniciar"] = True
            return "Achei arquivos danificados e consertei. Reinicie o PC para terminar.", "ok"
        if cod == 0:
            return "Verificação concluída.", "ok"
        return "O Windows não conseguiu rodar a verificação agora (pode haver uma atualização pendente). Reinicie e tente de novo.", "erro"

    def _c_dism(self):
        return [("dism", "Reparando a imagem do Windows", self._cx_dism, True)]

    def _cx_dism(self, ctx):
        cod, saida = _executar_longo(["DISM.exe", "/Online", "/Cleanup-Image", "/RestoreHealth"], 3600, ctx["parar"])
        if cod in (-1, -2):
            return ("Interrompido." if cod == -1 else "Passou de 1 hora e eu parei.") + " Dá para rodar de novo quando quiser.", "pulado"
        if cod == 0:
            ctx["reiniciar"] = True
            return "A imagem do Windows está íntegra. Rode o “Reparar arquivos do Windows” agora e reinicie.", "ok"
        return "Não consegui reparar agora. Confira a internet e se há atualização pendente, e tente de novo.", "erro"

    def _c_chkdsk(self):
        return [("chkdsk", "Verificando o disco", self._cx_chkdsk, True)]

    def _cx_chkdsk(self, ctx):
        letra = (os.environ.get("SystemDrive") or "C:")[:2]
        cod, saida = _executar_longo(["chkdsk", letra, "/scan"], 3600, ctx["parar"])
        if cod in (-1, -2):
            return "Interrompido." if cod == -1 else "Passou de 1 hora e eu parei. Tente de novo com o PC parado.", "pulado"
        if cod == 0:
            return "O Windows examinou o disco e não achou problemas.", "ok"
        if cod == 1:
            return "O Windows achou e corrigiu pequenos erros no disco.", "ok"
        if cod == 2:  # v9.1: 2 = só sobrou uma faxina interna que pede /f; não é erro do disco
            return "O disco está bom. O Windows só sugeriu uma faxina interna, que acontece sozinha com o tempo.", "ok"
        return ("O disco tem erros que só dá para consertar ao reiniciar. Use “Reparar o disco ao reiniciar”. "
                "Se o aviso voltar, faça cópia dos seus arquivos: o disco pode estar falhando."), "erro"

    def _c_chkdsk_agendar(self):
        return [("agendar", "Marcando o disco para verificação", self._cx_chkdsk_agendar, True)]

    def _cx_chkdsk_agendar(self, ctx):
        letra = (os.environ.get("SystemDrive") or "C:")[:2]
        cod, _ = executar(["fsutil", "dirty", "set", letra], timeout=30)
        if cod != 0:
            return "O Windows não aceitou marcar o disco.", "erro"
        ctx["reiniciar"] = True
        return "Pronto. Na próxima vez que o PC ligar, o Windows verifica e conserta o disco.", "ok"

    def _c_wu(self):
        return [("wu", "Consertando o Windows Update", self._cx_wu, True)]

    def _cx_wu(self, ctx):
        serv = ("wuauserv", "cryptSvc", "bits", "msiserver")
        raiz = _env("SYSTEMROOT") or _env("WINDIR")
        alvos = [os.path.join(raiz, "SoftwareDistribution"), os.path.join(raiz, "System32", "catroot2")] if raiz else []
        renomeadas, falhas = 0, 0
        try:
            for s in serv:
                executar(["net", "stop", s, "/y"], timeout=60)
            sufixo = ".thboost-" + datetime.now().strftime("%Y%m%d%H%M%S")
            for a in alvos:
                if os.path.isdir(a) and not _e_ligacao(a):
                    try:
                        os.rename(a, a + sufixo)
                        renomeadas += 1
                    except OSError:
                        falhas += 1
                    # cópias de segurança de correções anteriores (criadas só por este programa) são apagadas
                    for velho in glob.glob(a + ".thboost-*"):
                        if velho != a + sufixo and os.path.isdir(velho) and not _e_ligacao(velho):
                            shutil.rmtree(velho, ignore_errors=True)
        finally:
            for s in ("cryptSvc", "bits", "wuauserv", "msiserver"):
                executar(["net", "start", s], timeout=60)
        if falhas and not renomeadas:
            return "Não consegui limpar as pastas do Windows Update (algum programa está usando). Reinicie e tente de novo.", "erro"
        ctx["reiniciar"] = True
        return "Windows Update zerado. Reinicie o PC e procure atualizações de novo.", "ok"

    def _c_icones(self):
        return [("icones", "Reconstruindo ícones e miniaturas", self._cx_icones, False)]

    def _cx_icones(self, ctx):
        L = _env("LOCALAPPDATA")
        apagados = 0
        executar(["taskkill", "/F", "/IM", "explorer.exe"], timeout=20)
        try:
            time.sleep(1.0)
            alvos = []
            if L:
                alvos.append(os.path.join(L, "IconCache.db"))
                pasta = os.path.join(L, "Microsoft", "Windows", "Explorer")
                alvos += glob.glob(os.path.join(pasta, "iconcache_*.db")) + glob.glob(os.path.join(pasta, "thumbcache_*.db"))
            for a in alvos:
                if os.path.isfile(a) and not _e_ligacao(a) and _remover_arquivo(a):
                    apagados += 1
        finally:
            self._iniciar_explorer()
        return f"Cache de ícones e miniaturas refeito ({apagados} arquivo(s)). Os ícones voltam em alguns segundos.", "ok"

    def _iniciar_explorer(self):
        try:
            subprocess.Popen(["explorer.exe"])
        except OSError:
            pass

    def _c_explorer(self):
        return [("explorer", "Reiniciando o Explorer", self._cx_explorer, False)]

    def _cx_explorer(self, ctx):
        executar(["taskkill", "/F", "/IM", "explorer.exe"], timeout=20)
        time.sleep(1.0)
        self._iniciar_explorer()
        return "O Explorer foi reiniciado. A barra de tarefas deve voltar em instantes.", "ok"

    def _c_som(self):
        return [("som", "Reiniciando o áudio do Windows", self._cx_som, True)]

    def _cx_som(self, ctx):
        executar(["net", "stop", "audiosrv", "/y"], timeout=40)
        executar(["net", "stop", "AudioEndpointBuilder", "/y"], timeout=40)
        a, _ = executar(["net", "start", "AudioEndpointBuilder"], timeout=40)
        b, _ = executar(["net", "start", "audiosrv"], timeout=40)
        return (("Os serviços de áudio foram reiniciados.", "ok") if a == 0 and b == 0
                else ("Não consegui reiniciar o áudio. Reinicie o PC.", "erro"))

    def _c_spooler(self):
        return [("spooler", "Limpando a fila de impressão", self._cx_spooler, True)]

    def _cx_spooler(self, ctx):
        raiz = _env("SYSTEMROOT") or _env("WINDIR")
        executar(["net", "stop", "spooler", "/y"], timeout=40)
        apagados = 0
        try:
            pasta = os.path.join(raiz, "System32", "spool", "PRINTERS") if raiz else ""
            if pasta and os.path.isdir(pasta) and not _e_ligacao(pasta):
                for e in os.scandir(pasta):
                    if e.is_file(follow_symlinks=False) and _remover_arquivo(e.path):
                        apagados += 1
        finally:
            cod, _ = executar(["net", "start", "spooler"], timeout=40)
        return ((f"Fila limpa ({apagados} arquivo(s)) e impressão reiniciada.", "ok") if cod == 0
                else ("Limpei a fila, mas não consegui reiniciar o serviço de impressão. Reinicie o PC.", "erro"))

    def _c_hora(self):
        return [("hora", "Sincronizando o relógio", self._cx_hora, True)]

    def _cx_hora(self, ctx):
        executar(["net", "start", "w32time"], timeout=30)
        cod, _ = executar(["w32tm", "/resync", "/force"], timeout=40)
        return (("Relógio sincronizado com a internet.", "ok") if cod == 0
                else ("Não consegui sincronizar. Confira a internet e tente de novo.", "erro"))

    def _c_loja(self):
        return [("loja", "Limpando o cache da Microsoft Store", self._cx_loja, False)]

    def _cx_loja(self, ctx):
        cod, _ = executar(["wsreset.exe"], timeout=120)
        return (("Cache da Loja limpo. Ela abre sozinha.", "ok") if cod == 0
                else ("O Windows não deixou limpar o cache da Loja agora.", "erro"))

    def _c_rede(self):
        return [("dns", "Limpando o DNS", self._cx_rede_dns, True), ("ip", "Renovando o IP", self._cx_rede_ip, True),
                ("pilha", "Reiniciando a pilha de rede", self._cx_rede_pilha, True)]

    def _cx_rede_dns(self, ctx):
        cod, _ = executar(["ipconfig", "/flushdns"], timeout=30)
        return ("Cache DNS limpo.", "ok") if cod == 0 else ("Não consegui limpar o DNS.", "erro")

    def _cx_rede_ip(self, ctx):
        return ("IP renovado.", "ok") if renovar_ip() else ("O IP não renovou (pode ser rede sem DHCP).", "pulado")

    def _cx_rede_pilha(self, ctx):
        texto, ok = resetar_rede()
        if ok:
            ctx["reiniciar"] = True
        return texto, ("ok" if ok else "erro")

    # ===== backup =====

    def bk_config(self):
        c = CONFIG.get("backup") if isinstance(CONFIG.get("backup"), dict) else {}
        pastas = [p for p in (c.get("pastas") or BACKUP_PADRAO) if p in {x[0] for x in PASTAS_BACKUP}]
        return {"destino": c.get("destino") if isinstance(c.get("destino"), str) else "", "pastas": pastas,
                "ultimo": c.get("ultimo") if isinstance(c.get("ultimo"), dict) else None}

    def bk_definir(self, destino, pastas):
        validos = {d["id"] for d in destinos_de_backup()}
        if destino and destino not in validos:
            raise ValueError("destino inválido")
        ids = {x[0] for x in PASTAS_BACKUP}
        if not isinstance(pastas, list) or any(p not in ids for p in pastas):
            raise ValueError("pastas inválidas")
        c = self.bk_config()
        CONFIG["backup"] = {"destino": destino, "pastas": list(dict.fromkeys(pastas)), "ultimo": c["ultimo"]}
        salvar_config()

    def _bk_raiz(self, destino=None):
        d = destino or self.bk_config()["destino"]
        for x in destinos_de_backup():
            if x["id"] == d:
                return os.path.join(x["montagem"], PASTA_BACKUP_NOME, USUARIO.title() or "Usuario")
        return ""

    def backup_arquivos_iniciar(self):
        cfg = self.bk_config()
        raiz = self._bk_raiz()
        if not raiz:
            return self.msg("Escolha primeiro onde guardar o backup (um pendrive, HD externo ou outro disco).")
        if not cfg["pastas"]:
            return self.msg("Marque pelo menos uma pasta para o backup.")
        passos = [("contar", "Procurando o que mudou desde o último backup", self._bx_contar, False),
                  ("copiar", "Copiando seus arquivos", self._bx_copiar, False),
                  ("registro", "Anotando o backup", self._bx_registro, False)]
        if self.trab_iniciar("backup", "arquivos", "Backup dos arquivos", passos, {"raiz": raiz, "cfg": cfg}):
            self.msg("Backup dos arquivos começando...")

    def _bx_contar(self, ctx):
        raiz, cfg = ctx["raiz"], ctx["cfg"]
        fontes = [(p["id"], p["nome"], p["caminho"]) for p in pastas_de_backup() if p["id"] in cfg["pastas"] and p["existe"]]
        if not fontes:
            return "As pastas escolhidas não existem neste PC.", "erro"
        lista, total, vistos, pulados_nuvem = [], 0, 0, 0
        for ident, nome, origem in fontes:
            if ctx["parar"]():
                return "Interrompido.", "pulado"
            for dirpath, dirnames, nomes in os.walk(origem, followlinks=False):
                if ctx["parar"]():
                    return "Interrompido.", "pulado"
                dirnames[:] = [d for d in dirnames if not _e_ligacao(os.path.join(dirpath, d))]
                rel = os.path.relpath(dirpath, origem)
                for n in nomes:
                    if _SEM_COPIA.match(n):
                        continue
                    src = os.path.join(dirpath, n)
                    try:
                        st = os.lstat(src)
                    except OSError:
                        continue
                    if _atributo_ligacao(st) or not stat_is_reg(st):
                        continue
                    if getattr(st, "st_file_attributes", 0) & ATRIB_NUVEM:
                        pulados_nuvem += 1
                        continue
                    vistos += 1
                    dst = os.path.join(raiz, nome, "" if rel == "." else rel, n)
                    try:
                        sd = os.stat(_lp(dst))
                        if sd.st_size == st.st_size and sd.st_mtime >= st.st_mtime - 2:
                            continue
                    except OSError:
                        pass
                    lista.append((src, dst, st.st_size))
                    total += st.st_size
        try:
            os.makedirs(_lp(raiz), exist_ok=True)
            livre = psutil.disk_usage(raiz).free
        except OSError as erro:
            return f"Não consegui usar o destino ({erro}).", "erro"
        if total + 256 * 1048576 > livre:
            return (f"Não cabe: preciso de {tam_texto(total)} e o destino tem só {tam_texto(livre)} livres. "
                    "Escolha outro destino ou menos pastas."), "erro"
        ctx["lista"], ctx["total"], ctx["vistos"], ctx["nuvem"] = lista, total, vistos, pulados_nuvem
        if not lista:
            return f"Nada novo para copiar: {vistos} arquivo(s) já estão no backup.", "ok"
        return f"{len(lista)} arquivo(s) novos ou alterados ({tam_texto(total)}) de {vistos}.", "ok"

    def _bx_copiar(self, ctx):
        lista = ctx.get("lista")
        if lista is None:
            return "Nada a copiar.", "pulado"
        if not lista:
            return "Nada novo para copiar.", "ok"
        total, feito, n, falhas = ctx["total"] or 1, 0, 0, 0
        ultimo = 0.0
        for src, dst, tam in lista:
            if ctx["parar"]():
                ctx["parcial"] = True
                break
            tmp = _lp(dst) + ".thboost-tmp"
            try:
                os.makedirs(_lp(os.path.dirname(dst)), exist_ok=True)
                with open(_lp(src), "rb") as a, open(tmp, "wb") as b:
                    while True:
                        bloco = a.read(4 * 1048576)
                        if not bloco:
                            break
                        b.write(bloco)
                        feito += len(bloco)
                        if time.time() - ultimo > 0.4:
                            ultimo = time.time()
                            ctx["prog"](feito / total)
                            self.trab["backup"]["passos"][1]["texto"] = f"{n} de {len(lista)} · {tam_texto(feito)} de {tam_texto(total)}"
                        if ctx["parar"]():
                            raise InterruptedError
                shutil.copystat(_lp(src), tmp)
                os.replace(tmp, _lp(dst))
                n += 1
            except InterruptedError:
                ctx["parcial"] = True
                try:
                    os.remove(tmp)
                except OSError:
                    pass
                break
            except OSError:
                falhas += 1  # arquivo aberto por outro programa, sem permissão etc.
                try:
                    os.remove(tmp)
                except OSError:
                    pass
        ctx["copiados"], ctx["bytes"], ctx["falhas"] = n, feito, falhas
        texto = f"{n} arquivo(s) copiados ({tam_texto(feito)})."
        if falhas:
            texto += f" {falhas} em uso ou sem permissão ficaram de fora."
        if ctx.get("parcial"):
            return "Interrompido. " + texto + " Rode de novo para continuar de onde parou.", "pulado"
        return texto, "ok"

    def _bx_registro(self, ctx):
        if ctx.get("lista") is None:  # a contagem falhou (sem espaço, destino ruim): não anota um backup que não houve
            return "Nada a anotar.", "pulado"
        info = {"quando": datetime.now().strftime("%d/%m/%Y %H:%M"), "arquivos": ctx.get("copiados", 0),
                "mb": round(ctx.get("bytes", 0) / 1048576, 1), "pastas": ctx["cfg"]["pastas"], "destino": ctx["cfg"]["destino"],
                "parcial": bool(ctx.get("parcial"))}
        try:
            with open(os.path.join(ctx["raiz"], ARQ_REGISTRO_BACKUP), "w", encoding="utf-8") as f:
                json.dump(info, f, ensure_ascii=False, indent=1)
        except OSError:
            pass
        if not ctx.get("parcial"):
            c = self.bk_config()
            CONFIG["backup"] = {"destino": c["destino"], "pastas": c["pastas"], "ultimo": info}
            salvar_config()
        ctx["resumo"] = info
        return "Backup anotado." if not ctx.get("parcial") else "Backup parcial anotado.", "ok"

    def backup_restaurar_iniciar(self):
        raiz = self._bk_raiz()
        if not raiz or not os.path.isdir(raiz):
            return self.msg("Não achei um backup do Th Boost no destino escolhido.")
        if self.trab_iniciar("backup", "restaurar", "Restaurar arquivos do backup",
                             [("restaurar", "Devolvendo o que está faltando", self._bx_restaurar, False)], {"raiz": raiz}):
            self.msg("Restaurando arquivos do backup...")

    def _bx_restaurar(self, ctx):
        raiz = ctx["raiz"]
        n = pulados = 0
        for p in pastas_de_backup():
            origem_bk = os.path.join(raiz, p["nome"])
            if not p["caminho"] or not os.path.isdir(origem_bk):
                continue
            for dirpath, dirnames, nomes in os.walk(origem_bk, followlinks=False):
                if ctx["parar"]():
                    return f"Interrompido. {n} arquivo(s) devolvidos.", "pulado"
                dirnames[:] = [d for d in dirnames if not _e_ligacao(os.path.join(dirpath, d))]
                rel = os.path.relpath(dirpath, origem_bk)
                for nome in nomes:
                    if nome.endswith(".thboost-tmp"):
                        continue
                    src = os.path.join(dirpath, nome)
                    dst = os.path.join(p["caminho"], "" if rel == "." else rel, nome)
                    if os.path.lexists(_lp(dst)):
                        pulados += 1  # nunca sobrescreve o que já existe
                        continue
                    try:
                        os.makedirs(_lp(os.path.dirname(dst)), exist_ok=True)
                        shutil.copy2(_lp(src), _lp(dst))
                        n += 1
                    except OSError:
                        pass
        return f"{n} arquivo(s) devolvidos. {pulados} já existiam e foram deixados como estão.", "ok"

    def backup_ponto_iniciar(self):
        def passo(ctx):
            ok, saida = criar_ponto_manual()
            self.pontos["quando"] = 0.0  # força reler a lista
            if ok:
                return "Ponto de restauração criado.", "ok"
            if re.search(r"disabled|desativ|desligad|protection|prote", saida or "", re.IGNORECASE):
                return "A Proteção do Sistema está desligada neste disco. Ligue em “Ligar a proteção” abaixo e tente de novo.", "erro"
            return "O Windows não criou o ponto agora.", "erro"
        if self.trab_iniciar("backup", "ponto", "Ponto de restauração", [("ponto", "Criando o ponto de restauração", passo, True)]):
            self.msg("Criando um ponto de restauração...")

    def backup_protecao_iniciar(self):
        def passo(ctx):
            letra = (os.environ.get("SystemDrive") or "C:")[:2] + "\\"
            cod, _ = powershell(f"Enable-ComputerRestore -Drive '{letra}'", tempo=60)
            self.pontos["quando"] = 0.0
            return (("Proteção do Sistema ligada.", "ok") if cod == 0 else ("O Windows não deixou ligar a proteção.", "erro"))
        if self.trab_iniciar("backup", "protecao", "Proteção do Sistema", [("protecao", "Ligando a Proteção do Sistema", passo, True)]):
            self.msg("Ligando a Proteção do Sistema...")

    def backup_drivers_iniciar(self):
        raiz = self._bk_raiz()
        if not raiz:
            return self.msg("Escolha primeiro onde guardar o backup.")

        def passo(ctx):
            pasta = os.path.join(raiz, "Drivers")
            try:
                os.makedirs(pasta, exist_ok=True)
            except OSError as erro:
                return f"Não consegui criar a pasta no destino ({erro}).", "erro"
            cod, saida = _executar_longo(["pnputil", "/export-driver", "*", pasta], 1200, ctx["parar"])
            if cod in (-1, -2):
                return "Interrompido." if cod == -1 else "Demorou demais e eu parei.", "pulado"
            if cod != 0:
                return "O Windows não exportou os drivers.", "erro"
            try:
                tam = tamanho_pasta(pasta)
                qtd = len([d for d in os.listdir(pasta) if os.path.isdir(os.path.join(pasta, d))])
            except OSError:
                tam, qtd = 0, 0
            return f"{qtd} driver(s) guardados ({tam_texto(tam)}). Para usar depois: Gerenciador de Dispositivos > Atualizar driver > escolher esta pasta.", "ok"
        if self.trab_iniciar("backup", "drivers", "Backup dos drivers", [("drivers", "Exportando os drivers instalados", passo, True)]):
            self.msg("Exportando os drivers...")

    def _pasta_backups_ajustes(self):
        p = os.path.join(pasta_do_programa(), "backups")
        try:
            os.makedirs(p, exist_ok=True)
        except OSError:
            return ""
        return p

    def backup_ajustes_iniciar(self):
        def passo(ctx):
            pasta = self._pasta_backups_ajustes()
            if not pasta:
                return "Não consegui criar a pasta de backups ao lado do programa.", "erro"
            nome = "ThBoost-ajustes-" + datetime.now().strftime("%Y%m%d-%H%M%S") + ".zip"
            alvo = os.path.join(pasta, nome)
            n = 0
            with zipfile.ZipFile(alvo, "w", zipfile.ZIP_DEFLATED) as z:
                for arq in (ARQ_BACKUP, ARQ_EXTREMO, ARQ_CONFIG):
                    if os.path.isfile(arq):
                        z.write(arq, os.path.basename(arq))
                        n += 1
            if not n:
                os.remove(alvo)
                return "Ainda não há ajustes do Th Boost para guardar.", "pulado"
            extra = ""
            raiz = self._bk_raiz()
            if raiz:
                try:
                    os.makedirs(raiz, exist_ok=True)
                    shutil.copy2(alvo, os.path.join(raiz, nome))
                    extra = " Uma cópia também foi para o destino do backup."
                except OSError:
                    pass
            return f"Configurações do Th Boost guardadas ({n} arquivo(s)).{extra}", "ok"
        if self.trab_iniciar("backup", "ajustes", "Backup dos ajustes", [("ajustes", "Guardando as configurações do Th Boost", passo, False)]):
            self.msg("Guardando as configurações do Th Boost...")

    def _pastas_com_backups(self):
        """v9.1: a pasta ao lado do programa e também o destino do backup (pen drive/HD): assim um backup sobrevive
        a apagar a pasta do Th Boost ou a trocar de PC."""
        res = []
        for p in (self._pasta_backups_ajustes(), self._bk_raiz()):
            if p and os.path.isdir(p) and p not in res:
                res.append(p)
        return res

    def backups_ajustes_listar(self):
        vistos, res = set(), []
        for pasta in self._pastas_com_backups():
            try:
                nomes = os.listdir(pasta)
            except OSError:
                continue
            for nome in nomes:
                if nome in vistos or not re.fullmatch(r"ThBoost-ajustes-\d{8}-\d{6}\.zip", nome):
                    continue
                vistos.add(nome)
                st = os.stat(os.path.join(pasta, nome))
                res.append({"nome": nome, "quando": datetime.fromtimestamp(st.st_mtime).strftime("%d/%m/%Y %H:%M"),
                            "kb": max(1, st.st_size // 1024)})
        return sorted(res, key=lambda r: r["nome"], reverse=True)[:8]

    def backup_ajustes_importar(self, nome):
        if not isinstance(nome, str) or not re.fullmatch(r"ThBoost-ajustes-\d{8}-\d{6}\.zip", nome):
            raise ValueError("nome inválido")
        caminho = next((os.path.join(p, nome) for p in self._pastas_com_backups() if os.path.isfile(os.path.join(p, nome))), "")
        if not caminho:
            return self.msg("Não achei esse backup.")

        def passo(ctx):
            esperados = {os.path.basename(ARQ_BACKUP): ARQ_BACKUP, os.path.basename(ARQ_EXTREMO): ARQ_EXTREMO}
            lidos = {}
            with zipfile.ZipFile(caminho) as z:
                for m in z.namelist():
                    if m in esperados:
                        if z.getinfo(m).file_size > 2_000_000:
                            return "O arquivo de backup é grande demais para ser dos ajustes.", "erro"
                        dados = json.loads(z.read(m).decode("utf-8"))
                        if not isinstance(dados, dict):
                            return "O arquivo de backup está com defeito.", "erro"
                        lidos[m] = dados
            if not lidos:
                return "Esse backup não tem os registros dos ajustes.", "erro"
            for m, dados in lidos.items():
                alvo = esperados[m]
                if os.path.isfile(alvo):
                    shutil.copy2(alvo, alvo + ".antes")
                with open(alvo, "w", encoding="utf-8") as f:
                    json.dump(dados, f, ensure_ascii=False, indent=1)
            global _BACKUP
            with TRAVA_AJ:
                _BACKUP = None
            with TRAVA_EXT:
                _EXT_MEM.clear()
            self.atualizar_aj()
            self.ext["desfazer"] = _ext_tem_algo(_ext_ler())
            return "Registros dos ajustes devolvidos. Os botões de desfazer voltam a funcionar como na data do backup.", "ok"
        if self.trab_iniciar("backup", "importar", "Devolver configurações", [("importar", "Lendo o backup", passo, False)]):
            self.msg("Devolvendo as configurações...")

    def backup_abrir_pasta(self):
        raiz = self._bk_raiz()
        if not raiz or not os.path.isdir(raiz):
            return self.msg("Ainda não existe um backup no destino escolhido.")
        try:
            subprocess.Popen(["explorer.exe", raiz])
        except OSError:
            self.msg("Não consegui abrir a pasta.")

    def backup_lista(self):
        cfg = self.bk_config()
        self.pontos_ler()
        raiz = self._bk_raiz()
        pastas = pastas_de_backup()
        for p in pastas:
            p["marcada"] = p["id"] in cfg["pastas"]
        return {"destinos": destinos_de_backup(), "pastas": pastas, "config": cfg, "admin": e_admin(),
                "tem_backup": bool(raiz and os.path.isdir(raiz)), "pontos": {"estado": self.pontos["estado"], "itens": list(self.pontos["itens"])},
                "ajustes": self.backups_ajustes_listar()}

    # ===== pontos de restauração (leitura em segundo plano) =====

    def pontos_ler(self, forcar=False):
        p = self.pontos
        if p["estado"] == "lendo" or REG is None:
            return
        if not forcar and p["estado"] == "pronto" and time.time() - p["quando"] < 120:
            return
        p["estado"] = "lendo"

        def tarefa():
            try:
                p["itens"] = _pontos_restauracao()
                p["estado"] = "pronto"
            except Exception:
                p["estado"] = "erro"
            p["quando"] = time.time()
        threading.Thread(target=tarefa, daemon=True).start()

    # ===== diagnóstico e pontuação =====

    def diag_atualizar(self):
        """Leituras lentas (disco, pontos de restauração, monitor) em segundo plano, no máximo a cada 3 minutos."""
        d = self.diag
        if d["estado"] == "lendo" or REG is None:
            return
        if d["estado"] == "pronto" and time.time() - d["quando"] < 180:
            return
        d["estado"] = "lendo"

        def tarefa():
            lento = {}
            try:
                cod, saida = powershell("Get-PhysicalDisk | Select-Object FriendlyName,MediaType,HealthStatus | ConvertTo-Json -Compress", tempo=40)
                if cod == 0 and saida.strip():
                    dados = json.loads(saida)
                    lento["discos"] = [x for x in (dados if isinstance(dados, list) else [dados]) if isinstance(x, dict)]
                self.pontos_ler(True)
                for _ in range(80):
                    if self.pontos["estado"] != "lendo":
                        break
                    time.sleep(0.25)
                lento["pontos"] = list(self.pontos["itens"])
                self.monitor_ler()
                for _ in range(80):
                    if self.monitor["estado"] != "lendo":
                        break
                    time.sleep(0.25)
                lento["monitor"] = self.monitor.get("dados")
                try:
                    lento["memoria"] = self.memoria_agora()
                except Exception:
                    lento["memoria"] = None
                d["estado"] = "pronto"
            except Exception:
                d["estado"] = "erro"
            d["lento"] = lento
            d["quando"] = time.time()
        threading.Thread(target=tarefa, daemon=True).start()

    def dashboard(self):
        """Tudo que a página Dashboard mostra: pontuação por categoria, o que falta fazer e números do sistema."""
        self.diag_atualizar()
        a = self.amostra or {}
        lento = self.diag.get("lento") or {}
        win = REG is not None
        aj = self.aj or {}
        cats, achados = [], []

        def cat(ident, nome, valor, dica, ir):
            cats.append({"id": ident, "nome": nome, "valor": None if valor is None else int(round(max(0, min(100, valor)))),
                         "dica": dica, "ir": ir})

        def achado(ident, nivel, titulo, texto, ir=None, acao=None, rotulo=""):
            achados.append({"id": ident, "nivel": nivel, "titulo": titulo, "texto": texto, "ir": ir, "acao": acao, "rotulo": rotulo})

        # 1) ajustes de desempenho
        cand = [x for x in CATALOGO if (x.rec or x.ext) and x.risco != "medio" and aj.get(x.id) is not None]
        lig = sum(1 for x in cand if aj.get(x.id) is True)
        cat("desempenho", "Ajustes de desempenho", (100 * lig / len(cand)) if cand else None,
            f"{lig} de {len(cand)} ajustes seguros ligados" if cand else "Só no Windows", "extremo")
        if cand and len(cand) - lig >= 3:
            achado("ajustes", "aviso", f"{len(cand) - lig} ajustes de desempenho ainda desligados",
                   "A Otimização Extrema liga todos os que são seguros, com ponto de restauração e botão de desfazer.", "extremo", None, "Abrir a Otimização Extrema")
        # 2) inicialização
        try:
            ini = [i for i in listar_inicio() if i["ligado"]] if win else []
        except Exception:
            ini = []
        pesados = [i for i in ini if INICIO_DISPENSAVEL.match(i["nome"])]
        cat("inicio", "Inicialização do Windows", _por_pct(len(ini), [(0, 100), (6, 100), (12, 55), (25, 20)]) if win else None,
            f"{len(ini)} programas abrem com o Windows" if win else "Só no Windows", "inicializacao")
        if len(pesados) >= 2:
            achado("inicio", "aviso", f"{len(pesados)} programas pesados abrem com o Windows",
                   "Launchers e atualizadores (" + ", ".join(i["nome"] for i in pesados[:3]) + ") atrasam a inicialização e comem memória.", "inicializacao", None, "Ver a inicialização")
        # 3) espaço em disco
        disco = a.get("disco")
        if disco:
            livre_pct = 100 - disco["pct"]
            cat("espaco", "Espaço em disco", _por_pct(livre_pct, [(3, 5), (10, 35), (20, 70), (35, 100)]),
                f"{disco['livre']:.0f} GB livres de {disco['total']:.0f} GB", "disco")
            if livre_pct < 10:
                achado("espaco", "ruim", "O disco está quase cheio", f"Só {livre_pct:.0f}% livre. Abaixo de 10% o Windows e os jogos ficam lentos.", "extremo", None, "Limpar agora")
            elif livre_pct < 20:
                achado("espaco", "aviso", "Pouco espaço livre no disco", f"{livre_pct:.0f}% livre. O ideal é manter pelo menos 20%.", "disco", None, "Limpeza de disco")
        else:
            cat("espaco", "Espaço em disco", None, "Disco indisponível", "disco")
        # 4) memória
        ram_total = a.get("ram_total") or 0
        if ram_total:
            nota = _por_pct(ram_total, [(2, 20), (4, 40), (8, 70), (16, 95), (32, 100)])
            mem = lento.get("memoria") or {}
            extra = (f" · {mem['tipo']} a {mem['vel_atual']} MHz" if mem.get("vel_atual") else "") + (" · canal único" if mem.get("canal") == "unico" else "")
            if mem.get("abaixo"):
                nota = nota * 0.85
            cat("memoria", "Memória RAM", nota, f"{ram_total:.0f} GB instalados · {a.get('ram', 0):.0f}% em uso agora{extra}", "memoria")
            if mem.get("abaixo"):
                achado("mem_mhz", "aviso", f"A memória roda a {mem['vel_atual']} MHz e o kit é de {mem['vel_kit']} MHz",
                       "Ativar o perfil XMP/DOCP/EXPO na BIOS dá mais FPS e menos travadas, de graça. A página Memória RAM mostra o passo a passo.", "memoria", None, "Ver a memória")
            if mem.get("canal") == "unico":
                achado("mem_canal", "aviso", "Só 1 pente de memória (canal único)",
                       "Com 2 pentes iguais a memória fica bem mais rápida em jogos. Veja os detalhes na página Memória RAM.", "memoria", None, "Ver a memória")
            if ram_total <= 8:
                achado("ram", "info", f"Só {ram_total:.0f} GB de memória RAM",
                       "Para jogos atuais o ideal é 16 GB. Mais memória é um dos upgrades que mais ajudam. Enquanto isso, a Otimização Extrema libera o máximo possível.", "extremo", None, "Abrir a Otimização Extrema")
            if a.get("ram", 0) > 88:
                achado("ram_uso", "aviso", "A memória está quase toda em uso agora", "Feche programas que não está usando ou libere a RAM.", None, "ram", "Liberar a RAM")
        else:
            cat("memoria", "Memória RAM", None, "", "monitor")
        # 5) plano de energia
        plano = ""
        if win:
            try:
                plano = next((p["nome"] for p in listar_planos() if p["ativo"]), "")
            except Exception:
                plano = ""
        if plano:
            bom = bool(PLANO_BOM.search(plano))
            econ = bool(re.search(r"economia|saver", plano, re.IGNORECASE))
            cat("energia", "Plano de energia", 100 if bom else (30 if econ else 70), f"Em uso: {plano}", "energia")
            if not bom and not tem_bateria():
                achado("energia", "aviso", "O PC está no plano de energia “" + plano + "”",
                       "Em PC de mesa, o plano de alto desempenho deixa o processador sempre pronto para o jogo.", None, "plano", "Ativar Alto desempenho")
        else:
            cat("energia", "Plano de energia", None, "Só no Windows" if not win else "Não consegui ler", "energia")
        # 5b) processos
        try:
            nproc = max(0, len(psutil.pids()) - 1)  # sem o "ocioso", igual ao Gerenciador de Tarefas
        except Exception:
            nproc = 0
        if nproc:
            cat("processos", "Processos em segundo plano", _por_pct(nproc, [(90, 100), (140, 90), (190, 55), (280, 15)]),
                f"{nproc} processos rodando agora", "processos")
            if nproc > 190:
                achado("processos", "aviso", f"{nproc} processos rodando",
                       "Muitos processos ocupam memória e processador à toa. A coluna Processos fecha o que é dispensável e desliga serviços que pesam.",
                       "processos", None, "Reduzir processos")
        else:
            cat("processos", "Processos em segundo plano", None, "", "processos")
        # 6) jogos (FPS)
        fps_ids = [i for i in FPS_PACOTE if aj.get(i) is not None]
        fps_lig = sum(1 for i in fps_ids if aj.get(i) is True)
        mon = lento.get("monitor")
        nota_j = (100 * fps_lig / len(fps_ids)) if fps_ids else None
        dica_j = f"{fps_lig} de {len(fps_ids)} ajustes de FPS ligados" if fps_ids else "Só no Windows"
        if mon and mon.get("hz_max", 0) > mon.get("hz", 0) + 5:
            nota_j = (nota_j if nota_j is not None else 100) * 0.8
            dica_j += f" · monitor a {mon['hz']} Hz (aceita {mon['hz_max']} Hz)"
            achado("hz", "aviso", f"Seu monitor está a {mon['hz']} Hz e aceita {mon['hz_max']} Hz",
                   "Muita gente joga a 60 Hz sem saber que o monitor aguenta mais. Mais Hz deixa tudo mais fluido, mesmo com o mesmo FPS.", "jogos", None, "Ver em Jogos")
        cat("jogos", "Preparo para jogos", nota_j, dica_j, "jogos")
        if fps_ids and fps_lig < len(fps_ids) - 1:
            achado("fps", "aviso", "Ajustes de FPS desligados", f"{len(fps_ids) - fps_lig} ajustes que tiram trabalho do jogo ainda não estão ligados.", "jogos", None, "Abrir Jogos")
        # 7) segurança dos dados
        pontos = lento.get("pontos")
        ult_bk = (self.bk_config().get("ultimo") or {}).get("quando")
        dias_ponto = None
        if pontos:
            dias_ponto = (time.time() - pontos[0]["ts"]) / 86400
        nota_b = 0 if (win and pontos is not None and not pontos) else (None if pontos is None else _por_pct(dias_ponto, [(0, 100), (14, 85), (45, 40), (120, 10)]))
        if ult_bk:
            nota_b = (nota_b if nota_b is not None else 50) * 0.5 + 50
        cat("dados", "Segurança dos dados", nota_b,
            ("Ponto de restauração há %d dia(s)" % dias_ponto if dias_ponto is not None else "Lendo pontos de restauração...") + (f" · backup em {ult_bk}" if ult_bk else " · sem backup de arquivos"), "backup")
        if win and pontos is not None and (not pontos or dias_ponto > 45):
            achado("restauracao", "aviso", "Sem ponto de restauração recente", "Crie um antes de mudar coisas importantes no Windows.", "backup", None, "Abrir Backup")
        if not ult_bk:
            achado("backup", "info", "Você ainda não fez backup dos seus arquivos", "Documentos, Área de Trabalho e Imagens podem ser copiados para um pendrive ou HD externo em poucos minutos.", "backup", None, "Fazer backup")
        # extras
        try:
            ligado_h = (time.time() - psutil.boot_time()) / 3600
        except Exception:
            ligado_h = None
        if ligado_h and ligado_h > 24 * 7:
            achado("uptime", "aviso", f"O PC está ligado há {ligado_h / 24:.0f} dias", "Reiniciar de vez em quando libera memória e aplica atualizações.", None, None, "")
        if win and reinicio_pendente():
            achado("reinicio", "aviso", "Há um reinício pendente", "O Windows está esperando você reiniciar para terminar uma atualização.", None, None, "")
        for dsk in lento.get("discos") or []:
            if str(dsk.get("HealthStatus") or "").lower() in ("warning", "unhealthy", "1", "2"):  # 5/unknown não é defeito
                achado("disco_saude", "ruim", "O disco “%s” reporta problema de saúde" % str(dsk.get("FriendlyName") or "")[:40],
                       "Faça backup dos seus arquivos agora e considere trocar o disco.", "backup", None, "Fazer backup")
        if any("hdd" in str(dsk.get("MediaType") or "").lower() or str(dsk.get("MediaType")) == "3" for dsk in lento.get("discos") or []):
            achado("hdd", "info", "Seu PC usa HD mecânico", "Trocar por um SSD é o upgrade que mais acelera o Windows e o carregamento dos jogos.", None, None, "")
        if a.get("tcpu") and a["tcpu"] > 88:
            achado("temp", "ruim", f"Processador a {a['tcpu']:.0f}°C", "Calor demais reduz o desempenho. Limpe o cooler e confira a ventilação.", None, None, "")
        if win and not e_admin():
            achado("admin", "aviso", "Th Boost aberto sem Administrador", "Vários ajustes e correções não funcionam. Feche e abra pelo atalho da área de trabalho.", None, None, "")
        valores = [c["valor"] for c in cats if c["valor"] is not None]
        pesos = {"desempenho": 1.4, "inicio": 1.0, "espaco": 1.2, "memoria": 0.8, "energia": 0.9, "processos": 1.0, "jogos": 1.1, "dados": 0.8}
        num = sum(c["valor"] * pesos[c["id"]] for c in cats if c["valor"] is not None)
        den = sum(pesos[c["id"]] for c in cats if c["valor"] is not None)
        score = int(round(num / den)) if den else None
        ordem = {"ruim": 0, "aviso": 1, "info": 2}
        achados.sort(key=lambda x: ordem.get(x["nivel"], 3))
        return {"score": score, "categorias": cats, "achados": achados[:9],
                "lendo": self.diag["estado"] == "lendo", "stats": dict(self.stats),
                "sistema": {"cpu": nome_do_processador(), "nucleos": a.get("nucleos"), "ram_gb": round(ram_total) if ram_total else None,
                            "gpu": (a.get("gpu") or {}).get("nome") or ((mon or {}).get("placas") or [""])[0],
                            "ligado_h": round(ligado_h, 1) if ligado_h else None, "plano": plano, "processos": nproc or None,
                            "monitor": ({"hz": mon["hz"], "hz_max": mon["hz_max"], "res": mon["res"]} if mon else None)}}


def stat_is_reg(st):
    import stat as _s
    return _s.S_ISREG(st.st_mode)


# ---------------- processos: ver o que está rodando e reduzir ----------------
#
# Regras de segurança:
#  - só se fecha processo do PRÓPRIO usuário, de programa que fica fora da pasta do Windows;
#  - Windows, antivírus, drivers/hardware, navegadores e o próprio Th Boost nunca são fechados daqui;
#  - a tela manda só um nome; o programa confere de novo na lista atual antes de fechar, e cada processo
#    é conferido pela hora em que foi criado (para nunca fechar outro que herdou o mesmo número);
#  - serviços de programas instalados só são mexidos se estiverem na lista atual e fora das exclusões
#    (antivírus, drivers, VPN, antitrapaça, certificado digital...), e o início anterior fica guardado para desfazer.

_P_WINDOWS = frozenset({
    "system", "system idle process", "registry", "memory compression", "secure system", "vmmem", "smss.exe", "csrss.exe",
    "wininit.exe", "services.exe", "lsass.exe", "lsaiso.exe", "svchost.exe", "winlogon.exe", "fontdrvhost.exe",
    "dwm.exe", "explorer.exe", "sihost.exe", "taskhostw.exe", "ctfmon.exe", "runtimebroker.exe", "searchhost.exe",
    "searchindexer.exe", "searchapp.exe", "searchprotocolhost.exe", "searchfilterhost.exe", "shellexperiencehost.exe",
    "startmenuexperiencehost.exe", "textinputhost.exe", "applicationframehost.exe", "conhost.exe", "dllhost.exe",
    "audiodg.exe", "spoolsv.exe", "wmiprvse.exe", "taskmgr.exe", "wudfhost.exe", "dashost.exe", "backgroundtaskhost.exe",
    "smartscreen.exe", "useroobebroker.exe", "systemsettings.exe", "msiexec.exe", "unsecapp.exe", "wlanext.exe",
    "sgrmbroker.exe", "lockapp.exe", "logonui.exe", "csrss", "ntoskrnl.exe", "securityhealthsystray.exe",
    "securityhealthservice.exe", "sppsvc.exe", "trustedinstaller.exe", "tiworker.exe", "wermgr.exe", "werfault.exe",
    "msdtc.exe", "lsm.exe", "cmd.exe", "powershell.exe", "pwsh.exe", "wscript.exe",
    "mmc.exe", "regedit.exe", "winlogon", "gamebar.exe",
})
_P_SEGURANCA = re.compile(
    r"^(msmpeng|nissrv|mpcmdrun|mpdefendercoreservice|avp|avpui|kavtray|avgui|avgsvc|avgnt|avastsvc|avastui|afwserv|bdagent|"
    r"bdservicehost|vsserv|bdredline|updatesrv|mbamservice|mbamtray|mbam|mcshield|mfemms|mfevtps|mcuicnt|nortonsecurity|"
    r"nsservice|nswscsvc|ekrn|egui|wrsa|sophos\w*|savservice|cylance\w*|csfalconservice|csfalconcontainer|"
    r"sentinel\w*|mcafee\w*|trendmicro\w*|tmbmsrv|ntrtscan|pccntmon|zonealarm\w*|fsav\w*|fshoster\w*|dwengine|dwservice|"
    r"spideragent|panda\w*|cmdagent|windowsdefender\w*)\.exe$", re.IGNORECASE)
_P_HARDWARE = re.compile(
    r"^(nvcontainer|nvdisplay\.container|nvtelemetrycontainer|nvidia[\w .-]*|nvspcaps\w*|nvsphelper\w*|nvbackend|"
    r"radeonsoftware|amddvr|amdow|atieclxx|atiesrxx|amdrssrcext|cncmd|igfx\w*|intelcphdcpsvc|intelgraphics\w*|"
    r"rtkauduservice\w*|ravbg\w*|ravcpl\w*|rthdvcpl|realtek\w*|waveshaper\w*|nahimicservice|nahimic\w*|sonic\w*|"
    r"syntp\w*|synaptics\w*|apoint|elantech\w*|etdctrl|hidmonitor\w*|lghub\w*|logi\w*|lcore|razer\w*|rzsynapse\w*|"
    r"icue|corsair\w*|steelseries\w*|armourycrate\w*|armoury\w*|asus\w*|msiafterburner|rtss|msicenter\w*|dragoncenter\w*|"
    r"gigabyte\w*|aorus\w*|rgb\w*|openrgb|signalrgb|cam_helper|nzxt\w*|wacom\w*|tobii\w*|vgtray|vgc|"
    r"easyanticheat\w*|beservice|beclient|battleye\w*|faceit\w*|eosoverlayrenderer\w*|punkbuster\w*|xigncode\w*)\.exe$",
    re.IGNORECASE)
_P_NAVEGADOR = re.compile(
    r"^(chrome|msedge|msedgewebview2|firefox|brave|opera|opera_gx\w*|vivaldi|iexplore|chromium|waterfox|librewolf|"
    r"yandex|arc)\.exe$", re.IGNORECASE)

# rótulo amigável, tipo e se é fechado de uma vez pelo botão "Reduzir processos" (só ajudantes que ninguém usa direto)
CONHECIDOS = [
    (r"^(googleupdate|googlecrashhandler\w*|googleupdaterwakesvc)\.exe$", "Atualizador do Google", "atualizador", True),
    (r"^microsoftedgeupdate\.exe$", "Atualizador do Edge", "atualizador", True),
    (r"^(jusched|jucheck|javaupdsvc)\.exe$", "Atualizador do Java", "atualizador", True),
    (r"^(adobearm|adobegcclient|agsservice|agmservice|adobeipcbroker|adobenotificationclient|ccxprocess|cclibrary|"
     r"adobecollabsync|armsvc|acrotray|adobeupdateservice|adobe desktop service|coresync|adobe crash processor)\.exe$",
     "Adobe (segundo plano)", "atualizador", True),
    (r"^(supportassist\w*|sauser\w*|dellsupportassist\w*|hpsupportassistant\w*|hpcommsrecovery|hp\.myhp\w*)\.exe$",
     "Suporte do fabricante", "atualizador", True),
    (r"^(ituneshelper|ipodservice|applemobiledevice\w*|appleosx\w*)\.exe$", "iTunes (ajudante)", "atualizador", True),
    (r"^(ccleaner\w*|ccleanerbrowser\w*)\.exe$", "CCleaner", "atualizador", True),
    (r"^(creative cloud|creativecloud|adobe creative cloud)\.exe$", "Adobe Creative Cloud", "launcher", False),
    (r"^(steam|steamwebhelper|steamservice)\.exe$", "Steam", "launcher", False),
    (r"^(epicgameslauncher|epicwebhelper|unrealcefsubprocess)\.exe$", "Epic Games", "launcher", False),
    (r"^(battle\.net|blizzard\w*)\.exe$", "Battle.net", "launcher", False),
    (r"^(origin|originwebhelperservice|eadesktop|eabackgroundservice|eaconnect_microsoft|ealink\w*|eaanticheat\w*)\.exe$",
     "EA / Origin", "launcher", False),
    (r"^(upc|ubisoftconnect|uplaywebcore|ubisoftgamelauncher\w*)\.exe$", "Ubisoft Connect", "launcher", False),
    (r"^(galaxyclient|galaxyclientservice|galaxycommunication|gogalaxy\w*)\.exe$", "GOG Galaxy", "launcher", False),
    (r"^(riotclientservices|riotclientux|riotclientuxrender|riotclientcrashhandler)\.exe$", "Riot Client", "launcher", False),
    (r"^(xboxpcapp|xboxapp|gamingservices\w*|xboxappservices\w*)\.exe$", "Xbox", "launcher", False),
    (r"^discord(?:ptb|canary|development)?\.exe$|^update\.exe$", "Discord / atualizador", "chat", False),
    (r"^(spotify|spotifylauncher|spotifywebhelper)\.exe$", "Spotify", "chat", False),
    (r"^(teams|ms-teams|msteams|msteamsupdate|teamsupdate)\.exe$", "Microsoft Teams", "chat", False),
    (r"^(slack|telegram|whatsapp|whatsapp\.root|signal|zoom|zoomit|skype|skypehost|skypeapp|skypebackgroundhost)\.exe$",
     "Chat / reunião", "chat", False),
    (r"^(onedrive|onedrivestandalone\w*|filecoauth|dropbox|dropboxupdate|googledrivefs|googledrivesync|megasync|"
     r"icloud\w*|icloudservices|mega)\.exe$", "Sincronização na nuvem", "nuvem", False),
    (r"^(utorrent|bittorrent|qbittorrent|deluge\w*|transmission\w*)\.exe$", "Torrent", "outro", False),
]
# o que as opções “launchers e nuvem” e “chats e músicas” do Reduzir processos fecham (nunca o que está na frente nem o que sustenta um jogo)
TIPOS_OPCIONAIS = {"launchers": ("launcher", "nuvem"), "chats": ("chat",)}
# nomes de ajudantes de um programa (não contam como "outro programa aberto por ele")
_AJUDANTE_RE = re.compile(r"crash|report|helper|webhelper|cef|update|overlay|broker|watchdog|elevat|install", re.IGNORECASE)
_CONHECIDOS_RE = [(re.compile(r, re.IGNORECASE), rot, tipo, auto) for r, rot, tipo, auto in CONHECIDOS]
_ROTULOS_WINDOWS = {
    "svchost.exe": "Serviços do Windows", "system": "Núcleo do Windows", "explorer.exe": "Explorer (barra de tarefas)",
    "dwm.exe": "Gerenciador de janelas", "searchindexer.exe": "Indexação da busca", "msmpeng.exe": "Windows Defender",
    "runtimebroker.exe": "Permissões de apps", "taskhostw.exe": "Tarefas do Windows", "sihost.exe": "Interface do Windows",
    "audiodg.exe": "Áudio do Windows", "spoolsv.exe": "Impressão", "wmiprvse.exe": "Diagnóstico do Windows",
    "conhost.exe": "Janelas de console", "dllhost.exe": "Componentes do Windows", "registry": "Registro do Windows",
    "memory compression": "Compressão de memória", "csrss.exe": "Núcleo do Windows", "lsass.exe": "Segurança do Windows",
    "winlogon.exe": "Entrada no Windows", "services.exe": "Controle de serviços", "ctfmon.exe": "Teclado e escrita",
    "fontdrvhost.exe": "Fontes do Windows", "searchhost.exe": "Busca do Iniciar", "shellexperiencehost.exe": "Interface do Windows",
    "startmenuexperiencehost.exe": "Menu Iniciar", "textinputhost.exe": "Teclado de toque", "applicationframehost.exe": "Janelas de apps",
}
# ajudantes do Windows que quase ninguém usa (a mesma lista da Otimização Extrema)
_DISP_WIN = {k.lower(): v for k, v in PROCESSOS_DISPENSAVEIS.items()}
SVC_CHAVE = r"SYSTEM\CurrentControlSet\Services\%s"


def _rotulo_exe(nome):
    base = nome[:-4] if nome.lower().endswith(".exe") else nome
    return base[:1].upper() + base[1:]


def _raiz_windows():
    return (_env("SYSTEMROOT") or _env("WINDIR") or "").lower().rstrip("\\/")


def _dono_e_o_usuario(username):
    if not username:
        return False
    return username.replace("/", "\\").split("\\")[-1].upper() == USUARIO.upper()


def _ler_processos():
    """Lê os processos do sistema. Cada item: dict com pid, ppid (quem abriu), name, exe, username, rss, ct (hora de criação)."""
    res = []
    for p in psutil.process_iter(["pid", "ppid", "name", "exe", "username", "memory_info", "create_time"]):
        i = p.info
        try:
            mi = i.get("memory_info")
            res.append({"pid": i["pid"], "ppid": i.get("ppid") or 0, "name": i.get("name") or "", "exe": i.get("exe") or "",
                        "username": i.get("username") or "", "rss": getattr(mi, "rss", 0) or 0,
                        "ct": i.get("create_time") or 0.0})
        except (psutil.Error, OSError, KeyError):
            continue
    return res


def _pids_proprios():
    """O próprio Th Boost e tudo que ele abriu (como a janela do aplicativo)."""
    ids = {os.getpid()}
    try:
        eu = psutil.Process()
        ids.update(c.pid for c in eu.children(recursive=True))
        ids.update(p.pid for p in eu.parents()[:3])
    except (psutil.Error, OSError):
        pass
    return ids


def classificar(proc, proprios, raiz):
    """Devolve (categoria, rótulo, auto, fechável) para um processo."""
    nome = proc["name"].lower()
    exe = (proc["exe"] or "").lower()
    meu = _dono_e_o_usuario(proc["username"])
    if proc["pid"] in proprios:
        return "eu", "Th Boost", False, False
    if nome in _DISP_WIN and meu:
        return "dispensavel", _DISP_WIN[nome].capitalize(), True, True
    if (nome in _P_WINDOWS or not exe or not meu or (raiz and exe.startswith(raiz + "\\"))):
        return "windows", _ROTULOS_WINDOWS.get(nome) or _rotulo_exe(proc["name"]), False, False
    if _P_SEGURANCA.match(nome):
        return "seguranca", "Proteção do PC", False, False
    if _P_HARDWARE.match(nome):
        return "hardware", _rotulo_exe(proc["name"]), False, False
    if _P_NAVEGADOR.match(nome):
        return "navegador", _rotulo_exe(proc["name"]), False, False
    for rx, rot, tipo, auto in _CONHECIDOS_RE:
        if rx.match(nome):
            return tipo, rot, auto, True
    return "outro", _rotulo_exe(proc["name"]), False, True


def escanear_processos(fonte=None, proprios=None, raiz=None):
    """Agrupa os processos por nome. 'fonte', 'proprios' e 'raiz' existem para os testes."""
    procs = fonte if fonte is not None else _ler_processos()
    proprios = _pids_proprios() if proprios is None else proprios
    raiz = _raiz_windows() if raiz is None else raiz
    grupos, classe = {}, {}
    for p in procs:
        chave = p["name"].lower()
        if not chave or chave == "system idle process" or p["pid"] == 0:
            continue  # o "ocioso" não é um processo de verdade; o Gerenciador de Tarefas também não conta
        cat, rot, auto, fech = classificar(p, proprios, raiz)
        classe[p["pid"]] = (chave, cat, rot, p["ct"])
        g = grupos.get(chave)
        if g is None:
            g = grupos[chave] = {"nome": chave, "exe": p["name"], "rotulo": rot, "cat": cat, "auto": auto, "qtd": 0,
                                 "mb": 0.0, "fechavel": False, "pids": [], "pids_fechaveis": [], "ocupado": []}
        g["qtd"] += 1
        g["mb"] += p["rss"] / 1048576
        g["pids"].append((p["pid"], p["ct"]))
        if fech:
            g["pids_fechaveis"].append((p["pid"], p["ct"], p["rss"]))
        if cat == "eu":  # se qualquer instância é do próprio programa, o grupo todo fica protegido
            g.update(cat="eu", rotulo="Th Boost", auto=False)
    # quem abriu outro programa de verdade (um jogo aberto pelo launcher) está sendo usado: não é fechado por opção nenhuma
    for p in procs:
        pai = classe.get(p.get("ppid") or 0)
        filho = classe.get(p["pid"])
        if not pai or not filho or filho[3] + 1.0 < pai[3]:
            continue  # sem pai conhecido, ou o número do pai foi reaproveitado
        if filho[1] != "outro" or filho[2] == pai[2] or _AJUDANTE_RE.search(p["name"]):
            continue
        ocupado = grupos[pai[0]]["ocupado"]
        if filho[2] not in ocupado and len(ocupado) < 3:
            ocupado.append(filho[2])
    for g in grupos.values():
        g["fechavel"] = bool(g["pids_fechaveis"]) and g["cat"] not in ("eu", "windows", "seguranca", "hardware", "navegador") \
            and not any(pid in proprios for pid, _ in g["pids"])
        g["mb"] = round(g["mb"], 1)
    lista = sorted(grupos.values(), key=lambda g: -g["mb"])
    dispens = [g for g in lista if g["auto"] and g["fechavel"]]
    por_cat = {}
    for g in lista:
        c = por_cat.setdefault(g["cat"], {"qtd": 0, "mb": 0.0})
        c["qtd"] += g["qtd"]
        c["mb"] = round(c["mb"] + g["mb"], 1)
    opcionais = {}
    for chave, tipos in TIPOS_OPCIONAIS.items():
        alvo = [g for g in lista if g["fechavel"] and g["cat"] in tipos]
        opcionais[chave] = {"qtd": sum(len(g["pids_fechaveis"]) for g in alvo), "mb": round(sum(g["mb"] for g in alvo), 1)}
    sv = grupos.get("svchost.exe")
    return {"total": sum(g["qtd"] for g in lista), "mb_total": round(sum(g["mb"] for g in lista), 1), "grupos": lista,
            "mapa": grupos, "por_cat": por_cat, "svchost": sv["qtd"] if sv else 0, "opcionais": opcionais,
            "dispensaveis": {"qtd": sum(len(g["pids_fechaveis"]) for g in dispens), "mb": round(sum(g["mb"] for g in dispens), 1)}}


def escolher_opcionais(d, tipos, frente=None, jogando=False):
    """Quais programas abertos o Reduzir processos fecha por opção (launchers, nuvem, chats). Função pura.
    Fica de fora, com o motivo: o programa da janela da frente, quem está sustentando outro programa (um jogo aberto pelo
    launcher) e qualquer launcher enquanto há um jogo da lista rodando. Devolve (grupos_a_fechar, [(rótulo, motivo)])."""
    cand = [g for g in d["grupos"] if g["fechavel"] and g["cat"] in tipos]
    bloqueio = {}
    for g in cand:  # o bloqueio vale para o programa inteiro (Steam = steam.exe + steamwebhelper.exe...), em qualquer ordem
        if g["rotulo"] in bloqueio:
            continue
        if frente is not None and any(pid == frente for pid, _ in g["pids"]):
            bloqueio[g["rotulo"]] = "você está usando agora"
        elif g["ocupado"]:
            bloqueio[g["rotulo"]] = "está sustentando " + ", ".join(g["ocupado"][:2])
        elif jogando and g["cat"] == "launcher":
            bloqueio[g["rotulo"]] = "tem um jogo aberto"
    fechar = [g for g in cand if g["rotulo"] not in bloqueio]
    poupados = sorted(bloqueio.items())
    return fechar, poupados


def fechar_pids(pids):
    """Fecha os processos (primeiro com educação, depois à força). Devolve (quantos fechou, MB liberados)."""
    alvos, mb = [], 0.0
    for pid, ct, rss in pids:
        try:
            p = psutil.Process(pid)
            if abs(p.create_time() - ct) > 1.0:
                continue  # o número foi reaproveitado por outro processo: não mexe
            p.terminate()
            alvos.append((p, rss))
        except (psutil.Error, OSError):
            continue
    if not alvos:
        return 0, 0.0
    _, vivos = psutil.wait_procs([p for p, _ in alvos], timeout=2.5)
    vivos_ids = {p.pid for p in vivos}
    for p in vivos:
        try:
            p.kill()
        except (psutil.Error, OSError):
            pass
    if vivos:
        _, ainda = psutil.wait_procs(vivos, timeout=1.5)
        vivos_ids = {p.pid for p in ainda}
    fechados = [(p, r) for p, r in alvos if p.pid not in vivos_ids]
    return len(fechados), round(sum(r for _, r in fechados) / 1048576, 1)


def contar_servicos():
    """(rodando, total) de serviços do Windows. (None, None) se não deu para ler."""
    if not IS_WIN:
        return None, None
    try:
        todos = list(psutil.win_service_iter())
        rod = 0
        for s in todos:
            try:
                if s.status() == "running":
                    rod += 1
            except (psutil.Error, OSError):
                continue
        return rod, len(todos)
    except Exception:
        return None, None


def mb_texto(mb):
    return f"{mb / 1024:.1f} GB".replace(".", ",") if mb >= 1024 else f"{mb:.0f} MB"


# ---------- serviços de programas instalados ----------

_SVC3_FORA = re.compile(
    r"(defender|antivir|security|malware|norton|mcafee|kaspersky|avast|avg\b|bitdefender|eset|sophos|webroot|trend ?micro|"
    r"nvidia|nvcontainer|\bamd\b|radeon|intel|realtek|rtk|synaptics|elan\b|logitech|lghub|razer|corsair|steelseries|asus|"
    r"armoury|\bmsi\b|gigabyte|aorus|\brgb|cooler|thermal|bluetooth|wacom|tobii|"
    r"vpn|openvpn|wireguard|nord|expressvpn|cisco|forti|vmware|virtualbox|vbox|hyper-?v|docker|wsl|sql|mysql|maria|postgres|"
    r"apache|nginx|node|tomcat|redis|mongo|anydesk|teamviewer|rustdesk|parsec|sunshine|moonlight|tailscale|zerotier|hamachi|"
    r"logmein|easyanticheat|battleye|vanguard|vgc|faceit|punkbuster|xigncode|nprotect|gameguard|"
    r"safenet|safesign|gemalto|watchdata|vaultpass|bit4id|certific|token|smart ?card|"
    r"onedrive|dropbox|google ?drive|backup|veeam|acronis|macrium|"
    r"printer|print|spool|scan|epson|canon|brother|hp ?smart|lexmark|ricoh|xerox|kyocera)", re.IGNORECASE)
_SVC3_EXE = re.compile(r'^\s*"?([^"]*?\.exe)', re.IGNORECASE)


def _exe_do_servico(binpath):
    m = _SVC3_EXE.match(binpath or "")
    return m.group(1).strip() if m else ""


def listar_servicos_terceiros(fonte=None, raiz=None):
    """Serviços de programas instalados que iniciam sozinhos com o Windows e podem virar 'manual' sem risco real."""
    raiz = _raiz_windows() if raiz is None else raiz
    if fonte is None:
        if not IS_WIN or REG is None:
            return []
        try:
            fonte = []
            for s in psutil.win_service_iter():
                try:
                    fonte.append(s.as_dict())
                except (psutil.Error, OSError):
                    continue
        except Exception:
            return []
    memoria = {}
    try:
        memoria = {p["pid"]: p["rss"] for p in _ler_processos()} if fonte else {}
    except Exception:
        pass
    itens = []
    for d in fonte:
        nome = d.get("name") or ""
        if not nome or d.get("start_type") != "automatic":
            continue
        exe = _exe_do_servico(d.get("binpath"))
        baixo = exe.lower()
        if not exe or (raiz and baixo.startswith(raiz + "\\")) or "\\microsoft\\" in baixo or "\\windowsapps\\" in baixo \
                or "\\windows defender" in baixo or "\\windows kits\\" in baixo:
            continue
        if _SVC3_FORA.search(nome) or _SVC3_FORA.search(d.get("display_name") or "") or _SVC3_FORA.search(baixo):
            continue
        pid = d.get("pid")
        itens.append({"nome": nome, "exibicao": (d.get("display_name") or nome)[:70], "estado": d.get("status") or "",
                      "mb": round(memoria.get(pid, 0) / 1048576, 1) if pid else 0.0,
                      "programa": os.path.basename(exe)})
    return sorted(itens, key=lambda i: (i["estado"] != "running", -i["mb"], i["exibicao"].lower()))[:40]


def _win_build():
    """Número da compilação do Windows (None fora do Windows). O Windows 10 1703 (15063) é o primeiro que separa serviços."""
    if not IS_WIN:
        return None
    try:
        return int(sys.getwindowsversion().build)
    except Exception:
        return None


def contar_estavel(max_voltas=7, espera=1.0, ler=None, minimo=1):
    """Conta os processos esperando o Windows terminar de fechar serviços (parar um serviço leva alguns segundos).
    Para quando o número se repete duas vezes seguidas (depois de pelo menos 'minimo' esperas). Devolve o último escaneamento."""
    ler = ler or escanear_processos
    d = ler()
    for i in range(max_voltas):
        time.sleep(espera)
        n = ler()
        if n["total"] == d["total"] and i + 1 >= minimo:
            return n
        d = n
    return d


class ProcessosMixin:
    """Lista de processos, 'Reduzir processos' (tarefa com passos) e serviços de terceiros."""

    @staticmethod
    def _proc_base():
        """Quantos processos havia na primeira vez que o Reduzir foi usado (guardado para comparar depois de reiniciar)."""
        b = CONFIG.get("proc_base")
        if not isinstance(b, dict) or not b.get("n"):
            return None
        reiniciou = bool(b.get("boot")) and psutil.boot_time() > float(b["boot"]) + 5
        return {"n": int(b["n"]), "quando": float(b.get("t") or 0), "reiniciou": reiniciou}

    def proc_iniciar_estado(self):
        self._proc_cache = {"t": 0.0, "dados": None}
        self._svc3_cache = {"t": 0.0, "itens": None}
        self._serv_cont = {"t": 0.0, "rod": None, "total": None}

    # ----- leitura (a tela lê com a página aberta) -----

    def proc_dados(self, forcar=False):
        c = self._proc_cache
        if forcar or c["dados"] is None or time.time() - c["t"] > 2.5:
            c["dados"] = escanear_processos()
            c["t"] = time.time()
        return c["dados"]

    def proc_lista(self):
        d = self.proc_dados()
        sc = self._serv_cont
        if time.time() - sc["t"] > 25:
            sc["rod"], sc["total"] = contar_servicos()
            sc["t"] = time.time()
        grupos = []
        for g in d["grupos"][:70]:
            grupos.append({k: g[k] for k in ("nome", "exe", "rotulo", "cat", "auto", "qtd", "mb", "fechavel")})
        feitos = [{"nome": n, "exibicao": v.get("exibicao", n)} for n, v in (_backup().get("_svc3") or {}).items()]
        return {"total": d["total"], "mb": d["mb_total"], "grupos": grupos, "por_cat": d["por_cat"],
                "svchost": d["svchost"], "svchost_junto": self._svchost_junto(), "ram_gb": round(psutil.virtual_memory().total / 1024 ** 3, 1),
                "dispensaveis": d["dispensaveis"], "opcionais": d["opcionais"], "servicos_rodando": sc["rod"], "servicos_total": sc["total"],
                "ids_ligados": [i for i in (CONFIG.get("proc_ids") or []) if isinstance(i, str)],
                "svc3_feitos": feitos, "cpu": self.cpu_estado(), "base": self._proc_base(), "win_build": _win_build()}

    @staticmethod
    def _svchost_junto():
        """True se o ajuste que junta os Host de Serviço já está ligado (None se não dá para saber)."""
        a = POR_ID.get("svc_juntar")
        try:
            return None if a is None or not a.disponivel() else a.estado() is True
        except OSError:
            return None

    def svc3_lista(self):
        c = self._svc3_cache
        if c["itens"] is None or time.time() - c["t"] > 20:
            c["itens"] = listar_servicos_terceiros()
            c["t"] = time.time()
        feitos = _backup().get("_svc3") or {}
        return {"itens": [i for i in c["itens"] if i["nome"] not in feitos],
                "feitos": [{"nome": n, "exibicao": v.get("exibicao", n)} for n, v in feitos.items()]}

    # ----- fechar um programa -----

    def t_proc_fechar(self, nome):
        g = escanear_processos()["mapa"].get(nome.lower())
        if not g or not g["fechavel"]:
            return "Esse programa não pode ser fechado por aqui (é do Windows, da proteção do PC ou do próprio Th Boost)."
        n, mb = fechar_pids(g["pids_fechaveis"])
        self._proc_cache["t"] = 0.0
        if not n:
            return f"{g['rotulo']}: não consegui fechar. Ele pode estar protegido ou já ter fechado."
        self.stats["procs"] = self.stats.get("procs", 0) + n
        self._estat_gravar()
        return f"{g['rotulo']} fechado: {n} processo(s), cerca de {mb_texto(mb)} de memória liberada."

    def proc_fechar(self, nome):
        if not isinstance(nome, str) or not nome or len(nome) > 120:
            raise ValueError("nome inválido")
        self.em_fundo(lambda: self.t_proc_fechar(nome))

    # ----- reduzir tudo de uma vez -----

    def proc_reduzir_iniciar(self, opcoes):
        if self._pesado_ocupado() or self.trab["processos"]["ativo"]:
            return self.msg("Espere a tarefa em andamento terminar.")
        opc = {"raros": False, "svchost": False, "launchers": False, "chats": False}
        opc.update({k: v for k, v in (opcoes or {}).items() if k in opc})
        # ordem pensada para o número cair de verdade: o ponto de restauração vem ANTES da contagem (ele abre processos do
        # Windows que ficam um tempo), primeiro se desliga o que reabre as coisas e só no fim se fecha o que está aberto
        passos = [("ponto", "Criando ponto de restauração", self._px_ponto, True),
                  ("antes", "Contando os processos", self._px_antes, False),
                  ("apps", "Parando apps em segundo plano", self._px_apps, False),
                  ("servicos", "Desligando serviços que pesam", self._px_servicos, True)]
        if opc["raros"]:
            passos.append(("raros", "Desligando serviços raros", self._px_raros, True))
        if opc["svchost"]:
            passos.append(("svchost", "Juntando os serviços do Windows", self._px_svchost, True))
        passos.append(("fechar", "Fechando ajudantes e atualizadores", self._px_fechar, False))
        tipos = tuple(t for k, ts in TIPOS_OPCIONAIS.items() if opc[k] for t in ts)
        if tipos:
            passos.append(("programas", "Fechando programas abertos sem uso", self._px_programas, False))
        passos.append(("depois", "Conferindo o resultado", self._px_depois, False))
        if self.trab_iniciar("processos", "reduzir", "Reduzir processos", passos,
                             {"opc": opc, "tipos": tipos, "ligados": [], "rot_fechados": set(), "poupados": []}):
            self.msg("Reduzindo os processos...")

    def _px_antes(self, ctx):
        # se o ponto de restauração acabou de rodar, espera os processos que ele abriu (PowerShell, VSS...) assentarem:
        # assim o "antes" e o "depois" são contados nas mesmas condições
        d = contar_estavel(max_voltas=8, espera=0.8, minimo=2) if ctx.get("ponto_rodou") else escanear_processos()
        ctx["antes"] = (d["total"], d["mb_total"])
        ctx["antes_nomes"] = {g["nome"]: (g["qtd"], g["rotulo"]) for g in d["grupos"]}
        ctx["resumo"] = {"antes_n": d["total"], "antes_mb": d["mb_total"]}
        if not CONFIG.get("proc_base"):  # a primeira contagem fica guardada: depois de reiniciar dá para ver o quanto caiu de vez
            CONFIG["proc_base"] = {"n": d["total"], "t": time.time(), "boot": psutil.boot_time()}
            salvar_config()
        return f"{d['total']} processos rodando, usando {mb_texto(d['mb_total'])}.", "ok"

    def _px_ponto(self, ctx):
        ctx["ponto_rodou"] = True
        ok = ponto_restauracao()
        return ("Ponto de restauração criado.", "ok") if ok else ("Já existia um ponto recente ou o Windows não criou. Segui mesmo assim.", "pulado")

    def _px_fechar(self, ctx):
        d = escanear_processos()
        n, mb, nomes = 0, 0.0, {}
        for g in d["grupos"]:
            if ctx["parar"]():
                break
            if g["auto"] and g["fechavel"]:
                q, m = fechar_pids(g["pids_fechaveis"])
                if q:
                    n, mb = n + q, mb + m
                    nomes[g["rotulo"]] = nomes.get(g["rotulo"], 0) + q
                    ctx["rot_fechados"].add(g["rotulo"])
        ctx["fechados"], ctx["mb_fechados"] = n, mb
        ctx["nomes_fechados"] = dict(nomes)
        if not n:
            return "Nenhum ajudante ou atualizador estava aberto.", "ok"
        return f"{n} processo(s) fechados ({mb_texto(mb)}): {', '.join(sorted(nomes)[:5])}.", "ok"

    def _jogo_rodando(self):
        """True se algum jogo da lista do Th Boost está aberto agora."""
        try:
            return bool(self._cpu_pids_jogos())
        except Exception:
            return False

    @staticmethod
    def _pid_da_frente():
        try:
            pid = pid_em_primeiro_plano()
        except Exception:
            return None
        return pid if pid and pid > 0 else None

    def _fechar_opcionais(self, ctx, d, so=None):
        """Fecha launchers, nuvem e/ou chats abertos (conforme as opções), poupando o que está em uso. 'so' limita a esses rótulos
        (usado na conferência final: só fecha de novo o que ele mesmo já tinha fechado). Devolve (n, mb, {rótulo: qtd})."""
        fechar, poupados = escolher_opcionais(d, ctx["tipos"], self._pid_da_frente(), self._jogo_rodando())
        if so is not None:
            fechar = [g for g in fechar if g["rotulo"] in so]
            poupados = [(r, m) for r, m in poupados if r in so]
        for rot, motivo in poupados:
            if not any(r == rot for r, _ in ctx["poupados"]):
                ctx["poupados"].append((rot, motivo))
        n, mb, nomes = 0, 0.0, {}
        for g in fechar:
            if ctx["parar"]():
                break
            q, m = fechar_pids(g["pids_fechaveis"])
            if q:
                n, mb = n + q, mb + m
                nomes[g["rotulo"]] = nomes.get(g["rotulo"], 0) + q
                ctx["rot_fechados"].add(g["rotulo"])
        return n, mb, nomes

    def _px_programas(self, ctx):
        n, mb, nomes = self._fechar_opcionais(ctx, escanear_processos())
        ctx["fechados"] = ctx.get("fechados", 0) + n
        ctx["mb_fechados"] = ctx.get("mb_fechados", 0.0) + mb
        for r, q in nomes.items():
            ctx.setdefault("nomes_fechados", {})[r] = ctx.get("nomes_fechados", {}).get(r, 0) + q
        txt = ""
        if ctx["poupados"]:
            txt = " Deixei abertos: " + "; ".join(f"{r} ({m})" for r, m in ctx["poupados"][:4]) + "."
        if not n:
            return "Nenhum launcher, nuvem ou chat estava aberto para fechar." + txt, "ok"
        lista = ", ".join(f"{r} ({q})" for r, q in sorted(nomes.items(), key=lambda x: -x[1])[:6])
        return f"{n} processo(s) fechados ({mb_texto(mb)}): {lista}." + txt, "ok"

    def _ligar_ajustes(self, ctx, ids):
        feitos, ja, falhas = [], 0, 0
        for i in ids:
            a = POR_ID.get(i)
            if a is None or not a.disponivel():
                continue
            if a.estado() is True:
                ja += 1
                if isinstance(a, AjusteServico) and e_admin():  # já estava desligado, mas pode seguir rodando até o PC reiniciar
                    ctx["parados"] = ctx.get("parados", 0) + a.parar_agora()
                continue
            if a.precisa_admin and not e_admin():
                falhas += 1
                continue
            try:
                a.ligar()
                feitos.append(a.id)
            except OSError:
                falhas += 1  # serviço que o Windows recusa: o ajuste volta sozinho como era (tudo ou nada)
        self.atualizar_aj()
        if feitos:
            guardados = [i for i in (CONFIG.get("proc_ids") or []) if isinstance(i, str)]
            CONFIG["proc_ids"] = guardados + [i for i in feitos if i not in guardados]
            salvar_config()
            ctx["ligados"].extend(feitos)
        return len(feitos), ja, falhas

    def _px_apps(self, ctx):
        n, ja, falhas = self._ligar_ajustes(ctx, ["fundo_apps", "widgets"])
        if n:
            return f"{n} ajuste(s) ligados: apps da Loja e Widgets não ficam mais rodando escondidos.", "ok"
        return ("Já estava assim.", "ok") if ja else ("Não consegui mudar agora.", "erro" if falhas else "pulado")

    def _px_servicos(self, ctx):
        ids = [a.id for a in CATALOGO if a.grupo == "servicos" and a.risco != "medio" and (a.rec or a.ext) and not a.sup]
        n, ja, falhas = self._ligar_ajustes(ctx, ids)
        if not n and not ja and falhas:
            return "Precisa de Administrador. Feche e abra o Th Boost pelo atalho.", "pulado"
        txt = f"{n} serviço(s) desligados agora" + (f", {ja} já estavam desligados" if ja else "") + "."
        if ctx.get("parados"):
            txt += f" Parei {ctx['parados']} que ainda estavam rodando."
        if falhas:
            txt += f" {falhas} não puderam ser alterados."
        return txt, "ok"

    def _px_raros(self, ctx):
        ids = [a.id for a in CATALOGO if a.grupo == "servicos" and a.risco != "medio" and a.sup]
        n, ja, falhas = self._ligar_ajustes(ctx, ids)
        if n:
            ctx["reiniciar"] = True
        return (f"{n} grupo(s) de serviços raros desligados. A parte por usuário só some depois de reiniciar." if n
                else ("Já estavam desligados." if ja else "Não consegui alterar.")), ("ok" if (n or ja) else "pulado")

    def _px_svchost(self, ctx):
        n, ja, falhas = self._ligar_ajustes(ctx, ["svc_juntar"])
        if n:
            ctx["reiniciar"] = ctx["juntou"] = True
            return "Pronto. Os serviços passam a dividir menos processos depois de reiniciar o PC.", "ok"
        return ("Já estava ligado.", "ok") if ja else ("Não consegui alterar.", "pulado")

    def _px_depois(self, ctx):
        # o que foi fechado pode ter reaberto sozinho: fecha de novo, uma vez só (e só o que ele mesmo fechou)
        voltaram = {}
        if ctx.get("rot_fechados"):
            time.sleep(1.5)
            d0 = escanear_processos()
            for g in d0["grupos"]:
                if g["auto"] and g["fechavel"] and g["rotulo"] in ctx["rot_fechados"]:
                    q, _ = fechar_pids(g["pids_fechaveis"])
                    if q:
                        voltaram[g["rotulo"]] = voltaram.get(g["rotulo"], 0) + q
            if ctx.get("tipos"):
                _, _, nomes = self._fechar_opcionais(ctx, d0, so=ctx["rot_fechados"])
                for r, q in nomes.items():
                    voltaram[r] = voltaram.get(r, 0) + q
        d = contar_estavel(max_voltas=10, espera=0.8, minimo=3)
        self._proc_cache["t"] = 0.0
        a_n, a_mb = ctx.get("antes", (d["total"], d["mb_total"]))
        res = ctx.setdefault("resumo", {})
        res.update(depois_n=d["total"], depois_mb=d["mb_total"], fechados=ctx.get("fechados", 0),
                   ligados=len(ctx.get("ligados", [])), reiniciar=bool(ctx.get("reiniciar")),
                   fechou=[f"{r} ({q})" for r, q in sorted((ctx.get("nomes_fechados") or {}).items(), key=lambda x: -x[1]) if q][:8],
                   poupados=[f"{r}: {m}" for r, m in ctx.get("poupados", [])][:6],
                   ponto=bool(ctx.get("ponto_rodou")))
        build = _win_build()
        if ctx.get("juntou") and (build is None or build >= 15063):  # estimativa: com os serviços juntos sobram uns 14 Host de Serviço
            res["depois_reiniciar"] = max(1, d["total"] - max(0, d["svchost"] - 14))
        # por que o número não caiu mais (dito com todas as letras, para ninguém achar que o botão não fez nada)
        motivos = []
        if not e_admin():
            motivos.append("O Th Boost está sem Administrador: não consegue desligar serviços do Windows nem juntar os Host de Serviço (svchost). "
                           "Feche e abra pelo atalho da área de trabalho.")
        elif ctx.get("juntou"):
            motivos.append("Juntar os Host de Serviço (svchost) só vale depois de REINICIAR o PC: é uma regra do Windows. "
                           "O número que você vê agora ainda é o de antes disso.")
        if build is not None and build < 15063 and d["svchost"]:
            motivos.append("Seu Windows é anterior ao Windows 10 versão 1703: ele já junta os serviços sozinho, então não há o que juntar.")
        if voltaram:
            motivos.append("Reabriram sozinhos e eu fechei de novo: " + ", ".join(f"{r} ({q})" for r, q in sorted(voltaram.items())[:5]) +
                           ". Para não abrirem mais, tire da página Inicialização.")
        # o que apareceu de novo depois da contagem do "antes" (é daí que vinha o "+3, +4")
        antes_nomes = ctx.get("antes_nomes") or {}
        novos = sorted(((g["rotulo"], g["qtd"] - antes_nomes.get(g["nome"], (0, ""))[0]) for g in d["grupos"]
                        if g["qtd"] > antes_nomes.get(g["nome"], (0, ""))[0]), key=lambda x: -x[1])
        if novos and d["total"] >= a_n:
            motivos.append("Abriram processos novos enquanto o Th Boost trabalhava (o Windows e os programas abrem alguns sozinhos): " +
                           ", ".join(f"{r} (+{q})" for r, q in novos[:4]) + ".")
        # programas do próprio usuário que o botão não fecha sozinho (podem ter algo não salvo)
        sobras = [g for g in d["grupos"] if g["fechavel"] and g["cat"] == "outro" and g["qtd"] >= 3]
        sobras.sort(key=lambda g: -g["qtd"])
        if sobras:
            motivos.append("Seus programas que ainda têm vários processos abertos: " + ", ".join(f"{g['rotulo']} ({g['qtd']})" for g in sobras[:4]) +
                           ". O botão não fecha esses sozinho porque pode haver algo seu sem salvar; fechando aqui na lista, o número cai.")
        if d["total"] >= a_n and not ctx.get("fechados") and not ctx.get("ligados") and not ctx.get("parados"):
            motivos.append("Não havia ajudantes dispensáveis abertos nem serviços de baixo risco ligados: o que sobra é do Windows e dos seus programas.")
        res["motivos"] = motivos
        self.stats["procs"] = self.stats.get("procs", 0) + ctx.get("fechados", 0)
        self._estat_gravar()
        if d["total"] < a_n:
            return f"De {a_n} para {d['total']} processos (−{a_n - d['total']}) e de {mb_texto(a_mb)} para {mb_texto(d['mb_total'])} de memória.", "ok"
        if d["total"] > a_n:
            return f"Subiu de {a_n} para {d['total']}: abriram processos novos durante a tarefa (veja abaixo). O que o botão fechou não voltou.", "ok"
        return (f"{d['total']} processos. O número só cai de vez depois de reiniciar o PC." if ctx.get("reiniciar")
                else f"{d['total']} processos: não havia mais nada seguro para fechar."), "ok"

    # ----- desfazer -----

    def t_proc_desfazer(self):
        ids = [i for i in (CONFIG.get("proc_ids") or []) if isinstance(i, str) and i in POR_ID]
        if not ids:
            return "Não há nada do Reduzir processos para desfazer."
        if REG is None:
            return "Só funciona no Windows."
        if not e_admin() and any(POR_ID[i].precisa_admin for i in ids):
            return "Desfazer precisa de Administrador. Abra o Th Boost pelo atalho."
        feitos = 0
        for i in ids:
            a = POR_ID[i]
            try:
                if a.estado() is True:
                    a.desligar()
                    feitos += 1
            except OSError:
                pass
        CONFIG["proc_ids"] = []
        CONFIG.pop("proc_base", None)
        salvar_config()
        self.atualizar_aj()
        self._proc_cache["t"] = 0.0
        return f"{feitos} ajuste(s) devolvidos ao padrão do Windows. Serviços voltam a iniciar com o Windows."

    # ----- serviços de programas instalados -----

    def t_svc3_definir(self, nome, manual):
        if REG is None:
            return "Só funciona no Windows."
        if not e_admin():
            return "Isso precisa de Administrador. Abra o Th Boost pelo atalho."
        chave = SVC_CHAVE % nome
        if manual:
            alvo = next((i for i in self.svc3_lista()["itens"] if i["nome"] == nome), None)
            if alvo is None:
                return "Esse serviço não está mais na lista."
            with TRAVA_AJ:
                _backup().setdefault("_svc3", {})[nome] = {
                    "inicio": REG.ler("HKLM", chave, "Start"), "atrasado": REG.ler("HKLM", chave, "DelayedAutostart"),
                    "exibicao": alvo["exibicao"]}
                _guardar_backup()
            executar(["sc", "config", nome, "start=", "demand"])
            executar(["sc", "stop", nome])
            self._svc3_cache["t"] = 0.0
            self._proc_cache["t"] = 0.0
            return f"{alvo['exibicao']}: agora só inicia quando algum programa pedir. Dá para desfazer aqui."
        with TRAVA_AJ:
            antigo = (_backup().get("_svc3") or {}).get(nome)
        if not antigo:
            return "Não tenho o registro desse serviço para desfazer."
        ini = antigo.get("inicio")
        modo = "delayed-auto" if (ini == 2 and antigo.get("atrasado") == 1) else \
               ("auto" if ini in (2, None) else ("disabled" if ini == 4 else "demand"))
        executar(["sc", "config", nome, "start=", modo])
        if modo in ("auto", "delayed-auto"):
            executar(["sc", "start", nome])
        with TRAVA_AJ:
            bk = _backup()
            (bk.get("_svc3") or {}).pop(nome, None)
            if not bk.get("_svc3"):
                bk.pop("_svc3", None)
            _guardar_backup()
        self._svc3_cache["t"] = 0.0
        return f"{antigo.get('exibicao', nome)}: voltou a iniciar com o Windows."

    def svc3_definir(self, nome, manual):
        if not isinstance(nome, str) or not nome or len(nome) > 100 or not isinstance(manual, bool):
            raise ValueError("pedido inválido")
        self.em_fundo(lambda: self.t_svc3_definir(nome, manual))


# ---------------- limite de CPU dos programas em segundo plano ----------------
#
# Como funciona: o Windows tem "objetos de trabalho" (Job Objects) com um TETO de CPU de verdade ("hard cap"):
# todos os programas colocados no mesmo objeto, JUNTOS, nunca passam de X% da CPU do PC. O limite é do Windows,
# não é enfeite: ele vale mesmo se o programa quiser usar mais.
#
# Regras de segurança:
#  - só entram programas do PRÓPRIO usuário e só de tipos que costumam rodar em segundo plano: navegador, nuvem,
#    atualizador e ajudante dispensável. Windows, antivírus, drivers, chat/reunião, launchers de jogos, programas de
#    gravação/voz/áudio, o próprio Th Boost e qualquer jogo ficam de fora;
#  - v9.1: o que um programa limitado abrir depois NÃO herda o limite (o Windows deixaria o filho no mesmo teto). Antes,
#    um jogo aberto pela Steam entrava junto com a Steam no limite de 40% e travava.
#  - o programa que está na frente (o que você está usando) nunca fica limitado: enquanto ele está em primeiro plano o
#    teto sobe para 100% sozinho e volta quando você troca de janela;
#  - dá para desligar a qualquer hora, e ao fechar o Th Boost o teto é solto (também na próxima abertura, se o
#    programa tiver sido fechado à força);
#  - o que o Windows não deixa limitar (como abas protegidas do navegador) ganha só prioridade baixa, que é devolvida
#    ao normal quando o limite é desligado.

CPU_MIN, CPU_MAX, CPU_PADRAO = 10, 90, 40
CPU_JOB_NOME = "Local\\ThBoost_LimiteCPU"
_CPU_CATS = frozenset({"navegador", "nuvem", "atualizador", "dispensavel"})  # v9.1: sem "launcher" (os jogos nascem dele) e sem "outro" (OBS, voz, áudio)
_PASTAS_JOGO = ("\\steamapps\\common\\", "\\epic games\\", "\\gog games\\", "\\riot games\\", "\\xboxgames\\",
                "\\ea games\\", "\\origin games\\", "\\ubisoft game launcher\\games\\", "\\games\\", "\\jogos\\")


class _CpuRate(ctypes.Structure):
    _fields_ = [("ControlFlags", ctypes.c_uint32), ("CpuRate", ctypes.c_uint32)]


class _JobBasico(ctypes.Structure):
    _fields_ = [("PerProcessUserTimeLimit", ctypes.c_int64), ("PerJobUserTimeLimit", ctypes.c_int64),
                ("LimitFlags", ctypes.c_uint32), ("MinimumWorkingSetSize", ctypes.c_size_t),
                ("MaximumWorkingSetSize", ctypes.c_size_t), ("ActiveProcessLimit", ctypes.c_uint32),
                ("Affinity", ctypes.c_size_t), ("PriorityClass", ctypes.c_uint32), ("SchedulingClass", ctypes.c_uint32)]


class _JobEstendido(ctypes.Structure):
    _fields_ = [("Basico", _JobBasico), ("Io", ctypes.c_uint64 * 6), ("ProcessMemoryLimit", ctypes.c_size_t),
                ("JobMemoryLimit", ctypes.c_size_t), ("PeakProcessMemoryUsed", ctypes.c_size_t),
                ("PeakJobMemoryUsed", ctypes.c_size_t)]


class ApiJob:
    """Chamadas do Windows (kernel32) usadas pelo limite de CPU. Nos testes entra uma versão falsa."""

    _k = None

    def disponivel(self):
        """O teto de CPU por objeto de trabalho existe do Windows 8 (compilação 9200) em diante."""
        if not IS_WIN:
            return False
        try:
            return sys.getwindowsversion().build >= 9200
        except Exception:
            return False

    def _k32(self):
        if ApiJob._k is None:
            from ctypes import wintypes
            k = ctypes.WinDLL("kernel32", use_last_error=True)
            k.CreateJobObjectW.restype = wintypes.HANDLE
            k.CreateJobObjectW.argtypes = [ctypes.c_void_p, wintypes.LPCWSTR]
            k.OpenJobObjectW.restype = wintypes.HANDLE
            k.OpenJobObjectW.argtypes = [wintypes.DWORD, wintypes.BOOL, wintypes.LPCWSTR]
            k.SetInformationJobObject.restype = wintypes.BOOL
            k.SetInformationJobObject.argtypes = [wintypes.HANDLE, ctypes.c_int, ctypes.c_void_p, wintypes.DWORD]
            k.AssignProcessToJobObject.restype = wintypes.BOOL
            k.AssignProcessToJobObject.argtypes = [wintypes.HANDLE, wintypes.HANDLE]
            k.OpenProcess.restype = wintypes.HANDLE
            k.OpenProcess.argtypes = [wintypes.DWORD, wintypes.BOOL, wintypes.DWORD]
            k.CloseHandle.restype = wintypes.BOOL
            k.CloseHandle.argtypes = [wintypes.HANDLE]
            ApiJob._k = k
        return ApiJob._k

    def abrir(self, nome, criar):
        """Abre (ou cria) o objeto de trabalho do Th Boost. Devolve o handle ou None."""
        try:
            k = self._k32()
            h = k.CreateJobObjectW(None, nome) if criar else k.OpenJobObjectW(0x0002 | 0x0004, False, nome)
            return h or None
        except Exception:
            return None

    def teto(self, h, pct):
        """Define o teto de CPU do objeto: pct de 1 a 100 (100 = sem limite). Devolve True se o Windows aceitou."""
        try:
            info = _CpuRate(0x1 | 0x4, int(max(1, min(100, pct))) * 100)  # ENABLE | HARD_CAP, em centésimos de %
            return bool(self._k32().SetInformationJobObject(h, 15, ctypes.byref(info), ctypes.sizeof(info)))
        except Exception:
            return False

    def filhos_livres(self, h):
        """v9.1: o que um programa limitado abrir não entra no limite (JOB_OBJECT_LIMIT_SILENT_BREAKAWAY_OK)."""
        try:
            info = _JobEstendido()
            info.Basico.LimitFlags = 0x00001000
            return bool(self._k32().SetInformationJobObject(h, 9, ctypes.byref(info), ctypes.sizeof(info)))
        except Exception:
            return False

    def adicionar(self, h, pid):
        """Coloca o processo no objeto de trabalho. False se o Windows não deixou (processo protegido)."""
        try:
            k = self._k32()
            ph = k.OpenProcess(0x0100 | 0x0001, False, int(pid))  # PROCESS_SET_QUOTA | PROCESS_TERMINATE
            if not ph:
                return False
            try:
                return bool(k.AssignProcessToJobObject(h, ph))
            finally:
                k.CloseHandle(ph)
        except Exception:
            return False

    def fechar(self, h):
        try:
            self._k32().CloseHandle(h)
        except Exception:
            pass


def _prio_baixa(pid, ct):
    """Prioridade baixa para o que o Windows não deixou limitar. True se mexeu."""
    if not IS_WIN:
        return False
    try:
        p = psutil.Process(pid)
        if abs(p.create_time() - ct) > 1.0:
            return False
        p.nice(psutil.BELOW_NORMAL_PRIORITY_CLASS)
        return True
    except (psutil.Error, OSError, AttributeError):
        return False


def _prio_normal(pid, ct):
    if not IS_WIN:
        return False
    try:
        p = psutil.Process(pid)
        if abs(p.create_time() - ct) > 1.0:
            return False
        p.nice(psutil.NORMAL_PRIORITY_CLASS)
        return True
    except (psutil.Error, OSError, AttributeError):
        return False


def _cpu_limpar_pct(v):
    try:
        v = int(v)
    except (TypeError, ValueError):
        v = CPU_PADRAO
    return max(CPU_MIN, min(CPU_MAX, v))


def exe_de_jogo(exe):
    """True se o programa está numa pasta comum de jogos (Steam, Epic, GOG, Riot, Xbox...)."""
    e = (exe or "").lower().replace("/", "\\")
    return any(p in e for p in _PASTAS_JOGO)


def escolher_para_limitar(grupos, exe_por_pid, pids_jogos, ja):
    """Quais processos entram no limite. Devolve lista de (pid, create_time, rótulo)."""
    escolhidos = []
    for g in grupos:
        if g["cat"] not in _CPU_CATS:
            continue
        for pid, ct in g["pids"]:
            if pid in ja or pid in pids_jogos or exe_de_jogo(exe_por_pid.get(pid)):
                continue
            escolhidos.append((pid, ct, g["rotulo"]))
    return escolhidos


class CpuMixin:
    """Teto de CPU para os programas em segundo plano (a barrinha da página Processos)."""

    def cpu_iniciar_estado(self):
        self.cpu_api = ApiJob()
        self._cpu_trava = threading.Lock()
        self._cpu = {"h": None, "pids": {}, "rot": {}, "procs": {}, "falhas": {}, "prio": {}, "teto": None,
                     "t_varrer": 0.0, "uso": None, "liberado": False, "erro": ""}
        try:
            if self.cpu_api.disponivel():  # sobra de uma abertura anterior que fechou sem soltar o teto
                h = self.cpu_api.abrir(CPU_JOB_NOME, False)
                if h:
                    self.cpu_api.teto(h, 100)
                    self.cpu_api.fechar(h)
        except Exception:
            pass

    @staticmethod
    def _cpu_cfg():
        c = CONFIG.get("cpu_limite") if isinstance(CONFIG.get("cpu_limite"), dict) else {}
        return bool(c.get("ligado")), _cpu_limpar_pct(c.get("pct"))

    def cpu_estado(self):
        ligado, pct = self._cpu_cfg()
        c = self._cpu
        nomes = {}
        for r in c["rot"].values():
            nomes[r] = nomes.get(r, 0) + 1
        top = sorted(nomes.items(), key=lambda x: -x[1])[:5]
        return {"disponivel": bool(self.cpu_api.disponivel()), "ligado": ligado, "pct": pct, "min": CPU_MIN, "max": CPU_MAX,
                "n": len(c["pids"]), "falhas": len(c["falhas"]), "uso": c["uso"], "liberado": c["liberado"],
                "nomes": [{"nome": n, "qtd": q} for n, q in top], "erro": c["erro"]}

    # ----- ligar / desligar / mudar o teto -----

    def t_cpu_definir(self, ligar, pct):
        if not self.cpu_api.disponivel():
            return "O limite de CPU precisa do Windows 8 ou mais novo."
        pct = _cpu_limpar_pct(pct)
        ja_estava = self._cpu_cfg()[0]
        CONFIG["cpu_limite"] = {"ligado": bool(ligar), "pct": pct}
        salvar_config()
        if not ligar:
            n = self.cpu_soltar()
            return f"Limite de CPU desligado. {n} programa(s) voltaram a poder usar toda a CPU." if n else "Limite de CPU desligado."
        self._cpu_passo(forcar=True)
        c = self._cpu
        if c["erro"]:
            return c["erro"]
        quem = ", ".join(f"{x['nome']}" for x in self.cpu_estado()["nomes"][:3])
        if not c["pids"]:
            return f"Limite de {pct}% ligado. Nenhum programa em segundo plano para limitar agora; os que abrirem depois entram sozinhos."
        return (f"Limite de {pct}% ligado para {len(c['pids'])} processo(s) em segundo plano"
                + (f" ({quem})" if quem else "") + (". O programa que você está usando fica sem limite." if not ja_estava else "."))

    def cpu_definir(self, ligar, pct):
        if not isinstance(ligar, bool) or isinstance(pct, bool) or not isinstance(pct, int):
            raise ValueError("opções inválidas")
        self.em_fundo(lambda: self.t_cpu_definir(ligar, pct))

    def cpu_soltar(self):
        """Tira o teto e devolve as prioridades. Devolve quantos processos estavam no limite."""
        with self._cpu_trava:
            c = self._cpu
            n = len(c["pids"])
            if c["h"] is not None:
                self.cpu_api.teto(c["h"], 100)
            for pid, ct in list(c["prio"].items()):
                _prio_normal(pid, ct)
            c.update(pids={}, rot={}, procs={}, falhas={}, prio={}, teto=100 if c["h"] is not None else None,
                     uso=None, liberado=False, erro="")
            return n

    def cpu_fechar(self):
        """Ao encerrar o Th Boost: solta o teto e fecha o objeto."""
        try:
            self.cpu_soltar()
            with self._cpu_trava:
                if self._cpu["h"] is not None:
                    self.cpu_api.fechar(self._cpu["h"])
                    self._cpu["h"] = None
        except Exception:
            pass

    # ----- o passo que roda a cada 2 segundos -----

    def _cpu_pids_jogos(self):
        """Processos dos jogos da lista do Th Boost (nunca limitados)."""
        pids = set()
        pastas = [_norm(j["pasta"]).rstrip("\\/") + os.sep for j in list(getattr(self, "jogos", []) or []) if j.get("pasta")]
        if not pastas:
            return pids
        for p in psutil.process_iter(["pid", "exe"]):
            try:
                exe = p.info.get("exe")
                if exe and any(_norm(exe).startswith(b) for b in pastas):
                    pids.add(p.info["pid"])
            except (psutil.Error, OSError):
                continue
        return pids

    def _cpu_varrer(self):
        c = self._cpu
        procs = _ler_processos()
        d = escanear_processos(procs)
        exes = {p["pid"]: p["exe"] for p in procs}
        # tira quem fechou (ou cujo número foi reaproveitado por outro programa)
        vivos = {p["pid"]: p["ct"] for p in procs}
        for pid in list(c["pids"]):
            if abs(vivos.get(pid, -1.0) - c["pids"][pid]) > 1.0:
                for k in ("pids", "rot", "procs", "falhas", "prio"):
                    c[k].pop(pid, None)
        for pid in list(c["falhas"]):
            if abs(vivos.get(pid, -1.0) - c["falhas"][pid]) > 1.0:
                c["falhas"].pop(pid, None)
                c["prio"].pop(pid, None)
        ja = set(c["pids"]) | set(c["falhas"])
        for pid, ct, rot in escolher_para_limitar(d["grupos"], exes, self._cpu_pids_jogos(), ja):
            if self.cpu_api.adicionar(c["h"], pid):
                c["pids"][pid] = ct
                c["rot"][pid] = rot
                try:
                    c["procs"][pid] = psutil.Process(pid)
                except (psutil.Error, OSError):
                    pass
            else:
                c["falhas"][pid] = ct
                if _prio_baixa(pid, ct):
                    c["prio"][pid] = ct

    def _cpu_passo(self, forcar=False):
        ligado, pct = self._cpu_cfg()
        if not ligado or not self.cpu_api.disponivel():
            if self._cpu["pids"] or self._cpu["prio"]:
                self.cpu_soltar()
            return
        with self._cpu_trava:
            c = self._cpu
            if c["h"] is None:
                c["h"] = self.cpu_api.abrir(CPU_JOB_NOME, True)
                if c["h"] is None:
                    c["erro"] = "O Windows não deixou criar o limite de CPU agora."
                    return
                livres = getattr(self.cpu_api, "filhos_livres", None)
                if livres and not livres(c["h"]):  # sem isso, um jogo aberto por um programa limitado herdaria o teto
                    self.cpu_api.fechar(c["h"])
                    c["h"] = None
                    c["erro"] = "O Windows não aceitou o limite de CPU com segurança, então ele ficou desligado."
                    return
                c["teto"] = None
            c["erro"] = ""
            agora = time.time()
            if forcar or agora - c["t_varrer"] > 10:
                self._cpu_varrer()
                c["t_varrer"] = agora
            frente = pid_em_primeiro_plano()
            libera = frente in c["pids"]  # o programa em uso nunca fica limitado
            alvo = 100 if libera else pct
            if alvo != c["teto"]:
                if self.cpu_api.teto(c["h"], alvo):
                    c["teto"] = alvo
                else:
                    c["erro"] = "O Windows não aceitou o limite de CPU."
            c["liberado"] = libera
            total = 0.0
            for pid, p in list(c["procs"].items()):
                try:
                    total += p.cpu_percent(None)
                except (psutil.Error, OSError):
                    c["procs"].pop(pid, None)
            c["uso"] = round(total / max(1, psutil.cpu_count() or 1), 1)

    def _vigiar_cpu(self):
        while not self.fechando:
            time.sleep(2)
            try:
                self._cpu_passo()
            except Exception:
                continue


# ---------------- ferramentas: programas instalados, espaço em disco e atalhos do Windows ----------------
#
# Nada aqui apaga arquivos: desinstalar abre o desinstalador do próprio programa (como o Windows faz),
# e os arquivos grandes só podem ser mostrados no Explorer para você decidir.

_UNINSTALL = [("HKLM", r"SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall"),
              ("HKLM", r"SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall"),
              ("HKCU", r"Software\Microsoft\Windows\CurrentVersion\Uninstall")]

# programas que o Windows ou o hardware precisam: ficam fora da lista de desinstalação
_PROG_PROTEGIDO = re.compile(
    r"(microsoft (visual c\+\+|\.net|windows desktop runtime|edge webview2)|webview2|directx|nvidia (graphics driver|physx|hd audio)|"
    r"amd (software|chipset)|intel\(r\) (chipset|management|graphics|serial|rapid)|realtek|windows (driver|sdk)|"
    r"microsoft update health|vulkan run ?time|python \d|python launcher|py launcher)", re.IGNORECASE)  # v9.1: o Th Boost roda no Python

ATALHOS = [
    # id, nome, descrição, alvo (arquivo/URI aberto pelo Windows), grupo
    ("tarefas", "Gerenciador de Tarefas", "Veja o que está pesando agora e feche programas travados.", "taskmgr.exe", "Desempenho"),
    ("recursos", "Monitor de Recursos", "Uso detalhado de processador, memória, disco e rede por programa.", "resmon.exe", "Desempenho"),
    ("energia", "Opções de energia", "Escolha o plano de energia (Alto desempenho, Equilibrado...).", "powercfg.cpl", "Desempenho"),
    ("msconfig", "Configuração do sistema", "Inicialização e serviços do Windows, para quem sabe o que está fazendo.", "msconfig.exe", "Desempenho"),
    ("servicos", "Serviços do Windows", "Lista completa de serviços. Cuidado ao mexer.", "services.msc", "Desempenho"),
    ("memdiag", "Diagnóstico de Memória do Windows", "Testa a memória no próximo reinício e procura pentes com defeito. O Windows pergunta antes de reiniciar.", "mdsched.exe", "Desempenho"),
    ("modojogo", "Modo de Jogo", "Ligue ou desligue o Modo de Jogo do Windows.", "ms-settings:gaming-gamemode", "Jogos"),
    ("graficos", "Configurações de gráficos", "Escolha qual placa de vídeo cada jogo usa e ligue o agendamento por hardware.", "ms-settings:display-advancedgraphics", "Jogos"),
    ("tela", "Taxa de atualização do monitor", "Confira se o monitor está na taxa mais alta (Hz) que ele aceita.", "ms-settings:display-advanced", "Jogos"),
    ("dxdiag", "Diagnóstico do DirectX", "Mostra processador, placa de vídeo e versão do DirectX.", "dxdiag.exe", "Jogos"),
    ("som", "Som", "Dispositivos de áudio de entrada e saída.", "mmsys.cpl", "Jogos"),
    ("mouse", "Mouse", "Velocidade e botões do mouse.", "main.cpl", "Jogos"),
    ("limpeza", "Limpeza de disco do Windows", "A ferramenta de limpeza do próprio Windows.", "cleanmgr.exe", "Disco"),
    ("armazenamento", "Armazenamento", "O que ocupa espaço no disco, segundo o Windows.", "ms-settings:storagesense", "Disco"),
    ("otimizar_disco", "Otimizar unidades", "Desfragmenta HD e faz o TRIM do SSD.", "dfrgui.exe", "Disco"),
    ("gerenciador_disco", "Gerenciamento de disco", "Partições e unidades conectadas.", "diskmgmt.msc", "Disco"),
    ("programas", "Programas e recursos", "A lista de programas do Windows para desinstalar.", "appwiz.cpl", "Sistema"),
    ("dispositivos", "Gerenciador de dispositivos", "Drivers e hardware, para ver o que está com defeito.", "devmgmt.msc", "Sistema"),
    ("update", "Windows Update", "Procure atualizações e veja o histórico.", "ms-settings:windowsupdate", "Sistema"),
    ("seguranca", "Segurança do Windows", "Antivírus e proteção do Windows.", "windowsdefender:", "Sistema"),
    ("eventos", "Visualizador de eventos", "Registros de erros do Windows, para achar a causa de travamentos.", "eventvwr.msc", "Sistema"),
    ("sistema", "Informações do sistema", "Resumo técnico completo do PC.", "msinfo32.exe", "Sistema"),
    ("rede", "Conexões de rede", "Adaptadores de rede e Wi-Fi.", "ncpa.cpl", "Rede"),
]
ATALHOS_POR_ID = {a[0]: a for a in ATALHOS}


def atalhos_publico():
    return [{"id": i, "nome": n, "desc": d, "grupo": g} for i, n, d, _, g in ATALHOS]


def _data_instalacao(texto):
    try:
        return datetime.strptime(str(texto)[:8], "%Y%m%d").strftime("%d/%m/%Y")
    except ValueError:
        return ""


def listar_programas():
    """Programas instalados, do mesmo lugar que o painel 'Programas e recursos' do Windows."""
    if REG is None:
        return []
    vistos, itens = set(), []
    for raiz, caminho in _UNINSTALL:
        for sub in REG.subchaves(raiz, caminho):
            c = caminho + "\\" + sub
            nome = REG.ler(raiz, c, "DisplayName")
            if not isinstance(nome, str) or not nome.strip():
                continue
            if REG.ler(raiz, c, "SystemComponent") == 1 or REG.ler(raiz, c, "ParentKeyName") or REG.ler(raiz, c, "ReleaseType") in ("Update", "Hotfix", "Security Update"):
                continue
            desin = REG.ler(raiz, c, "UninstallString")
            if not isinstance(desin, str) or not desin.strip():
                continue
            chave = nome.strip().lower() + "|" + str(REG.ler(raiz, c, "DisplayVersion") or "")
            if chave in vistos:
                continue
            vistos.add(chave)
            kb = REG.ler(raiz, c, "EstimatedSize")
            itens.append({"id": f"{raiz}|{c}", "nome": nome.strip()[:80],
                          "versao": str(REG.ler(raiz, c, "DisplayVersion") or "")[:24],
                          "editora": str(REG.ler(raiz, c, "Publisher") or "")[:50],
                          "mb": round(kb / 1024, 1) if isinstance(kb, int) and kb > 0 else 0.0,
                          "data": _data_instalacao(REG.ler(raiz, c, "InstallDate") or ""),
                          "protegido": bool(_PROG_PROTEGIDO.search(nome)), "_desin": desin.strip()})
    return sorted(itens, key=lambda i: i["nome"].lower())


def programas_publico():
    return [{k: v for k, v in i.items() if not k.startswith("_")} for i in listar_programas()]


def espaco_alvos():
    """Pastas que dá para analisar: as do usuário, mais o perfil inteiro."""
    res = [{"id": "usuario", "nome": "Todo o seu perfil", "caminho": _env("USERPROFILE")}]
    res += [{"id": p["id"], "nome": p["nome"], "caminho": p["caminho"]} for p in pastas_de_backup() if p["caminho"]]
    return [a for a in res if a["caminho"] and os.path.isdir(a["caminho"])]


class FerramentasMixin:
    """Programas instalados, análise de espaço e atalhos de ferramentas do Windows."""

    # ----- programas -----

    def programas_lista(self):
        return {"itens": programas_publico()}

    def programa_desinstalar(self, ident):
        if not isinstance(ident, str) or len(ident) > 300:
            raise ValueError("pedido inválido")
        alvo = next((p for p in listar_programas() if p["id"] == ident), None)
        if alvo is None:
            return self.msg("Esse programa não está mais na lista.")
        if alvo["protegido"]:
            return self.msg(f"{alvo['nome']} é um componente que o Windows ou seus jogos usam. Não vou desinstalar por aqui.")
        try:
            subprocess.Popen(alvo["_desin"])  # o desinstalador do próprio programa, como no painel do Windows
            self.msg(f"Abrindo o desinstalador de {alvo['nome']}...")
        except OSError:
            self.msg(f"Não consegui abrir o desinstalador de {alvo['nome']}. Use Programas e recursos do Windows.")

    # ----- atalhos -----

    def atalho_abrir(self, ident):
        a = ATALHOS_POR_ID.get(ident) if isinstance(ident, str) else None
        if a is None:
            raise ValueError("atalho inválido")
        if not IS_WIN:
            return self.msg("Disponível só no Windows.")
        try:
            os.startfile(a[3])
            self.msg(f"{a[1]} aberto.")
        except (OSError, AttributeError):
            self.msg(f"Não consegui abrir {a[1]} neste Windows.")

    # ----- espaço em disco -----

    def espaco_iniciar(self, alvo):
        achado = next((a for a in espaco_alvos() if a["id"] == alvo), None) if isinstance(alvo, str) else None
        if achado is None:
            return self.msg("Escolha uma pasta da lista.")
        if self.trab["espaco"]["ativo"]:
            return self.msg("A análise já está rodando.")
        ctx = {"raiz": achado["caminho"], "id": achado["id"], "nome": achado["nome"]}
        if self.trab_iniciar("espaco", "analisar", f"Espaço: {achado['nome']}",
                             [("ler", "Medindo as pastas", self._ex_medir, False)], ctx):
            self.msg(f"Analisando {achado['nome']}...")

    def _ex_medir(self, ctx):
        raiz = ctx["raiz"]
        pastas, arquivos, total, n = {}, [], 0, 0
        limite = time.time() + 240
        grandes_min = 50 * 1048576
        try:
            filhos = [e for e in os.scandir(raiz)]
        except OSError as erro:
            return f"Não consegui ler a pasta ({erro}).", "erro"
        for k, e in enumerate(filhos):
            if ctx["parar"]() or time.time() > limite:
                ctx["parcial"] = True
                break
            ctx["prog"](k / max(1, len(filhos)))
            try:
                if e.is_symlink() or _e_ligacao(e.path):
                    continue
                if e.is_file(follow_symlinks=False):
                    st = e.stat(follow_symlinks=False)
                    total += st.st_size
                    pastas["(arquivos soltos)"] = pastas.get("(arquivos soltos)", 0) + st.st_size
                    if st.st_size >= grandes_min:
                        arquivos.append((e.path, st.st_size, st.st_mtime))
                    continue
                if not e.is_dir(follow_symlinks=False):
                    continue
            except OSError:
                continue
            soma = 0
            for dirpath, dirnames, nomes in os.walk(e.path, followlinks=False):
                if ctx["parar"]() or time.time() > limite:
                    ctx["parcial"] = True
                    break
                dirnames[:] = [d for d in dirnames if not _e_ligacao(os.path.join(dirpath, d))]
                for nome in nomes:
                    caminho = os.path.join(dirpath, nome)
                    try:
                        st = os.lstat(caminho)
                    except OSError:
                        continue
                    if _atributo_ligacao(st) or not stat_is_reg(st):
                        continue
                    soma += st.st_size
                    n += 1
                    if st.st_size >= grandes_min:
                        arquivos.append((caminho, st.st_size, st.st_mtime))
            pastas[e.name] = pastas.get(e.name, 0) + soma
            total += soma
        arquivos.sort(key=lambda a: -a[1])
        self.espaco = {
            "alvo": ctx["id"], "nome": ctx["nome"], "total": total, "arquivos_lidos": n, "parcial": bool(ctx.get("parcial")),
            "quando": datetime.now().strftime("%d/%m/%Y %H:%M"),
            "pastas": [{"nome": k, "bytes": v} for k, v in sorted(pastas.items(), key=lambda x: -x[1])[:15] if v > 0],
            "arquivos": [{"i": i, "nome": os.path.basename(c), "pasta": os.path.dirname(c)[-60:], "bytes": b,
                          "quando": datetime.fromtimestamp(m).strftime("%d/%m/%Y"), "_caminho": c}
                         for i, (c, b, m) in enumerate(arquivos[:25])]}
        ctx["resumo"] = {"total": total}
        return f"{tam_texto(total)} em {n} arquivos" + (" (análise parcial)" if ctx.get("parcial") else "") + ".", "ok"

    def espaco_publico(self):
        e = dict(self.espaco)
        e["arquivos"] = [{k: v for k, v in a.items() if not k.startswith("_")} for a in e.get("arquivos", [])]
        e["alvos"] = [{"id": a["id"], "nome": a["nome"]} for a in espaco_alvos()]
        return e

    def espaco_mostrar(self, i):
        if not isinstance(i, int) or isinstance(i, bool):
            raise ValueError("pedido inválido")
        a = next((x for x in self.espaco.get("arquivos", []) if x["i"] == i), None)
        if a is None or not os.path.isfile(a["_caminho"]):
            return self.msg("Esse arquivo não está mais lá.")
        try:
            subprocess.Popen(["explorer.exe", "/select,", a["_caminho"]])
        except OSError:
            self.msg("Não consegui abrir o Explorer.")

    # ----- links oficiais (drivers, Visual C++, DirectX) -----

    def link_oficial(self, ident):
        l = LINKS_OFICIAIS.get(ident) if isinstance(ident, str) else None
        if l is None:
            raise ValueError("link inválido")
        try:
            abrir_link(l[2])
            self.msg(f"Abrindo o site oficial ({l[1]})...")
        except Exception:
            self.msg("Não consegui abrir o navegador.")


# ---------------- memória RAM: o que existe no PC e como deixá-la mais rápida ----------------
#
# O "clock" da memória (a velocidade em MHz) é gravado na BIOS/UEFI da placa-mãe, no perfil XMP (Intel), DOCP/EXPO
# (AMD) ou AMP (AMD antigo). Nenhum programa do Windows muda isso com segurança, então o Th Boost só LÊ o que existe,
# avisa quando a memória está abaixo da velocidade do kit (ou em canal único) e leva a pessoa até a BIOS com o passo a
# passo. Nada é gravado na BIOS por aqui.

TIPOS_MEMORIA = {20: "DDR", 21: "DDR2", 24: "DDR3", 26: "DDR4", 34: "DDR5"}
_VELOCIDADES = frozenset((800, 1066, 1333, 1600, 1866, 2133, 2400, 2666, 2800, 2933, 3000, 3200, 3466, 3600, 3733, 3866,
                          4000, 4133, 4266, 4400, 4800, 5200, 5600, 6000, 6400, 6800, 7200, 7600, 8000))
_CURTOS = {"316": 1600, "318": 1866, "321": 2133, "324": 2400, "426": 2666, "429": 2933, "430": 3000, "432": 3200,
           "436": 3600, "440": 4000, "548": 4800, "552": 5200, "556": 5600, "560": 6000, "564": 6400}
_TECLAS_BIOS = (("asus", "Del ou F2"), ("msi", "Del"), ("gigabyte", "Del"), ("aorus", "Del"), ("asrock", "F2 ou Del"),
                ("dell", "F2"), ("hewlett", "Esc ou F10"), ("hp", "Esc ou F10"), ("lenovo", "F2"), ("acer", "F2 ou Del"),
                ("samsung", "F2"), ("positivo", "F2 ou Del"), ("itautec", "F2 ou Del"))


def _lista(x):
    if x is None:
        return []
    return [i for i in (x if isinstance(x, list) else [x]) if isinstance(i, dict)]


def _inteiro(x):
    try:
        return int(float(x))
    except (TypeError, ValueError):
        return 0


def velocidade_pelo_codigo(peca):
    """Tenta ler a velocidade vendida do kit pelo código da peça (CMK16GX4M2B3200C16 -> 3200). Só uma dica."""
    p = re.sub(r"[\s_]", "", str(peca or "").upper())
    m = re.match(r"(?:KF|HX|KHX)(\d{3})[CS]\d", p)
    if m and m.group(1) in _CURTOS:
        return _CURTOS[m.group(1)]
    for t in re.findall(r"(?<!\d)(\d{4})(?!\d)", p):
        if int(t) in _VELOCIDADES:
            return int(t)
    return 0


def canal_dos_slots(slots):
    """v9.1: pelo nome dos encaixes (DIMM_A2, ChannelB-DIMM0, P0 CHANNEL A...) diz se os pentes estão em canais diferentes.
    'duplo' (confirmado), 'mesmo' (2+ pentes no MESMO canal: erro comum de montagem), 'provavel' (não deu para saber), 'unico'."""
    if len(slots) <= 1:
        return "unico"
    letras = []
    for t in slots:
        u = str(t or "").upper()
        m = (re.search(r"CHANNEL\s*[-_]?\s*([A-H])\b", u) or re.search(r"\bCH(?:AN)?\s*[-_]?\s*([A-H])\b", u)
             or re.search(r"DIMM\s*[-_]?\s*([A-H])\s*[-_]?\d", u) or re.search(r"(?:^|[\s_-])([A-H])[0-3](?:$|[\s_-])", u))
        c = re.search(r"(?:CONTROLLER|\bP)\s*(\d)", u)  # controladora/processador diferente = canal diferente
        letras.append(((c.group(1) if c else "") + m.group(1)) if m else None)
    if any(l is None for l in letras):
        return "duplo" if len({l for l in letras if l}) >= 2 else "provavel"
    return "duplo" if len(set(letras)) >= 2 else "mesmo"


def _perfil_da_placa(cpu):
    c = (cpu or "").lower()
    if "ryzen" in c or "epyc" in c or "threadripper" in c:
        return "DOCP ou EXPO (em algumas placas chama XMP)"
    if "amd" in c or "athlon" in c or "phenom" in c or re.search(r"\bfx\b", c):
        return "XMP ou AMP"
    if "intel" in c or "core" in c or "pentium" in c or "celeron" in c:
        return "XMP"
    return "XMP, DOCP ou EXPO"


def _tecla_da_bios(fabricante):
    f = (fabricante or "").lower()
    return next((t for k, t in _TECLAS_BIOS if k in f), "Del ou F2")


def analisar_memoria(d, cpu="", notebook=False):
    """Transforma o que o Windows disse sobre os pentes de memória em números e avisos (função pura, testável)."""
    if not isinstance(d, dict):
        return None
    mods = []
    for m in _lista(d.get("modulos")):
        cap = _inteiro(m.get("Capacity")) / 1024 ** 3
        if cap <= 0:
            continue
        peca = str(m.get("PartNumber") or "").strip()[:40]
        mods.append({"slot": str(m.get("DeviceLocator") or m.get("BankLabel") or "").strip()[:24],
                     "gb": int(cap) if abs(cap - round(cap)) < 0.05 else round(cap, 1),
                     "mhz_atual": _inteiro(m.get("ConfiguredClockSpeed")), "mhz_spd": _inteiro(m.get("Speed")),
                     "tipo": TIPOS_MEMORIA.get(_inteiro(m.get("SMBIOSMemoryType")), ""),
                     "fab": str(m.get("Manufacturer") or "").strip()[:24], "peca": peca,
                     "mhz_codigo": velocidade_pelo_codigo(peca)})
    if not mods:
        return None
    placa = (_lista(d.get("placa")) or [{}])[0]
    slots = sum(_inteiro(x.get("MemoryDevices")) for x in _lista(d.get("matriz")))
    total = sum(m["gb"] for m in mods)
    tipo = next((m["tipo"] for m in mods if m["tipo"]), "")
    atuais = [m["mhz_atual"] or m["mhz_spd"] for m in mods if (m["mhz_atual"] or m["mhz_spd"])]
    vel_atual = min(atuais) if atuais else 0
    vel_spd = max([m["mhz_spd"] for m in mods] or [0])
    vel_cod = max([m["mhz_codigo"] for m in mods] or [0])
    vel_kit, fonte = (vel_spd, "spd") if vel_spd >= vel_cod else (vel_cod, "codigo")
    abaixo = bool(vel_atual and vel_kit and vel_atual < vel_kit * 0.93)
    canal = canal_dos_slots([m["slot"] for m in mods])
    perfil = _perfil_da_placa(cpu)
    ach = []
    if abaixo:
        base = "o kit informa" if fonte == "spd" else "pelo código da peça, o kit parece ser de"
        ach.append({"id": "abaixo", "nivel": "aviso", "titulo": f"A memória roda a {vel_atual} MHz, mas {base} {vel_kit} MHz",
                    "texto": f"É muito comum: o PC liga a memória na velocidade básica até você ativar o perfil {perfil} na BIOS. "
                             "Ativar é de graça e costuma dar mais FPS e menos travadas, principalmente com vídeo integrado ou processador AMD."})
        if notebook:
            ach.append({"id": "notebook", "nivel": "info", "titulo": "Em notebook, a BIOS quase nunca tem essa opção",
                        "texto": "Muitos notebooks travam a velocidade da memória. Se a BIOS não mostrar XMP, não há o que fazer por software."})
    if canal == "mesmo":
        ach.append({"id": "canal", "nivel": "aviso", "titulo": "Os pentes parecem estar no MESMO canal",
                    "texto": "Pelos nomes dos encaixes (" + ", ".join(m["slot"] for m in mods if m["slot"]) + "), os pentes estão no mesmo canal "
                             "e a memória trabalha como canal único. No manual da placa-mãe veja os encaixes indicados para 2 pentes "
                             "(quase sempre A2 e B2) e troque um de lugar com o PC desligado da tomada."})
    if canal == "unico":
        ach.append({"id": "canal", "nivel": "aviso", "titulo": "Só 1 pente de memória (canal único)",
                    "texto": "Com 2 pentes iguais (canal duplo) a memória entrega até o dobro de largura de banda. Em jogos, é um dos upgrades "
                             "que mais ajudam, principalmente com vídeo integrado. Se for comprar, leve 2 pentes iguais do mesmo kit."})
    if len({(m["gb"], m["mhz_spd"]) for m in mods}) > 1:
        ach.append({"id": "misto", "nivel": "info", "titulo": "Os pentes são diferentes entre si",
                    "texto": "Quando os pentes têm tamanho ou velocidade diferentes, o PC roda todos na velocidade do mais lento."})
    if slots and slots > len(mods):
        ach.append({"id": "livres", "nivel": "info", "titulo": f"{slots - len(mods)} slot(s) de memória livre(s)",
                    "texto": "Dá para colocar mais pentes (iguais aos que já estão) sem tirar os atuais."})
    if not abaixo and canal != "unico":
        ach.append({"id": "ok", "nivel": "ok", "titulo": "Memória na velocidade do kit" if vel_atual else "Memória lida",
                    "texto": (f"Rodando a {vel_atual} MHz" + (f" em canal duplo." if canal == "duplo" else ".")) if vel_atual else ""})
    return {"estado": "pronto", "total_gb": total, "tipo": tipo, "modulos": mods, "slots": slots, "vel_atual": vel_atual,
            "vel_kit": vel_kit, "fonte": fonte, "abaixo": abaixo, "canal": canal, "perfil": perfil,
            "placa": " ".join(str(placa.get(k) or "").strip() for k in ("Manufacturer", "Product")).strip()[:60],
            "tecla": _tecla_da_bios(placa.get("Manufacturer")), "notebook": bool(notebook), "achados": ach}


def ler_memoria():
    """Lê pentes, slots e placa-mãe pelo Windows. Devolve a análise ou None."""
    cod, saida = powershell(
        "$m=@(Get-CimInstance Win32_PhysicalMemory | Select-Object DeviceLocator,BankLabel,Capacity,Speed,ConfiguredClockSpeed,"
        "SMBIOSMemoryType,Manufacturer,PartNumber);"
        "$a=@(Get-CimInstance Win32_PhysicalMemoryArray | Select-Object MemoryDevices);"
        "$b=@(Get-CimInstance Win32_BaseBoard | Select-Object Manufacturer,Product);"
        "ConvertTo-Json -Compress -Depth 4 @{modulos=$m;matriz=$a;placa=$b}", tempo=30)
    if cod != 0 or not saida.strip():
        return None
    try:
        dados = json.loads(saida)
    except ValueError:
        return None
    return analisar_memoria(dados, nome_do_processador(), tem_bateria())


class MemoriaMixin:
    """A página Memória RAM: leitura em segundo plano e o atalho para reiniciar direto na BIOS."""

    def memoria_iniciar_estado(self):
        self.memoria = {"estado": "nenhum", "dados": None, "quando": 0.0}

    def memoria_agora(self, forcar=False):
        """Lê (ou reaproveita a leitura de até 10 minutos). Roda na thread de quem chamou."""
        m = self.memoria
        if not forcar and m["estado"] == "pronto" and time.time() - m["quando"] < 600:
            return m["dados"]
        try:
            m["dados"] = ler_memoria()
            m["estado"] = "pronto" if m["dados"] else "erro"
        except Exception:
            m["dados"], m["estado"] = None, "erro"
        m["quando"] = time.time()
        return m["dados"]

    def memoria_ler(self, forcar=False):
        m = self.memoria
        if m["estado"] == "lendo" or REG is None:
            return
        if not forcar and m["estado"] == "pronto" and time.time() - m["quando"] < 600:
            return
        m["estado"] = "lendo"

        def tarefa():
            self.memoria_agora(True)
        threading.Thread(target=tarefa, daemon=True).start()

    def memoria_lista(self):
        if self.memoria["estado"] in ("nenhum", "erro") or time.time() - self.memoria["quando"] > 600:
            self.memoria_ler()
        m = self.memoria
        return {"estado": m["estado"], "dados": m["dados"], "admin": e_admin(), "win": REG is not None}

    def t_memoria_bios(self):
        if REG is None:
            return "Disponível só no Windows."
        tecla = (self.memoria.get("dados") or {}).get("tecla") or "Del ou F2"
        if not e_admin():
            return f"Reiniciar direto na BIOS precisa de Administrador. Abra o Th Boost pelo atalho, ou reinicie o PC e aperte {tecla} várias vezes assim que ele ligar."
        cod, _ = executar(["shutdown", "/r", "/fw", "/t", "30", "/c", "Th Boost: reiniciando na BIOS para ativar o perfil da memória."])
        if cod != 0:
            return f"Este PC não aceitou reiniciar direto na BIOS (isso só existe em PC com UEFI). Reinicie normalmente e aperte {tecla} várias vezes assim que ele ligar."
        return "Reiniciando na BIOS em 30 segundos. Salve o que estiver aberto. Para desistir, aperte Cancelar."

    def memoria_bios(self):
        self.em_fundo(self.t_memoria_bios)

    def t_memoria_bios_cancelar(self):
        if REG is None:
            return "Disponível só no Windows."
        cod, _ = executar(["shutdown", "/a"])
        return "Reinício cancelado." if cod == 0 else "Não havia reinício agendado."

    def memoria_bios_cancelar(self):
        self.em_fundo(self.t_memoria_bios_cancelar)


# ---------------- overclock da placa de vídeo NVIDIA (a barra de 0 a 150%) ----------------
#
# Como funciona: o Th Boost fala com a NVML, a biblioteca que já vem no driver da NVIDIA (a mesma que o nvidia-smi usa).
# Uma barra só, de 0 a 150%, sobe três coisas juntas: o clock do núcleo, o clock da memória e o limite de potência.
#   0%   = padrão da placa (é onde a barra SEMPRE começa quando o programa abre);
#   150% = o máximo que o Th Boost aplica: núcleo +OC_NUCLEO_150 MHz, memória +OC_MEM_150 MHz e potência no teto da placa.
# Cada valor também fica limitado ao que a própria placa/driver informa como permitido. Placa de vídeo não aguenta
# "150% de clock": a barra é uma escala do que é seguro tentar, e quem manda no limite é a placa.
#
# Travas de segurança:
#  - nada fica gravado na placa: tudo volta ao padrão ao reiniciar o PC;
#  - o Th Boost zera ao fechar, e ao abrir se a vez anterior fechou do nada com o overclock ligado;
#  - se a placa passar de OC_TEMP_LIMITE graus, volta sozinho a 0%;
#  - precisa de Administrador e de placa NVIDIA com driver novo; AMD e Intel não são mexidas.

OC_MAX = 150
OC_PASSO = 5
OC_NUCLEO_150 = 150     # MHz no núcleo quando a barra está em 150%
OC_MEM_150 = 500        # MHz na memória quando a barra está em 150%
OC_MEM_150_NVAPI = 250  # MHz na memória pelo caminho das placas mais antigas (a escala do driver ali é outra: vai mais devagar)
OC_TEMP_LIMITE = 88     # graus: passou disso, o overclock é desligado sozinho
OC_TEMP_AVISO = 83      # graus: a tela avisa que está esquentando

_NVML_ERROS = {1: "a NVML não foi iniciada", 2: "valor recusado pela placa", 3: "esta placa ou este driver não aceita esse ajuste",
               4: "precisa abrir o Th Boost como Administrador", 9: "o driver da NVIDIA não está carregado",
               13: "este driver é antigo demais para esse ajuste (atualize o driver da NVIDIA)", 15: "a placa parou de responder",
               16: "a placa pede reinício do PC", 17: "o Windows bloqueou o ajuste"}


def oc_plano(nivel, teto):
    """(núcleo MHz, memória MHz, watts) para um nível de 0 a 150. teto = {core, mem, padrao, max}. Função pura."""
    try:
        n = max(0, min(OC_MAX, int(nivel)))
    except (TypeError, ValueError):
        n = 0
    f = n / float(OC_MAX)
    tc, tm = teto.get("core") or 0, teto.get("mem") or 0
    core = min(int(round(f * tc / 15.0)) * 15, tc) if tc else 0  # arredonda para o passo da placa, sem passar do limite dela
    mem = min(int(round(f * tm / 25.0)) * 25, tm) if tm else 0
    pad, mx = teto.get("padrao") or 0, teto.get("max") or 0
    watts = int(round(pad + f * (mx - pad))) if pad and mx > pad else int(pad)
    return core, mem, watts


def oc_tabela(teto):
    """Uma linha por passo da barra: [nível, núcleo, memória, watts]. A tela só escolhe a linha (nunca refaz a conta)."""
    return [[n, *oc_plano(n, teto)] for n in range(0, OC_MAX + 1, OC_PASSO)]


class _Nvml:
    """Envelope fino em volta da NVML (ctypes). Nunca levanta erro: devolve o código da NVML (0 = deu certo)."""

    _SIGS = {
        "nvmlInit_v2": [], "nvmlShutdown": [],
        "nvmlDeviceGetHandleByIndex_v2": [ctypes.c_uint, ctypes.POINTER(ctypes.c_void_p)],
        "nvmlDeviceGetName": [ctypes.c_void_p, ctypes.c_char_p, ctypes.c_uint],
        "nvmlDeviceGetTemperature": [ctypes.c_void_p, ctypes.c_uint, ctypes.POINTER(ctypes.c_uint)],
        "nvmlDeviceGetClockInfo": [ctypes.c_void_p, ctypes.c_uint, ctypes.POINTER(ctypes.c_uint)],
        "nvmlDeviceGetPowerUsage": [ctypes.c_void_p, ctypes.POINTER(ctypes.c_uint)],
        "nvmlDeviceGetPowerManagementLimit": [ctypes.c_void_p, ctypes.POINTER(ctypes.c_uint)],
        "nvmlDeviceGetPowerManagementDefaultLimit": [ctypes.c_void_p, ctypes.POINTER(ctypes.c_uint)],
        "nvmlDeviceGetPowerManagementLimitConstraints": [ctypes.c_void_p, ctypes.POINTER(ctypes.c_uint), ctypes.POINTER(ctypes.c_uint)],
        "nvmlDeviceSetPowerManagementLimit": [ctypes.c_void_p, ctypes.c_uint],
        "nvmlDeviceGetGpcClkVfOffset": [ctypes.c_void_p, ctypes.POINTER(ctypes.c_int)],
        "nvmlDeviceSetGpcClkVfOffset": [ctypes.c_void_p, ctypes.c_int],
        "nvmlDeviceGetGpcClkMinMaxVfOffset": [ctypes.c_void_p, ctypes.POINTER(ctypes.c_int), ctypes.POINTER(ctypes.c_int)],
        "nvmlDeviceGetMemClkVfOffset": [ctypes.c_void_p, ctypes.POINTER(ctypes.c_int)],
        "nvmlDeviceSetMemClkVfOffset": [ctypes.c_void_p, ctypes.c_int],
        "nvmlDeviceGetMemClkMinMaxVfOffset": [ctypes.c_void_p, ctypes.POINTER(ctypes.c_int), ctypes.POINTER(ctypes.c_int)],
    }

    def __init__(self):
        self.lib = None
        self.dev = None
        self.erro = ""
        self.tentou = False

    @staticmethod
    def _candidatas():
        extra = os.environ.get("TOTIMIZE_NVML")
        if extra:
            return [extra]
        if not IS_WIN:
            return []
        sistema = os.environ.get("SystemRoot", r"C:\Windows")
        arquivos = os.environ.get("ProgramFiles", r"C:\Program Files")
        return ["nvml.dll", os.path.join(sistema, "System32", "nvml.dll"),
                os.path.join(arquivos, "NVIDIA Corporation", "NVSMI", "nvml.dll")]

    def abrir(self):
        """Carrega a NVML e pega a primeira placa NVIDIA. True se deu certo."""
        if self.dev is not None:
            return True
        if self.tentou:
            return False
        self.tentou = True
        for caminho in self._candidatas():
            try:
                self.lib = ctypes.CDLL(caminho)
                break
            except OSError:
                self.lib = None
        if self.lib is None:
            self.erro = "Não achei a biblioteca da NVIDIA (nvml.dll): placa NVIDIA e driver instalados?"
            return False
        for nome, args in self._SIGS.items():
            f = getattr(self.lib, nome, None)
            if f is not None:
                f.restype = ctypes.c_int
                f.argtypes = args
        if self.chamar("nvmlInit_v2") not in (0, 5):
            self.erro = "A biblioteca da NVIDIA não iniciou."
            self.lib = None
            return False
        h = ctypes.c_void_p()
        if self.chamar("nvmlDeviceGetHandleByIndex_v2", 0, ctypes.byref(h)) != 0 or not h.value:
            self.erro = "Nenhuma placa NVIDIA encontrada."
            self.lib = None
            return False
        self.dev = h
        return True

    def chamar(self, nome, *args):
        f = getattr(self.lib, nome, None) if self.lib is not None else None
        if f is None:
            return 13
        try:
            return int(f(*args))
        except (OSError, ValueError, ctypes.ArgumentError):
            return 999

    def _com_dev(self, nome, *args):
        return self.chamar(nome, self.dev, *args)

    def u32(self, nome):
        v = ctypes.c_uint()
        cod = self._com_dev(nome, ctypes.byref(v))
        return cod, (v.value if cod == 0 else None)

    def u32_dois(self, nome):
        a, b = ctypes.c_uint(), ctypes.c_uint()
        cod = self._com_dev(nome, ctypes.byref(a), ctypes.byref(b))
        return cod, ((a.value, b.value) if cod == 0 else None)

    def i32(self, nome):
        v = ctypes.c_int()
        cod = self._com_dev(nome, ctypes.byref(v))
        return cod, (v.value if cod == 0 else None)

    def i32_dois(self, nome):
        a, b = ctypes.c_int(), ctypes.c_int()
        cod = self._com_dev(nome, ctypes.byref(a), ctypes.byref(b))
        return cod, ((a.value, b.value) if cod == 0 else None)

    def definir(self, nome, valor):
        return self._com_dev(nome, int(valor))

    def nome(self):
        buf = ctypes.create_string_buffer(96)
        if self._com_dev("nvmlDeviceGetName", buf, 96) != 0:
            return "Placa NVIDIA"
        return buf.value.decode("utf-8", "replace").strip() or "Placa NVIDIA"

    def temperatura(self):
        v = ctypes.c_uint()
        return int(v.value) if self._com_dev("nvmlDeviceGetTemperature", 0, ctypes.byref(v)) == 0 else None

    def clock(self, tipo):
        """Clock de agora em MHz (tipo 0 = núcleo, 2 = memória). None se não der para ler."""
        v = ctypes.c_uint()
        return int(v.value) if self._com_dev("nvmlDeviceGetClockInfo", tipo, ctypes.byref(v)) == 0 else None


def _motivo_nvml(cod):
    return _NVML_ERROS.get(cod, f"erro {cod} da biblioteca da NVIDIA")


# ---------------- v9.3: placas NVIDIA mais antigas (GTX 600, 700, 900, 10...) ----------------
# A NVML só aceita ajuste de núcleo e memória nas placas e drivers mais novos. Nas outras (por exemplo a GTX 750), o
# Th Boost usa a NVAPI, a outra biblioteca que vem no driver da NVIDIA (nvapi64.dll), do mesmo jeito que os programas de
# overclock fazem: lê a tabela de "estados de desempenho" (P-states) e muda só o deslocamento (offset) do P0, o estado
# de jogo. O próprio driver diz se a placa deixa mexer e até quanto; nada é gravado na placa (reiniciar volta ao padrão).

_NVAPI_IDS = {"init": 0x0150E828, "enum": 0xE5AC921F, "nome": 0xCEEE8E9F, "ler": 0x6FF81213, "definir": 0x0F4DAE6B}
_PS20_TAM = 7316                    # sizeof(NV_GPU_PERF_PSTATES20_INFO_V1)
_PS20_VER1 = _PS20_TAM | (1 << 16)  # MAKE_NVAPI_VERSION(NV_GPU_PERF_PSTATES20_INFO_V1, 1)
_PS20_PSTATE = 456                  # um P-state: id, editável, 8 clocks de 44 bytes e 4 tensões de 24 bytes
_PS20_CLOCK = 44
NVAPI_NUCLEO, NVAPI_MEMORIA = 0, 4  # NVAPI_GPU_PUBLIC_CLOCK_GRAPHICS / _MEMORY
_NVAPI_ERROS = {-1: "o driver recusou", -3: "este driver não tem esse ajuste", -5: "valor recusado pela placa",
                -6: "nenhuma placa NVIDIA encontrada", -9: "este driver é diferente do esperado (atualize o driver da NVIDIA)",
                -104: "esta placa não aceita esse ajuste", -137: "precisa abrir o Th Boost como Administrador"}


def nvapi_ps20_ler(buf):
    """Lê a tabela P-states 2.0 (bytes da NVAPI) e devolve {domínio: {editavel, agora, min, max}} do P0, em MHz.
    Função pura (dá para testar fora do Windows)."""
    import struct as _st
    if len(buf) < _PS20_TAM:
        return {}
    _ver, flags, n_ps, n_clk, _n_v = _st.unpack_from("<IIIII", buf, 0)
    out = {}
    for i in range(min(n_ps, 16)):
        base = 20 + i * _PS20_PSTATE
        ps_id, ps_flags = _st.unpack_from("<II", buf, base)
        if ps_id != 0:  # só o P0 (o estado de jogo)
            continue
        for j in range(min(n_clk, 8)):
            c = base + 8 + j * _PS20_CLOCK
            dom, _tipo, c_flags, val, mn, mx = _st.unpack_from("<IIIiii", buf, c)
            if dom in (NVAPI_NUCLEO, NVAPI_MEMORIA):
                # vale o "pode mexer" de cada clock (alguns drivers deixam os outros dois em 0 mesmo aceitando)
                out[dom] = {"editavel": bool(c_flags & 1), "agora": int(val / 1000),
                            "min": int(mn / 1000), "max": int(mx / 1000)}
    return out


def nvapi_ps20_montar(dominio, mhz):
    """Monta o pedido para o driver: só o P0, só um clock, só o deslocamento. Função pura."""
    import struct as _st
    b = bytearray(_PS20_TAM)
    _st.pack_into("<IIIII", b, 0, _PS20_VER1, 0, 1, 1, 0)       # versão, -, 1 P-state, 1 clock, 0 tensões
    _st.pack_into("<II", b, 20, 0, 0)                            # P0
    _st.pack_into("<IIIi", b, 28, int(dominio), 0, 0, int(mhz) * 1000)  # domínio, tipo, -, deslocamento em kHz
    return b


class _Nvapi:
    """Envelope fino em volta da NVAPI (ctypes). Nunca levanta erro."""

    def __init__(self):
        self.ok = False
        self.tentou = False
        self.erro = ""
        self.gpu = None
        self.f = {}

    @staticmethod
    def _candidatas():
        extra = os.environ.get("TOTIMIZE_NVAPI")
        if extra:
            return [extra]
        if not IS_WIN:
            return []
        return ["nvapi64.dll" if ctypes.sizeof(ctypes.c_void_p) == 8 else "nvapi.dll"]

    def abrir(self, nome_nvml=""):
        if self.ok:
            return True
        if self.tentou:
            return False
        self.tentou = True
        lib = None
        for c in self._candidatas():
            try:
                lib = ctypes.CDLL(c)
                break
            except OSError:
                lib = None
        qi = getattr(lib, "nvapi_QueryInterface", None) if lib is not None else None
        if qi is None:
            self.erro = "Não achei a outra biblioteca da NVIDIA (nvapi64.dll)."
            return False
        qi.restype = ctypes.c_void_p
        qi.argtypes = [ctypes.c_uint]
        tipos = {"init": ctypes.CFUNCTYPE(ctypes.c_int),
                 "enum": ctypes.CFUNCTYPE(ctypes.c_int, ctypes.POINTER(ctypes.c_void_p), ctypes.POINTER(ctypes.c_uint)),
                 "nome": ctypes.CFUNCTYPE(ctypes.c_int, ctypes.c_void_p, ctypes.c_char_p),
                 "ler": ctypes.CFUNCTYPE(ctypes.c_int, ctypes.c_void_p, ctypes.c_char_p),
                 "definir": ctypes.CFUNCTYPE(ctypes.c_int, ctypes.c_void_p, ctypes.c_char_p)}
        try:
            for k, ident in _NVAPI_IDS.items():
                end = qi(ident)
                if end:
                    self.f[k] = tipos[k](end)
            if not all(k in self.f for k in ("init", "enum", "ler", "definir")):
                self.erro = "este driver da NVIDIA não tem o ajuste de clock"
                return False
            if self.f["init"]() != 0:
                self.erro = "a biblioteca da NVIDIA não iniciou"
                return False
            gpus = (ctypes.c_void_p * 64)()
            n = ctypes.c_uint(0)
            if self.f["enum"](gpus, ctypes.byref(n)) != 0 or not n.value:
                self.erro = "nenhuma placa NVIDIA encontrada"
                return False
            self.gpu = gpus[0]
            if n.value > 1 and "nome" in self.f and nome_nvml:  # mais de uma placa: pega a mesma que a NVML mostra
                for k in range(min(n.value, 64)):
                    buf = ctypes.create_string_buffer(64)
                    if self.f["nome"](gpus[k], buf) == 0 and buf.value.decode("utf-8", "replace").strip() in nome_nvml:
                        self.gpu = gpus[k]
                        break
        except (OSError, ValueError, ctypes.ArgumentError):
            self.erro = "a biblioteca da NVIDIA deu erro"
            return False
        self.ok = True
        return True

    def ler(self):
        """(código, {domínio: {...}}) do P0. Código 0 = deu certo."""
        if not self.ok:
            return -6, {}
        b = ctypes.create_string_buffer(_PS20_TAM)
        ctypes.c_uint.from_buffer(b).value = _PS20_VER1
        try:
            cod = int(self.f["ler"](self.gpu, b))
        except (OSError, ValueError, ctypes.ArgumentError):
            return -1, {}
        return cod, (nvapi_ps20_ler(b.raw) if cod == 0 else {})

    def definir(self, dominio, mhz):
        if not self.ok:
            return -6
        b = ctypes.create_string_buffer(bytes(nvapi_ps20_montar(dominio, mhz)), _PS20_TAM)
        try:
            return int(self.f["definir"](self.gpu, b))
        except (OSError, ValueError, ctypes.ArgumentError):
            return -1


def _motivo_nvapi(cod):
    return _NVAPI_ERROS.get(cod, f"erro {cod} do driver da NVIDIA")


class OverclockMixin:
    """Barra de overclock da placa de vídeo (página GPU & NVIDIA)."""

    def oc_iniciar_estado(self):
        self.oc_nv = _Nvml()
        self.oc_api = _Nvapi()
        self._oc_trava = threading.RLock()
        self._oc = {"nivel": 0, "info": None, "aviso": "", "pronto": False}
        if CONFIG.get("oc_ativo"):  # a vez anterior fechou sem zerar: volta tudo ao padrão antes de qualquer coisa
            threading.Thread(target=self._oc_zerar_antigo, daemon=True).start()
        threading.Thread(target=self._vigiar_oc, daemon=True).start()

    # ----- leitura -----

    def _oc_ler(self):
        """Lê a placa: limites, valores de agora e a tabela da barra. Sempre devolve um dict."""
        nv = self.oc_nv
        if not hasattr(self, "oc_api"):
            self.oc_api = _Nvapi()
        if not nv.abrir():
            return {"suporte": False, "motivo": nv.erro or "Sem placa NVIDIA."}
        i = {"suporte": True, "nome": nv.nome()}
        cod_f, faixa = nv.i32_dois("nvmlDeviceGetGpcClkMinMaxVfOffset")
        cod_a, agora = nv.i32("nvmlDeviceGetGpcClkVfOffset")
        i["nucleo"] = {"ok": cod_f == 0 and cod_a == 0, "agora": agora or 0, "max": max(0, faixa[1]) if faixa else 0,
                       "motivo": "" if cod_f == 0 and cod_a == 0 else _motivo_nvml(cod_f or cod_a)}
        cod_f, faixa = nv.i32_dois("nvmlDeviceGetMemClkMinMaxVfOffset")
        cod_a, agora = nv.i32("nvmlDeviceGetMemClkVfOffset")
        i["memoria"] = {"ok": cod_f == 0 and cod_a == 0, "agora": agora or 0, "max": max(0, faixa[1]) if faixa else 0,
                        "motivo": "" if cod_f == 0 and cod_a == 0 else _motivo_nvml(cod_f or cod_a)}
        for chave, dom, cheio in (("nucleo", NVAPI_NUCLEO, OC_NUCLEO_150), ("memoria", NVAPI_MEMORIA, OC_MEM_150)):
            i[chave]["via"] = "nvml"
            i[chave]["cheio"] = cheio
        if not (i["nucleo"]["ok"] and i["memoria"]["ok"]) and self.oc_api.abrir(i["nome"]):  # v9.3: placas mais antigas
            cod, ps = self.oc_api.ler()
            for chave, dom, cheio in (("nucleo", NVAPI_NUCLEO, OC_NUCLEO_150), ("memoria", NVAPI_MEMORIA, OC_MEM_150_NVAPI)):
                if i[chave]["ok"]:
                    continue
                d = ps.get(dom)
                if cod == 0 and d and d["editavel"] and d["max"] > 0:
                    i[chave] = {"ok": True, "agora": d["agora"], "max": d["max"], "min": d["min"], "motivo": "", "via": "nvapi", "cheio": cheio}
                elif cod != 0:
                    i[chave]["motivo"] = _motivo_nvapi(cod)
                elif d and not d["editavel"]:
                    i[chave]["motivo"] = "o driver desta placa trava esse ajuste (comum em notebook)"
        cod_p, padrao = nv.u32("nvmlDeviceGetPowerManagementDefaultLimit")
        cod_l, limites = nv.u32_dois("nvmlDeviceGetPowerManagementLimitConstraints")
        cod_n, atual = nv.u32("nvmlDeviceGetPowerManagementLimit")
        pot_ok = cod_p == 0 and cod_l == 0 and cod_n == 0
        i["potencia"] = {"ok": pot_ok, "agora": round((atual or 0) / 1000.0), "padrao": round((padrao or 0) / 1000.0),
                         "min": round(limites[0] / 1000.0) if limites else 0, "max": round(limites[1] / 1000.0) if limites else 0,
                         "padrao_mw": padrao or 0, "agora_mw": atual or 0, "min_mw": limites[0] if limites else 0, "max_mw": limites[1] if limites else 0,
                         "motivo": "" if pot_ok else _motivo_nvml(cod_p or cod_l or cod_n)}
        i["temp"] = nv.temperatura()
        i["mhz"] = nv.clock(0)
        i["mhz_mem"] = nv.clock(2)
        cod_u, uso = nv.u32("nvmlDeviceGetPowerUsage")
        i["consumo"] = round(uso / 1000.0) if cod_u == 0 and uso is not None else None
        teto = {"core": min(i["nucleo"]["cheio"], i["nucleo"]["max"]) if i["nucleo"]["ok"] else 0,
                "mem": min(i["memoria"]["cheio"], i["memoria"]["max"]) if i["memoria"]["ok"] else 0,
                "padrao": i["potencia"]["padrao"] if pot_ok else 0, "max": i["potencia"]["max"] if pot_ok else 0}
        i["teto"] = teto
        i["tabela"] = oc_tabela(teto)
        i["algum"] = bool(i["nucleo"]["ok"] or i["memoria"]["ok"] or pot_ok)
        return i

    def oc_estado(self):
        o = self._oc
        return {"info": o["info"], "nivel": o["nivel"], "aviso": o["aviso"], "pronto": o["pronto"],
                "limite_temp": OC_TEMP_LIMITE, "max": OC_MAX, "passo": OC_PASSO}

    # ----- aplicar -----

    def oc_definir(self, nivel):
        if not isinstance(nivel, int) or isinstance(nivel, bool) or not 0 <= nivel <= OC_MAX:
            raise ValueError("nível inválido")
        if nivel and not e_admin():
            return self.msg("O overclock precisa do Th Boost aberto como Administrador. Feche e abra pelo atalho da área de trabalho.")
        self.msg("Aplicando o overclock..." if nivel else "Voltando a placa ao padrão...")
        self.em_fundo(lambda: self.t_oc_definir(nivel))

    def t_oc_definir(self, nivel, motivo=""):
        with self._oc_trava:
            nv = self.oc_nv
            info = self._oc_ler()
            if not info["suporte"]:
                return info["motivo"]
            if not info["algum"]:
                return "Esta placa não aceita overclock por aqui: " + (info["nucleo"]["motivo"] or info["potencia"]["motivo"]) + "."
            core, mem, watts = oc_plano(nivel, info["teto"])
            # v9.1: o "0%" volta ao que a placa tinha ANTES do Th Boost (por exemplo um ajuste feito no Afterburner),
            # e não ao zero de fábrica
            antes = CONFIG.get("oc_antes") if isinstance(CONFIG.get("oc_antes"), dict) else None
            if nivel and not self._oc["nivel"] and not CONFIG.get("oc_ativo"):
                antes = {"core": int(info["nucleo"]["agora"] or 0) if info["nucleo"]["ok"] else 0,
                         "mem": int(info["memoria"]["agora"] or 0) if info["memoria"]["ok"] else 0,
                         "pot_mw": int(info["potencia"]["agora_mw"]) if info["potencia"]["ok"] else 0}
                CONFIG["oc_antes"] = antes
            antes = antes or {}

            def _volta(chave, padrao, minimo, maximo):
                v = antes.get(chave)
                return v if isinstance(v, int) and not isinstance(v, bool) and minimo <= v <= maximo else padrao
            api = self.oc_api

            def pela_nvml(fn):
                return lambda v: (nv.definir(fn, v), _motivo_nvml)

            def pela_nvapi(dom):
                return lambda v: (api.definir(dom, v), _motivo_nvapi)
            passos = []  # (nome, função que aplica, valor, valor ao zerar)
            if info["potencia"]["ok"]:
                pot = info["potencia"]  # em miliwatts exatos: 0% devolve o de antes (ou o padrão da placa) sem arredondar
                zero_mw = _volta("pot_mw", pot["padrao_mw"], pot["min_mw"], pot["max_mw"])
                alvo_mw = zero_mw if not nivel else max(pot["min_mw"], min(watts * 1000, pot["max_mw"]))
                passos.append(("potência", pela_nvml("nvmlDeviceSetPowerManagementLimit"), alvo_mw, zero_mw))
            if info["memoria"]["ok"]:
                zero = _volta("mem", 0, -3000, 3000)
                fn = pela_nvapi(NVAPI_MEMORIA) if info["memoria"].get("via") == "nvapi" else pela_nvml("nvmlDeviceSetMemClkVfOffset")
                passos.append(("memória", fn, mem if nivel else zero, zero))
            if info["nucleo"]["ok"]:
                zero = _volta("core", 0, -1000, 1000)
                fn = pela_nvapi(NVAPI_NUCLEO) if info["nucleo"].get("via") == "nvapi" else pela_nvml("nvmlDeviceSetGpcClkVfOffset")
                passos.append(("núcleo", fn, core if nivel else zero, zero))
            falhas = []
            for nome, fn, valor, _ in passos:
                cod, motivo_de = fn(valor)
                if cod != 0:
                    falhas.append(f"{nome}: {motivo_de(cod)}")
                    if nivel:
                        break
            if falhas and nivel:  # não deixa pela metade: volta tudo ao padrão
                for _, fn, _, zero in passos:
                    fn(zero)
                self._oc["nivel"] = 0
                CONFIG.pop("oc_ativo", None)
                CONFIG.pop("oc_antes", None)
                salvar_config()
                return "Não consegui aplicar (" + "; ".join(falhas) + "). A placa ficou como estava."
            self._oc["nivel"] = nivel
            self._oc["aviso"] = motivo
            if nivel:
                CONFIG["oc_ativo"] = True
            else:
                CONFIG.pop("oc_ativo", None)
                CONFIG.pop("oc_antes", None)
            salvar_config()
            self._oc["info"] = self._oc_ler()
            if not nivel:
                return motivo or ("Overclock em 0%: a placa voltou ao que era antes." + (" Alguns itens não responderam: " + "; ".join(falhas) if falhas else ""))
            partes = []
            if info["nucleo"]["ok"]:
                partes.append(f"núcleo +{core} MHz")
            if info["memoria"]["ok"]:
                partes.append(f"memória +{mem} MHz")
            if info["potencia"]["ok"]:
                partes.append(f"potência {watts} W")
            ausentes = [n for n, k in (("núcleo", "nucleo"), ("memória", "memoria"), ("potência", "potencia")) if not info[k]["ok"]]
            fim = f" (esta placa não aceita ajuste de {', '.join(ausentes)})" if ausentes else ""
            return f"Overclock em {nivel}%: " + ", ".join(partes) + "." + fim + " Acompanhe a temperatura."

    def _oc_zerar_antigo(self):
        try:
            texto = self.t_oc_definir(0, "O overclock de antes foi desligado (o programa tinha fechado com ele ligado).")
            self.msg(texto)
        except Exception:
            pass

    def oc_fechar(self):
        """Ao encerrar o Th Boost: devolve a placa ao padrão (só se ele mexeu)."""
        try:
            if self._oc["nivel"] or CONFIG.get("oc_ativo"):
                self.t_oc_definir(0, "")
        except Exception:
            pass

    # ----- vigia de temperatura -----

    def _vigiar_oc(self):
        while not self.fechando:
            nivel = self._oc["nivel"]
            try:
                if nivel or not self.ocioso:
                    info = self._oc_ler()
                    self._oc["info"] = info
                    self._oc["pronto"] = True
                    if not info["suporte"]:
                        return  # sem placa NVIDIA: nada a vigiar
                    t = info.get("temp")
                    if nivel and t is not None and t >= OC_TEMP_LIMITE:
                        texto = self.t_oc_definir(0, f"A placa chegou a {t}°C: o overclock foi desligado sozinho (voltou a 0%).")
                        self.msg(texto)
                    elif nivel and t is not None and t >= OC_TEMP_AVISO:
                        self._oc["aviso"] = f"A placa está em {t}°C. Se passar de {OC_TEMP_LIMITE}°C o overclock desliga sozinho."
                    elif nivel and self._oc["aviso"].startswith("A placa está"):
                        self._oc["aviso"] = ""
            except Exception:
                pass
            time.sleep(2.0 if nivel else 3.0)


# ---------------- perfil de desempenho da CPU (página Processador) ----------------
#
# O clock real do processador (overclock de verdade) só é mudado na BIOS da placa-mãe: nenhum programa do Windows faz isso
# com segurança, igual à memória RAM. O que o Windows deixa ajustar é COMO o processador se comporta: quão rápido sobe de
# velocidade, se o turbo fica liberado e se algum núcleo pode "dormir". É isso que os perfis abaixo mexem, no plano de
# energia que estiver ativo e só na tomada (na bateria nada muda).
#   Padrão do Windows = o plano do jeito que estava antes do Th Boost mexer (é o que a página mostra ao abrir);
#   Desempenho        = sobe de clock rápido, núcleos acordados, turbo liberado;
#   Máximo            = sempre em velocidade alta, turbo no máximo, preferência total por desempenho.
# Antes de mudar, o Th Boost guarda os valores originais no th_boost_config.json e "Padrão do Windows" devolve exatamente eles.

_SUB_PROC = "54533251-82be-4824-96c1-47b60b740d00"
_CFG_CPU = {
    "min": (_SUB_PROC, "893dee8e-2bef-41e0-89c6-b55d0929964c"),      # estado mínimo do processador (%)
    "max": (_SUB_PROC, "bc5038f7-23e0-4960-96da-33abaf5935ec"),      # estado máximo do processador (%)
    "nucleos": (_SUB_PROC, "0cc5b647-c1df-4637-891a-dec35c318583"),  # núcleos que ficam sempre acordados (%)
    "turbo": (_SUB_PROC, "be337238-0d82-4146-a960-4f3749d470c7"),    # modo do turbo (2 = agressivo)
    "turbo_pol": (_SUB_PROC, "45bcc044-d885-43e2-8605-ee0ec6e96b59"),  # política do turbo (%)
    "epp": (_SUB_PROC, "36687f9e-e3a5-4dbf-b1dc-15eb381c6863"),      # preferência energia x desempenho (0 = desempenho)
    "ventoinha": (_SUB_PROC, "94d3a615-a899-4ac5-ae2b-e4d8f634367f"),  # refrigeração ativa (1)
}
PERFIS_CPU = {
    "desempenho": {"min": 50, "max": 100, "nucleos": 100, "turbo": 2, "epp": 30, "ventoinha": 1},
    "maximo": {"min": 100, "max": 100, "nucleos": 100, "turbo": 2, "turbo_pol": 100, "epp": 0, "ventoinha": 1},
    # v8.8: perfis para ESFRIAR o PC ou o notebook (página Resfriamento): o turbo é a velocidade extra que mais esquenta
    "fresco": {"max": 90, "turbo": 0, "epp": 60, "ventoinha": 1},
    "gelado": {"min": 5, "max": 70, "turbo": 0, "epp": 80, "ventoinha": 1},
}
NOMES_CPU = {"padrao": "Padrão do Windows", "desempenho": "Desempenho", "maximo": "Máximo", "fresco": "Fresco", "gelado": "Gelado"}
_TEXTOS_CPU = [
    {"id": "padrao", "titulo": "Padrão do Windows", "tag": "0%",
     "texto": "O processador se comporta do jeito que o seu plano de energia já tinha. É assim que a página abre.",
     "itens": ["Nada é mexido", "Se o Th Boost mudou algo antes, isso volta exatamente como estava"]},
    {"id": "desempenho", "titulo": "Desempenho", "tag": "MÉDIO",
     "texto": "O processador sobe de velocidade mais rápido, nenhum núcleo dorme e o turbo fica liberado. Esquenta e gasta um pouco mais.",
     "itens": ["Velocidade mínima: 50%", "Núcleos sempre acordados: 100%", "Turbo agressivo", "Preferência por desempenho"]},
    {"id": "maximo", "titulo": "Máximo", "tag": "ALTO",
     "texto": "Processador sempre em velocidade alta, turbo no máximo e preferência total por desempenho. Mais calor, ventoinha mais alta e mais consumo: bom para jogar, na tomada.",
     "itens": ["Velocidade mínima: 100%", "Núcleos sempre acordados: 100%", "Turbo agressivo e política 100%", "Preferência: só desempenho", "Ventoinha ativa"]},
]
_TEXTOS_FRIO = [
    {"id": "padrao", "titulo": "Normal", "tag": "NORMAL",
     "texto": "O processador se comporta do jeito que o seu plano de energia já tinha. Se o Th Boost esfriou o PC antes, tudo volta exatamente como estava.",
     "itens": ["Nada é mexido", "Os valores de antes voltam inteiros"]},
    {"id": "fresco", "titulo": "Fresco", "tag": "MAIS FRIO",
     "texto": "O processador não passa de 90% da velocidade e o turbo (a velocidade extra, que é o que mais esquenta) fica desligado. Costuma baixar vários graus e quase não se nota no dia a dia.",
     "itens": ["Velocidade máxima: 90%", "Turbo desligado", "Prefere gastar menos energia", "Ventoinha ativa antes de reduzir a velocidade"]},
    {"id": "gelado", "titulo": "Gelado", "tag": "BEM FRIO",
     "texto": "O processador não passa de 70%, sem turbo, e volta a ficar bem lento quando está parado. É o que mais esfria, mas o PC fica mais devagar em tarefas pesadas e em jogos.",
     "itens": ["Velocidade máxima: 70%", "Velocidade mínima: 5%", "Turbo desligado", "Prefere economizar energia", "Ventoinha ativa antes de reduzir a velocidade"]},
]
_ROTULOS_CPU = {"min": "Velocidade mínima", "max": "Velocidade máxima", "nucleos": "Núcleos sempre acordados", "turbo": "Modo do turbo",
                "turbo_pol": "Política do turbo", "epp": "Preferência por desempenho", "ventoinha": "Ventoinha ativa"}


# Temperatura: o Windows só informa a "zona térmica" da placa (ACPI), que em muitos notebooks acompanha o calor do processador e em
# alguns PCs de mesa é um número fixo. Por isso a página chama de aproximada. Precisa de Administrador. Lê em segundo plano e guarda
# por 20 segundos, para a tela não esperar o PowerShell.
PS_TEMP_ZONA = ("$t=@(Get-CimInstance -Namespace root/wmi -ClassName MSAcpi_ThermalZoneTemperature -ErrorAction SilentlyContinue | "
                "ForEach-Object {[math]::Round($_.CurrentTemperature/10-273.15)}); if($t.Count){($t | Measure-Object -Maximum).Maximum}")
_TEMP_ZONA = {"v": None, "t": 0.0, "lendo": False}


def interpretar_temp_zona(saida):
    """O número que o PowerShell imprimiu -> graus Celsius plausíveis (10 a 120), ou None. Função pura."""
    m = re.fullmatch(r"\s*(-?\d{1,3})(?:[.,]\d+)?\s*", saida or "")
    if not m:
        return None
    v = int(m.group(1))
    return v if 10 <= v <= 120 else None


def _atualizar_temp_zona():
    try:
        cod, saida = powershell(PS_TEMP_ZONA, tempo=25)
        _TEMP_ZONA["v"] = interpretar_temp_zona(saida) if cod == 0 else None
    except Exception:
        _TEMP_ZONA["v"] = None
    _TEMP_ZONA["t"] = time.time()
    _TEMP_ZONA["lendo"] = False


def temperatura_zona_windows():
    """(graus ou None, de onde veio). Nunca espera: devolve o que já foi lido e pede uma leitura nova em segundo plano."""
    if not IS_WIN:
        return None, ""
    if time.time() - _TEMP_ZONA["t"] > 20 and not _TEMP_ZONA["lendo"]:
        _TEMP_ZONA["lendo"] = True
        threading.Thread(target=_atualizar_temp_zona, daemon=True).start()
    return _TEMP_ZONA["v"], ("zona térmica do Windows" if _TEMP_ZONA["v"] is not None else "")


def _hex_ac(saida):
    """O valor de CA (tomada) que o 'powercfg /query' imprime. As duas últimas linhas com 0x são CA e CC, em qualquer idioma."""
    achados = re.findall(r"0x[0-9a-fA-F]{8}", saida or "")
    return int(achados[-2], 16) if len(achados) >= 2 else None


def cpu_plano_ativo():
    """(guid, nome) do plano de energia ativo, ou (None, '')."""
    cod, saida = executar(["powercfg", "/getactivescheme"])
    m = re.search(rf"({_GUID})\s*(?:\(([^)]*)\))?", saida or "") if cod == 0 else None
    return (m.group(1).lower(), (m.group(2) or "").strip()) if m else (None, "")


def cpu_valores_ac(guid):
    """Valores atuais (tomada) de cada ajuste de CPU do plano. None onde o Windows não informa."""
    saida = {}
    for chave, (sub, cfg) in _CFG_CPU.items():
        cod, txt = executar(["powercfg", "/qh", guid, sub, cfg])  # v9.1: /qh mostra também os ajustes escondidos
        saida[chave] = _hex_ac(txt) if cod == 0 else None
    return saida


def cpu_perfil_detectar(valores):
    """Qual perfil os valores de agora já correspondem: 'maximo', 'desempenho', 'gelado', 'fresco' ou 'padrao'."""
    for nome in ("maximo", "desempenho", "gelado", "fresco"):
        comparaveis = [(k, v) for k, v in PERFIS_CPU[nome].items() if valores.get(k) is not None]  # o que o PC não tem não conta
        if len(comparaveis) >= 3 and all(valores[k] == v for k, v in comparaveis):
            return nome
    return "padrao"


def cpu_x3d_duplo(nome=None, logicos=None):
    """AMD Ryzen X3D com mais de 8 núcleos (dois blocos, só um com V-Cache). Função pura quando recebe os dados."""
    nome = nome if nome is not None else (nome_do_processador() if IS_WIN else "")
    logicos = logicos if logicos is not None else (psutil.cpu_count() or 0)
    return bool(re.search(r"X3D\b", nome or "", re.I)) and logicos > 16


def cpu_alvo(nivel, antes):
    """Valor de cada ajuste ao ir para um perfil: o do perfil, ou o original guardado nos que o perfil não mexe. Função pura."""
    perfil = PERFIS_CPU.get(nivel) or {}
    alvo = {}
    for chave in _CFG_CPU:
        if antes.get(chave) is None:
            continue  # v9.1: sem o valor original guardado, não mexe (não daria para voltar depois)
        v = perfil.get(chave, antes.get(chave))
        if isinstance(v, int) and not isinstance(v, bool):
            alvo[chave] = v
    return alvo


class CpuPerfilMixin:
    """Perfis de desempenho da CPU (página Processador)."""

    def cpu_perfil_iniciar_estado(self):
        self._cpup = {"t": 0.0, "dados": None}
        self._cpup_trava = threading.Lock()

    @staticmethod
    def _cpup_cfg():
        c = CONFIG.get("cpu_perfil")
        return c if isinstance(c, dict) and c.get("nivel") in PERFIS_CPU and isinstance(c.get("antes"), dict) else None

    def cpu_perfil_lista(self):
        """O que a página Processador mostra. Lê o plano com o powercfg (guarda por 4 segundos)."""
        agora = time.time()
        with self._cpup_trava:
            if self._cpup["dados"] and agora - self._cpup["t"] < 4.0:
                return self._cpup["dados"]
            freq = None
            try:
                freq = psutil.cpu_freq()
            except Exception:
                pass
            d = {"windows": bool(IS_WIN), "admin": e_admin(), "cpu": nome_do_processador() if IS_WIN else "",
                 "fisicos": psutil.cpu_count(logical=False) or 0, "logicos": psutil.cpu_count() or 0,
                 "mhz": round(freq.current) if freq and freq.current else None, "mhz_max": round(freq.max) if freq and freq.max else None,
                 "perfis": _TEXTOS_CPU, "frios": _TEXTOS_FRIO, "rotulos": _ROTULOS_CPU, "temp": None, "temp_fonte": "", "uso": None, "plano": "", "valores": {}, "atual": "padrao", "aplicado": False,
                 "guardado": False}
            try:
                d["uso"] = round(psutil.cpu_percent(interval=None))
            except Exception:
                pass
            if IS_WIN:
                d["temp"], d["temp_fonte"] = temperatura_zona_windows()
                guid, nome = cpu_plano_ativo()
                if guid:
                    d["plano"] = nome
                    d["valores"] = cpu_valores_ac(guid)
                    d["atual"] = cpu_perfil_detectar(d["valores"])
                cfg = self._cpup_cfg()
                d["aplicado"] = bool(cfg and cfg["nivel"] == d["atual"])
                d["guardado"] = bool(cfg)
            self._cpup.update(t=agora, dados=d)
            return d

    def cpu_perfil_definir(self, nivel):
        if nivel not in NOMES_CPU:
            raise ValueError("perfil inválido")
        if not IS_WIN:
            return self.msg("O perfil da CPU só existe no Windows.")
        if not e_admin():
            return self.msg("Mudar o plano de energia precisa do Th Boost aberto como Administrador. Feche e abra pelo atalho da área de trabalho.")
        self.msg("Aplicando o perfil da CPU...")
        self.em_fundo(lambda: self.t_cpu_perfil_definir(nivel))

    def t_cpu_perfil_definir(self, nivel):
        trava = self.__dict__.setdefault("_cpup_aplicando", threading.Lock())
        if not trava.acquire(blocking=False):
            return "Já estou aplicando um perfil. Espere terminar."
        try:
            return self._t_cpu_perfil_definir(nivel)
        finally:
            trava.release()

    def _t_cpu_perfil_definir(self, nivel):
        planos = {p["guid"] for p in listar_planos()}
        cfg = self._cpup_cfg()
        if nivel == "padrao":
            if not cfg:
                return "A CPU já está no padrão do seu plano de energia: o Th Boost não tinha mudado nada."
            guid, antes = cfg.get("plano"), cfg["antes"]
            if guid not in planos:  # o plano que ele tinha mexido foi apagado
                CONFIG.pop("cpu_perfil", None)
                salvar_config()
                self._cpup["t"] = 0.0
                return "O plano de energia que o Th Boost tinha mudado não existe mais. Não há nada para desfazer."
            nivel_alvo = "padrao"
        else:
            guid, nome = cpu_plano_ativo()
            if not guid:
                return "Não consegui ler o plano de energia do Windows."
            if cfg and cfg.get("plano") == guid:
                antes = cfg["antes"]  # já guardado: nunca sobrescreve o original
            else:
                if cfg and cfg.get("plano") in planos:  # trocou de plano: devolve o antigo antes de mexer no novo
                    self._cpu_perfil_gravar(cfg["plano"], cpu_alvo("padrao", cfg["antes"]), False)
                antes = cpu_valores_ac(guid)
            nivel_alvo = nivel
        alvo = cpu_alvo(nivel_alvo, antes)
        if nivel_alvo == "padrao" and cfg and "turbo" not in alvo and "turbo" in (PERFIS_CPU.get(cfg.get("nivel")) or {}):
            # v9.1: versões antigas não conseguiam ler o turbo (ajuste escondido) e não o guardavam; o Fresco/Gelado o
            # desligavam e o "Normal" não o devolvia. Volta para o padrão do Windows na tomada (2 = agressivo).
            alvo["turbo"] = 2
        if nivel_alvo != "padrao" and cpu_x3d_duplo():
            alvo.pop("nucleos", None)  # v9.1: X3D de dois blocos: o driver da AMD cuida dos núcleos durante o jogo
        # v9.1: "Padrão" devolve os valores do plano guardado, mas só ativa esse plano se ele já era o ativo
        # (se você está na Extrema ou numa sessão de jogo, não troca de plano por baixo dela)
        ativar = nivel_alvo != "padrao" or cpu_plano_ativo()[0] == guid
        feitos = self._cpu_perfil_gravar(guid, alvo, ativar)
        if feitos < 2:  # não deixa pela metade: devolve o plano ao que estava
            anterior = cfg["nivel"] if cfg and cfg.get("plano") == guid else "padrao"
            self._cpu_perfil_gravar(guid, cpu_alvo(anterior, antes), ativar)
            return "O Windows recusou a mudança no plano de energia. Confira se abriu como Administrador."
        if nivel_alvo == "padrao":
            CONFIG.pop("cpu_perfil", None)
        else:
            CONFIG["cpu_perfil"] = {"nivel": nivel_alvo, "plano": guid, "antes": {k: v for k, v in antes.items() if isinstance(v, int)}}
        salvar_config()
        self._cpup["t"] = 0.0
        nomes = NOMES_CPU
        return f"Perfil da CPU: {nomes[nivel_alvo]}." + (" Os valores de antes voltaram." if nivel_alvo == "padrao" else " Para desfazer, escolha Padrão do Windows.")

    @staticmethod
    def _cpu_perfil_gravar(guid, alvo, ativar):
        """Grava os valores no plano. Devolve quantos o Windows aceitou (o que o PC não tem é ignorado)."""
        feitos = 0
        for chave, valor in alvo.items():
            sub, cfg = _CFG_CPU[chave]
            cod, _ = executar(["powercfg", "/setacvalueindex", guid, sub, cfg, str(int(valor))])
            feitos += 1 if cod == 0 else 0
        if ativar:
            executar(["powercfg", "/setactive", guid])
        return feitos


# ---------------- mouse: reconhecer a marca e o modelo ----------------
#
# Para cada mouse USB ou Bluetooth o Windows guarda o código do fabricante (VID), o código do produto (PID) e o texto que o
# próprio mouse informa ("G502 HERO Gaming Mouse", por exemplo). O Th Boost só LÊ esses dados e tenta reconhecer a marca e o
# modelo. Nem todo mouse informa o modelo: os sem fio com receptor (Logitech Unifying e Lightspeed, por exemplo) aparecem só
# como "USB Receiver". Nesse caso a pessoa escolhe o modelo à mão e o Th Boost lembra da escolha. Nada é gravado no mouse.
# A imagem é uma ilustração própria do Th Boost (o programa não traz fotos de produtos, que têm dono): cada modelo conhecido tem
# o seu formato, cores, botões laterais, cabo e luz; os outros caem num formato parecido. A pessoa também pode usar a FOTO DELA
# do mouse (um arquivo do computador), que fica guardada só neste PC.

# marca: (cor do destaque na ilustração, é marca de mouse gamer?)
MARCAS_MOUSE = {
    "Logitech": ("#00b8fc", True), "Razer": ("#44d62c", True), "SteelSeries": ("#ff5200", True),
    "Corsair": ("#ffd400", True), "ASUS": ("#ff2d46", True), "HyperX": ("#e4002b", True),
    "Redragon": ("#e11d2e", True), "Glorious": ("#e9e9ee", True), "Zowie": ("#e5202e", True),
    "Cooler Master": ("#a855f7", True), "Roccat": ("#35c0a8", True), "Mad Catz": ("#ff7a00", True),
    "Pulsar": ("#22d3ee", True), "Finalmouse": ("#e9e9ee", True), "Lamzu": ("#f472b6", True),
    "Attack Shark": ("#fb923c", True), "Endgame Gear": ("#facc15", True), "Vaxee": ("#60a5fa", True),
    "Havit": ("#f97316", True), "Fortrek": ("#ef4444", True), "Warrior": ("#ef4444", True), "A4Tech": ("#f43f5e", True),
    "Microsoft": ("#7fba00", False), "Dell": ("#3b82f6", False), "HP": ("#38bdf8", False), "Lenovo": ("#ef4444", False),
    "Genius": ("#f59e0b", False), "Rapoo": ("#34d399", False), "Multilaser": ("#3b82f6", False), "Trust": ("#e5e7eb", False),
}
COR_PADRAO_MOUSE = "#3389fa"  # v8.9: azul do tema (antes vermelho); as marcas continuam com a cor delas

# código do fabricante (VID) -> marca. Só os que são do fabricante mesmo (chips genéricos de OEM ficam de fora).
VID_MARCAS = {"046d": "Logitech", "1532": "Razer", "1038": "SteelSeries", "1b1c": "Corsair", "0b05": "ASUS",
              "045e": "Microsoft", "413c": "Dell", "03f0": "HP", "17ef": "Lenovo", "0458": "Genius", "2516": "Cooler Master",
              "24ae": "Rapoo", "1e7d": "Roccat", "09da": "A4Tech", "0738": "Mad Catz"}

# palavras que aparecem no texto que o mouse informa (a marca ou uma linha famosa dela)
_TOKENS_MARCA = [
    (r"\blogitech\b|\blogi\b|lightspeed|unifying|\bmx (master|anywhere|vertical)\b|"
     r"\bg ?pro\b|\bg(102|203|300s?|304|305|402|502|600|602|603|604|703|900|903)\b", "Logitech"),
    (r"\brazer\b|deathadder|basilisk|lancehead|mamba|\bnaga\b|\bviper\b|orochi|abyssus|diamondback", "Razer"),
    (r"steelseries|\brival ?\d|\bsensei\b|aerox", "SteelSeries"),
    (r"corsair|dark ?core|scimitar|harpoon|ironclaw|nightsword|katar|\bm65\b|\bsabre\b", "Corsair"),
    (r"\basus\b|\brog\b|tuf gaming|gladius|chakram|pugio|spatha|keris", "ASUS"),
    (r"hyperx|pulsefire", "HyperX"), (r"redragon", "Redragon"), (r"glorious|\bmodel [od]\b", "Glorious"),
    (r"zowie|benq", "Zowie"), (r"cooler ?master|\bmm7\d\d\b", "Cooler Master"), (r"roccat|\bkone\b|\bburst\b", "Roccat"),
    (r"mad ?catz", "Mad Catz"), (r"pulsar", "Pulsar"), (r"finalmouse", "Finalmouse"), (r"lamzu", "Lamzu"),
    (r"attack ?shark", "Attack Shark"), (r"endgame", "Endgame Gear"), (r"vaxee", "Vaxee"), (r"havit", "Havit"),
    (r"fortrek", "Fortrek"), (r"warrior", "Warrior"), (r"a4 ?tech|bloody", "A4Tech"),
    (r"intellimouse|sculpt|\bmicrosoft\b", "Microsoft"), (r"\bdell\b", "Dell"), (r"\bhp\b|hewlett", "HP"),
    (r"lenovo", "Lenovo"), (r"genius", "Genius"), (r"rapoo", "Rapoo"), (r"multilaser", "Multilaser"), (r"\btrust\b", "Trust"),
]
_TOKENS_MARCA = [(re.compile(p, re.I), m) for p, m in _TOKENS_MARCA]

# textos que o Windows usa para qualquer mouse: não dizem o modelo
_GENERICOS_MOUSE = ("input device", "entrada usb", "dispositivo de entrada", "hid-compliant", "hid compliant", "compatível com hid",
                    "compativel com hid", "composite", "composto", "usb receiver", "receptor usb", "ps/2", "standard system",
                    "padrão do sistema", "padrao do sistema", "(standard", "human interface", "interface humana", "generic",
                    "genérico", "generico", "unknown", "desconhecido", "usb device", "dispositivo usb", "mouse compat",
                    "dispositivo hid", "hid device")
_RE_VIRTUAL = re.compile(r"virtual|vmware|vbox|parallels|qemu|hyper-v|remote desktop|terminal server|\brdp\b|"
                         r"área de trabalho remota|area de trabalho remota|synthetic", re.I)
_RE_TOUCHPAD = re.compile(r"touchpad|synaptics|\belan(tech)?\b|trackpad|trackpoint|pointing stick|precision touch", re.I)
_RE_RECEPTOR = re.compile(r"receiver|receptor|dongle|unifying|lightspeed|2\.4 ?g", re.I)
_RE_SEMFIO = re.compile(r"wireless|sem fio", re.I)
_RE_VID_USB = re.compile(r"VID_([0-9A-F]{4})&PID_([0-9A-F]{4})", re.I)
_RE_VID_BT = re.compile(r"VID&([0-9A-F]{4})([0-9A-F]{4})_PID&([0-9A-F]{4})", re.I)
_RE_ESPORTIVO = re.compile(r"viper|\bg ?pro\b|superlight|model [od]\b|zowie|\bec[12]\b|\bfk[12]\b|xm1|pulsar|finalmouse|lamzu|"
                           r"attack ?shark|vaxee|\bg(102|203|304|305|403|703)\b|aerox|orochi|harpoon|pulsefire|endgame", re.I)
_RE_ERGONOMICO = re.compile(r"deathadder|g502|g402|g602|g603|g604|g903|rival ?600|scimitar|\bnaga\b|\bkone\b|mx (master|vertical)|"
                            r"mamba|basilisk|nightsword|gladius|chakram|dark ?core|ironclaw|\bm65\b|\bm711\b", re.I)

PS_MOUSE = (
    "$m=@();"
    "foreach($d in @(Get-PnpDevice -Class Mouse -PresentOnly -ErrorAction SilentlyContinue | Select-Object -First 8)){"
    "$c=@();$id=$d.InstanceId;"
    "for($i=0;$i -lt 3 -and $id;$i++){"
    "$p=@{};"
    "foreach($k in @('DEVPKEY_Device_BusReportedDeviceDesc','DEVPKEY_Device_Manufacturer','DEVPKEY_NAME','DEVPKEY_Device_Parent')){"
    "try{$p[$k]=(Get-PnpDeviceProperty -InstanceId $id -KeyName $k -ErrorAction Stop).Data}catch{$p[$k]=$null}};"
    "$c+=@{id=$id;desc=$p['DEVPKEY_Device_BusReportedDeviceDesc'];fab=$p['DEVPKEY_Device_Manufacturer'];nome=$p['DEVPKEY_NAME']};"
    "$id=$p['DEVPKEY_Device_Parent']};"
    "$m+=@{cadeia=$c}};"
    "ConvertTo-Json -Compress -Depth 6 @{mouses=$m}"
)


def nomes_marcas_mouse():
    return sorted(MARCAS_MOUSE)


def _texto_mouse(x, limite=60):
    """Texto vindo do Windows ou da tela: sem caracteres de controle nem < >, uma linha só."""
    if not isinstance(x, str):
        return ""
    return re.sub(r"\s+", " ", re.sub(r"[\x00-\x1f\x7f<>]", " ", x)).strip()[:limite]


def _generico_mouse(t):
    b = t.lower()
    return not t or any(g in b for g in _GENERICOS_MOUSE)


def _limpar_modelo_mouse(texto, marca=""):
    """'Razer DeathAdder V2 Gaming Mouse' -> 'DeathAdder V2'. Devolve '' quando o texto é genérico ou não sobra nada."""
    t = _texto_mouse(texto)
    if _generico_mouse(t):
        return ""
    t = re.sub(r"\(.*?\)", " ", t)
    if marca:
        t = re.sub(r"^\s*" + re.escape(marca) + r"\b[\s\-_:]*", "", t, flags=re.I)
    t = re.sub(r"\b(gaming|game|wireless|wired|optical|usb|hid|compliant|device|mouse|mice|receiver|dongle|bluetooth|"
               r"2\.4 ?g(hz)?)\b", " ", t, flags=re.I)
    t = re.sub(r"\s+", " ", t).strip(" -_:,.")
    return t[:40] if len(t) >= 2 else ""


def _vid_pid_mouse(ids):
    for i in ids:
        m = _RE_VID_USB.search(i)
        if m:
            return m.group(1).lower(), m.group(2).lower()
    for i in ids:
        m = _RE_VID_BT.search(i)
        if m and m.group(1) == "0002":  # 0002 = código de fabricante da USB-IF; 0001 seria da Bluetooth SIG
            return m.group(2).lower(), m.group(3).lower()
    return "", ""


def _marca_pelos_textos(textos):
    for t in textos:
        for rx, marca in _TOKENS_MARCA:
            if rx.search(t):
                return marca
    return ""


def _entrada_mouse(e):
    """Uma entrada 'mouse' do Windows (com a cadeia de dispositivos pai) -> o que dá para dizer sobre ela."""
    cadeia = _lista(e.get("cadeia")) if isinstance(e, dict) else []
    if not cadeia:
        return None
    ids = [str(c.get("id") or "") for c in cadeia]
    descs = [_texto_mouse(c.get("desc")) for c in cadeia]
    nomes = [_texto_mouse(c.get("nome")) for c in cadeia]
    fabs = [_texto_mouse(c.get("fab")) for c in cadeia]
    todos = [t for t in descs + nomes + fabs if t]
    vid, pid = _vid_pid_mouse(ids)
    usb = any(i.upper().startswith("USB\\") for i in ids)
    bt = any("BTH" in i.upper() for i in ids)
    virtual = vid == "0e0f" or any(_RE_VIRTUAL.search(t) for t in todos) or any(i.upper().startswith(("ROOT\\", "VMBUS")) for i in ids)
    touch = any(_RE_TOUCHPAD.search(t) for t in todos)
    # o texto do produto: o primeiro que não é genérico (o próprio mouse informa; o nome do Windows vem depois)
    produto = next((t for t in descs + nomes if t and not _generico_mouse(t)), "")
    # fabricante só vale se não for o "Microsoft"/"(Standard ...)" que o Windows põe em qualquer mouse
    fab_util = [f for f in fabs if f and not _generico_mouse(f) and f.lower() not in ("microsoft", "microsoft corporation")]
    marca = _marca_pelos_textos([t for t in descs + nomes if t and not _generico_mouse(t)] + fab_util) or VID_MARCAS.get(vid, "")
    modelo = _limpar_modelo_mouse(produto, marca)
    if modelo and marca and modelo.lower() == marca.lower():
        modelo = ""
    junto = " ".join(todos)
    conexao = ("Bluetooth" if bt else "Sem fio (receptor USB)" if _RE_RECEPTOR.search(junto)
               else "Sem fio" if _RE_SEMFIO.search(junto) else "USB" if usb else "")
    return {"externo": (usb or bt) and not virtual and not touch, "virtual": virtual, "touchpad": touch, "marca": marca,
            "modelo": modelo, "vid": vid, "pid": pid, "conexao": conexao,
            "receptor": bool(_RE_RECEPTOR.search(junto) and not bt)}


# ---- perfis por modelo: como desenhar o mouse e o que se sabe com segurança sobre ele ----
# forma: pequeno | simples | esportivo | ergonomico (os 4 desenhos do Th Boost)
# corpo/lateral: cor do topo e das laterais da carcaça; laterais: botões do polegar (0 a 3); dpi: botão de DPI atrás da roda;
# rgb: faixa de luz na cor da marca; fio: '' (sem fio), 'liso' ou 'trancado'; logo: 'neon' (esportivo) ou 'discreto' (escritório).
# 'dados' só leva o que a ficha do fabricante ou do anúncio do produto diz; sem certeza, fica vazio.
PERFIS_MOUSE = [
    ("Redragon", r"\bg105\b", {"forma": "ergonomico", "corpo": "#17171c", "lateral": "#0c0c0f", "laterais": 2, "dpi": True, "rgb": True,
                                "fio": "trancado", "logo": "neon",
                                "dados": ["8 botões programáveis", "Sensor óptico com DPI ajustável até 8000", "Cabo USB trançado",
                                          "Luz RGB com vários efeitos", "Formato ergonômico para a mão direita"]}),
    ("Logitech", r"\bm170\b", {"forma": "pequeno", "corpo": "#8c9199", "lateral": "#16171b", "laterais": 0, "dpi": False, "rgb": False,
                                "fio": "", "logo": "discreto", "semfio": True, "dois": True,
                                "dados": ["Sem fio 2.4 GHz com receptor USB", "Sensor óptico de 1000 DPI",
                                          "Formato compacto para destros e canhotos"]}),
    ("Logitech", r"\bg502\b", {"forma": "ergonomico", "corpo": "#1c1c21", "lateral": "#0e0e11", "laterais": 3, "dpi": True, "rgb": True,
                                "fio": "liso", "logo": "neon", "dados": []}),
    ("Logitech", r"\bg(203|102)\b", {"forma": "esportivo", "corpo": "#1b1b20", "lateral": "#0e0e11", "laterais": 2, "dpi": True,
                                     "rgb": True, "fio": "liso", "logo": "neon", "dados": []}),
    ("Logitech", r"\bg ?pro\b|superlight", {"forma": "esportivo", "corpo": "#202026", "lateral": "#101013", "laterais": 2, "dpi": False,
                                             "rgb": False, "fio": "", "logo": "neon", "semfio": True, "dados": []}),
    ("Razer", r"deathadder", {"forma": "ergonomico", "corpo": "#1a1a1f", "lateral": "#0d0d10", "laterais": 2, "dpi": True, "rgb": True,
                              "fio": "liso", "logo": "neon", "dados": []}),
    ("Redragon", r".*", {"forma": "ergonomico", "corpo": "#17171c", "lateral": "#0c0c0f", "laterais": 2, "dpi": True, "rgb": True,
                         "fio": "liso", "logo": "neon", "dados": []}),
]
_PERFIS_MOUSE = [(m, re.compile(rx, re.I), p) for m, rx, p in PERFIS_MOUSE]
_RE_COR = re.compile(r"^#[0-9a-f]{6}$", re.I)


def perfil_do_mouse(marca, modelo):
    """O perfil de desenho do modelo, ou None se o modelo não é conhecido (aí vale o formato por marca)."""
    marca, modelo = (marca or "").strip(), (modelo or "").strip()
    for m, rx, p in _PERFIS_MOUSE:
        generico = rx.pattern == r".*"  # o perfil geral da marca vem por último
        if marca and marca != m:
            continue
        if generico:
            if marca == m:
                return dict(p)
            continue
        if modelo and rx.search(modelo):
            return dict(p)
    return None


def chave_do_mouse(marca, modelo):
    """Identifica o modelo para guardar a foto dele: minúsculas, só letras e números."""
    t = re.sub(r"[^a-z0-9]+", " ", f"{marca or ''} {modelo or ''}".lower()).strip()
    return t[:60] if len(t) >= 2 else ""


FOTO_MAX = 300 * 1024  # bytes: a tela reduz a foto antes de mandar


def foto_tipo(dados):
    """png, jpeg ou webp pelos primeiros bytes (a extensão e o Content-Type não valem). '' se for outra coisa."""
    if dados[:8] == b"\x89PNG\r\n\x1a\n":
        return "image/png"
    if dados[:3] == b"\xff\xd8\xff":
        return "image/jpeg"
    if dados[:4] == b"RIFF" and dados[8:12] == b"WEBP":
        return "image/webp"
    return ""


def _pasta_fotos():
    return os.environ.get("TOTIMIZE_FOTOS") or os.path.join(_pasta_dados(), "mouse_fotos")


def _arq_foto(chave):
    return os.path.join(_pasta_fotos(), hashlib.sha1(chave.encode("utf-8")).hexdigest()[:20] + ".img")


def foto_do_mouse(chave):
    """(bytes, tipo) da foto guardada para este modelo, ou None."""
    if not chave:
        return None
    try:
        with open(_arq_foto(chave), "rb") as f:
            dados = f.read(FOTO_MAX + 1)
    except OSError:
        return None
    tipo = foto_tipo(dados)
    return (dados, tipo) if tipo and len(dados) <= FOTO_MAX else None


def foto_guardar(chave, dados):
    """Guarda a foto (já conferida pelos primeiros bytes e pelo tamanho). Devolve '' se deu certo ou o motivo da recusa."""
    if not chave:
        return "Escolha a marca ou o modelo do mouse antes de usar uma foto."
    if not isinstance(dados, (bytes, bytearray)) or not dados:
        return "A foto veio vazia."
    if len(dados) > FOTO_MAX:
        return "A foto é grande demais (máximo 300 KB). Escolha outra ou reduza o tamanho."
    if not foto_tipo(bytes(dados)):
        return "Use uma foto PNG, JPG ou WEBP."
    try:
        os.makedirs(_pasta_fotos(), exist_ok=True)
        pasta = _pasta_fotos()
        outras = [n for n in os.listdir(pasta) if n.endswith(".img") and n != os.path.basename(_arq_foto(chave))]
        if len(outras) >= 30:  # pasta não cresce sem fim: apaga as mais antigas
            outras.sort(key=lambda n: os.path.getmtime(os.path.join(pasta, n)))
            for n in outras[: len(outras) - 29]:
                os.remove(os.path.join(pasta, n))
        tmp = _arq_foto(chave) + ".tmp"
        with open(tmp, "wb") as f:
            f.write(bytes(dados))
        os.replace(tmp, _arq_foto(chave))
    except OSError:
        return "Não consegui guardar a foto neste computador."
    return ""


def foto_apagar(chave):
    try:
        os.remove(_arq_foto(chave))
        return True
    except OSError:
        return False


def link_busca_foto(marca, modelo):
    """Endereço de busca de imagens para a pessoa achar a foto do mouse dela (abre no navegador, ela escolhe e salva)."""
    t = f"{marca or ''} {modelo or ''} mouse".strip()
    return "https://www.google.com/search?tbm=isch&q=" + urllib.parse.quote(t[:80])


def formato_do_mouse(marca, modelo):
    """Qual ilustração usar: 'esportivo' (leve e baixo), 'ergonomico' (grande, com apoio para o polegar) ou 'simples'."""
    perfil = perfil_do_mouse(marca, modelo)
    if perfil:
        return perfil["forma"]
    t = f"{marca} {modelo}"
    if _RE_ERGONOMICO.search(t):
        return "ergonomico"
    if _RE_ESPORTIVO.search(t):
        return "esportivo"
    return "esportivo" if (MARCAS_MOUSE.get(marca) or ("", False))[1] else "simples"


def _nome_do_mouse(marca, modelo):
    return " ".join(x for x in (marca, modelo) if x)


def _mouse_vazio():
    return {"achado": False, "nome": "", "marca": "", "modelo": "", "vid": "", "pid": "", "conexao": "", "formato": "simples",
            "cor": COR_PADRAO_MOUSE, "confianca": "nenhuma", "origem": "windows", "outros": [], "touchpad": False,
            "receptor": False, "dica": ""}


def analisar_mouse(d):
    """Transforma o que o Windows disse sobre os mouses em marca e modelo (função pura, testável)."""
    res = _mouse_vazio()
    if not isinstance(d, dict):
        return res
    ents = [x for x in (_entrada_mouse(e) for e in _lista(d.get("mouses"))) if x]
    externos = [x for x in ents if x["externo"]]
    if not externos:
        res["touchpad"] = any(x["touchpad"] for x in ents)
        res["dica"] = ("Só encontrei o touchpad do notebook. Conecte um mouse e toque em Atualizar."
                       if res["touchpad"] else "Não encontrei nenhum mouse conectado.")
        return res

    def pontos(x):
        return (4 if x["marca"] and x["modelo"] else 2 if x["marca"] else 1 if x["modelo"] else 0) + (1 if x["vid"] else 0)
    melhor = max(externos, key=pontos)
    vistos, outros = {_nome_do_mouse(melhor["marca"], melhor["modelo"]) or (melhor["vid"], melhor["pid"])}, []
    for x in externos:
        chave = _nome_do_mouse(x["marca"], x["modelo"]) or (x["vid"], x["pid"])
        if x is not melhor and chave not in vistos:
            vistos.add(chave)
            outros.append(_nome_do_mouse(x["marca"], x["modelo"]) or f"Mouse {x['vid'].upper()}:{x['pid'].upper()}".strip(": "))
    marca, modelo = melhor["marca"], melhor["modelo"]
    res.update(achado=True, marca=marca, modelo=modelo, vid=melhor["vid"].upper(), pid=melhor["pid"].upper(),
               conexao=melhor["conexao"], receptor=melhor["receptor"], outros=outros[:4],
               confianca="alta" if marca and modelo else ("media" if marca else "baixa"))
    if marca and not modelo and melhor["receptor"]:
        res["dica"] = ("O Windows só informa o fabricante do receptor sem fio, não o modelo do mouse. "
                       "Escolha o modelo abaixo e o Th Boost lembra.")
    elif marca and not modelo:
        res["dica"] = "O Windows informou a marca, mas não o modelo deste mouse. Dá para escolher o modelo abaixo."
    elif not marca and not modelo:
        res["dica"] = "Este mouse não informa marca nem modelo ao Windows. Dá para escolher à mão abaixo."
    return res


def combinar_mouse(det, manual=None):
    """Junta o que o Windows achou com a escolha manual da pessoa (a escolha manual vale mais). Sempre devolve o mesmo formato."""
    d = dict(det) if isinstance(det, dict) else _mouse_vazio()
    if isinstance(manual, dict) and (manual.get("marca") or manual.get("modelo")):
        d.update(achado=True, marca=manual.get("marca") or "", modelo=manual.get("modelo") or "", origem="manual",
                 confianca="manual", dica="")
    d["nome"] = _nome_do_mouse(d["marca"], d["modelo"]) or ("Mouse conectado" if d["achado"] else "")
    d["formato"] = formato_do_mouse(d["marca"], d["modelo"])
    d["cor"] = (MARCAS_MOUSE.get(d["marca"]) or (COR_PADRAO_MOUSE, False))[0]
    d["perfil"] = perfil_do_mouse(d["marca"], d["modelo"])
    d["chave"] = chave_do_mouse(d["marca"], d["modelo"])
    d["foto"] = False
    return d


def manual_mouse_valido(marca, modelo):
    """Confere a escolha vinda da tela. Devolve {'marca','modelo'} limpo ou None se for inválida. Vazio = voltar ao automático."""
    if marca is None:
        marca = ""
    if not isinstance(marca, str) or not isinstance(modelo, str) and modelo is not None:
        return None
    if marca and marca not in MARCAS_MOUSE:
        return None
    modelo = _texto_mouse(modelo or "", 40)
    if marca and modelo.lower().startswith(marca.lower() + " "):
        modelo = modelo[len(marca) + 1:].strip()
    return {"marca": marca, "modelo": modelo}


def ler_mouse():
    """Pergunta ao Windows quais mouses estão conectados. Devolve a análise ou None."""
    cod, saida = powershell(PS_MOUSE, tempo=60)
    if cod != 0 or not saida.strip():
        return None
    try:
        dados = json.loads(saida)
    except ValueError:
        return None
    return analisar_mouse(dados)


class MouseIdMixin:
    """A página Mouse e Precisão: reconhece o mouse em segundo plano e aplica o perfil competitivo."""

    def mouse_iniciar_estado(self):
        self.mouse_id = {"estado": "nenhum", "dados": None, "quando": 0.0}

    def mouse_agora(self, forcar=False):
        m = self.mouse_id
        if not forcar and m["estado"] == "pronto" and time.time() - m["quando"] < 300:
            return m["dados"]
        try:
            m["dados"] = ler_mouse()
            m["estado"] = "pronto" if m["dados"] else "erro"
        except Exception:
            m["dados"], m["estado"] = None, "erro"
        m["quando"] = time.time()
        return m["dados"]

    def mouse_ler(self, forcar=False):
        m = self.mouse_id
        if m["estado"] == "lendo" or REG is None:
            return
        if not forcar and m["estado"] == "pronto" and time.time() - m["quando"] < 300:
            return
        m["estado"] = "lendo"
        threading.Thread(target=lambda: self.mouse_agora(True), daemon=True).start()

    def mouse_lista(self):
        m = self.mouse_id
        if m["estado"] in ("nenhum", "erro") and REG is not None and time.time() - m["quando"] > 20:
            self.mouse_ler()
        dados = combinar_mouse(m["dados"], CONFIG.get("mouse_manual"))
        try:
            arq = _arq_foto(dados["chave"]) if dados["chave"] and foto_do_mouse(dados["chave"]) else ""
            dados["foto"] = int(os.path.getmtime(arq)) if arq else False  # a tela usa o número para recarregar quando a foto muda
        except OSError:
            dados["foto"] = False
        return {"estado": m["estado"] if REG is not None else "previa", "win": REG is not None,
                "dados": dados, "marcas": nomes_marcas_mouse(),
                "manual": CONFIG.get("mouse_manual") or {"marca": "", "modelo": ""}}

    def _mouse_atual(self):
        return combinar_mouse(self.mouse_id["dados"], CONFIG.get("mouse_manual"))

    def mouse_foto_atual(self):
        """(bytes, tipo) da foto que a pessoa guardou para o mouse mostrado agora, ou None."""
        return foto_do_mouse(self._mouse_atual()["chave"])

    def mouse_foto_guardar(self, dados):
        """Guarda a foto do mouse mostrado agora. Devolve '' se deu certo ou o motivo da recusa (já em português)."""
        d = self._mouse_atual()
        erro = foto_guardar(d["chave"], dados)
        if not erro:
            self.msg(f"Foto guardada para {d['nome'] or 'o mouse'}. Ela aparece no lugar do desenho.")
        return erro

    def mouse_foto_remover(self):
        d = self._mouse_atual()
        if foto_apagar(d["chave"]):
            self.msg("Foto removida: voltou o desenho do Th Boost.")

    def mouse_buscar_foto(self):
        """Abre a busca de imagens do mouse no navegador. O Th Boost não baixa nada: a pessoa escolhe e salva a foto."""
        d = self._mouse_atual()
        if not d["chave"]:
            return self.msg("Escolha a marca ou o modelo do mouse primeiro.")
        try:
            abrir_link(link_busca_foto(d["marca"], d["modelo"]))
            self.msg("Abrindo a busca de imagens. Salve a foto que gostar e use \"Usar minha foto\".")
        except Exception:
            self.msg("Não consegui abrir o navegador.")

    def mouse_definir_manual(self, marca, modelo):
        v = manual_mouse_valido(marca, modelo)
        if v is None:
            raise ValueError("escolha inválida")
        if v["marca"] or v["modelo"]:
            CONFIG["mouse_manual"] = v
            self.msg(f"Mouse escolhido: {_nome_do_mouse(v['marca'], v['modelo'])}.")
        else:
            CONFIG.pop("mouse_manual", None)
            self.msg("Mouse: voltei a reconhecer sozinho.")
        salvar_config()

    def _perfil_itens(self, chave, itens, ligar):
        """v9.1: liga os ajustes de um perfil lembrando quais ELE ligou; ao desligar, desfaz só esses (o que você já tinha
        ligado antes continua ligado) e não desfaz o que o outro perfil (mouse/teclado) ainda usa."""
        avisos, feitos = [], []
        outro = "teclado" if chave == "mouse" else "mouse"
        with TRAVA_AJ:
            bk = _backup()
            legado = ("perfil_" + chave) not in bk
            meus = [i for i in (bk.get("perfil_" + chave) or []) if isinstance(i, str)]
            do_outro = set(i for i in (bk.get("perfil_" + outro) or []) if isinstance(i, str))
            outro_legado = ("perfil_" + outro) not in bk
        if not ligar and legado:  # ligado por uma versão antiga (sem a lista): desfaz o perfil inteiro
            meus = [i for i, _ in itens]
            if outro_legado:  # o outro perfil também é antigo: se ele parece ligado, o USB fica com ele
                itens_outro = {"mouse": ("mouse_acel",), "teclado": ("teclado_rapido", "teclas_aderencia")}[outro]
                try:
                    if all(POR_ID[i].estado() is True for i in itens_outro):
                        do_outro.add("mouse_usb")
                except Exception:
                    pass
        for ident, rotulo in itens:
            a = POR_ID[ident]
            try:
                if ligar:
                    if a.estado() is True:
                        feitos.append(rotulo)
                        if ident in do_outro and ident not in meus:
                            meus.append(ident)  # dividido com o outro perfil: só sai quando os dois desligarem
                        continue
                elif ident not in meus or ident in do_outro:
                    continue  # não foi este perfil que ligou (ou o outro perfil ainda precisa dele)
                if a.precisa_admin and not e_admin():
                    avisos.append(f"{a.titulo} precisa de Administrador (feche e abra o Th Boost pelo atalho)")
                    continue
                a.ligar() if ligar else a.desligar()
                feitos.append(rotulo)
                if ligar and ident not in meus:
                    meus.append(ident)
                elif not ligar:
                    meus = [i for i in meus if i != ident]
            except OSError as erro:
                avisos.append(f"{a.titulo}: {erro}")
        with TRAVA_AJ:
            bk = _backup()
            if ligar:
                bk["perfil_" + chave] = meus
            else:
                bk.pop("perfil_" + chave, None)  # desligado: o que sobrou na lista era dividido com o outro perfil
            _guardar_backup()
        return avisos, feitos

    def t_mouse_perfil(self, ligar):
        """Perfil competitivo: sem aceleração do ponteiro, velocidade 10 (a do Windows, 1 para 1) e USB sem suspensão."""
        avisos, feitos = self._perfil_itens("mouse", (("mouse_acel", "sem aceleração"), ("mouse_usb", "USB sem suspensão")), ligar)
        if ligar:
            antes = velocidade_mouse()
            if antes != 10:
                with TRAVA_AJ:
                    _backup()["mouse_vel_antes"] = antes
                    _guardar_backup()
                definir_velocidade_mouse(10)
            feitos.append("velocidade 10/20")
        else:
            with TRAVA_AJ:
                antes = _backup().pop("mouse_vel_antes", None)
                _guardar_backup()
            if isinstance(antes, int) and not isinstance(antes, bool) and 1 <= antes <= 20:
                definir_velocidade_mouse(antes)
        self.atualizar_aj()
        if ligar:
            texto = "Perfil de mouse competitivo ligado: " + ", ".join(feitos) + "."
        else:
            texto = "Perfil de mouse competitivo desligado: o mouse voltou ao que era antes."
        return texto + (" Atenção: " + "; ".join(avisos) + "." if avisos else "")

    def t_teclado_perfil(self, ligar):
        """Teclado rápido: a tecla segurada repete sem espera, nada de aviso de acessibilidade no meio do jogo e USB sem suspensão."""
        avisos, feitos = self._perfil_itens("teclado", (("teclado_rapido", "repetição sem espera"),
                                                         ("teclas_aderencia", "sem avisos de Shift"),
                                                         ("mouse_usb", "USB sem suspensão")), ligar)
        self.atualizar_aj()
        if ligar:
            texto = "Teclado rápido ligado: " + ", ".join(feitos) + "."
        else:
            texto = "Teclado rápido desligado: o teclado voltou ao que era antes."
        return texto + (" Atenção: " + "; ".join(avisos) + "." if avisos else "")

    def teclado_perfil(self, ligar):
        if REG is None:
            return self.msg("O teclado rápido só funciona no Windows.")
        self.msg("Ligando o teclado rápido..." if ligar else "Desligando o teclado rápido...")
        self.em_fundo(lambda: self.t_teclado_perfil(ligar))

    def mouse_perfil(self, ligar):
        if REG is None:
            return self.msg("O perfil de mouse só funciona no Windows.")
        self.msg("Ligando o perfil de mouse competitivo..." if ligar else "Desligando o perfil de mouse competitivo...")
        self.em_fundo(lambda: self.t_mouse_perfil(ligar))


# ---------------- v9.0: aviso de versão nova (o dono publicou no GitHub) e atualização com um clique ----------------
# O programa lê de tempos em tempos um arquivo pequeno do repositório do dono (versao.json). Se a versão de lá for mais
# nova, aparece o aviso "O dono atualizou o Th Boost". Ao clicar em Atualizar:
#   1) baixa o ZIP SÓ do repositório do dono no GitHub (qualquer outro endereço é recusado, até nos redirecionamentos);
#   2) confere a "impressão digital" do ZIP (SHA-256 publicada no versao.json) e o que tem dentro (só os arquivos do
#      Th Boost, e o th_boost.py precisa ser Python válido e dizer a mesma versão);
#   3) guarda os arquivos atuais em "versao_anterior" e troca pelos novos;
#   4) abre o Th Boost novo e fecha o antigo; a janela se recarrega sozinha.
# Nada do computador é enviado: é só um download, como abrir uma página.

ATU_REPO = "thiagotriolux22026-sudo/th-boost"
ATU_URL = f"https://raw.githubusercontent.com/{ATU_REPO}/main/versao.json"
ATU_PAGINA = f"https://github.com/{ATU_REPO}"
ATU_PREFIXOS = (f"https://github.com/{ATU_REPO}/", f"https://raw.githubusercontent.com/{ATU_REPO}/")
ATU_HOSTS = ("github.com", "raw.githubusercontent.com", "objects.githubusercontent.com")
ATU_ARQUIVOS = ("th_boost.py", "Th Boost.ico", "LEIAME.txt", "Abrir Th Boost.bat",
                "Criar atalho na area de trabalho.bat", "Encerrar Th Boost.bat", "Gerar executavel.bat")
ATU_MAX_ZIP = 40 * 1024 * 1024
ATU_MAX_ARQ = 25 * 1024 * 1024
ATU_INTERVALO = 6 * 3600  # procura de novo a cada 6 horas enquanto o programa estiver aberto
_RE_SHA = re.compile(r"[0-9a-f]{64}")


def _atu_teste():
    """Só para os testes automáticos: um "GitHub de mentira" no próprio computador (127.0.0.1). Fora disso, nada muda."""
    u = os.environ.get("THBOOST_ATU_URL", "")
    return u if re.fullmatch(r"http://127\.0\.0\.1:\d{2,5}/[\w./-]*", u) else ""


def atu_url_info():
    return _atu_teste() or ATU_URL


def atu_link_ok(url):
    """O ZIP só pode vir do repositório do dono (ou do GitHub de mentira dos testes)."""
    if not isinstance(url, str) or len(url) > 400 or any(c in url for c in "\\\r\n\t \"'<>"):
        return False
    t = _atu_teste()
    if t and url.startswith(t.split("/", 3)[0] + "//" + t.split("/", 3)[2] + "/"):
        return True
    return url.startswith(ATU_PREFIXOS) and ".." not in url


def versao_tupla(v):
    """'v9.0' -> (9, 0, 0); 'v8.10' é mais nova que 'v8.9'. None se não for uma versão."""
    m = re.fullmatch(r"v?(\d{1,3})(?:\.(\d{1,3}))?(?:\.(\d{1,3}))?", str(v or "").strip())
    return tuple(int(x or 0) for x in m.groups()) if m else None


def atu_mais_nova(remota, local):
    a, b = versao_tupla(remota), versao_tupla(local)
    return bool(a and b and a > b)


def atu_valida_info(d):
    """Confere o versao.json publicado. Devolve uma cópia limpa ou levanta ValueError."""
    if not isinstance(d, dict):
        raise ValueError("versao.json inválido")
    v = d.get("versao")
    if not isinstance(v, str) or not versao_tupla(v):
        raise ValueError("versão inválida no versao.json")
    z, sha = d.get("zip"), str(d.get("sha256") or "").lower()
    if not atu_link_ok(z):
        raise ValueError("o endereço do ZIP não é do repositório do Th Boost")
    if not _RE_SHA.fullmatch(sha):
        raise ValueError("falta a impressão digital (SHA-256) do ZIP")
    tam = d.get("tamanho")
    if tam is not None and (not isinstance(tam, int) or isinstance(tam, bool) or not 0 < tam <= ATU_MAX_ZIP):
        raise ValueError("tamanho inválido no versao.json")
    nov = d.get("novidades") if isinstance(d.get("novidades"), list) else []
    nov = [re.sub(r"\s+", " ", re.sub(r"[\x00-\x1f\x7f]", "", x)).strip()[:160] for x in nov if isinstance(x, str)][:8]
    v = v.strip()
    return {"versao": v if v.startswith("v") else "v" + v, "zip": z, "sha256": sha, "tamanho": tam, "novidades": [x for x in nov if x],
            "data": str(d.get("data") or "")[:20]}


class _AtuRedireciona(urllib.request.HTTPRedirectHandler):
    """Segue o redirecionamento do GitHub (github.com -> raw.githubusercontent.com) e nenhum outro."""

    def redirect_request(self, req, fp, code, msg, headers, newurl):
        p = urllib.parse.urlparse(newurl)
        t = _atu_teste()
        teste_ok = t and newurl.startswith(t.split("/", 3)[0] + "//" + t.split("/", 3)[2] + "/")
        if not teste_ok and (p.scheme != "https" or p.hostname not in ATU_HOSTS):
            raise urllib.error.HTTPError(newurl, code, "redirecionamento recusado", headers, fp)
        return super().redirect_request(req, fp, code, msg, headers, newurl)


def atu_baixar(url, limite, progresso=None, timeout=30):
    """Baixa até 'limite' bytes (mais que isso é recusado). Usa o proxy do Windows, se houver."""
    if not atu_link_ok(url) and url != atu_url_info():
        raise ValueError("endereço recusado")
    abridor = urllib.request.build_opener(_AtuRedireciona)
    req = urllib.request.Request(url, headers={"User-Agent": f"ThBoost/{VERSAO}", "Cache-Control": "no-cache"})
    partes, total = [], 0
    with abridor.open(req, timeout=timeout) as r:
        esperado = int(r.headers.get("Content-Length") or 0)
        if esperado > limite:
            raise ValueError("arquivo grande demais")
        while True:
            bloco = r.read(65536)
            if not bloco:
                break
            total += len(bloco)
            if total > limite:
                raise ValueError("arquivo grande demais")
            partes.append(bloco)
            if progresso and esperado:
                progresso(min(99, int(total * 100 / esperado)))
    return b"".join(partes)


def atu_buscar_info():
    dados = atu_baixar(atu_url_info(), 65536, timeout=15)
    return atu_valida_info(json.loads(dados.decode("utf-8-sig")))


def atu_conferir_zip(dados, info):
    """Confere o ZIP baixado. Devolve {nome: conteúdo} dos arquivos do Th Boost, ou levanta ValueError."""
    if hashlib.sha256(dados).hexdigest() != info["sha256"]:
        raise ValueError("a impressão digital do ZIP não confere (download incompleto ou arquivo trocado)")
    try:
        zf = zipfile.ZipFile(io.BytesIO(dados))
    except zipfile.BadZipFile:
        raise ValueError("o ZIP baixado está estragado")
    nomes = [i for i in zf.infolist() if not i.is_dir()]
    if not nomes or len(nomes) > 40:
        raise ValueError("o ZIP não parece do Th Boost")
    topo = {i.filename.split("/")[0] for i in nomes}
    pref = (next(iter(topo)) + "/") if len(topo) == 1 and all("/" in i.filename for i in nomes) else ""
    saida = {}
    for i in nomes:
        n = i.filename[len(pref):]
        if n not in ATU_ARQUIVOS:
            continue  # arquivos extras do ZIP são ignorados; só os do Th Boost são trocados
        if i.file_size > ATU_MAX_ARQ:
            raise ValueError("arquivo grande demais dentro do ZIP")
        with zf.open(i) as f:
            conteudo = f.read(ATU_MAX_ARQ + 1)
        if len(conteudo) > ATU_MAX_ARQ:
            raise ValueError("arquivo grande demais dentro do ZIP")
        saida[n] = conteudo
    if "th_boost.py" not in saida:
        raise ValueError("o ZIP não tem o th_boost.py")
    try:
        texto = saida["th_boost.py"].decode("utf-8")
        compile(texto, "th_boost.py", "exec")
    except (UnicodeDecodeError, SyntaxError, ValueError):
        raise ValueError("o th_boost.py novo está com defeito; nada foi trocado")
    m = re.search(r'^VERSAO = "(v[\d.]+)"', texto, re.M)
    if not m or versao_tupla(m.group(1)) != versao_tupla(info["versao"]):
        raise ValueError("a versão dentro do ZIP não é a anunciada; nada foi trocado")
    return saida


def atu_trocar_arquivos(arquivos, pasta):
    """Guarda os arquivos atuais em 'versao_anterior' e troca pelos novos.
    O th_boost.py é o que importa: se ele não puder ser trocado, nada muda. Os outros (ícone, LEIAME, .bat) podem estar
    em uso pelo Windows (o ícone da bandeja, por exemplo); esses ficam como estão e o resto segue."""
    principal = "th_boost.py"
    if principal not in arquivos:
        raise ValueError("falta o th_boost.py")
    copia = os.path.join(pasta, "versao_anterior")
    os.makedirs(copia, exist_ok=True)
    for n in arquivos:
        atual = os.path.join(pasta, n)
        if os.path.isfile(atual):
            try:
                shutil.copy2(atual, os.path.join(copia, n))
            except OSError:
                if n == principal:
                    raise  # sem a cópia do programa atual, não troca nada
    def troca(n):
        tmp = os.path.join(pasta, n + ".novo")
        try:
            with open(tmp, "wb") as f:
                f.write(arquivos[n])
            os.replace(tmp, os.path.join(pasta, n))
        except OSError:
            try:
                os.remove(tmp)
            except OSError:
                pass
            raise
    troca(principal)
    trocados = [principal]
    for n in arquivos:
        if n != principal:
            try:
                troca(n)
                trocados.append(n)
            except OSError:
                pass  # arquivo em uso: fica o antigo
    return trocados


# v9.1: vigia da atualização. Roda separado (o Th Boost antigo já fechou). Se a versão nova não avisar que abriu em até
# 2 minutos, devolve o th_boost.py guardado em "versao_anterior" e abre a versão de antes.
ATU_VIGIA = r"""
import os, sys, time, shutil, subprocess
pasta, exe, nova, pid = sys.argv[1], sys.argv[2], sys.argv[3], int(sys.argv[4])
espera = float(sys.argv[5]) if len(sys.argv) > 5 else 120.0
ok = os.path.join(pasta, "versao_anterior", "atu_ok")
ini = time.time()
h = None
if os.name == "nt":  # segura o processo pelo "identificador": assim o número dele não é reaproveitado por outro programa
    import ctypes
    k32 = ctypes.windll.kernel32
    k32.OpenProcess.restype = ctypes.c_void_p
    k32.OpenProcess.argtypes = [ctypes.c_ulong, ctypes.c_bool, ctypes.c_ulong]
    k32.WaitForSingleObject.argtypes = [ctypes.c_void_p, ctypes.c_ulong]
    k32.TerminateProcess.argtypes = [ctypes.c_void_p, ctypes.c_uint]
    h = k32.OpenProcess(0x00100000 | 0x0001, False, pid)  # SYNCHRONIZE | PROCESS_TERMINATE
while time.time() - ini < espera:
    try:
        if os.path.getmtime(ok) >= ini - 5:
            sys.exit(0)
    except OSError:
        pass
    time.sleep(1)
try:
    if os.name == "nt":
        if h and k32.WaitForSingleObject(h, 0) == 0x102:  # ainda rodando (travado): fecha só ele
            k32.TerminateProcess(h, 1)
            k32.WaitForSingleObject(h, 5000)
    else:
        os.kill(pid, 9)
except Exception:
    pass
copia = os.path.join(pasta, "versao_anterior", "th_boost.py")
alvo = os.path.join(pasta, "th_boost.py")
try:
    shutil.copyfile(copia, alvo + ".volta")
    os.replace(alvo + ".volta", alvo)
except OSError:
    sys.exit(1)
fl = (0x00000008 | 0x00000200 | 0x08000000) if os.name == "nt" else 0
kw = {"creationflags": fl} if os.name == "nt" else {"start_new_session": True}
subprocess.Popen([exe, alvo, "--reinicio", "--falhou", nova], cwd=pasta, close_fds=True, stdin=subprocess.DEVNULL,
                 stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, **kw)
"""


def _atu_popen(args):
    opc = {"cwd": pasta_do_programa(), "stdin": subprocess.DEVNULL, "stdout": subprocess.DEVNULL,
           "stderr": subprocess.DEVNULL, "close_fds": True}
    if IS_WIN:
        opc["creationflags"] = 0x00000008 | 0x00000200 | 0x08000000  # DETACHED_PROCESS | NEW_PROCESS_GROUP | NO_WINDOW
    else:
        opc["start_new_session"] = True
    return subprocess.Popen(args, **opc)


def atu_reabrir(versao_antiga, versao_nova=""):
    """Abre o Th Boost novo (que espera este aqui fechar) e o vigia da atualização. Devolve True se conseguiu."""
    script = os.path.join(pasta_do_programa(), "th_boost.py")
    exe = sys.executable
    if IS_WIN and os.path.basename(exe).lower() == "python.exe":
        w = os.path.join(os.path.dirname(exe), "pythonw.exe")
        if os.path.isfile(w):
            exe = w
    try:
        novo = _atu_popen([exe, script, "--reinicio", "--de", versao_antiga])
    except OSError:
        return False
    if versao_nova and os.path.isfile(os.path.join(pasta_do_programa(), "versao_anterior", "th_boost.py")):
        try:
            _atu_popen([exe, "-I", "-c", ATU_VIGIA, pasta_do_programa(), exe, versao_nova, str(novo.pid),
                        os.environ.get("THBOOST_ATU_VIGIA", "120")])
        except OSError:
            pass  # sem o vigia a atualização segue igual (só não volta sozinha se a nova falhar)
    return True


def atu_avisar_que_abriu():
    """Chamado pela versão nova logo que abre: o vigia vê este arquivo e não desfaz nada."""
    try:
        caminho = os.path.join(pasta_do_programa(), "versao_anterior", "atu_ok")
        with open(caminho, "w", encoding="utf-8") as f:
            f.write(VERSAO)
    except OSError:
        pass


def atu_falhou_argv():
    """Versão que não conseguiu abrir ('--falhou v9.2'), quando o vigia voltou para esta."""
    a = sys.argv[1:]
    if "--falhou" in a:
        i = a.index("--falhou")
        if i + 1 < len(a) and versao_tupla(a[i + 1]):
            return a[i + 1][:12]
    return ""


def atu_de_argv():
    """Versão anterior quando o programa foi reaberto por uma atualização ('--de v8.9')."""
    a = sys.argv[1:]
    if "--de" in a:
        i = a.index("--de")
        if i + 1 < len(a) and versao_tupla(a[i + 1]):
            return a[i + 1][:12]
    return ""


class AtualizaMixin:
    """Estado do aviso de versão nova (vai para a tela) e as ações Procurar / Atualizar."""

    def atu_iniciar_estado(self):
        congelado = bool(getattr(sys, "frozen", False))  # rodando como .exe: troca de arquivo não serve, abre o link
        self.atu = {"estado": "parado", "atual": VERSAO, "nova": "", "novidades": [], "pct": 0, "erro": "",
                    "quando": 0, "de": atu_de_argv(), "modo": "link" if congelado else "auto", "falhou": atu_falhou_argv()}
        self.atu_info = None
        self._atu_trava = threading.Lock()
        if self.atu["falhou"]:
            CONFIG["atu_pular"] = self.atu["falhou"]  # não fica oferecendo sozinho a versão que não abriu aqui
            salvar_config()
            self.msg(f"A versão {self.atu['falhou']} não abriu neste computador, então voltei para a {VERSAO}. "
                     "Nada foi perdido. Avise o dono do Th Boost.")
        if not os.environ.get("THBOOST_SEM_ATU"):
            threading.Thread(target=self._atu_vigiar, daemon=True).start()

    def atu_snapshot(self):
        return dict(self.atu, novidades=list(self.atu["novidades"]), avisar=CONFIG.get("avisar_atualizacao", True) is not False)

    def _atu_vigiar(self):
        time.sleep(float(os.environ.get("THBOOST_ATU_ESPERA", "20")))  # deixa o programa abrir primeiro
        while not self.fechando:
            if CONFIG.get("avisar_atualizacao", True) is not False and self.atu["estado"] in ("parado", "em_dia", "disponivel", "falhou"):
                self.atu_procurar(manual=False)
            time.sleep(ATU_INTERVALO)

    def atu_procurar(self, manual=True):
        if not self._atu_trava.acquire(blocking=False):
            return
        try:
            if self.atu["estado"] in ("baixando", "instalando", "reiniciando"):
                return
            antes = self.atu["estado"]
            self.atu.update(estado="procurando", erro="")
            try:
                info = atu_buscar_info()
            except Exception as e:
                # procura automática sem internet: fica quieto; a pedido, conta o que houve
                self.atu.update(estado="falhou" if manual else (antes if antes != "procurando" else "parado"),
                                erro="Não deu para procurar agora (sem internet?)." if manual else "")
                return
            self.atu["quando"] = time.time()
            if not manual and info["versao"] == CONFIG.get("atu_pular"):
                self.atu_info = None
                self.atu.update(estado="em_dia", nova="", novidades=[])
                return
            if atu_mais_nova(info["versao"], VERSAO):
                self.atu_info = info
                self.atu.update(estado="disponivel", nova=info["versao"], novidades=info["novidades"])
                if antes != "disponivel":
                    self.msg(f"Versão nova do Th Boost: {info['versao']}. Clique em Atualizar no aviso.")
            else:
                self.atu_info = None
                self.atu.update(estado="em_dia", nova="", novidades=[])
        finally:
            self._atu_trava.release()

    def atu_instalar(self):
        info = self.atu_info
        if not info or self.atu["estado"] != "disponivel":
            raise ValueError("não há versão nova para instalar")
        if self.atu["modo"] == "link":  # .exe: abre a página para baixar
            abrir_link(ATU_PAGINA)
            self.msg("Abri a página do Th Boost para baixar a versão nova.")
            return
        self.atu.update(estado="baixando", pct=0, erro="")

        def tarefa():
            info2 = info
            try:
                try:  # lê o versao.json de novo: se o dono publicou outra versão (ou corrigiu o ZIP), já pega a certa
                    novo = atu_buscar_info()
                    if atu_mais_nova(novo["versao"], VERSAO):
                        info2 = self.atu_info = novo
                        self.atu.update(nova=novo["versao"], novidades=novo["novidades"])
                except Exception:
                    pass
                dados = atu_baixar(info2["zip"], ATU_MAX_ZIP, progresso=lambda p: self.atu.update(pct=p), timeout=60)
                self.atu.update(estado="instalando", pct=100)
                arquivos = atu_conferir_zip(dados, info2)
                atu_trocar_arquivos(arquivos, pasta_do_programa())
            except Exception as e:
                motivo = str(e) if isinstance(e, ValueError) else "não consegui baixar ou gravar os arquivos (internet ou pasta sem permissão)"
                self.atu.update(estado="disponivel", erro=f"A atualização não deu certo: {motivo}. O Th Boost continua na {VERSAO}.")
                return
            self.atu.update(estado="reiniciando")
            if not atu_reabrir(VERSAO, info2["versao"]):
                self.atu.update(estado="disponivel", erro="Os arquivos novos foram instalados, mas não consegui abrir o Th Boost de novo. Feche e abra pelo atalho.")
                return
            time.sleep(1.2)  # dá tempo da tela receber o "reiniciando"
            self.encerrar()

        threading.Thread(target=tarefa, daemon=True).start()


# ---------------- v9.1: Autoteste — confere, no computador da pessoa, se cada parte do Th Boost funciona ----------------
# Só lê (não muda nada no Windows). O resultado vira um relatório que a pessoa pode copiar e mandar para o suporte.
# O relatório não leva o nome do usuário nem o nome do computador.

AT_OK, AT_AVISO, AT_ERRO, AT_PULADO = "ok", "aviso", "erro", "pulado"


def _at_anon(texto):
    t = str(texto)
    casa = os.path.expanduser("~")
    if casa and len(casa) > 3:
        t = t.replace(casa, "%USERPROFILE%")
    for nome in {os.environ.get("USERNAME", ""), os.environ.get("COMPUTERNAME", "")}:
        if len(nome) >= 3:
            t = re.sub(re.escape(nome), "<oculto>", t, flags=re.I)
    return t[:300]


def _n(x, casas=1):
    """Número no jeito brasileiro (vírgula decimal)."""
    return f"{x:.{casas}f}".replace(".", ",")


def _at_ps(comando, timeout=25):
    return executar(["powershell", "-NoProfile", "-NonInteractive", "-ExecutionPolicy", "Bypass", "-Command", comando], timeout=timeout)


def _at_reg(raiz, caminho, nome):
    """Lê um valor do registro (ou None). Usa winreg direto: o autoteste não pode depender do que ele testa."""
    try:
        import winreg as _w
        r = {"HKLM": _w.HKEY_LOCAL_MACHINE, "HKCU": _w.HKEY_CURRENT_USER}[raiz]
        with _w.OpenKey(r, caminho) as k:
            return _w.QueryValueEx(k, nome)[0]
    except (OSError, ImportError, KeyError):
        return None


def at_sistema():
    if not IS_WIN:
        return AT_PULADO, f"não é Windows ({sys.platform})"
    v = sys.getwindowsversion()
    nome = "Windows 11" if v.build >= 22000 else "Windows 10" if v.major == 10 else f"Windows {v.major}.{v.minor}"
    ed = _at_reg("HKLM", r"SOFTWARE\Microsoft\Windows NT\CurrentVersion", "DisplayVersion") or ""
    return AT_OK, f"{nome} {ed} (build {v.build})".replace("  ", " ")


def at_python():
    bits = "64 bits" if sys.maxsize > 2 ** 32 else "32 bits"
    modo = ".exe" if getattr(sys, "frozen", False) else "th_boost.py"
    st = AT_OK if sys.version_info >= (3, 9) else AT_AVISO
    return st, f"Python {sys.version.split()[0]} ({bits}), psutil {getattr(psutil, '__version__', '?')}, rodando como {modo}"


def at_admin():
    if not IS_WIN:
        return AT_PULADO, "só no Windows"
    return (AT_OK, "sim") if e_admin() else (AT_ERRO, "NÃO — abra pelo atalho e clique em Sim quando o Windows pedir. Sem isso, plano de energia, serviços, RAM, overclock e FPS não funcionam.")


def at_pasta():
    pasta = pasta_do_programa()
    teste = os.path.join(pasta, f"th_boost_autoteste_{os.getpid()}.tmp")
    try:
        with open(teste, "w") as f:
            f.write("ok")
        os.remove(teste)
        return AT_OK, f"dá para gravar em {_at_anon(pasta)}"
    except OSError:
        return AT_ERRO, f"não dá para gravar em {_at_anon(pasta)}: configurações, backup e atualização não vão funcionar. Tire o Th Boost de dentro do ZIP ou de Arquivos de Programas."


def at_ram():
    m = psutil.virtual_memory()
    tot, livre = m.total / 2 ** 30, m.available / 2 ** 30
    txt = f"{_n(tot)} GB no total, {_n(livre)} GB livres agora ({100 - m.percent:.0f}%)"
    if tot < 7.5:
        return AT_AVISO, txt + ". Menos de 8 GB: jogos atuais vão travar por falta de memória (nenhum programa resolve isso; só mais RAM)."
    if m.percent > 85:
        return AT_AVISO, txt + ". Memória quase cheia: feche programas antes de jogar."
    return AT_OK, txt


def at_disco():
    raiz = (os.environ.get("SystemDrive", "C:") + "\\") if IS_WIN else "/"
    try:
        u = psutil.disk_usage(raiz)
    except OSError as e:
        return AT_ERRO, f"não consegui ler o disco {raiz}: {e}"
    livre_gb, pct = u.free / 2 ** 30, 100 * u.free / max(1, u.total)
    txt = f"{raiz} com {livre_gb:.0f} GB livres de {u.total / 2 ** 30:.0f} GB ({pct:.0f}%)"
    if livre_gb < 15 or pct < 10:
        return AT_AVISO, txt + ". Pouco espaço deixa o Windows e os jogos lentos: use a Limpeza ou apague jogos que não usa."
    return AT_OK, txt


def at_cpu():
    nome = (_at_reg("HKLM", r"HARDWARE\DESCRIPTION\System\CentralProcessor\0", "ProcessorNameString") or "").strip() if IS_WIN else ""
    f = None
    try:
        f = psutil.cpu_freq()
    except Exception:
        pass
    txt = f"{nome or 'processador'}: {psutil.cpu_count(logical=False) or '?'} núcleos / {psutil.cpu_count() or '?'} threads"
    if f and f.max:
        txt += f", {_n(f.current / 1000, 2)} GHz agora (máx. {_n(f.max / 1000, 2)} GHz)"
    return AT_OK, re.sub(r"\s+", " ", txt)


def at_energia():
    if not IS_WIN:
        return AT_PULADO, "só no Windows"
    cod, saida = executar(["powercfg", "/getactivescheme"], timeout=15)
    if cod != 0:
        return AT_ERRO, "o comando powercfg não respondeu: os planos de energia e o Resfriamento não vão funcionar."
    m = re.search(r"\(([^)]+)\)", saida)
    txt = f"powercfg funciona; plano ativo: {m.group(1) if m else 'desconhecido'}"
    try:
        b = psutil.sensors_battery()
    except Exception:
        b = None
    if b is not None and not b.power_plugged:
        return AT_AVISO, txt + f". Notebook NA BATERIA ({b.percent:.0f}%): na bateria o Windows segura o desempenho; para jogar, ligue na tomada."
    if b is not None:
        txt += f". Notebook na tomada ({b.percent:.0f}%)"
    return AT_OK, txt


def at_powershell():
    if not IS_WIN:
        return AT_PULADO, "só no Windows"
    cod, saida = _at_ps("$PSVersionTable.PSVersion.ToString()", timeout=30)
    v = saida.strip().splitlines()[-1] if saida.strip() else ""
    if cod == 0 and re.match(r"\d+\.\d+", v):
        return AT_OK, f"PowerShell {v}"
    return AT_ERRO, "o PowerShell não respondeu (antivírus ou política da empresa?): muitas funções usam ele."


def at_registro():
    if not IS_WIN:
        return AT_PULADO, "só no Windows"
    if REG is None:
        return AT_ERRO, "não consegui abrir o registro do Windows"
    gm = _at_reg("HKCU", r"Software\Microsoft\GameBar", "AutoGameModeEnabled")
    dvr = _at_reg("HKCU", r"System\GameConfigStore", "GameDVR_Enabled")
    hags = _at_reg("HKLM", r"SYSTEM\CurrentControlSet\Control\GraphicsDrivers", "HwSchMode")
    partes = [f"Modo de Jogo {'ligado' if gm in (None, 1) else 'desligado'}",
              f"gravação em segundo plano (Game DVR) {'desligada' if dvr == 0 else 'ligada'}",
              f"agendamento de GPU por hardware {'ligado' if hags == 2 else 'desligado' if hags == 1 else 'padrão'}"]
    st = AT_OK if gm in (None, 1) and dvr == 0 else AT_AVISO
    return st, "registro lido; " + ", ".join(partes)


def at_servicos():
    if not IS_WIN:
        return AT_PULADO, "só no Windows"
    cod, saida = executar(["sc", "query", "wuauserv"], timeout=15)
    if cod == 0 and "STATE" in saida.upper():
        return AT_OK, "dá para consultar os serviços do Windows"
    return AT_ERRO, "não consegui consultar os serviços (sc query): as páginas Serviços e Jogos podem falhar."


def at_gpu():
    if not IS_WIN:
        g = ler_gpu()
        return (AT_OK, f"NVIDIA {g['nome']}") if g else (AT_PULADO, "só no Windows")
    cod, saida = _at_ps("Get-CimInstance Win32_VideoController | Select-Object Name,DriverVersion,@{n='Data';e={$_.DriverDate.ToString('yyyy-MM-dd')}} | ConvertTo-Json -Compress", timeout=40)
    try:
        dados = json.loads(saida[saida.index("["):] if saida.lstrip().startswith("[") else saida[saida.index("{"):]) if cod == 0 else None
    except ValueError:
        dados = None
    if not dados:
        return AT_AVISO, "não consegui ler a placa de vídeo pelo Windows"
    if isinstance(dados, dict):
        dados = [dados]
    partes, velho = [], False
    for d in dados[:3]:
        nome = str(d.get("Name") or "?")
        data = str(d.get("Data") or "")
        partes.append(f"{nome} (driver {d.get('DriverVersion') or '?'}{', de ' + data if data else ''})")
        if re.match(r"\d{4}-\d{2}", data) and not re.search(r"basic|remote|virtual|parsec|meta", nome, re.I):
            idade = (datetime.now() - datetime.strptime(data[:7], "%Y-%m")).days
            velho = velho or idade > 365
    g = ler_gpu()
    txt = "; ".join(partes) + ("; nvidia-smi funciona" if g else "")
    if velho:
        return AT_AVISO, txt + ". Driver de vídeo com mais de 1 ano: atualizar pelo site da NVIDIA/AMD/Intel costuma melhorar jogos novos."
    return AT_OK, txt


def at_paginacao():
    """Arquivo de paginação desligado é uma causa comum de jogos fechando sozinhos e de travadas."""
    if not IS_WIN:
        return AT_PULADO, "só no Windows"
    cod, saida = _at_ps("$c=(Get-CimInstance Win32_ComputerSystem).AutomaticManagedPagefile; "
                        "$n=@(Get-CimInstance Win32_PageFileUsage).Count; \"$c|$n\"", timeout=30)
    m = re.search(r"(True|False)\|(\d+)", saida or "", re.I) if cod == 0 else None
    if not m:
        return AT_AVISO, "não consegui ler o arquivo de paginação"
    auto, qtd = m.group(1).lower() == "true", int(m.group(2))
    if auto:
        return AT_OK, "arquivo de paginação no automático (o Windows cuida do tamanho)"
    if qtd == 0:
        return AT_ERRO, ("arquivo de paginação DESLIGADO: jogos podem fechar sozinhos e travar quando a memória enche. "
                         "Toque em Corrigir para voltar ao automático (vale depois de reiniciar)."), "pagefile_auto"
    return AT_OK, "arquivo de paginação com tamanho escolhido à mão (funciona; o automático costuma ser melhor)"


def at_tela():
    if not IS_WIN:
        return AT_PULADO, "só no Windows"
    m = info_monitor()
    if not m:
        return AT_AVISO, "não consegui ler o monitor"
    txt = f"{m['res']} a {m['hz']} Hz"
    if m["hz"] <= 60 and m["hz_max"] >= 100:
        return AT_AVISO, (txt + f". O Windows diz que a tela aceita até {m['hz_max']} Hz: confira em Configurações > Sistema > "
                          "Tela > Tela avançada > Taxa de atualização (e se o cabo é HDMI 2.0/DisplayPort).")
    return AT_OK, txt


def at_fps():
    if caminho_presentmon():
        return AT_OK, "PresentMon.exe encontrado: o contador de FPS funciona"
    return AT_AVISO, "PresentMon.exe não está na pasta do Th Boost: o contador de FPS fica desligado (o resto funciona)."


def at_temperatura():
    if not IS_WIN:
        t = temp_cpu()
        return (AT_OK, f"{t:.0f} °C") if t else (AT_PULADO, "só no Windows")
    cod, saida = _at_ps("Get-CimInstance -Namespace root/wmi -ClassName MSAcpi_ThermalZoneTemperature -ErrorAction Stop | Select-Object -ExpandProperty CurrentTemperature", timeout=30)
    nums = [int(x) for x in re.findall(r"^\s*(\d{3,5})\s*$", saida, re.M)] if cod == 0 else []
    temps = [round(n / 10 - 273.15) for n in nums if 2731 < n < 3982]
    if not temps:
        return AT_AVISO, "este computador não informa a temperatura para o Windows (comum). A temperatura da CPU só aparece com programas do fabricante."
    t = max(temps)
    st = AT_AVISO if t >= 90 else AT_OK
    return st, f"sensor de temperatura do Windows: {t} °C" + (" — quente: limpe as saídas de ar e use o Resfriamento." if t >= 90 else "")


def at_internet():
    p = medir_ping()
    try:
        import socket
        socket.getaddrinfo("github.com", 443)
        dns = True
    except OSError:
        dns = False
    if p is None and not dns:
        return AT_ERRO, "sem internet (o ping e o DNS falharam)"
    txt = f"ping {p:.0f} ms" if p is not None else "ping bloqueado (DNS funciona)"
    if p is not None and p > 120:
        return AT_AVISO, txt + ": alto para jogos online (Wi-Fi fraco? prefira cabo)"
    return AT_OK, txt + ("" if dns else "; DNS falhou")


def at_atualizacao():
    try:
        info = atu_buscar_info()
    except Exception:
        return AT_AVISO, "não consegui ler o aviso de versão nova no GitHub (internet ou bloqueio)"
    if atu_mais_nova(info["versao"], VERSAO):
        return AT_AVISO, f"tem versão nova: {info['versao']} (você está na {VERSAO})"
    return AT_OK, f"em dia ({VERSAO})"


AT_LISTA = [
    ("sistema", "Sistema", "Windows", at_sistema),
    ("python", "Sistema", "Python e psutil", at_python),
    ("admin", "Sistema", "Administrador", at_admin),
    ("pasta", "Sistema", "Pasta do programa", at_pasta),
    ("cpu", "Peças", "Processador", at_cpu),
    ("ram", "Peças", "Memória RAM", at_ram),
    ("disco", "Peças", "Espaço no disco", at_disco),
    ("gpu", "Peças", "Placa de vídeo e driver", at_gpu),
    ("temp", "Peças", "Temperatura", at_temperatura),
    ("tela", "Peças", "Monitor", at_tela),
    ("paginacao", "Funções", "Arquivo de paginação", at_paginacao),
    ("energia", "Funções", "Energia / Resfriamento (powercfg)", at_energia),
    ("ps", "Funções", "PowerShell", at_powershell),
    ("reg", "Funções", "Registro (ajustes do Windows)", at_registro),
    ("svc", "Funções", "Serviços do Windows", at_servicos),
    ("fps", "Funções", "Contador de FPS", at_fps),
    ("net", "Internet", "Internet e ping", at_internet),
    ("atu", "Internet", "Aviso de versão nova", at_atualizacao),
]


AT_ACOES = {"pagefile_auto": "Corrigir"}


def pagefile_automatico():
    """Volta o arquivo de paginação para o automático do Windows (vale depois de reiniciar)."""
    if not IS_WIN:
        return "Só funciona no Windows."
    if not e_admin():
        return "Precisa de Administrador. Feche e abra o Th Boost pelo atalho."
    cod, _ = _at_ps("$c=Get-CimInstance Win32_ComputerSystem; Set-CimInstance -InputObject $c -Property @{AutomaticManagedPagefile=$true}",
                    timeout=60)
    return ("Arquivo de paginação no automático. Reinicie o PC para valer." if cod == 0
            else "O Windows não aceitou mudar o arquivo de paginação.")


class AutotesteMixin:
    def at_iniciar_estado(self):
        self.at = {"estado": "nunca", "itens": [], "inicio": 0, "fim": 0, "texto": ""}

    def at_snapshot(self):
        return {"estado": self.at["estado"], "itens": [dict(i) for i in self.at["itens"]], "fim": self.at["fim"]}

    def at_texto(self):
        return self.at["texto"]

    def at_rodar(self):
        if self.at["estado"] == "rodando":
            return
        itens = [{"id": i, "grupo": g, "rotulo": r, "st": "esperando", "txt": "", "acao": ""} for i, g, r, _ in AT_LISTA]
        self.at.update(estado="rodando", itens=itens, inicio=time.time(), fim=0, texto="")

        def tarefa():
            for item, (_, _, _, fn) in zip(itens, AT_LISTA):
                item["st"] = "testando"
                acao = ""
                try:
                    r = fn()
                    st, txt = r[0], r[1]
                    acao = r[2] if len(r) > 2 and r[2] in AT_ACOES else ""
                except Exception as e:  # um teste quebrado não derruba os outros
                    st, txt = AT_ERRO, f"o teste falhou: {type(e).__name__}"
                item.update(st=st, txt=_at_anon(txt), acao=acao)
            jogos = {}
            for j in getattr(self, "jogos", []):
                jogos[j.get("origem", "?")] = jogos.get(j.get("origem", "?"), 0) + 1
            marca = {AT_OK: "OK   ", AT_AVISO: "AVISO", AT_ERRO: "ERRO ", AT_PULADO: "--   "}
            linhas = [f"Th Boost {VERSAO} - Autoteste - {datetime.now():%d/%m/%Y %H:%M}", ""]
            grupo = None
            for i in itens:
                if i["grupo"] != grupo:
                    grupo = i["grupo"]
                    linhas.append(f"[{grupo}]")
                linhas.append(f"{marca.get(i['st'], i['st'])} {i['rotulo']}: {i['txt']}")
            linhas += ["", f"Jogos encontrados: {sum(jogos.values())}" + (" (" + ", ".join(f"{k}: {v}" for k, v in sorted(jogos.items())) + ")" if jogos else ""),
                       f"Segundo plano: {'ligado' if CONFIG.get('segundo_plano') else 'desligado'}",
                       f"Resumo: {sum(1 for i in itens if i['st'] == AT_OK)} ok, {sum(1 for i in itens if i['st'] == AT_AVISO)} aviso(s), {sum(1 for i in itens if i['st'] == AT_ERRO)} erro(s)"]
            self.at.update(estado="pronto", fim=time.time(), texto="\n".join(linhas))
            erros = sum(1 for i in itens if i["st"] == AT_ERRO)
            self.msg("Autoteste pronto: " + ("tudo certo." if not erros else f"{erros} problema(s) encontrado(s). Veja em Configurações › Autoteste."))

        threading.Thread(target=tarefa, daemon=True).start()


# ---------------- v9.2: cor do painel ----------------
# O painel inteiro (botões, destaques, gráficos, logo e degradês) é azul por padrão. "Cor do painel" gira o tom de todas
# essas cores juntas (no espaço OKLCH, que guarda o brilho que o olho vê: o texto continua legível em qualquer cor).
# Verde, amarelo e vermelho de aviso e os cinzas não mudam. A escolha fica em CONFIG["tema_tr"] (graus, -180 a 180).

TEMA_CORES = (("azul", "Azul", 0), ("ciano", "Ciano", -45), ("verde", "Verde", -107), ("dourado", "Dourado", -171),
              ("laranja", "Laranja", 151), ("vermelho", "Vermelho", 128), ("rosa", "Rosa", 97), ("roxo", "Roxo", 47))


def tema_valida(v):
    """Graus do giro, de -180 a 180 (inteiro), ou None se não for um número. Função pura."""
    if isinstance(v, bool) or not isinstance(v, (int, float)) or v != v:
        return None
    v = int(round(v)) % 360
    return v - 360 if v > 180 else v


def tema_tr():
    v = tema_valida(CONFIG.get("tema_tr"))
    return v or 0


def _rgb_linear(L, A, B):
    l = (L + 0.3963377774 * A + 0.2158037573 * B) ** 3
    m = (L - 0.1055613458 * A - 0.0638541728 * B) ** 3
    s = (L - 0.0894841775 * A - 1.2914855480 * B) ** 3
    return (4.0767416621 * l - 3.3077115913 * m + 0.2309699292 * s,
            -1.2684380046 * l + 2.6097574011 * m - 0.3413193965 * s,
            -0.0041960863 * l - 0.7034186147 * m + 1.7076147010 * s)


def _croma_max(L, h):
    """A cor mais forte que a tela mostra neste brilho e neste tom (OKLCH)."""
    lo, hi = 0.0, 0.4
    for _ in range(22):
        c = (lo + hi) / 2
        if all(-1e-6 <= x <= 1 + 1e-6 for x in _rgb_linear(L, c * math.cos(h), c * math.sin(h))):
            lo = c
        else:
            hi = c
    return lo


TEMA_L0, TEMA_H0 = 0.638, math.radians(256.9)  # o azul do painel (#3389fa)


def tema_tc(tr):
    """v9.6: quanto as cores ficam mais fortes no tom escolhido. O azul do painel já está no máximo que a tela mostra;
    vermelho, rosa e roxo aceitam bem mais. Sem isso, o vermelho ficava "clarinho". 1 = igual ao azul. Função pura."""
    tr = tema_valida(tr) or 0
    if not tr:
        return 1.0
    r = _croma_max(TEMA_L0, TEMA_H0 + math.radians(tr)) / _croma_max(TEMA_L0, TEMA_H0)
    return round(max(1.0, min(1.4, r)), 3)


def html_com_tema(html):
    """A página já chega com a cor escolhida (sem piscar azul ao abrir)."""
    tr = tema_tr()
    if not tr:
        return html
    tc = tema_tc(tr)
    extra = f";--tc:{tc:g}" if tc != 1 else ""
    return html.replace('<html lang="pt-BR">', f'<html lang="pt-BR" style="--tr:{tr}deg{extra}">', 1)


def _oklab(r, g, b):
    def lin(c):
        return c / 12.92 if c <= 0.04045 else ((c + 0.055) / 1.055) ** 2.4
    r, g, b = lin(r), lin(g), lin(b)
    l = (0.4122214708 * r + 0.5363325363 * g + 0.0514459929 * b) ** (1 / 3)
    m = (0.2119034982 * r + 0.6806995451 * g + 0.1073969566 * b) ** (1 / 3)
    s = (0.0883024619 * r + 0.2817188376 * g + 0.6299787005 * b) ** (1 / 3)
    return (0.2104542553 * l + 0.7936177850 * m - 0.0040720468 * s,
            1.9779984951 * l - 2.4285922050 * m + 0.4505937099 * s,
            0.0259040371 * l + 0.7827717662 * m - 0.8086757660 * s)


def _srgb(L, A, B):
    l = (L + 0.3963377774 * A + 0.2158037573 * B) ** 3
    m = (L - 0.1055613458 * A - 0.0638541728 * B) ** 3
    s = (L - 0.0894841775 * A - 1.2914855480 * B) ** 3
    rgb = (4.0767416621 * l - 3.3077115913 * m + 0.2309699292 * s,
           -1.2684380046 * l + 2.6097574011 * m - 0.3413193965 * s,
           -0.0041960863 * l - 0.7034186147 * m + 1.7076147010 * s)

    def gam(c):
        c = min(1.0, max(0.0, c))
        return c * 12.92 if c <= 0.0031308 else 1.055 * c ** (1 / 2.4) - 0.055
    return tuple(gam(c) for c in rgb)


def tom_hex(cor, tr):
    """Gira o tom de uma cor '#rrggbb' (igual ao que o painel faz com as cores azuis). Função pura."""
    if not tr or not re.fullmatch(r"#[0-9a-fA-F]{6}", cor or ""):
        return (cor or "").lower()
    r, g, b = (int(cor[i:i + 2], 16) / 255 for i in (1, 3, 5))
    L, A, B = _oklab(r, g, b)
    c, h = math.hypot(A, B) * tema_tc(tr), math.atan2(B, A) + math.radians(tr)
    return "#" + "".join(f"{round(x * 255):02x}" for x in _srgb(L, c * math.cos(h), c * math.sin(h)))


# ---------------- v9.4: gráfico leve nos jogos (junto do Modo FPS On) ----------------
# Ao ligar o Modo FPS On, o Th Boost deixa o gráfico do Valorant, do CS2 e do Roblox no mínimo (sombras, efeitos,
# texturas, detalhes e suavização), mas com a resolução em 100% (a imagem continua nítida). Ao desligar, cada item volta
# ao valor que você usava. Só mexe nos itens de gráfico (o resto do arquivo, como sensibilidade e volume, fica como está).
# O jogo precisa estar fechado: se estiver aberto, a troca espera ele fechar (o jogo regrava o arquivo ao sair).

GR_ESPERA = 4  # segundos depois que o jogo fecha antes de mexer (ele ainda está gravando o arquivo)

# ---- Valorant: GameUserSettings.ini, seção [ScalabilityGroups] (0 = baixo) ----
GR_VAL_CHAVES = ("sg.ViewDistanceQuality", "sg.AntiAliasingQuality", "sg.ShadowQuality", "sg.PostProcessQuality",
                 "sg.TextureQuality", "sg.EffectsQuality", "sg.FoliageQuality", "sg.ShadingQuality")
GR_VAL_BAIXO = dict({k: "0" for k in GR_VAL_CHAVES}, **{"sg.ResolutionQuality": "100.000000"})

# ---- CS2: cs2_video.txt (Steam\userdata\<conta>\730\local\cfg) ----
GR_CS2_BAIXO = {"setting.shaderquality": "0", "setting.r_texturefilteringquality": "0", "setting.msaa_samples": "0",
                "setting.r_csgo_cmaa_enable": "0", "setting.videocfg_shadow_quality": "0", "setting.videocfg_texture_detail": "0",
                "setting.videocfg_particle_detail": "0", "setting.videocfg_ao_detail": "0", "setting.videocfg_hdr_detail": "3",
                "setting.videocfg_fsr_detail": "0"}  # hdr 3 = "Desempenho"; fsr 0 = desligado (resolução 100%)

# ---- Roblox: GlobalBasicSettings_*.xml (qualidade 1 = a mais baixa) ----
GR_RBX_BAIXO = {"SavedQualityLevel": "1", "GraphicsQualityLevel": "1"}

# ---- v9.5: perfil "Processador fraco" (o processador fica em 100% e a placa de vídeo sobra) ----
# O que pesa no processador (sombras, distância de visão, partículas, efeitos, vegetação) fica no mínimo, igual ao
# outro perfil; o que só pesa na placa (texturas, materiais, suavização, filtro de textura) sobe um pouco. O FPS fica o
# mesmo do mínimo (quem segura é o processador), a imagem fica melhor e a placa passa a trabalhar mais.
GR_VAL_PROC = dict(GR_VAL_BAIXO, **{"sg.TextureQuality": "1", "sg.ShadingQuality": "1", "sg.PostProcessQuality": "1"})
GR_CS2_PROC = dict(GR_CS2_BAIXO, **{"setting.shaderquality": "1", "setting.r_texturefilteringquality": "5",
                                     "setting.msaa_samples": "2", "setting.videocfg_texture_detail": "1",
                                     "setting.videocfg_hdr_detail": "-1"})  # 16x, MSAA 2x, texturas médias (placa de 1 GB aguenta)
GR_RBX_PROC = dict(GR_RBX_BAIXO)  # no Roblox um controle só mexe nos dois: fica no mínimo
GR_PERFIS = ("minimo", "proc")


def _ini_ler(t, secao, chaves):
    out, dentro = {}, False
    for ln in t.splitlines():
        s = ln.strip()
        if s.startswith("[") and s.endswith("]"):
            dentro = s[1:-1] == secao
            continue
        if dentro and "=" in s:
            k, v = s.split("=", 1)
            if k.strip() in chaves:
                out[k.strip()] = v.strip()
    return out


def _ini_mudar(t, secao, valores):
    """Troca (ou cria) chave=valor dentro de [secao]; valor None apaga a linha. Mantém o resto e o fim de linha."""
    nl = "\r\n" if "\r\n" in t else "\n"
    novas, feitas = [], set()
    dentro = achou = False
    fim = None  # onde termina a seção (para colocar o que falta)
    for ln in t.splitlines():
        s = ln.strip()
        if s.startswith("[") and s.endswith("]"):
            if dentro and fim is None:
                fim = len(novas)
            dentro = s[1:-1] == secao
            achou = achou or dentro
            novas.append(ln)
            continue
        if dentro and "=" in s:
            k = s.split("=", 1)[0].strip()
            if k in valores:
                feitas.add(k)
                if valores[k] is not None:
                    novas.append(f"{k}={valores[k]}")
                continue
        novas.append(ln)
    if dentro and fim is None:
        fim = len(novas)
    faltam = [f"{k}={v}" for k, v in valores.items() if k not in feitas and v is not None]
    if faltam and not achou:
        if novas and novas[-1].strip():
            novas.append("")
        novas += [f"[{secao}]"] + faltam
    elif faltam:
        pos = fim
        while pos > 0 and not novas[pos - 1].strip():
            pos -= 1
        novas[pos:pos] = faltam
    return nl.join(novas) + (nl if t.endswith(("\n", "\r")) or not t else "")


def gr_val_ler(t):
    return _ini_ler(t, "ScalabilityGroups", set(GR_VAL_BAIXO))


def gr_val_mudar(t, valores):
    return _ini_mudar(t, "ScalabilityGroups", valores)


def gr_cs2_ler(t):
    return {k: m.group(1) for k in GR_CS2_BAIXO for m in [re.search(r'"%s"\s+"([^"]*)"' % re.escape(k), t)] if m}


def gr_cs2_mudar(t, valores):
    """Só troca chaves que já existem no arquivo (o CS2 sempre grava todas)."""
    for k, v in valores.items():
        if v is not None:
            t = re.sub(r'("%s"\s+")([^"]*)(")' % re.escape(k), lambda m, v=v: m.group(1) + v + m.group(3), t, count=1)
    return t


def gr_rbx_ler(t):
    return {m.group(2): m.group(3) for m in re.finditer(r'<(\w+) name="(%s)">(-?\d+)</\1>' % "|".join(GR_RBX_BAIXO), t)}


def gr_rbx_mudar(t, valores):
    for k, v in valores.items():
        if v is not None:
            t = re.sub(r'(<(\w+) name="%s">)(-?\d+)(</\2>)' % re.escape(k), lambda m, v=v: m.group(1) + v + m.group(4), t, count=1)
    return t


GR_JOGOS = {
    "valorant": {"nome": "Valorant", "procs": ("valorant-win64-shipping.exe", "valorant.exe"),
                 "ler": gr_val_ler, "mudar": gr_val_mudar, "baixo": GR_VAL_BAIXO, "proc": GR_VAL_PROC},
    "cs2": {"nome": "CS2", "procs": ("cs2.exe",), "ler": gr_cs2_ler, "mudar": gr_cs2_mudar, "baixo": GR_CS2_BAIXO, "proc": GR_CS2_PROC},
    "roblox": {"nome": "Roblox", "procs": ("robloxplayerbeta.exe",), "ler": gr_rbx_ler, "mudar": gr_rbx_mudar, "baixo": GR_RBX_BAIXO,
               "proc": GR_RBX_PROC},
}


def gr_perfil():
    return "proc" if CONFIG.get("grafico_perfil") == "proc" else "minimo"


def gr_valores(jogo, perfil=None):
    d = GR_JOGOS[jogo]
    return d["proc"] if (perfil or gr_perfil()) == "proc" else d["baixo"]


def gr_arquivos():
    """{jogo: [arquivos de gráfico deste PC]}"""
    la = os.environ.get("LOCALAPPDATA") or ""
    out = {"valorant": [], "cs2": [], "roblox": []}
    if la:
        for sub in ("Windows", "WindowsClient"):
            out["valorant"] += glob.glob(os.path.join(la, "VALORANT", "Saved", "Config", "*", sub, "GameUserSettings.ini"))
        out["roblox"] = glob.glob(os.path.join(la, "Roblox", "GlobalBasicSettings_*.xml"))
    for raiz in _raizes_steam():
        out["cs2"] += glob.glob(os.path.join(raiz, "userdata", "*", "730", "local", "cfg", "cs2_video.txt"))
    return {k: sorted(set(v)) for k, v in out.items()}


def _gr_le_arquivo(caminho):
    with open(caminho, "rb") as f:
        b = f.read(4 * 1024 * 1024)
    for bom, cod in ((b"\xef\xbb\xbf", "utf-8-sig"), (b"\xff\xfe", "utf-16"), (b"\xfe\xff", "utf-16")):
        if b.startswith(bom):
            return b.decode(cod), cod
    try:
        return b.decode("utf-8"), "utf-8"
    except UnicodeDecodeError:
        return b.decode("latin-1"), "latin-1"


def _gr_grava(caminho, texto, cod):
    tmp = caminho + ".thboost.tmp"
    with open(tmp, "wb") as f:
        f.write(texto.encode(cod))
    try:
        os.replace(tmp, caminho)
    except OSError:
        try:
            os.remove(tmp)
        except OSError:
            pass
        raise


def _gr_rodando(procs):
    try:
        for p in psutil.process_iter(["name"]):
            if (p.info.get("name") or "").lower() in procs:
                return True
    except Exception:
        pass
    return False


class GraficoMixin:
    """Gráfico leve: aplica ao ligar o Modo FPS On e devolve ao desligar (ou quando o jogo fechar)."""

    def gr_aplicar(self):
        with self.gr_trava:
            texto = self._gr_aplicar_sem_trava()
            if not getattr(self, "modo_fps", False):  # desligaram o Modo FPS On enquanto aplicava: desfaz
                return self._gr_voltar_sem_trava()
            return texto

    def gr_voltar(self, avisar=False):
        with self.gr_trava:
            return self._gr_voltar_sem_trava(avisar)

    def gr_conferir(self):
        if not self.gr["espera"]:
            return
        with self.gr_trava:
            self._gr_conferir_sem_trava()

    def gr_fechar(self):
        with self.gr_trava:
            self._gr_fechar_sem_trava()

    def gr_iniciar_estado(self):
        self.gr = {"espera": {}, "fechou_em": {}, "ultimo": 0.0, "texto": ""}  # espera: {jogo: "aplicar"|"voltar"}
        self.gr_trava = threading.RLock()
        if CONFIG.get("grafico_bk"):  # fechou com o gráfico leve aplicado: devolve (ou espera o jogo fechar)
            threading.Thread(target=lambda: self.gr_voltar(avisar=True), daemon=True).start()

    def gr_ligado(self):
        return CONFIG.get("grafico_leve", True) is not False

    def gr_estado(self):
        bk = CONFIG.get("grafico_bk") or {}
        return {"ligado": self.gr_ligado(), "perfil": gr_perfil(), "aplicado": sorted({v.get("jogo") for v in bk.values() if isinstance(v, dict)}),
                "espera": dict(self.gr["espera"]), "texto": self.gr["texto"]}

    def _gr_aplicar_jogo(self, jogo, arquivos):
        """Deixa um jogo no mínimo. Guarda o valor de antes de cada item (uma vez só). Devolve quantos arquivos mudou."""
        d = GR_JOGOS[jogo]
        bk = CONFIG.setdefault("grafico_bk", {})
        feitos = 0
        for arq in arquivos:
            try:
                t, cod = _gr_le_arquivo(arq)
                antes = d["ler"](t)
                if jogo != "valorant" and not antes:
                    continue  # arquivo sem os itens de gráfico (versão diferente): não mexe
                if arq not in bk:
                    bk[arq] = {"jogo": jogo, "antes": {k: antes.get(k) for k in d["baixo"]}}
                    try:  # cópia inteira do arquivo, por garantia
                        pasta = os.path.join(os.environ.get("LOCALAPPDATA") or pasta_do_programa(), "ThBoost", "grafico")
                        os.makedirs(pasta, exist_ok=True)
                        nome = f"{jogo}_{hashlib.sha256(arq.lower().encode()).hexdigest()[:10]}_{os.path.basename(arq)}"
                        shutil.copy2(arq, os.path.join(pasta, nome))
                    except OSError:
                        pass
                novo = d["mudar"](t, gr_valores(jogo))
                if novo != t:
                    _gr_grava(arq, novo, cod)
                feitos += 1
            except OSError:
                bk.pop(arq, None)
        salvar_config()
        return feitos

    def _gr_voltar_jogo(self, jogo):
        d = GR_JOGOS[jogo]
        bk = CONFIG.get("grafico_bk") or {}
        feitos = 0
        for arq, info in list(bk.items()):
            if not isinstance(info, dict) or info.get("jogo") != jogo:
                continue
            try:
                if os.path.isfile(arq):
                    t, cod = _gr_le_arquivo(arq)
                    antes = {k: v for k, v in (info.get("antes") or {}).items() if k in d["baixo"]}
                    if jogo != "valorant":  # nos outros só se troca o que existe
                        antes = {k: v for k, v in antes.items() if v is not None}
                    novo = d["mudar"](t, antes)
                    if novo != t:
                        _gr_grava(arq, novo, cod)
                feitos += 1
                bk.pop(arq, None)
            except OSError:
                continue  # arquivo preso (somente leitura, aberto): tenta de novo depois
        if not bk:
            CONFIG.pop("grafico_bk", None)
        salvar_config()
        return feitos

    def _gr_aplicar_sem_trava(self):
        """Modo FPS On ligou."""
        if not self.gr_ligado():
            return ""
        arqs = gr_arquivos()
        feitos, esperam = [], []
        for jogo, lista in arqs.items():
            if not lista:
                continue
            if _gr_rodando(GR_JOGOS[jogo]["procs"]):
                self.gr["espera"][jogo] = "aplicar"
                esperam.append(GR_JOGOS[jogo]["nome"])
            elif self._gr_aplicar_jogo(jogo, lista):
                self.gr["espera"].pop(jogo, None)
                feitos.append(GR_JOGOS[jogo]["nome"])
        partes = []
        if feitos:
            partes.append("Gráfico leve: " + ", ".join(feitos) + (" no perfil Processador fraco" if gr_perfil() == "proc" else " no mínimo") +
                          " (resolução continua 100%).")
        if esperam:
            partes.append(", ".join(esperam) + (" está aberto" if len(esperam) == 1 else " estão abertos") +
                          ": o gráfico leve entra quando fechar (feche e abra o jogo de novo).")
        self.gr["texto"] = " ".join(partes[1:]) if esperam and feitos else (" ".join(partes) if esperam else "")  # na tela: só o que espera
        return " ".join(partes)

    def _gr_voltar_sem_trava(self, avisar=False):
        """Modo FPS On desligou (ou o Th Boost abriu depois de fechar com ele ligado)."""
        bk = CONFIG.get("grafico_bk") or {}
        jogos = sorted({v.get("jogo") for v in bk.values() if isinstance(v, dict) and v.get("jogo") in GR_JOGOS})
        for j, acao in list(self.gr["espera"].items()):
            if acao == "aplicar":
                self.gr["espera"].pop(j, None)
        feitos, esperam = [], []
        for jogo in jogos:
            if _gr_rodando(GR_JOGOS[jogo]["procs"]):
                self.gr["espera"][jogo] = "voltar"
                esperam.append(GR_JOGOS[jogo]["nome"])
            else:
                self._gr_voltar_jogo(jogo)
                self.gr["espera"].pop(jogo, None)
                feitos.append(GR_JOGOS[jogo]["nome"])
        partes = []
        if feitos:
            partes.append("O gráfico de " + ", ".join(feitos) + " voltou ao que você usava.")
        if esperam:
            partes.append(", ".join(esperam) + (" está aberto" if len(esperam) == 1 else " estão abertos") +
                          ": o seu gráfico volta assim que fechar.")
        self.gr["texto"] = " ".join(partes) if esperam else ""
        texto = " ".join(partes)
        if avisar and texto:
            self.msg(texto)
        return texto

    def _gr_conferir_sem_trava(self):
        """Chamado o tempo todo: faz o que ficou esperando o jogo fechar (no máximo a cada 3 s)."""
        if not self.gr["espera"]:
            return
        agora = time.time()
        if agora - self.gr["ultimo"] < 3:
            return
        self.gr["ultimo"] = agora
        for jogo, acao in list(self.gr["espera"].items()):
            if _gr_rodando(GR_JOGOS[jogo]["procs"]):
                self.gr["fechou_em"].pop(jogo, None)
                continue
            if agora - self.gr["fechou_em"].setdefault(jogo, agora) < GR_ESPERA:
                continue  # acabou de fechar: o jogo ainda pode estar gravando o arquivo
            self.gr["fechou_em"].pop(jogo, None)
            self.gr["espera"].pop(jogo, None)
            nome = GR_JOGOS[jogo]["nome"]
            if acao == "aplicar" and getattr(self, "modo_fps", False) and self.gr_ligado():
                if self._gr_aplicar_jogo(jogo, gr_arquivos().get(jogo) or []):
                    self.msg(f"{nome} fechou: o gráfico leve já está pronto para a próxima vez que abrir.")
            elif acao == "voltar":
                self._gr_voltar_jogo(jogo)
                self.msg(f"{nome} fechou: o gráfico voltou ao que você usava.")
        if not self.gr["espera"]:
            self.gr["texto"] = ""

    def _gr_fechar_sem_trava(self):
        """O Th Boost vai fechar: devolve o que der agora; o que estiver aberto volta na próxima vez que ele abrir."""
        try:
            bk = CONFIG.get("grafico_bk") or {}
            for jogo in sorted({v.get("jogo") for v in bk.values() if isinstance(v, dict) and v.get("jogo") in GR_JOGOS}):
                if not _gr_rodando(GR_JOGOS[jogo]["procs"]):
                    self._gr_voltar_jogo(jogo)
        except Exception:
            pass


# ---------------- v9.2: FPS na tela (overlay de monitoramento) e contador de FPS com um clique ----------------
# O "FPS na tela" é uma janelinha sempre por cima do jogo (num canto), que não pega clique nem foco: o mouse e o teclado
# continuam indo para o jogo. Ela roda num programa separado (o mesmo th_boost.py com --overlay), que só lê os números do
# Th Boost a cada meio segundo. Ctrl+Shift+F esconde e mostra durante o jogo.
# Funciona por cima de jogos em janela ou em "tela cheia sem bordas" (a maioria dos jogos atuais). Em tela cheia exclusiva,
# alguns jogos não deixam nenhuma janela aparecer por cima.

OV_PADRAO = {"on": False, "pos": "se", "tam": 2, "itens": ["fps", "fps1", "ms", "cpu", "tcpu", "gpu", "tgpu", "ram", "lim"]}
OV_ITENS = ("fps", "fps1", "ms", "cpu", "tcpu", "gpu", "tgpu", "ram", "lim")
GARGALO_TXT = {"cpu": ("CPU", "#f87171"), "gpu": ("GPU", "#4ade80"), "folga": ("nenhum", "#e2e8f0")}


def gargalo(amostras):
    """Quem segura o FPS agora, pela média das últimas leituras [(CPU total %, núcleo mais usado %, GPU %)]:
    'gpu' (a placa está no limite: overclock da placa ajuda), 'cpu' (o processador está no limite e a placa sobra)
    ou 'folga' (nenhum dos dois: o FPS está preso por um limite do jogo). None sem leituras suficientes. Função pura."""
    ok = [a for a in amostras if a and a[0] is not None and a[2] is not None]
    if len(ok) < 3:
        return None
    tot = sum(a[0] for a in ok) / len(ok)
    mx = sum((a[1] if a[1] is not None else a[0]) for a in ok) / len(ok)
    gpu = sum(a[2] for a in ok) / len(ok)
    if gpu >= 90:
        return "gpu"
    if tot >= 85 or mx >= 95:
        return "cpu"
    return "folga"
OV_POS = ("se", "sd", "ie", "id")  # superior esquerdo, superior direito, inferior esquerdo, inferior direito
OV_SEM_TK = 3  # código de saída da janelinha quando o Python deste PC não tem o Tk (a parte de janelas)

# PresentMon oficial (Intel, código aberto, github.com/GameTechDev/PresentMon), conferido pela impressão digital
PM_VERSAO = "2.6.0"
PM_NOME = f"PresentMon-{PM_VERSAO}-x64.exe"
PM_URL = f"https://github.com/GameTechDev/PresentMon/releases/download/v{PM_VERSAO}/{PM_NOME}"
PM_SHA256 = "b2a706bc6ad475749e3b7e3409263aa1e6906d45bdcf993f6dbc0f660188f1af"
PM_TAM = 980320
PM_HOSTS = ("github.com", "release-assets.githubusercontent.com", "objects.githubusercontent.com")


def ov_valida(d, base=None):
    """Configuração do FPS na tela, só com valores conhecidos. Função pura."""
    o = dict(base or OV_PADRAO)
    o["itens"] = list(o.get("itens") or OV_PADRAO["itens"])
    if not isinstance(d, dict):
        return o
    if isinstance(d.get("on"), bool):
        o["on"] = d["on"]
    if d.get("pos") in OV_POS:
        o["pos"] = d["pos"]
    if isinstance(d.get("tam"), int) and not isinstance(d.get("tam"), bool) and 1 <= d["tam"] <= 3:
        o["tam"] = d["tam"]
    if isinstance(d.get("itens"), list):
        itens = [i for i in OV_ITENS if i in d["itens"]]
        o["itens"] = itens or ["fps"]
    return o


def ov_linhas(itens, v):
    """Linhas do overlay [(rótulo, valor, cor)] a partir dos números de agora. Função pura."""
    def n(x, suf=""):
        return "--" if x is None else f"{x:.0f}{suf}"
    def cor_fps(x):
        return "#9aa4b2" if x is None else "#4ade80" if x >= 60 else "#facc15" if x >= 30 else "#f87171"
    def cor_t(x, quente):
        return "#e2e8f0" if x is None else "#f87171" if x >= quente else "#facc15" if x >= quente - 10 else "#e2e8f0"
    L = []
    for i in itens:
        if i == "fps":
            L.append(("FPS", n(v.get("fps")), cor_fps(v.get("fps"))))
        elif i == "fps1":
            L.append(("1% baixo", n(v.get("fps1")), cor_fps(v.get("fps1"))))
        elif i == "ms":
            ms = v.get("ms")
            L.append(("Quadro", "--" if ms is None else f"{ms:.1f} ms".replace(".", ","), "#e2e8f0"))
        elif i == "cpu":
            L.append(("CPU", n(v.get("cpu"), "%"), "#e2e8f0"))
        elif i == "tcpu":
            if v.get("tcpu") is not None:  # a maioria dos PCs com Windows não informa: aí a linha some
                L.append(("CPU °C", n(v.get("tcpu"), "°"), cor_t(v.get("tcpu"), 90)))
        elif i == "gpu":
            L.append(("GPU", n(v.get("gpu"), "%"), "#e2e8f0"))
        elif i == "tgpu":
            if v.get("tgpu") is not None:
                L.append(("GPU °C", n(v.get("tgpu"), "°"), cor_t(v.get("tgpu"), 83)))
        elif i == "ram":
            L.append(("RAM", n(v.get("ram"), "%"), "#e2e8f0"))
        elif i == "lim" and v.get("lim") in GARGALO_TXT:  # v9.5: quem segura o FPS
            L.append(("Gargalo", *GARGALO_TXT[v["lim"]]))
    return L


# ----- baixar o PresentMon -----

class _PmRedireciona(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        p = urllib.parse.urlparse(newurl)
        teste = os.environ.get("THBOOST_PM_URL", "")
        if not (teste.startswith("http://127.0.0.1:") and newurl.startswith("http://127.0.0.1:")) and \
                (p.scheme != "https" or p.hostname not in PM_HOSTS):
            raise urllib.error.HTTPError(newurl, code, "redirecionamento recusado", headers, fp)
        return super().redirect_request(req, fp, code, msg, headers, newurl)


def pm_url():
    t = os.environ.get("THBOOST_PM_URL", "")
    return t if re.fullmatch(r"http://127\.0\.0\.1:\d{2,5}/[\w./-]+", t) else PM_URL


def pm_baixar(pasta, progresso=None):
    """Baixa o PresentMon oficial e só grava se a impressão digital bater. Devolve o caminho gravado."""
    abridor = urllib.request.build_opener(_PmRedireciona)
    req = urllib.request.Request(pm_url(), headers={"User-Agent": f"ThBoost/{VERSAO}"})
    partes, total = [], 0
    with abridor.open(req, timeout=60) as r:
        while True:
            b = r.read(65536)
            if not b:
                break
            total += len(b)
            if total > PM_TAM * 2:
                raise ValueError("o arquivo veio maior do que o esperado")
            partes.append(b)
            if progresso:
                progresso(min(99, int(total * 100 / PM_TAM)))
    dados = b"".join(partes)
    if hashlib.sha256(dados).hexdigest() != PM_SHA256:
        raise ValueError("a impressão digital do arquivo não confere; nada foi gravado")
    alvo = os.path.join(pasta, PM_NOME)
    tmp = alvo + ".baixando"
    with open(tmp, "wb") as f:
        f.write(dados)
    os.replace(tmp, alvo)
    return alvo


# ----- o processo do overlay (janela por cima do jogo) -----

def overlay_principal(porta, token):
    """Roda a janelinha do FPS na tela. Sai sozinha quando o Th Boost manda desligar ou fecha."""
    try:
        import tkinter as tk
    except ImportError:
        return OV_SEM_TK
    u32 = None
    if IS_WIN:
        try:  # nítido em tela com zoom do Windows
            ctypes.windll.shcore.SetProcessDpiAwareness(1)
        except (OSError, AttributeError):
            pass
        try:
            u32 = ctypes.windll.user32
            u32.GetParent.restype = ctypes.c_void_p
            u32.GetParent.argtypes = [ctypes.c_void_p]
            u32.GetWindowLongW.argtypes = [ctypes.c_void_p, ctypes.c_int]
            u32.SetWindowLongW.argtypes = [ctypes.c_void_p, ctypes.c_int, ctypes.c_long]
            u32.SetLayeredWindowAttributes.argtypes = [ctypes.c_void_p, ctypes.c_uint, ctypes.c_ubyte, ctypes.c_uint]
            u32.SetWindowPos.argtypes = [ctypes.c_void_p, ctypes.c_void_p, ctypes.c_int, ctypes.c_int, ctypes.c_int, ctypes.c_int, ctypes.c_uint]
        except (OSError, AttributeError):
            u32 = None
    url = f"http://127.0.0.1:{int(porta)}/api/overlay?k={urllib.parse.quote(token)}"
    abridor = urllib.request.build_opener(urllib.request.ProxyHandler({}))
    try:
        root = tk.Tk()
    except tk.TclError:
        return OV_SEM_TK
    root.withdraw()
    root.overrideredirect(True)
    chave = "#010203"  # cor que fica transparente
    root.config(bg=chave)
    try:
        root.attributes("-topmost", True)
        root.attributes("-transparentcolor", chave)
        root.attributes("-alpha", 0.93)
    except tk.TclError:
        pass
    caixa = tk.Frame(root, bg="#0b1220", highlightthickness=1, highlightbackground="#1e3a8a")
    caixa.pack(padx=0, pady=0)
    estado = {"falhas": 0, "visivel": True, "alternar": False, "cfg": None, "rotulos": [], "hwnd": None, "mostrou": False,
              "hk": "", "acento": "#8fb3ff", "borda": "#1e3a8a"}

    def prende():  # sem foco, sem clique (o jogo continua recebendo tudo) e fora da barra de tarefas
        if not u32:
            return
        try:
            hwnd = u32.GetParent(root.winfo_id()) or root.winfo_id()
            estado["hwnd"] = hwnd
            ex = u32.GetWindowLongW(hwnd, -20) & 0xFFFFFFFF
            novo = ex | 0x80000 | 0x20 | 0x80 | 0x08000000 | 0x8  # LAYERED, TRANSPARENT (clique passa), TOOLWINDOW, NOACTIVATE, TOPMOST
            u32.SetWindowLongW(hwnd, -20, ctypes.c_long(novo - (1 << 32) if novo >= 1 << 31 else novo).value)
            # cor-chave #010203 vira transparente e o resto fica 93% opaco (feito aqui, para não depender da ordem do Tk)
            u32.SetLayeredWindowAttributes(hwnd, 0x00030201, 237, 0x1 | 0x2)
        except Exception:
            pass

    def no_topo():
        if u32 and estado["hwnd"]:
            try:  # HWND_TOPMOST, sem mover, sem mudar o tamanho, sem pegar o foco
                u32.SetWindowPos(estado["hwnd"], ctypes.c_void_p(-1), 0, 0, 0, 0, 0x0001 | 0x0002 | 0x0010)
            except Exception:
                pass
        root.after(1000, no_topo)

    def monta(cfg, linhas):
        tam = cfg.get("tam", 2)
        f1, f2 = {1: (9, 12), 2: (10, 15), 3: (12, 19)}[tam]
        sig = (tam, tuple(l[0] for l in linhas))
        if estado.get("sig") != sig:
            for w in caixa.winfo_children():
                w.destroy()
            estado["rotulos"] = []
            for r_, (rot, val, cor) in enumerate(linhas):
                a = tk.Label(caixa, text=rot, fg=estado["acento"], bg="#0b1220", font=("Segoe UI", f1, "bold"), anchor="w")
                b = tk.Label(caixa, text=val, fg=cor, bg="#0b1220", font=("Consolas", f2, "bold"), anchor="e")
                a.grid(row=r_, column=0, sticky="w", padx=(10, 12), pady=(4 if r_ == 0 else 0, 4 if r_ == len(linhas) - 1 else 0))
                b.grid(row=r_, column=1, sticky="e", padx=(0, 10))
                estado["rotulos"].append(b)
            estado["sig"] = sig
        for b, (_, val, cor) in zip(estado["rotulos"], linhas):
            if b.cget("text") != val:
                b.config(text=val)
            if b.cget("fg") != cor:
                b.config(fg=cor)
        root.update_idletasks()
        w, h = root.winfo_reqwidth(), root.winfo_reqheight()
        sw, sh, m = root.winfo_screenwidth(), root.winfo_screenheight(), 14
        pos = cfg.get("pos", "se")
        x = m if pos in ("se", "ie") else sw - w - m
        y = m if pos in ("se", "sd") else sh - h - m - 40
        root.geometry(f"+{x}+{y}")

    def atalho():  # Ctrl+Shift+F esconde/mostra (fica numa thread com a fila de mensagens própria do Windows)
        if not IS_WIN:
            return
        try:
            import ctypes.wintypes as _wt
            u = ctypes.windll.user32
            if not u.RegisterHotKey(None, 1, 0x0002 | 0x0004 | 0x4000, 0x46):
                estado["hk"] = "0"  # outro programa já usa Ctrl+Shift+F: o Th Boost avisa na tela
                return
            estado["hk"] = "1"
            msg = _wt.MSG()
            while u.GetMessageW(ctypes.byref(msg), None, 0, 0) > 0:
                if msg.message == 0x0312:  # WM_HOTKEY
                    estado["alternar"] = True
        except Exception:
            pass

    def ciclo():
        try:
            with abridor.open(url + (f"&hk={estado['hk']}" if estado["hk"] else ""), timeout=3) as r:
                d = json.loads(r.read() or b"{}")
            estado["falhas"] = 0
        except Exception:
            estado["falhas"] += 1
            if estado["falhas"] >= 10:  # o Th Boost fechou
                root.destroy()
                return
            root.after(500, ciclo)
            return
        if not d.get("on"):
            root.destroy()
            return
        ac, bo = d.get("acento") or "#8fb3ff", d.get("borda") or "#1e3a8a"
        if (ac, bo) != (estado["acento"], estado["borda"]) and re.fullmatch(r"#[0-9a-f]{6}", ac) and re.fullmatch(r"#[0-9a-f]{6}", bo):
            estado["acento"], estado["borda"], estado["sig"] = ac, bo, None  # a cor do painel mudou: remonta
            caixa.config(highlightbackground=bo)
        if estado["alternar"]:
            estado["alternar"] = False
            estado["visivel"] = not estado["visivel"]
        monta(d, [tuple(x) for x in d.get("linhas") or []])
        if estado["visivel"]:
            if not estado["mostrou"] or root.state() == "withdrawn":
                root.deiconify()
                if not estado["mostrou"]:
                    root.update_idletasks()
                    prende()
                    estado["mostrou"] = True
        elif root.state() != "withdrawn":
            root.withdraw()
        root.after(500, ciclo)

    threading.Thread(target=atalho, daemon=True).start()
    root.after(50, ciclo)
    root.after(1500, no_topo)
    root.mainloop()
    return 0


class OverlayMixin:
    """Parte do Nucleo que cuida do FPS na tela e do download do contador de FPS."""

    def ov_iniciar_estado(self):
        self.ov = ov_valida(CONFIG.get("overlay"))
        self.ov["on"] = False  # sempre começa desligado (liga pela tela ou pelo Modo FPS On)
        self.ov_proc = None
        self.ov_trava = threading.Lock()  # nunca duas janelinhas ao mesmo tempo
        self.ov_hk = None  # o atalho Ctrl+Shift+F ficou registrado? (None = ainda não se sabe)
        self.ov_quedas = []  # horários em que a janelinha fechou logo depois de abrir
        self.pm = {"estado": "", "pct": 0, "erro": ""}

    def ov_snapshot(self):
        return {"cfg": dict(self.ov, itens=list(self.ov["itens"])), "rodando": bool(self.ov_proc and self.ov_proc.poll() is None),
                "pm": dict(self.pm), "pm_versao": PM_VERSAO, "atalho": self.ov_hk}

    def ov_dados(self):
        """O que a janelinha mostra (o /api/overlay manda isto a cada meio segundo)."""
        d, g = self.mon.dados, (self.mon.dados.get("gpu") or {})
        try:
            ram = psutil.virtual_memory().percent
        except Exception:
            ram = None
        a = self.amostra or {}
        # CPU %: lida sempre pela mesma linha do programa (o Monitor), senão o número sai errado (0% ou média velha)
        v = {"fps": d.get("fps"), "fps1": d.get("fps1"), "ms": d.get("fps_ms"), "cpu": d.get("cpu_ov"), "ram": ram, "lim": d.get("gargalo"),
             "gpu": g.get("uso"), "tgpu": g.get("temp"), "tcpu": None if self.ocioso else a.get("tcpu")}
        if self.ocioso:  # janela fechada: a amostra para (e fica velha); lê a temperatura daqui (no máximo a cada 5 s)
            agora = time.time()
            if agora - getattr(self, "_ov_tcpu_t", 0) > 5:
                self._ov_tcpu_t = agora
                try:
                    self._ov_tcpu = temp_cpu()
                except Exception:
                    self._ov_tcpu = None
            v["tcpu"] = getattr(self, "_ov_tcpu", None)
        tr = tema_tr()
        return {"on": self.ov["on"], "pos": self.ov["pos"], "tam": self.ov["tam"], "linhas": ov_linhas(self.ov["itens"], v),
                "acento": tom_hex("#8fb3ff", tr), "borda": tom_hex("#1e3a8a", tr)}

    def ov_atalho(self, valor):
        """A janelinha conta se conseguiu o Ctrl+Shift+F (vem junto da leitura dos números)."""
        if valor in ("0", "1"):
            self.ov_hk = valor == "1"

    def ov_definir(self, dados):
        antes = self.ov["on"]
        self.ov = ov_valida(dados, self.ov)
        CONFIG["overlay"] = {k: self.ov[k] for k in ("pos", "tam", "itens")}
        salvar_config()
        if self.ov["on"] and not antes:
            self.ov_quedas = []
            self._ov_abrir(avisar=True)
        elif not self.ov["on"] and antes:
            self.mon.protege = set()
            self.msg("FPS na tela desligado.")
        self.mon.overlay = self.ov["on"]
        self.fps_contador_ajusta()

    def _ov_abrir(self, avisar=False):
        with self.ov_trava:
            self._ov_abrir_travado(avisar)

    def _ov_abrir_travado(self, avisar):
        if not self.ov["on"]:
            return
        if self.ov_proc and self.ov_proc.poll() is None:  # já aberta (por exemplo, desligou e ligou rápido): ela continua
            return
        if getattr(sys, "frozen", False):
            args = [sys.executable, "--overlay", str(PORTA), TOKEN]
        else:
            exe = sys.executable
            if IS_WIN and os.path.basename(exe).lower() == "python.exe":
                w = os.path.join(os.path.dirname(exe), "pythonw.exe")
                if os.path.isfile(w):
                    exe = w
            args = [exe, os.path.abspath(__file__), "--overlay", str(PORTA), TOKEN]
        try:
            self.ov_proc = subprocess.Popen(args, cwd=pasta_do_programa(), stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL,
                                            stderr=subprocess.DEVNULL, creationflags=subprocess.CREATE_NO_WINDOW if IS_WIN else 0)
            self.ov_aberta_em = time.time()
            self.mon.protege = {self.ov_proc.pid}  # o Modo Leve não baixa a prioridade da janelinha
            if avisar:
                self.msg("FPS na tela ligado. Ctrl+Shift+F esconde e mostra durante o jogo.")
        except OSError:
            self.ov["on"] = False
            self.msg("Não consegui abrir o FPS na tela.")

    def ov_conferir(self):
        """A cada segundo: se a janelinha fechou sozinha, abre de novo; se ela não consegue abrir neste PC, desliga e avisa."""
        if not self.ov["on"]:
            return
        with self.ov_trava:
            p = self.ov_proc
            if not p or p.poll() is None:
                return
            agora, cod = time.time(), p.returncode
            rapida = agora - getattr(self, "ov_aberta_em", 0) < 8  # fechou logo depois de abrir
            if cod != OV_SEM_TK and not rapida and agora - getattr(self, "_ov_reaberto", 0) < 30:
                return  # reabriu há pouco: espera um pouco antes de tentar de novo
            if rapida:
                self.ov_quedas.append(agora)
            self.ov_proc = None
            if cod == OV_SEM_TK or len(self.ov_quedas) >= 2:
                self.ov["on"] = False
                self.mon.overlay = False
                self.mon.protege = set()
                motivo = ("o Python deste computador foi instalado sem a parte de janelas (tcl/tk). Instale o Python de novo pelo "
                          "python.org deixando marcada a opção “tcl/tk and IDLE”, ou use o Th Boost.exe"
                          if cod == OV_SEM_TK else "a janelinha fechou logo depois de abrir")
                self.msg(f"Não deu para mostrar o FPS na tela: {motivo}.")
            else:  # fechou depois de um tempo (por exemplo, o Windows matou): abre de novo
                self._ov_reaberto = agora
                self._ov_abrir_travado(False)
                return
        self.fps_contador_ajusta()

    def ov_fechar(self):
        self.ov["on"] = False
        self.mon.protege = set()
        p = self.ov_proc
        if p and p.poll() is None:
            try:
                p.terminate()
            except OSError:
                pass

    def fps_contador_ajusta(self):
        """O contador de FPS fica ligado enquanto alguém precisa dele (Modo FPS On, FPS na tela ou o Monitor)."""
        quer = bool(self.modo_fps or self.ov["on"] or getattr(self, "contador_manual", False))
        if quer and not self.mon.fps_ligado and caminho_presentmon():
            self.mon.ligar_fps(True)
        elif not quer and self.mon.fps_ligado:
            self.mon.ligar_fps(False)

    def pm_instalar(self):
        if self.pm["estado"] == "baixando":
            return
        if caminho_presentmon():
            return self.msg("O contador de FPS já está instalado.")
        self.pm = {"estado": "baixando", "pct": 0, "erro": ""}

        def tarefa():
            try:
                pm_baixar(pasta_do_programa(), progresso=lambda p: self.pm.update(pct=p))
            except Exception as e:
                motivo = str(e) if isinstance(e, ValueError) else "não deu para baixar agora (internet ou pasta sem permissão)"
                self.pm = {"estado": "erro", "pct": 0, "erro": f"O contador de FPS não foi instalado: {motivo}."}
                return self.msg(self.pm["erro"])
            self.pm = {"estado": "ok", "pct": 100, "erro": ""}
            self.mon.dados["fps_erro"] = ""
            self.msg("Contador de FPS instalado (PresentMon oficial, conferido). Pronto para usar.")
            self.fps_contador_ajusta()
        threading.Thread(target=tarefa, daemon=True).start()




# ---------------- estado compartilhado, histórico e tarefas ----------------

# ---------------- modo segundo plano (a janela fecha, o programa continua) ----------------

ARQ_CONFIG = os.environ.get("TOTIMIZE_CONFIG") or os.path.join(pasta_do_programa(), "th_boost_config.json")
CONFIG = {"segundo_plano": False}


def _nome_limpo(valor):
    """Nome que aparece em 'Olá, ...': sem caracteres de controle nem < >, até 24 letras. '' se vier vazio."""
    if not isinstance(valor, str):
        return ""
    return re.sub(r"\s+", " ", re.sub(r"[\x00-\x1f\x7f<>]", "", valor)).strip()[:24]


def nome_da_pessoa():
    """O nome escolhido pela pessoa; se ainda não escolheu, o nome do usuário do Windows deste computador."""
    return _nome_limpo(CONFIG.get("nome")) or _nome_limpo(USUARIO.title()) or "Jogador"


def carregar_config():
    dados = None
    for arq in (ARQ_CONFIG, ARQ_CONFIG + ".bak"):  # v9.1: se o arquivo estragou (queda de energia), usa a cópia anterior
        try:
            with open(arq, encoding="utf-8") as f:
                dados = json.load(f)
        except (OSError, ValueError):
            dados = None
        if isinstance(dados, dict):
            break
    if not isinstance(dados, dict):
        return
    CONFIG["segundo_plano"] = dados.get("segundo_plano") is True
    for k in ("stats", "backup", "pre_opcoes"):
        if isinstance(dados.get(k), dict):
            CONFIG[k] = dados[k]
    if isinstance(dados.get("auto_jogo"), bool):
        CONFIG["auto_jogo"] = dados["auto_jogo"]
    if isinstance(dados.get("avisar_atualizacao"), bool):
        CONFIG["avisar_atualizacao"] = dados["avisar_atualizacao"]
    oa = dados.get("oc_antes")
    if isinstance(oa, dict) and all(isinstance(oa.get(k), int) and not isinstance(oa.get(k), bool) for k in ("core", "mem", "pot_mw")):
        CONFIG["oc_antes"] = {k: oa[k] for k in ("core", "mem", "pot_mw")}
    if isinstance(dados.get("atu_pular"), str) and versao_tupla(dados["atu_pular"]):
        CONFIG["atu_pular"] = dados["atu_pular"][:12]
    if tema_valida(dados.get("tema_tr")):
        CONFIG["tema_tr"] = tema_valida(dados["tema_tr"])
    if isinstance(dados.get("overlay"), dict):
        CONFIG["overlay"] = {k: v for k, v in ov_valida(dados["overlay"]).items() if k in ("pos", "tam", "itens")}
    if isinstance(dados.get("sessao_pendente"), dict):  # validado em sessao_retomar
        CONFIG["sessao_pendente"] = dados["sessao_pendente"]
    nome = _nome_limpo(dados.get("nome"))
    if nome:
        CONFIG["nome"] = nome
    manuais = []
    for i in (dados.get("jogos_manuais") or [])[:60] if isinstance(dados.get("jogos_manuais"), list) else []:
        if isinstance(i, dict) and isinstance(i.get("exe"), str) and isinstance(i.get("nome"), str):
            manuais.append({"nome": i["nome"][:60], "exe": i["exe"][:300]})
    if manuais:
        CONFIG["jogos_manuais"] = manuais
    if isinstance(dados.get("jogos_ocultos"), list):
        CONFIG["jogos_ocultos"] = [c for c in dados["jogos_ocultos"] if isinstance(c, str) and len(c) < 120][:300]
    if isinstance(dados.get("proc_ids"), list):
        CONFIG["proc_ids"] = [i for i in dados["proc_ids"] if isinstance(i, str)][:60]
    cl = dados.get("cpu_limite")
    if isinstance(cl, dict):
        CONFIG["cpu_limite"] = {"ligado": cl.get("ligado") is True, "pct": _cpu_limpar_pct(cl.get("pct"))}
    if dados.get("oc_ativo") is True:
        CONFIG["oc_ativo"] = True
    cpp = dados.get("cpu_perfil")
    if (isinstance(cpp, dict) and cpp.get("nivel") in PERFIS_CPU and isinstance(cpp.get("plano"), str)
            and re.fullmatch(_GUID, cpp["plano"]) and isinstance(cpp.get("antes"), dict)):
        CONFIG["cpu_perfil"] = {"nivel": cpp["nivel"], "plano": cpp["plano"].lower(),
                                "antes": {k: v for k, v in cpp["antes"].items()
                                          if k in _CFG_CPU and isinstance(v, int) and not isinstance(v, bool) and 0 <= v <= 100}}
    mm_ = dados.get("mouse_manual")
    if isinstance(mm_, dict):
        v = manual_mouse_valido(mm_.get("marca") or "", mm_.get("modelo") or "")
        if v and (v["marca"] or v["modelo"]):
            CONFIG["mouse_manual"] = v
    pb = dados.get("proc_base")
    if isinstance(pb, dict) and isinstance(pb.get("n"), int) and not isinstance(pb.get("n"), bool) and 0 < pb["n"] < 100000:
        CONFIG["proc_base"] = {"n": pb["n"], "t": float(pb.get("t") or 0), "boot": float(pb.get("boot") or 0)}


_TRAVA_CFG = threading.Lock()


def salvar_config():
    """v9.1: grava num arquivo temporário e troca de uma vez (uma queda de energia no meio não perde as configurações)
    e guarda a versão anterior como .bak. Várias partes do programa salvam ao mesmo tempo: a trava evita mistura."""
    with _TRAVA_CFG:
        try:
            try:
                texto = json.dumps(dict(CONFIG), indent=1)
            except RuntimeError:  # outra parte mudou a configuração no meio: tenta de novo
                time.sleep(0.05)
                texto = json.dumps(dict(CONFIG), indent=1)
            tmp = ARQ_CONFIG + ".tmp"
            with open(tmp, "w", encoding="utf-8") as f:
                f.write(texto)
                f.flush()
                os.fsync(f.fileno())
            if os.path.isfile(ARQ_CONFIG):
                try:
                    shutil.copyfile(ARQ_CONFIG, ARQ_CONFIG + ".bak")
                except OSError:
                    pass
            os.replace(tmp, ARQ_CONFIG)
        except (OSError, TypeError, ValueError, RuntimeError):
            pass  # sem permissão de escrita na pasta: vale só até fechar o programa


def _pasta_dados():
    base = (os.environ.get("LOCALAPPDATA") if IS_WIN else None) or os.path.join(os.path.expanduser("~"), ".cache")
    return os.path.join(base, "ThBoost")


# Quem abre o Th Boost de novo lê este arquivo para falar com o que já está rodando, em vez de abrir outro.
ARQ_INSTANCIA = os.environ.get("TOTIMIZE_INSTANCIA") or os.path.join(_pasta_dados(), "instancia.json")
USAR_INSTANCIA = (not os.environ.get("TOTIMIZE_SEM_JANELA")) or bool(os.environ.get("TOTIMIZE_INSTANCIA"))


def _chamar(inst, caminho, corpo=None):
    """Fala com um Th Boost já aberto (sem passar por proxy). Devolve o JSON da resposta ou None."""
    url = f"http://127.0.0.1:{int(inst['porta'])}{caminho}?k={urllib.parse.quote(str(inst['token']))}"
    req = urllib.request.Request(url, data=corpo, method="POST" if corpo is not None else "GET",
                                 headers={"Content-Type": "application/json"} if corpo is not None else {})
    try:
        with urllib.request.build_opener(urllib.request.ProxyHandler({})).open(req, timeout=3) as r:
            return json.loads(r.read() or b"{}")
    except (OSError, ValueError, KeyError, TypeError):
        return None


def instancia_ativa():
    try:
        with open(ARQ_INSTANCIA, encoding="utf-8") as f:
            inst = json.load(f)
        resp = _chamar(inst, "/api/ping")
    except (OSError, ValueError, TypeError):
        return None
    return inst if resp and resp.get("ok") and resp.get("pid") == inst.get("pid") else None


def pedir_instancia(inst, acao):
    return _chamar(inst, "/api/acao", json.dumps({"acao": acao}).encode("utf-8")) is not None


def gravar_instancia():
    try:
        os.makedirs(os.path.dirname(ARQ_INSTANCIA), exist_ok=True)
        with open(ARQ_INSTANCIA, "w", encoding="utf-8") as f:
            json.dump({"pid": os.getpid(), "porta": PORTA, "token": TOKEN}, f)
        if not IS_WIN:
            os.chmod(ARQ_INSTANCIA, 0o600)
    except OSError:
        pass


def apagar_instancia():
    try:
        with open(ARQ_INSTANCIA, encoding="utf-8") as f:
            if json.load(f).get("pid") != os.getpid():
                return
        os.remove(ARQ_INSTANCIA)
    except (OSError, ValueError, AttributeError):
        pass


# Ícone perto do relógio. Roda num PowerShell à parte: se falhar, o Th Boost segue normal (dá para abrir pelo atalho).
PS_BANDEJA = r"""
$ErrorActionPreference = 'Stop'
try {
  Add-Type -AssemblyName System.Windows.Forms
  Add-Type -AssemblyName System.Drawing
  function Enviar([string]$acao) {
    try {
      $c = New-Object System.Net.WebClient
      $c.Proxy = $null
      $c.Headers.Add('Content-Type', 'application/json')
      [void]$c.UploadString($env:T_URL, 'POST', ('{"acao":"' + $acao + '"}'))
    } catch { }
  }
  $ni = New-Object System.Windows.Forms.NotifyIcon
  $ni.Icon = New-Object System.Drawing.Icon($env:T_ICONE)
  $ni.Text = 'Th Boost - em segundo plano'
  $menu = New-Object System.Windows.Forms.ContextMenuStrip
  $mAbrir = $menu.Items.Add('Abrir o Th Boost')
  $mSair = $menu.Items.Add('Encerrar o Th Boost')
  $mAbrir.add_Click({ Enviar 'abrir_janela' })
  $mSair.add_Click({ Enviar 'encerrar_tudo'; $ni.Visible = $false; [System.Windows.Forms.Application]::Exit() })
  $ni.add_DoubleClick({ Enviar 'abrir_janela' })
  $ni.ContextMenuStrip = $menu
  $ni.Visible = $true
  $estado = @{ janela = $true; falhas = 0 }
  $relogio = New-Object System.Windows.Forms.Timer
  $relogio.Interval = 2000
  $relogio.add_Tick({
    try {
      $c = New-Object System.Net.WebClient
      $c.Proxy = $null
      $j = $c.DownloadString($env:T_PING) | ConvertFrom-Json
      $estado.falhas = 0
      if (-not $j.bg) { $ni.Visible = $false; [System.Windows.Forms.Application]::Exit(); return }
      if ($estado.janela -and -not $j.janela) {
        $ni.ShowBalloonTip(4000, 'Th Boost', 'Continua rodando em segundo plano. Clique duas vezes no ícone para abrir.', [System.Windows.Forms.ToolTipIcon]::Info)
      }
      $estado.janela = [bool]$j.janela
    } catch {
      $estado.falhas = $estado.falhas + 1
      if ($estado.falhas -ge 3) { $ni.Visible = $false; [System.Windows.Forms.Application]::Exit() }
    }
  })
  $relogio.Start()
  [System.Windows.Forms.Application]::Run()
  $ni.Visible = $false
  $ni.Dispose()
} catch { }
Remove-Item -LiteralPath $env:T_ARQ -ErrorAction SilentlyContinue
"""

# Traz a janela do Th Boost para a frente (quando a pessoa abre o programa de novo e a janela já existe).
PS_FOCO = r"""
$ErrorActionPreference = 'Stop'
$tipo = @'
using System;
using System.Text;
using System.Runtime.InteropServices;
public static class ThBoostFoco {
  delegate bool EnumProc(IntPtr h, IntPtr l);
  [DllImport("user32.dll")] static extern bool EnumWindows(EnumProc f, IntPtr l);
  [DllImport("user32.dll", CharSet = CharSet.Unicode)] static extern int GetWindowText(IntPtr h, StringBuilder s, int n);
  [DllImport("user32.dll", CharSet = CharSet.Unicode)] static extern int GetClassName(IntPtr h, StringBuilder s, int n);
  [DllImport("user32.dll")] static extern bool IsWindowVisible(IntPtr h);
  [DllImport("user32.dll")] static extern bool ShowWindow(IntPtr h, int c);
  [DllImport("user32.dll")] static extern bool SetForegroundWindow(IntPtr h);
  public static void Focar(string titulo) {
    IntPtr achado = IntPtr.Zero;
    EnumWindows(delegate(IntPtr h, IntPtr l) {
      if (!IsWindowVisible(h)) return true;
      StringBuilder t = new StringBuilder(256);
      GetWindowText(h, t, 256);
      if (!t.ToString().StartsWith(titulo)) return true;
      StringBuilder c = new StringBuilder(256);
      GetClassName(h, c, 256);
      if (c.ToString() != "Chrome_WidgetWin_1") return true;
      achado = h;
      return false;
    }, IntPtr.Zero);
    if (achado != IntPtr.Zero) { ShowWindow(achado, 9); SetForegroundWindow(achado); }
  }
}
'@
try { Add-Type -TypeDefinition $tipo; [ThBoostFoco]::Focar('Th Boost') } catch { }
Remove-Item -LiteralPath $env:T_ARQ -ErrorAction SilentlyContinue
"""


def _rodar_ps(roteiro, prefixo, extra_env, oculto=True):
    """Grava o roteiro numa pasta temporária e roda num PowerShell escondido. Devolve o processo (ou None)."""
    if not IS_WIN:
        return None
    arq = os.path.join(tempfile.gettempdir(), f"thboost_{prefixo}_{os.getpid()}.ps1")
    try:
        with open(arq, "w", encoding="utf-8-sig") as f:
            f.write(roteiro)
        ambiente = dict(os.environ, T_ARQ=arq, **extra_env)
        return subprocess.Popen(["powershell", "-NoProfile", "-NonInteractive", "-STA", "-WindowStyle", "Hidden",
                                 "-ExecutionPolicy", "Bypass", "-File", arq], env=ambiente,
                                creationflags=subprocess.CREATE_NO_WINDOW,
                                stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    except OSError:
        return None


VERSAO = "v9.6"
PORTA = 0
TOKEN = secrets.token_urlsafe(24)
TRAVA = threading.Lock()


def _contar_processos():
    try:
        return len(psutil.pids())
    except Exception:
        return None


class Nucleo(ExtremoMixin, JogosMixin, ManutencaoMixin, ProcessosMixin, FerramentasMixin, MemoriaMixin, CpuMixin,
             OverclockMixin, CpuPerfilMixin, MouseIdMixin, AtualizaMixin, AutotesteMixin, OverlayMixin, GraficoMixin):
    """Guarda tudo o que a interface mostra e executa as ações pedidas por ela."""

    def __init__(self):
        self.mon = Monitor()
        self.mon.start()
        self._fps_antes = None  # o que o Modo FPS On mudou (para devolver ao desligar)
        self._fps_sumiu = 0
        self.modo_fps = False  # v9.2: o Modo FPS On liga mesmo sem o contador de FPS
        self.contador_manual = False
        self.ov_iniciar_estado()
        self.historico = collections.deque(maxlen=40)
        self.contador_msg = 0
        self.serie = {k: collections.deque(maxlen=120) for k in ("cpu", "ram", "gpu", "down", "up")}
        self.amostra = {}
        self.ping_ms = None
        self.otim = {"ativo": False, "fracao": 0.0, "passo": "", "titulo": "", "passos": [], "fim": 0, "mb": 0.0}
        self.ext_iniciar_estado()
        self.gr_iniciar_estado()
        self.jogos_iniciar_estado()
        self.trab_iniciar_estado()
        self.proc_iniciar_estado()
        self.memoria_iniciar_estado()
        self.cpu_iniciar_estado()
        self.cpu_perfil_iniciar_estado()
        self.mouse_iniciar_estado()
        self.jogos = []
        self.procurando = False
        self.capas = {}
        self.fechando = False
        self.aj = {}
        self.mouse_vel = None
        self.ocioso = False          # janela fechada com o segundo plano ligado
        self.saindo = False          # encerrando de vez (avisa a bandeja para sumir)
        self.bandeja = None          # processo do ícone perto do relógio
        self.aberturas = 0           # quantas vezes a janela foi reaberta por pedido
        self._ultima_abertura = 0.0
        self.atualizar_aj()
        threading.Thread(target=self._vigiar_aj, daemon=True).start()
        psutil.cpu_percent(interval=None)  # primeira leitura serve só de base
        threading.Thread(target=self._amostrar, daemon=True).start()
        self.procurar_jogos()
        threading.Thread(target=self._vigiar_jogos, daemon=True).start()
        threading.Thread(target=self._vigiar_cpu, daemon=True).start()
        self.oc_iniciar_estado()
        self.atu_iniciar_estado()
        self.at_iniciar_estado()
        threading.Thread(target=self._retomar_depois, daemon=True).start()

    def _retomar_depois(self):
        time.sleep(4)  # deixa a lista de jogos e o resto carregarem
        try:
            self.sessao_retomar()
        except Exception:
            pass

    # ----- mensagens (viram avisos e histórico na tela) -----

    def msg(self, texto):
        if not texto:
            return
        with TRAVA:
            self.contador_msg += 1
            self.historico.appendleft({"id": self.contador_msg, "h": datetime.now().strftime("%H:%M"),
                                       "t": str(texto)})

    # ----- coleta de números a cada segundo -----

    def _amostrar(self):
        while not self.fechando:
            try:
                self._fps_conferir()
            except Exception:
                pass
            if self.ocioso:  # sem janela ninguém vê os números
                time.sleep(3.0)
                continue
            try:
                self._coletar()
            except Exception as erro:  # a coleta nunca pode derrubar o programa
                self.amostra["erro"] = str(erro)
            time.sleep(1.0)

    def _coletar(self):
        d = self.mon.dados
        g = d["gpu"] or {}
        cpu = psutil.cpu_percent(interval=None)
        mem = psutil.virtual_memory()
        vram = None
        if g.get("vram_total") and g.get("vram_usada") is not None:
            vram = g["vram_usada"] / g["vram_total"] * 100
        try:
            du = psutil.disk_usage(disco_sistema())
            disco = {"pct": du.percent, "livre": du.free / 1024 ** 3, "total": du.total / 1024 ** 3}
        except OSError:
            disco = None
        a = {
            "cpu": cpu, "nucleos": psutil.cpu_count() or 0,
            "ram": mem.percent, "ram_usada": mem.used / 1024 ** 3, "ram_total": mem.total / 1024 ** 3,
            "ram_livre": mem.available / 1024 ** 3,
            "gpu": d["gpu"], "gpu_lida": d["gpu_lida"], "gpu_uso": g.get("uso"), "vram": vram,
            "tcpu": temp_cpu(), "tgpu": g.get("temp"), "disco": disco,
            "down": d["down"], "up": d["up"], "nproc": _contar_processos(),
        }
        self.amostra = a
        self.serie["cpu"].append(round(cpu, 1))
        self.serie["ram"].append(round(mem.percent, 1))
        self.serie["gpu"].append(round(g.get("uso") or 0, 1))
        self.serie["down"].append(round(d["down"] / 1024, 1))
        self.serie["up"].append(round(d["up"] / 1024, 1))

    # ----- ajustes do Windows -----

    def atualizar_aj(self):
        try:
            self.aj = estados_ajustes()
            self.mouse_vel = velocidade_mouse()
        except Exception:
            pass

    def _vigiar_aj(self):
        while not self.fechando:
            time.sleep(4)
            if not self.ocioso:
                self.atualizar_aj()

    def t_aj(self, a, ligar):
        if a.precisa_admin and not e_admin():
            return "Este ajuste precisa de Administrador. Abra o Th Boost pelo atalho."
        try:
            a.ligar() if ligar else a.desligar()
        except OSError as erro:
            self.atualizar_aj()
            return f"{a.titulo}: não foi possível alterar ({erro})."
        self.atualizar_aj()
        if not ligar and getattr(a, "ausente_ligado", False) and a.estado() is True:
            return f"{a.titulo}: voltou ao padrão do Windows, que já é ligado."
        if a.estado() == bool(ligar):
            extra = f" {a.nota}" if (ligar and a.nota) else ""
            return f"{a.titulo}: {'ligado' if ligar else 'desfeito'}.{extra}"
        return f"{a.titulo}: comando enviado, mas o Windows ainda não confirmou. Confira em alguns segundos."

    def t_preset(self, grupo, modo):
        itens = [a for a in CATALOGO if a.grupo == grupo and a.disponivel()]
        if modo == "rec":
            alvo, ligar = [a for a in itens if a.rec and a.estado() is False], True
            if alvo:
                ponto_restauracao()
        else:  # o que já é o padrão do Windows quando o valor não existe (Modo de Jogo) não conta como "mexido"
            alvo, ligar = [a for a in itens if a.estado() is True and not (getattr(a, "ausente_ligado", False)
                                                                           and a.id not in _backup())], False
        if not e_admin():
            pulados = [a for a in alvo if a.precisa_admin]
            alvo = [a for a in alvo if not a.precisa_admin]
        else:
            pulados = []
        feitos, recusados = 0, []
        for a in alvo:
            try:
                a.ligar() if ligar else a.desligar()
            except OSError:
                pass
            try:
                certo = a.estado() == bool(ligar)  # v9.1: conta só o que o Windows confirmou
            except Exception:
                certo = False
            if certo:
                feitos += 1
            else:
                recusados.append(a)
        self.atualizar_aj()
        verbo = "aplicado(s)" if ligar else "restaurado(s) ao padrão"
        texto = (f"{feitos} ajuste(s) {verbo}." if feitos
                 else ("Tudo já estava assim." if not (pulados or recusados) else "Nada foi alterado."))
        if pulados:
            texto += f" {len(pulados)} precisa(m) de Administrador."
        if recusados:
            texto += (f" {len(recusados)} o Windows não aceitou: " + ", ".join(a.titulo for a in recusados[:3])
                      + ("..." if len(recusados) > 3 else "") + ".")
        return texto

    def t_debloat(self, pacotes):
        if not e_admin():
            return "Remover apps precisa de Administrador. Abra o Th Boost pelo atalho."
        ponto = ponto_restauracao()
        feitos = remover_apps(pacotes)
        return (f"{feitos} de {len(pacotes)} app(s) removido(s). Dá para reinstalar pela Microsoft Store."
                + ("" if ponto else " (O Windows não criou um ponto de restauração: a Proteção do Sistema pode estar desligada.)"))

    def lista(self, nome):
        if nome == "energia":
            planos = listar_planos()
            conhecidos = []
            for k, v in PLANOS_CONHECIDOS.items():
                p = plano_existente(k, planos)
                conhecidos.append({"chave": k, "nome": v[1], "existe": p is not None, "ativo": bool(p and p["ativo"])})
            ativo = next((p["nome"] for p in planos if p["ativo"]), "")
            return {"planos": planos, "conhecidos": conhecidos, "ativo": ativo}
        if nome == "dns":
            return dns_atual()
        if nome == "inicio":
            return {"itens": listar_inicio()}
        if nome == "apps":
            lista, erro = listar_apps_info()
            return {"apps": lista, "erro": erro}
        if nome == "autoteste":
            return {"texto": self.at_texto(), "estado": self.at["estado"]}
        if nome == "dashboard":
            return self.dashboard()
        if nome == "processos":
            return self.proc_lista()
        if nome == "svc3":
            return self.svc3_lista()
        if nome == "correcoes":
            return {"itens": correcoes_publico(), "links": links_publico(), "admin": e_admin()}
        if nome == "backup":
            return self.backup_lista()
        if nome == "programas":
            return self.programas_lista()
        if nome == "espaco":
            return self.espaco_publico()
        if nome == "atalhos":
            return {"itens": atalhos_publico()}
        if nome == "monitor":
            if self.monitor["estado"] in ("nenhum", "erro"):
                self.monitor_ler()
            return {"estado": self.monitor["estado"], "dados": self.monitor["dados"]}
        if nome == "perfis":
            return self.jogos_perfis()
        if nome == "memoria":
            return self.memoria_lista()
        if nome == "cpu_perfil":
            return self.cpu_perfil_lista()
        if nome == "mouse_info":
            return self.mouse_lista()
        raise ValueError("lista desconhecida")

    def catalogo(self):
        return {"ajustes": catalogo_publico(), "windows": REG is not None}

    def estado(self):
        d = self.mon.dados
        a = dict(self.amostra)
        with TRAVA:
            hist = list(self.historico)
        a.update({
            "versao": VERSAO, "admin": e_admin(), "win": IS_WIN, "usuario": USUARIO.title(),
            "nome": nome_da_pessoa(), "nome_fixo": bool(_nome_limpo(CONFIG.get("nome"))),
            "pasta": pasta_do_programa(), "presentmon": bool(caminho_presentmon()),
            "modo_leve": self.mon.modo_leve, "fps_ligado": self.mon.fps_ligado, "modo_fps": self.modo_fps,
            "contador_manual": self.contador_manual, "tema_tr": tema_tr(), "grafico": self.gr_estado(), "gargalo": self.mon.dados.get("gargalo"),
            "fps": d["fps"], "fps_app": d["app"], "fps_erro": d["fps_erro"], "fps1": d.get("fps1"), "fps_ms": d.get("fps_ms"),
            "ov": self.ov_snapshot(),
            "ping": self.ping_ms, "otim": self.otim, "ext": self.ext_snapshot(),
            "oc": self.oc_estado(),
            "jogos": {"procurando": self.procurando, "ocultos": len(CONFIG.get("jogos_ocultos") or []),
                      "lista": [{"i": i, "nome": j["nome"], "origem": j["origem"],
                                 "steam": bool(j.get("appid")), "pasta": bool(j.get("pasta")),
                                 "icone": bool(j.get("exe") and not j.get("appid")), "manual": bool(j.get("manual"))}
                                for i, j in enumerate(self.jogos)]},
            "pre": self.pre_snapshot(), "sessao": self.sessao_snapshot(), "trab": self.trab_snapshot(),
            "stats": dict(self.stats), "auto_jogo": bool(CONFIG.get("auto_jogo")),
            "hist": hist, "serie": {k: list(v) for k, v in self.serie.items()},
            "aj": self.aj, "mouse_vel": self.mouse_vel,
            "segundo_plano": CONFIG["segundo_plano"],
            "atu": self.atu_snapshot(), "at": self.at_snapshot(),
        })
        return a

    def _fps_voltar(self, texto):
        """Devolve o Modo Leve e o plano de energia de antes do Modo FPS On.
        Se uma sessão de jogo está rodando, ela continua com o que precisa e, quando terminar, devolve o que era de antes
        do Modo FPS On (v9.2: antes o Modo Leve podia ficar ligado para sempre)."""
        antes = self._fps_antes or {}
        self._fps_antes = None
        s = self.sessao
        if s and s.get("leve"):
            s["leve_antes"] = bool(antes.get("leve"))
        else:
            self.mon.modo_leve = bool(antes.get("leve"))
            self.mon.forcar = True
        if antes.get("plano") and s:
            if not s.get("plano_anterior"):
                s["plano_anterior"] = antes["plano"]
            self.msg(texto + " A sessão de jogo continua; quando ela terminar, tudo volta como era antes.")
        elif antes.get("plano"):
            self.em_fundo(lambda: texto + " " + plano_voltar(antes["plano"]))
        else:
            self.msg(texto)

    def _fps_conferir(self):
        """v9.2: o Modo FPS On não depende mais do contador; aqui só confere se a janelinha do FPS na tela fechou sozinha."""
        self.ov_conferir()
        self.gr_conferir()  # v9.4: troca o gráfico do jogo que estava esperando fechar

    def ocupado(self):
        """v9.1: o que ainda está rodando e não pode ser cortado ao fechar a janela ('' = nada)."""
        if self.atu.get("estado") in ("baixando", "instalando", "reiniciando"):
            return "atualização"
        if self.ov["on"]:
            return "FPS na tela"
        if self.sessao and (self.sessao.get("pasta") or self.sessao.get("pid")):
            return "sessão de jogo"  # só quando dá para saber que o jogo fechou; a sessão manual termina ao fechar a janela
        if self.otim["ativo"] or self.pre["ativo"]:
            return "otimização"
        if self.ext["ativo"]:
            return "otimização extrema"
        for k, t in self.trab.items():
            if t.get("ativo"):
                return {"correcao": "correção", "backup": "backup", "espaco": "análise de espaço"}.get(k, "tarefa")
        return ""

    # ----- tarefas em segundo plano -----

    def em_fundo(self, alvo, depois=None):
        def tarefa():
            try:
                resultado = alvo()
            except Exception as erro:
                resultado = f"Erro: {erro}"
            (depois or self.msg)(resultado)
        threading.Thread(target=tarefa, daemon=True).start()

    def _limpar_texto(self, grupo, sup=False):
        """Limpa um grupo (temp, nav, apps ou win). Devolve (texto, bytes liberados)."""
        r = limpar_grupo(grupo, parar=lambda: self.fechando, sup=sup)
        texto = f"{ROTULOS_GRUPO[grupo]}: ~{tam_texto(r['bytes'])} liberados."
        adm = sum(1 for p in r["pulados"] if p["motivo"] == "admin")
        if adm:
            texto += f" {adm} parte(s) precisam de Administrador."
        if any(p["motivo"] == "reinicio" for p in r["pulados"]):
            texto += " Atualizações do Windows mantidas: há um reinício pendente."
        return texto, r["bytes"]

    def t_temp(self):
        texto, b = self._limpar_texto("temp")
        self.estat_limpeza(b)
        return texto

    def t_limpar(self, grupo):
        texto, b = self._limpar_texto(grupo)
        self.estat_limpeza(b)
        return texto

    def t_limpar_tudo(self):
        total, partes = 0, []
        for g in ("temp", "nav", "apps", "win"):
            texto, b = self._limpar_texto(g)
            total += b
        self.estat_limpeza(total)
        ok, _ = esvaziar_lixeira()  # aqui a pessoa confirmou numa janela que fala da lixeira
        return f"Limpeza completa: ~{tam_texto(total)} liberados" + (" e a lixeira foi esvaziada." if ok else ".")

    def t_ram(self):
        return liberar_ram()[1]

    def t_plano(self):
        return plano_para_jogar()[0]

    def t_dns(self):
        cod, _ = executar(["ipconfig", "/flushdns"])
        return "Cache DNS limpo." if cod == 0 else "Não foi possível limpar o cache DNS."

    def t_lixeira(self):
        return esvaziar_lixeira()[1]

    def t_renovar_ip(self):
        if not IS_WIN:
            return "Disponível só no Windows."
        return "IP renovado." if renovar_ip() else "Não foi possível renovar o IP (abra como Administrador)."

    def t_ping(self):
        ms = medir_ping()
        if isinstance(ms, int):
            self.ping_ms = ms
            return f"Ping: {ms} ms"
        self.ping_ms = None
        return "Sem resposta ao testar o ping."

    # ----- otimização com passos -----

    def otimizar(self, titulo_fim="Otimização concluída"):
        if self.otim["ativo"] or self.ext["ativo"]:
            return self.msg("Já estou otimizando, aguarde.")
        passos = [("Limpando temporários", lambda: self._limpar_texto("temp")),
                  ("Limpando os navegadores", lambda: self._limpar_texto("nav")),
                  ("Limpando caches de programas", lambda: self._limpar_texto("apps")),
                  ("Limpeza do Windows", lambda: self._limpar_texto("win")),
                  ("Liberando a RAM", self.t_ram),
                  ("Plano de energia", self.t_plano),
                  ("Limpando o DNS", self.t_dns)]
        self.otim = {"ativo": True, "fracao": 0.04, "passo": "Começando...", "titulo": titulo_fim,
                     "passos": [{"nome": n, "estado": "pendente", "texto": "", "mb": 0.0} for n, _ in passos],
                     "fim": self.otim.get("fim", 0), "mb": 0.0}
        self.msg("Otimizando...")

        def tarefa():
            saidas, total = [], 0
            for i, (nome, funcao) in enumerate(passos):
                self.otim["passo"] = nome + "..."
                self.otim["fracao"] = max(0.04, i / len(passos))
                self.otim["passos"][i]["estado"] = "rodando"
                inicio = time.time()
                b = 0
                try:
                    r = funcao()
                    texto, b = r if isinstance(r, tuple) else (r, 0)
                    estado = "ok"
                except Exception as erro:
                    texto, estado = f"Erro: {erro}", "erro"
                # cada passo fica à vista por um instante, para dar para acompanhar na tela
                time.sleep(max(0.0, 0.6 - (time.time() - inicio)))
                saidas.append(texto)
                total += b
                self.otim["passos"][i].update({"estado": estado, "texto": texto, "mb": round(b / 1048576, 1)})
                self.otim["mb"] = round(total / 1048576, 1)
                self.otim["fracao"] = (i + 1) / len(passos)
            self.otim["passo"] = "Pronto para otimizar"
            self.otim["ativo"] = False
            self.otim["fim"] = self.otim.get("fim", 0) + 1
            self.estat_otimizacao(total / 1048576, "normal")
            self.msg(f"{titulo_fim}: ~{tam_texto(total)} de lixo apagados · " + " · ".join(saidas[-3:]))

        threading.Thread(target=tarefa, daemon=True).start()

    # ----- jogos -----

    def procurar_jogos(self):
        if self.procurando:
            return
        self.procurando = True

        def tarefa():
            try:
                lista = detectar_jogos()
            except Exception:
                lista = []
            self.capas = {}
            self.jogos = lista
            self.procurando = False

        threading.Thread(target=tarefa, daemon=True).start()

    def nome_definir(self, nome):
        """Troca o nome que aparece embaixo da logo. Vazio volta ao nome do usuário do Windows."""
        if nome is not None and not isinstance(nome, str):
            raise ValueError("nome inválido")
        limpo = _nome_limpo(nome)
        if limpo:
            CONFIG["nome"] = limpo
        else:
            CONFIG.pop("nome", None)
        salvar_config()
        self.msg(f"Pronto, agora é {nome_da_pessoa()}.")

    def t_jogo_adicionar(self):
        """Abre a janela do Windows para escolher o .exe de um jogo e põe na lista."""
        if getattr(self, "_escolhendo_jogo", False):
            return ""
        self._escolhendo_jogo = True
        try:
            self.msg("Escolha o programa do jogo (.exe) na janela que abriu.")
            exe = escolher_exe_do_jogo()
        finally:
            self._escolhendo_jogo = False
        if not exe:
            self.msg("Nenhum jogo escolhido.")
            return ""
        ok, texto = jogo_manual_adicionar(exe)
        self.msg(f"{texto} entrou na lista." if ok else texto)
        if ok:
            self.procurar_jogos()
        return ""

    def capa(self, i):
        """Caminho da imagem do jogo i (usa a da Steam no PC ou baixa uma vez). None se não houver."""
        if not (0 <= i < len(self.jogos)):
            return None
        if i not in self.capas:
            try:
                self.capas[i] = capa_do_jogo(self.jogos[i])
            except Exception:
                self.capas[i] = None
        return self.capas[i]

    def jogo(self, i):
        return self.jogos[i] if isinstance(i, int) and 0 <= i < len(self.jogos) else None

    # ----- ações vindas da interface -----

    def acao(self, dados):
        nome = dados.get("acao")
        if nome == "otimizar_tudo":
            self.otimizar()
        elif nome == "ram":
            self.msg("Liberando a RAM...")
            self.em_fundo(self.t_ram)
        elif nome == "plano":
            self.em_fundo(self.t_plano)
        elif nome == "dns":
            self.em_fundo(self.t_dns)
        elif nome == "temp":
            self.msg("Limpando temporários...")
            self.em_fundo(self.t_temp)
        elif nome == "lixeira":
            self.msg("Esvaziando a lixeira...")
            self.em_fundo(self.t_lixeira)
        elif nome == "renovar_ip":
            self.msg("Renovando IP...")
            self.em_fundo(self.t_renovar_ip)
        elif nome == "ping":
            self.em_fundo(self.t_ping)
        elif nome in ("limpar_nav", "limpar_apps", "limpar_win"):
            g = {"limpar_nav": "nav", "limpar_apps": "apps", "limpar_win": "win"}[nome]
            self.msg(f"Limpando: {ROTULOS_GRUPO[g].lower()}...")
            self.em_fundo(lambda: self.t_limpar(g))
        elif nome == "limpar_tudo":
            self.msg("Limpeza completa em andamento...")
            self.em_fundo(self.t_limpar_tudo)
        elif nome == "extremo":
            opc = dados.get("opcoes", {})
            if not isinstance(opc, dict) or any(
                    (v not in ("extrema", "suprema")) if k == "nivel" else (k not in ("dism", "apps", "busca", "winold") or not isinstance(v, bool))
                    for k, v in opc.items()):
                raise ValueError("opções inválidas")
            self.ext_iniciar(opc)
        elif nome == "extremo_parar":
            self.ext_parar()
        elif nome == "extremo_pular":
            self.ext_pular = True
        elif nome == "extremo_analisar":
            nivel = dados.get("nivel", "extrema")
            if nivel not in ("extrema", "suprema"):
                raise ValueError("nível inválido")
            self.ext_analisar(nivel)
        elif nome == "extremo_desfazer":
            self.ext_desfazer()
        elif nome == "reiniciar_pc":
            self.em_fundo(lambda: self.reiniciar_pc() or "")
        elif nome == "reiniciar_cancelar":
            self.em_fundo(lambda: self.reiniciar_cancelar() or "")
        elif nome == "limpeza_windows":
            if not IS_WIN:
                return self.msg("Disponível só no Windows.")
            try:
                subprocess.Popen(["cleanmgr.exe"])
                self.msg("Limpeza de disco do Windows aberta.")
            except OSError:
                self.msg("Não foi possível abrir a Limpeza de disco.")
        elif nome == "leve":
            self.mon.modo_leve = not self.mon.modo_leve
            self.mon.forcar = True
            self.msg("Modo Leve ligado." if self.mon.modo_leve else "Modo Leve desligado.")
        elif nome == "fps":  # v9.2: Modo FPS On = prioridade para o jogo + plano de desempenho (+ contador, se instalado)
            if not self.modo_fps:
                self.modo_fps = True
                if self._fps_antes is None:
                    self._fps_antes = {"leve": self.mon.modo_leve, "plano": None}
                self.mon.modo_leve = True
                self.mon.forcar = True
                self.fps_contador_ajusta()

                ref = self._fps_antes

                def plano():
                    texto, anterior, _ = plano_para_jogar()
                    if anterior and (not self.modo_fps or self._fps_antes is not ref):  # foi desligado enquanto o plano trocava
                        return "Modo FPS On desligado. " + plano_voltar(anterior)
                    if ref is not None and anterior:
                        ref["plano"] = anterior
                    extra = "" if caminho_presentmon() else " (Para ver o FPS, instale o contador na página FPS na tela.)"
                    gr = self.gr_aplicar() if self.modo_fps else ""  # v9.4: gráfico leve no Valorant, CS2 e Roblox
                    return "Modo FPS On ligado: o jogo tem prioridade. " + texto + (" " + gr if gr else "") + extra
                self.em_fundo(plano)
            else:
                self.modo_fps = False
                self.fps_contador_ajusta()
                self._fps_voltar("Modo FPS On desligado.")
                self.em_fundo(self.gr_voltar, lambda r: r and self.msg(r))  # v9.4: o gráfico dos jogos volta
        elif nome == "grafico_leve":  # v9.4: liga/desliga o gráfico leve junto do Modo FPS On
            liga = bool(dados.get("on"))
            if liga:
                CONFIG.pop("grafico_leve", None)
            else:
                CONFIG["grafico_leve"] = False
            salvar_config()
            if self.modo_fps:
                self.em_fundo(self.gr_aplicar if liga else self.gr_voltar, lambda r: r and self.msg(r))
        elif nome == "grafico_perfil":  # v9.5: "minimo" ou "proc" (processador fraco: a placa trabalha mais)
            perfil = dados.get("perfil")
            if perfil in GR_PERFIS and perfil != gr_perfil():
                if perfil == "proc":
                    CONFIG["grafico_perfil"] = "proc"
                else:
                    CONFIG.pop("grafico_perfil", None)
                salvar_config()
                if self.modo_fps and self.gr_ligado():
                    self.em_fundo(self.gr_aplicar, lambda r: r and self.msg(r))
        elif nome == "fps_contador":  # só o contador (botão do Monitor)
            self.contador_manual = not self.contador_manual
            if self.contador_manual and not caminho_presentmon():
                self.contador_manual = False
                return self.msg("Instale o contador de FPS na página FPS na tela (um clique).")
            self.fps_contador_ajusta()
        elif nome == "tema":  # v9.2: cor do painel (a tela já mudou na hora; aqui só guarda)
            v = tema_valida(dados.get("tr"))
            if v is not None and v != tema_tr():
                if v:
                    CONFIG["tema_tr"] = v
                else:
                    CONFIG.pop("tema_tr", None)
                salvar_config()
        elif nome == "overlay":
            self.ov_definir(dados.get("cfg") if isinstance(dados.get("cfg"), dict) else {})
        elif nome == "pm_instalar":
            self.pm_instalar()
        elif nome == "oc_nivel":
            self.oc_definir(dados.get("nivel"))
        elif nome == "oc_zerar":
            self.oc_definir(0)
        elif nome == "cpu_perfil":
            self.cpu_perfil_definir(dados.get("perfil"))
        elif nome == "mouse_ler":
            self.mouse_ler(True)
        elif nome == "mouse_manual":
            self.mouse_definir_manual(dados.get("marca"), dados.get("modelo"))
        elif nome == "mouse_foto_remover":
            self.mouse_foto_remover()
        elif nome == "mouse_buscar_foto":
            self.mouse_buscar_foto()
        elif nome == "mouse_perfil":
            ligar = dados.get("ligar")
            if not isinstance(ligar, bool):
                raise ValueError("pedido inválido")
            self.mouse_perfil(ligar)
        elif nome == "teclado_perfil":
            ligar = dados.get("ligar")
            if not isinstance(ligar, bool):
                raise ValueError("pedido inválido")
            self.teclado_perfil(ligar)
        elif nome in ("aj", "aj_preset", "energia", "dns_trocar", "rede_reset", "inicio", "debloat", "mouse_vel"):
            self.acao_ajuste(nome, dados)
        elif nome == "segundo_plano":
            ligar = dados.get("ligar")
            if not isinstance(ligar, bool):
                raise ValueError("pedido inválido")
            CONFIG["segundo_plano"] = ligar
            salvar_config()
            if ligar:
                self.iniciar_bandeja()
                self.msg("Segundo plano ligado: ao fechar a janela, o Th Boost continua rodando escondido.")
            else:
                self.msg("Segundo plano desligado: ao fechar a janela, o Th Boost encerra.")
        elif nome == "autoteste":
            self.at_rodar()
        elif nome in AT_ACOES:
            self.msg("Corrigindo...")
            self.em_fundo(pagefile_automatico)
        elif nome == "atu_procurar":
            threading.Thread(target=self.atu_procurar, daemon=True).start()
        elif nome == "atu_instalar":
            self.atu_instalar()
        elif nome == "atu_avisar":
            ligar = dados.get("ligar")
            if not isinstance(ligar, bool):
                raise ValueError("pedido inválido")
            CONFIG["avisar_atualizacao"] = ligar
            salvar_config()
            if ligar:
                threading.Thread(target=self.atu_procurar, daemon=True).start()
        elif nome == "abrir_janela":
            self.reabrir_janela()
        elif nome == "encerrar_tudo":
            self.msg("Encerrando o Th Boost...")
            self.saindo = True  # a bandeja percebe e some sozinha antes de o programa fechar
            threading.Timer(2.5, self.encerrar).start()
        elif nome == "jogos_procurar":
            self.procurar_jogos()
        elif nome == "jogo_otimizar":
            i = dados.get("i")
            if i is not None and (not isinstance(i, int) or isinstance(i, bool)):
                raise ValueError("jogo inválido")
            opc = dados.get("opcoes") or {}
            if not isinstance(opc, dict) or any(k not in PRE_PADRAO or not isinstance(v, bool) for k, v in opc.items()):
                raise ValueError("opções inválidas")
            self.pre_iniciar(i, opc)
        elif nome == "pre_opcoes":
            opc = dados.get("opcoes")
            if not isinstance(opc, dict) or any(k not in PRE_PADRAO or not isinstance(v, bool) for k, v in opc.items()):
                raise ValueError("opções inválidas")
            self.pre_definir_opcoes(opc)
        elif nome == "sessao_fim":
            self.em_fundo(lambda: self.sessao_fim("Sessão encerrada por você") or "")
        elif nome == "auto_jogo":
            ligar = dados.get("ligar")
            if not isinstance(ligar, bool):
                raise ValueError("pedido inválido")
            CONFIG["auto_jogo"] = ligar
            salvar_config()
            self.msg("Modo automático ligado: quando um jogo da lista abrir, o Th Boost otimiza sozinho e devolve tudo ao fechar."
                     if ligar else "Modo automático desligado.")
        elif nome == "jogos_desfazer_perfis":
            self.em_fundo(self.jogos_desfazer_perfis)
        elif nome == "monitor_ler":
            self.monitor_ler()
        elif nome == "memoria_ler":
            self.memoria_ler(True)
        elif nome == "memoria_bios":
            self.memoria_bios()
        elif nome == "memoria_bios_cancelar":
            self.memoria_bios_cancelar()
        elif nome == "trab_parar":
            chave = dados.get("chave")
            if not isinstance(chave, str) or chave not in self.trab:
                raise ValueError("pedido inválido")
            self.trab_parar(chave)
        elif nome == "correcao":
            ident = dados.get("id")
            if not isinstance(ident, str) or ident not in CORRECOES_POR_ID:
                raise ValueError("correção inválida")
            self.correcao_iniciar(ident)
        elif nome == "link":
            self.link_oficial(dados.get("id"))
        elif nome == "bk_config":
            self.bk_definir(dados.get("destino") if isinstance(dados.get("destino"), str) else "", dados.get("pastas"))
        elif nome == "bk_arquivos":
            self.backup_arquivos_iniciar()
        elif nome == "bk_restaurar":
            self.backup_restaurar_iniciar()
        elif nome == "bk_ponto":
            self.backup_ponto_iniciar()
        elif nome == "bk_protecao":
            self.backup_protecao_iniciar()
        elif nome == "bk_drivers":
            self.backup_drivers_iniciar()
        elif nome == "bk_ajustes":
            self.backup_ajustes_iniciar()
        elif nome == "bk_importar":
            self.backup_ajustes_importar(dados.get("nome"))
        elif nome == "bk_abrir":
            self.backup_abrir_pasta()
        elif nome == "proc_fechar":
            self.proc_fechar(dados.get("nome"))
        elif nome == "proc_reduzir":
            opc = dados.get("opcoes") or {}
            if not isinstance(opc, dict) or any(k not in ("raros", "svchost", "launchers", "chats") or not isinstance(v, bool) for k, v in opc.items()):
                raise ValueError("opções inválidas")
            self.proc_reduzir_iniciar(opc)
        elif nome == "proc_desfazer":
            self.em_fundo(self.t_proc_desfazer)
        elif nome == "cpu_limite":
            self.cpu_definir(dados.get("ligar"), dados.get("pct"))
        elif nome == "svc3":
            self.svc3_definir(dados.get("nome"), dados.get("manual"))
        elif nome == "programa_desinstalar":
            self.programa_desinstalar(dados.get("id"))
        elif nome == "atalho":
            self.atalho_abrir(dados.get("id"))
        elif nome == "espaco_iniciar":
            self.espaco_iniciar(dados.get("alvo"))
        elif nome == "espaco_mostrar":
            self.espaco_mostrar(dados.get("i"))
        elif nome == "nome_definir":
            self.nome_definir(dados.get("nome"))
        elif nome == "jogo_adicionar":
            self.em_fundo(self.t_jogo_adicionar)
        elif nome == "jogo_tirar":
            j = self.jogo(dados.get("i"))
            if not j:
                return
            jogo_tirar_da_lista(j)
            self.msg(f"{j['nome']} saiu da lista. Para trazer de volta, use \"Mostrar os que tirei\".")
            self.procurar_jogos()
        elif nome == "jogos_mostrar_ocultos":
            CONFIG["jogos_ocultos"] = []
            salvar_config()
            self.msg("Os jogos que você tirou voltaram para a lista.")
            self.procurar_jogos()
        elif nome == "jogo_abrir":
            j = self.jogo(dados.get("i"))
            if not j:
                return
            self.msg(f"Abrindo {j['nome']}..." if lancar_jogo(j["abrir"])
                     else f"Não foi possível abrir {j['nome']}.")
        else:
            raise ValueError("ação desconhecida")

    def acao_ajuste(self, nome, dados):
        """Ações das páginas de ajustes. Tudo que vem da tela é conferido aqui antes de mexer no Windows."""
        if REG is None:
            return self.msg("Os ajustes do Windows só funcionam no Windows.")
        if nome == "aj":
            a = POR_ID.get(dados.get("id"))
            ligar = dados.get("ligar")
            if a is None or not isinstance(ligar, bool):
                raise ValueError("ajuste inválido")
            self.em_fundo(lambda: self.t_aj(a, ligar))
        elif nome == "aj_preset":
            grupo, modo = dados.get("grupo"), dados.get("modo")
            if grupo not in {a.grupo for a in CATALOGO} or modo not in ("rec", "padrao"):
                raise ValueError("pedido inválido")
            self.msg("Aplicando os ajustes recomendados..." if modo == "rec" else "Restaurando o padrão do Windows...")
            self.em_fundo(lambda: self.t_preset(grupo, modo))
        elif nome == "energia":
            chave = dados.get("plano")
            if chave not in PLANOS_CONHECIDOS:
                raise ValueError("plano inválido")
            self.em_fundo(lambda: ativar_plano(chave))
        elif nome == "dns_trocar":
            modo = dados.get("modo")
            if modo not in ("auto", "google", "cloudflare", "antes"):
                raise ValueError("DNS inválido")
            self.msg("Trocando o DNS...")
            self.em_fundo(lambda: dns_trocar(modo))
        elif nome == "rede_reset":
            self.msg("Resetando a rede...")
            self.em_fundo(lambda: resetar_rede()[0])
        elif nome == "inicio":
            ident, ligar = dados.get("id"), dados.get("ligar")
            if not isinstance(ident, str) or not isinstance(ligar, bool):
                raise ValueError("pedido inválido")
            self.em_fundo(lambda: definir_inicio(ident, ligar))
        elif nome == "debloat":
            pacotes = dados.get("pacotes")
            if (not isinstance(pacotes, list) or not pacotes or len(pacotes) > 40
                    or any(not isinstance(p, str) or p not in APPS_POR_NOME for p in pacotes)):
                raise ValueError("lista de apps inválida")
            self.msg(f"Removendo {len(pacotes)} app(s)... pode levar um tempo.")
            self.em_fundo(lambda: self.t_debloat(pacotes))
        elif nome == "mouse_vel":
            v = dados.get("valor")
            if not isinstance(v, int) or isinstance(v, bool):
                raise ValueError("valor inválido")
            v = definir_velocidade_mouse(v)
            self.atualizar_aj()
            self.msg(f"Velocidade do ponteiro: {v}/20" + (" (padrão do Windows)." if v == 10 else "."))

    def ping(self):
        """Resposta curta para a bandeja e para quem abre o programa de novo."""
        return {"ok": True, "pid": os.getpid(), "bg": CONFIG["segundo_plano"] and not self.saindo,
                "janela": CLIENTES["abertos"] > 0, "aberturas": self.aberturas, "ocioso": self.ocioso,
                "bandeja": bool(self.bandeja and self.bandeja.poll() is None)}

    def reabrir_janela(self):
        """Pedido de quem abriu o Th Boost de novo (ou do ícone da bandeja)."""
        if CLIENTES["abertos"] > 0:  # já tem janela: só traz para a frente
            _rodar_ps(PS_FOCO, "foco", {})
            return
        if time.time() - self._ultima_abertura < 5:  # evita abrir duas por clique duplo
            return
        self._ultima_abertura = time.time()
        self.aberturas += 1
        if not os.environ.get("TOTIMIZE_SEM_JANELA"):
            abrir_janela(f"http://127.0.0.1:{PORTA}/")
            ajustar_icone_barra()

    def iniciar_bandeja(self):
        if not IS_WIN or (self.bandeja is not None and self.bandeja.poll() is None):
            return
        icone = os.path.join(pasta_do_programa(), "Th Boost.ico")
        if not os.path.isfile(icone):
            return
        base = f"http://127.0.0.1:{PORTA}"
        self.bandeja = _rodar_ps(PS_BANDEJA, "bandeja", {"T_ICONE": icone, "T_URL": f"{base}/api/acao?k={TOKEN}",
                                                         "T_PING": f"{base}/api/ping?k={TOKEN}"})

    def encerrar(self):
        """Devolve as prioridades ao normal, para o FPS e sai."""
        if self.fechando:
            return
        self.fechando = True
        apagar_instancia()
        try:
            self.sessao_fim("O Th Boost fechou")  # devolve plano de energia e serviços pausados durante um jogo
        except Exception:
            pass
        try:
            antes = self._fps_antes or {}
            if antes.get("plano"):
                plano_voltar(antes["plano"])  # o Modo FPS On tinha trocado o plano de energia
        except Exception:
            pass
        try:
            self.ov_fechar()  # some com o FPS na tela
        except Exception:
            pass
        self.gr_fechar()  # devolve o gráfico dos jogos (o que estiver aberto volta na próxima vez)
        self.cpu_fechar()  # solta o teto de CPU dos programas em segundo plano
        self.oc_fechar()  # devolve a placa de vídeo ao padrão, se o overclock estava ligado
        try:
            self.mon.ligar_fps(False)
            self.mon.aplicar_prioridades(False)
        except Exception:
            pass
        os._exit(0)


def plano_para_jogar():
    """v9.1: coloca um plano de energia de desempenho SEM desfazer escolhas da pessoa.
    Devolve (texto, guid do plano anterior para voltar depois ou None, estado 'ok'/'pulado'/'erro')."""
    if not IS_WIN:
        return "Só funciona no Windows.", None, "pulado"
    nivel = (CONFIG.get("cpu_perfil") or {}).get("nivel")
    if nivel and nivel != "padrao":
        return (f"Mantive o perfil de processador “{NOMES_CPU.get(nivel, nivel)}” que você escolheu "
                "(o plano de energia não foi trocado)."), None, "ok"
    try:
        bat = psutil.sensors_battery()
    except Exception:
        bat = None
    if bat is not None and not bat.power_plugged:
        return ("Notebook na bateria: mantive o plano de energia. Ligue na tomada para jogar com o desempenho "
                "máximo."), None, "pulado"
    planos = listar_planos()
    ativo = next((p for p in planos if p["ativo"]), None)
    if ativo and PLANO_BOM.search(ativo["nome"]):
        return f"O plano “{ativo['nome']}” já é de desempenho.", None, "ok"
    txt = ativar_plano("alto")
    if "ativado" in txt:
        return txt, (ativo["guid"] if ativo else PLANOS_CONHECIDOS["equilibrado"][0]), "ok"
    return txt, None, "erro"


def plano_voltar(guid):
    """Volta ao plano de antes (se ainda existir; senão, Equilibrado)."""
    planos = {p["guid"] for p in listar_planos()}
    alvo = guid if guid in planos else PLANOS_CONHECIDOS["equilibrado"][0]
    cod, _ = executar(["powercfg", "/setactive", alvo])
    return "Plano de energia de antes de volta." if cod == 0 else "Não consegui voltar o plano de energia de antes."


NUCLEO = None
HTML_PRONTO = ""
CLIENTES = {"abertos": 0, "ja_teve": False, "ultimo": time.time()}


class Manipulador(BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.1"

    def log_message(self, *args):
        pass

    def _host_ok(self):
        return self.headers.get("Host", "") in (f"127.0.0.1:{PORTA}", f"localhost:{PORTA}")

    def _token_ok(self, consulta):
        return secrets.compare_digest(consulta.get("k", [""])[0], TOKEN)

    def _responder(self, codigo, corpo, tipo="application/json", extra=None):
        if isinstance(corpo, (dict, list)):
            corpo = json.dumps(corpo, ensure_ascii=False)
        dados = corpo.encode("utf-8") if isinstance(corpo, str) else corpo
        self.send_response(codigo)
        self.send_header("Content-Type", tipo)
        self.send_header("Content-Length", str(len(dados)))
        self.send_header("Cache-Control", "no-store")
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header("X-Frame-Options", "DENY")
        for k, v in (extra or {}).items():
            self.send_header(k, v)
        self.end_headers()
        self.wfile.write(dados)

    def do_GET(self):
        if not self._host_ok():
            return self._responder(403, {"erro": "host"})
        url = urllib.parse.urlparse(self.path)
        consulta = urllib.parse.parse_qs(url.query)
        if url.path == "/":
            return self._responder(200, html_com_tema(HTML_PRONTO), "text/html; charset=utf-8", {
                "Content-Security-Policy": "default-src 'self'; img-src 'self' data:; style-src 'self' 'unsafe-inline'; "
                                           "script-src 'self' 'unsafe-inline'; connect-src 'self'; frame-ancestors 'none'"})
        if url.path == "/favicon.ico":
            return self._responder(204, b"", "image/x-icon")
        if not self._token_ok(consulta):
            return self._responder(403, {"erro": "token"})
        if url.path == "/api/estado":
            return self._responder(200, NUCLEO.estado())
        if url.path == "/api/fluxo":
            return self._fluxo()
        if url.path == "/api/ping":
            return self._responder(200, NUCLEO.ping())
        if url.path == "/api/overlay":  # v9.2: a janelinha do FPS na tela lê daqui
            NUCLEO.ov_atalho((consulta.get("hk") or [""])[0])
            return self._responder(200, NUCLEO.ov_dados())
        if url.path == "/api/catalogo":
            return self._responder(200, NUCLEO.catalogo())
        if url.path == "/api/lista":
            try:
                return self._responder(200, NUCLEO.lista(consulta.get("nome", [""])[0]))
            except ValueError:
                return self._responder(404, {"erro": "lista desconhecida"})
        if url.path == "/api/mouse_foto":  # a foto que a pessoa guardou para o mouse mostrado agora
            f = NUCLEO.mouse_foto_atual()
            if not f:
                return self._responder(404, b"", "image/png")
            return self._responder(200, f[0], f[1], {"Cache-Control": "no-store", "X-Content-Type-Options": "nosniff"})
        m = re.fullmatch(r"/capa/(\d+)", url.path)
        if m:
            caminho = NUCLEO.capa(int(m.group(1)))
            if not caminho or not os.path.isfile(caminho):
                return self._responder(404, b"", "image/jpeg")
            tipo = "image/png" if caminho.lower().endswith(".png") else "image/jpeg"
            with open(caminho, "rb") as f:
                return self._responder(200, f.read(), tipo, {"Cache-Control": "max-age=3600"})
        return self._responder(404, {"erro": "não encontrado"})

    def _fluxo(self):
        """Envia o estado a cada segundo. Enquanto a janela estiver aberta, esta conexão fica viva."""
        self.send_response(200)
        self.send_header("Content-Type", "text/event-stream")
        self.send_header("Cache-Control", "no-store")
        self.send_header("Connection", "keep-alive")
        self.end_headers()
        CLIENTES["abertos"] += 1
        CLIENTES["ja_teve"] = True
        try:
            while not NUCLEO.fechando:
                CLIENTES["ultimo"] = time.time()
                try:
                    corpo = json.dumps(NUCLEO.estado(), ensure_ascii=False)
                except (OSError, ValueError, TypeError, KeyError, AttributeError, RuntimeError):
                    time.sleep(1.0)  # v9.1: um erro passageiro ao montar o estado não derruba a tela
                    continue
                self.wfile.write(("data: " + corpo + "\n\n").encode("utf-8"))
                self.wfile.flush()
                time.sleep(1.0)
        except (OSError, ValueError):
            pass
        finally:
            CLIENTES["abertos"] -= 1
            CLIENTES["ultimo"] = time.time()
            self.close_connection = True

    def do_POST(self):
        if not self._host_ok():
            return self._responder(403, {"erro": "host"})
        url = urllib.parse.urlparse(self.path)
        consulta = urllib.parse.parse_qs(url.query)
        origem = self.headers.get("Origin")
        if origem and origem not in (f"http://127.0.0.1:{PORTA}", f"http://localhost:{PORTA}"):
            return self._responder(403, {"erro": "origem"})
        if url.path == "/api/mouse_foto" and self._token_ok(consulta):  # envio da foto (imagem pura, até 300 KB)
            try:
                n = int(self.headers.get("Content-Length", "0"))
            except ValueError:
                n = -1
            if not 0 < n <= FOTO_MAX:
                return self._responder(413, {"erro": "A foto é grande demais (máximo 300 KB) ou veio vazia."})
            erro = NUCLEO.mouse_foto_guardar(self.rfile.read(n))
            return self._responder(400 if erro else 200, {"erro": erro} if erro else {"ok": True})
        if not self._token_ok(consulta) or url.path != "/api/acao":
            return self._responder(403, {"erro": "token"})
        if "application/json" not in self.headers.get("Content-Type", ""):
            return self._responder(415, {"erro": "tipo"})
        try:
            n = int(self.headers.get("Content-Length", "0"))
            if n > 4096:
                return self._responder(413, {"erro": "grande"})
            dados = json.loads(self.rfile.read(n) or b"{}")
            NUCLEO.acao(dados if isinstance(dados, dict) else {})
        except (ValueError, KeyError, TypeError):
            return self._responder(400, {"erro": "pedido inválido"})
        except Exception:
            return self._responder(500, {"erro": "falhou"})
        return self._responder(200, {"ok": True, "estado": NUCLEO.estado()})


PORTA_PREFERIDA = 47813  # porta fixa: o navegador só lembra as preferências (efeitos, página) se a porta for sempre a mesma


class Servidor(ThreadingHTTPServer):
    daemon_threads = True
    allow_reuse_address = not IS_WIN  # no Windows isso deixaria dois programas usarem a mesma porta


# ---------------- janela do programa ----------------

def _navegadores():
    """Caminhos do Edge e do Chrome (o Edge já vem no Windows 10 e 11)."""
    pastas = [os.environ.get("ProgramFiles(x86)", r"C:\Program Files (x86)"),
              os.environ.get("ProgramFiles", r"C:\Program Files"),
              os.environ.get("LOCALAPPDATA", "")]
    relativos = [r"Microsoft\Edge\Application\msedge.exe", r"Google\Chrome\Application\chrome.exe"]
    achados = []
    for rel in relativos:
        for pasta in pastas:
            if pasta and os.path.isfile(os.path.join(pasta, rel)):
                achados.append(os.path.join(pasta, rel))
    for nome in ("msedge", "chrome", "google-chrome", "chromium"):
        caminho = shutil.which(nome)
        if caminho:
            achados.append(caminho)
    return achados


def abrir_janela(url):
    """Abre o painel como um aplicativo (janela própria, sem barra de endereço)."""
    perfil = os.path.join(pasta_do_programa(), "ui_perfil")
    for exe in _navegadores():
        try:
            subprocess.Popen([exe, f"--app={url}", f"--user-data-dir={perfil}", "--window-size=1280,800",
                              "--no-first-run", "--no-default-browser-check", "--disable-sync",
                              "--disable-features=Translate,msEdgeSidebar"],
                             creationflags=subprocess.CREATE_NO_WINDOW if IS_WIN else 0)
            return True
        except OSError:
            continue
    return webbrowser.open(url)


# ---------------- ícone do botão na barra de tarefas (Windows) ----------------

# Roda num PowerShell à parte: se algo falhar, o Th Boost segue normal (só fica o ícone do Edge).
PS_ICONE = r"""
$ErrorActionPreference = 'Stop'
$icone = $env:T_ICONE
$cmd = $env:T_CMD
$tipo = @'
using System;
using System.Text;
using System.Runtime.InteropServices;
public static class ThBoostIcone {
  [StructLayout(LayoutKind.Sequential, Pack = 4)]
  public struct PROPERTYKEY { public Guid fmtid; public uint pid; }
  [StructLayout(LayoutKind.Explicit)]
  public struct PROPVARIANT {
    [FieldOffset(0)] public ushort vt;
    [FieldOffset(8)] public IntPtr p;
    [FieldOffset(12)] public int pad;
  }
  [ComImport, Guid("886D8EEB-8CF2-4446-8D02-CDBA1DBDCF99"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
  public interface IPropertyStore {
    [PreserveSig] int GetCount(out uint c);
    [PreserveSig] int GetAt(uint i, out PROPERTYKEY k);
    [PreserveSig] int GetValue(ref PROPERTYKEY k, out PROPVARIANT v);
    [PreserveSig] int SetValue(ref PROPERTYKEY k, ref PROPVARIANT v);
    [PreserveSig] int Commit();
  }
  [DllImport("shell32.dll")]
  static extern int SHGetPropertyStoreForWindow(IntPtr hwnd, ref Guid riid, [MarshalAs(UnmanagedType.Interface)] out IPropertyStore ps);
  delegate bool EnumProc(IntPtr h, IntPtr l);
  [DllImport("user32.dll")] static extern bool EnumWindows(EnumProc f, IntPtr l);
  [DllImport("user32.dll", CharSet = CharSet.Unicode)] static extern int GetWindowText(IntPtr h, StringBuilder s, int n);
  [DllImport("user32.dll", CharSet = CharSet.Unicode)] static extern int GetClassName(IntPtr h, StringBuilder s, int n);
  [DllImport("user32.dll")] static extern bool IsWindowVisible(IntPtr h);

  public static IntPtr Achar(string titulo) {
    IntPtr achado = IntPtr.Zero;
    EnumWindows(delegate(IntPtr h, IntPtr l) {
      if (!IsWindowVisible(h)) return true;
      StringBuilder t = new StringBuilder(256);
      GetWindowText(h, t, 256);
      if (!t.ToString().StartsWith(titulo)) return true;
      StringBuilder c = new StringBuilder(256);
      GetClassName(h, c, 256);
      if (c.ToString() != "Chrome_WidgetWin_1") return true;
      achado = h;
      return false;
    }, IntPtr.Zero);
    return achado;
  }

  static void Texto(IPropertyStore ps, uint pid, string valor) {
    PROPERTYKEY k = new PROPERTYKEY();
    k.fmtid = new Guid("9F4C2855-9F79-4B39-A8D0-E1D42DE1D5F3");
    k.pid = pid;
    PROPVARIANT v = new PROPVARIANT();
    v.vt = 31;
    v.p = Marshal.StringToCoTaskMemUni(valor);
    int r = ps.SetValue(ref k, ref v);
    Marshal.FreeCoTaskMem(v.p);
    if (r != 0) throw new Exception("SetValue " + r.ToString("X"));
  }

  [DllImport("shell32.dll")] static extern void SHChangeNotify(int e, uint f, IntPtr a, IntPtr b);
  public static void Redesenhar() { SHChangeNotify(0x08000000, 0, IntPtr.Zero, IntPtr.Zero); }

  public static void Aplicar(IntPtr hwnd, string id, string icone, string comando, string nome) {
    Guid iid = new Guid("886D8EEB-8CF2-4446-8D02-CDBA1DBDCF99");
    IPropertyStore ps;
    int r = SHGetPropertyStoreForWindow(hwnd, ref iid, out ps);
    if (r != 0) throw new Exception("store " + r.ToString("X"));
    Texto(ps, 2, comando);
    Texto(ps, 3, icone + ",0");
    Texto(ps, 4, nome);
    Texto(ps, 5, id);
    ps.Commit();
  }
}
'@
try {
  Add-Type -TypeDefinition $tipo
  # v9.2: os atalhos do Th Boost (área de trabalho, menu Iniciar e fixados na barra) passam a usar o ícone novo.
  # O Windows guarda a imagem de cada caminho de ícone; trocando o caminho ele é obrigado a ler o ícone de novo
  # (por isso o logo vermelho antigo continuava aparecendo no que foi fixado).
  try {
    $pasta = $env:T_PASTA.TrimEnd('\')
    $sh = New-Object -ComObject WScript.Shell
    $lugares = @([Environment]::GetFolderPath('Desktop'), [Environment]::GetFolderPath('CommonDesktopDirectory'),
      [Environment]::GetFolderPath('StartMenu'), [Environment]::GetFolderPath('CommonStartMenu'),
      (Join-Path $env:APPDATA 'Microsoft\Internet Explorer\Quick Launch\User Pinned\TaskBar'),
      (Join-Path $env:APPDATA 'Microsoft\Internet Explorer\Quick Launch\User Pinned\StartMenu'))
    $mudou = $false
    foreach ($l in $lugares) {
      if (-not $l -or -not (Test-Path -LiteralPath $l)) { continue }
      foreach ($f in @(Get-ChildItem -LiteralPath $l -Filter '*.lnk' -Recurse -Depth 3 -ErrorAction SilentlyContinue)) {
        try {
          $a = $sh.CreateShortcut($f.FullName)
          $txt = ([string]$a.TargetPath) + ' ' + ([string]$a.Arguments)
          $nosso = $false
          foreach ($n in @('Abrir Th Boost.bat', 'Th Boost.exe')) {
            if ($txt.IndexOf((Join-Path $pasta $n), [StringComparison]::OrdinalIgnoreCase) -ge 0) { $nosso = $true }
          }
          if ($nosso -and $a.IconLocation -ne ($icone + ',0')) { $a.IconLocation = $icone + ',0'; $a.Save(); $mudou = $true }
        } catch { }
      }
    }
    if ($mudou) { [ThBoostIcone]::Redesenhar() }
  } catch { }
  for ($i = 0; $i -lt 45; $i++) {
    $h = [ThBoostIcone]::Achar('Th Boost')
    if ($h -ne [IntPtr]::Zero) {
      [ThBoostIcone]::Aplicar($h, 'ThBoost.Painel', $icone, $cmd, 'Th Boost')
      break
    }
    Start-Sleep -Milliseconds 700
  }
} catch { }
"""


def icone_estavel(pasta, destino=None):
    """v9.2: copia o "Th Boost.ico" para um arquivo com nome tirado do conteúdo (th_boost_<impressão>.ico).
    Ícone novo = caminho novo, e o Windows não consegue mostrar a imagem velha guardada. Devolve o caminho a usar."""
    icone = os.path.join(pasta, "Th Boost.ico")
    try:
        with open(icone, "rb") as f:
            dados = f.read(2 * 1024 * 1024)
        if dados[:4] != b"\x00\x00\x01\x00":
            return icone
        base = destino or os.path.join(os.environ.get("LOCALAPPDATA") or pasta, "ThBoost", "icones")
        os.makedirs(base, exist_ok=True)
        alvo = os.path.join(base, f"th_boost_{hashlib.sha256(dados).hexdigest()[:12]}.ico")
        if not os.path.isfile(alvo):
            tmp = alvo + ".tmp"
            with open(tmp, "wb") as f:
                f.write(dados)
            os.replace(tmp, alvo)
            for velho in glob.glob(os.path.join(base, "th_boost_*.ico")):  # os de versões antigas
                if os.path.normcase(velho) != os.path.normcase(alvo):
                    try:
                        os.remove(velho)
                    except OSError:
                        pass
        return alvo
    except OSError:
        return icone


def ajustar_icone_barra():
    """Faz o botão da barra de tarefas mostrar o ícone do Th Boost (e não o do Edge) e põe o ícone novo nos atalhos."""
    if not IS_WIN:
        return
    pasta = pasta_do_programa()
    if not os.path.isfile(os.path.join(pasta, "Th Boost.ico")):
        return
    icone = icone_estavel(pasta)
    bat = os.path.join(pasta, "Abrir Th Boost.bat")
    if os.path.isfile(bat):
        comando = f'"{bat}"'
    elif getattr(sys, "frozen", False):
        comando = f'"{sys.executable}"'
    else:
        comando = f'"{sys.executable}" "{os.path.abspath(__file__)}"'

    def tarefa():
        arq = os.path.join(tempfile.gettempdir(), f"thboost_icone_{os.getpid()}.ps1")
        try:
            with open(arq, "w", encoding="utf-8-sig") as f:
                f.write(PS_ICONE)
            ambiente = dict(os.environ, T_ICONE=icone, T_CMD=comando, T_PASTA=pasta)
            subprocess.run(["powershell", "-NoProfile", "-NonInteractive", "-ExecutionPolicy", "Bypass", "-File", arq],
                           env=ambiente, timeout=90, creationflags=subprocess.CREATE_NO_WINDOW,
                           stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        except Exception:
            pass
        finally:
            try:
                os.remove(arq)
            except OSError:
                pass

    threading.Thread(target=tarefa, daemon=True).start()


def esconder_console():
    """Se o programa foi aberto com uma janela preta própria (clique direto no .py), esconde essa janela.
    Quando foi aberto de dentro de um terminal que já existia, não mexe nele."""
    if not IS_WIN:
        return
    try:
        k32, u32 = ctypes.windll.kernel32, ctypes.windll.user32
        k32.GetConsoleWindow.restype = ctypes.c_void_p
        u32.ShowWindow.argtypes = [ctypes.c_void_p, ctypes.c_int]
        janela = k32.GetConsoleWindow()
        if not janela:
            return
        lista = (ctypes.c_uint * 8)()
        if k32.GetConsoleProcessList(lista, 8) <= 1:  # só este programa usa a janela preta
            u32.ShowWindow(janela, 0)
    except Exception:
        pass


def vigiar():
    """Fecha o programa quando a janela é fechada, a menos que o segundo plano esteja ligado."""
    inicio = time.time()
    while True:
        time.sleep(1.0)
        agora = time.time()
        if CLIENTES["abertos"] > 0:
            NUCLEO.ocioso = NUCLEO.mon.ocioso = False
            continue
        sem_janela = CLIENTES["ja_teve"] and agora - CLIENTES["ultimo"] > 3
        if CONFIG["segundo_plano"]:
            # fica rodando escondido: mantém o Modo Leve e as prioridades, sem gastar com números que ninguém vê
            NUCLEO.ocioso = NUCLEO.mon.ocioso = bool(sem_janela)
            continue
        if CLIENTES["ja_teve"] and agora - CLIENTES["ultimo"] > 6:
            ocupado = NUCLEO.ocupado()
            if ocupado:  # v9.1: janela fechada no meio de um trabalho ou de uma sessão de jogo: termina escondido antes de sair
                NUCLEO.ocioso = NUCLEO.mon.ocioso = True
                if not getattr(NUCLEO, "_avisou_fundo", False):
                    NUCLEO._avisou_fundo = True
                    NUCLEO.msg(f"Janela fechada: o Th Boost continua escondido até terminar ({ocupado}).")
                continue
            NUCLEO.encerrar()
        if not CLIENTES["ja_teve"] and agora - inicio > 60:  # a janela nem chegou a abrir
            NUCLEO.encerrar()


def principal():
    global NUCLEO, PORTA, HTML_PRONTO
    if "--overlay" in sys.argv[1:]:  # v9.2: a janelinha do FPS na tela (processo separado)
        a = sys.argv[1:]
        i = a.index("--overlay")
        if i + 2 < len(a) and a[i + 1].isdigit():
            sys.exit(overlay_principal(int(a[i + 1]), a[i + 2]) or 0)
        return
    if "--encerrar" in sys.argv[1:]:  # usado pelo "Encerrar Th Boost.bat": fecha o que está rodando em segundo plano
        inst = instancia_ativa() if USAR_INSTANCIA else None
        if inst:
            pedir_instancia(inst, "encerrar_tudo")
        return
    reinicio = "--reinicio" in sys.argv[1:]  # v9.0: aberto pela atualização; o antigo está fechando
    if USAR_INSTANCIA and not reinicio:  # já existe um Th Boost aberto (por exemplo em segundo plano): só abre a janela dele
        inst = instancia_ativa()
        if inst and pedir_instancia(inst, "abrir_janela"):
            return
    if IS_WIN:
        try:  # evita que o Windows borre o texto em telas de alta resolução
            ctypes.windll.shcore.SetProcessDpiAwareness(1)
        except (OSError, AttributeError):
            pass
    esconder_console()
    porta_fixa = int(os.environ.get("TOTIMIZE_PORTA", "0") or 0)
    servidor = None
    for _ in range(60 if reinicio else 1):  # depois de atualizar, espera o Th Boost antigo soltar a porta (até ~18 s)
        try:
            servidor = Servidor(("127.0.0.1", porta_fixa or PORTA_PREFERIDA), Manipulador)
            break
        except OSError:
            if reinicio:
                time.sleep(0.3)
    if servidor is None:  # porta ocupada (por exemplo, outro Th Boost aberto): usa qualquer outra livre
        servidor = Servidor(("127.0.0.1", 0), Manipulador)
    PORTA = servidor.server_address[1]
    HTML_PRONTO = HTML.replace("__TOKEN__", TOKEN)
    carregar_config()
    NUCLEO = Nucleo()
    threading.Thread(target=servidor.serve_forever, daemon=True).start()
    if reinicio and atu_de_argv():
        atu_avisar_que_abriu()  # v9.1: o vigia da atualização vê que a versão nova abriu e não desfaz nada
    if USAR_INSTANCIA:
        gravar_instancia()
    if CONFIG["segundo_plano"]:
        NUCLEO.iniciar_bandeja()
    url = f"http://127.0.0.1:{PORTA}/"
    if os.environ.get("TOTIMIZE_SEM_JANELA"):
        print("Th Boost em", url, "token", TOKEN, flush=True)
    elif reinicio and PORTA == (porta_fixa or PORTA_PREFERIDA):
        # a janela que estava aberta se recarrega sozinha; se em 15 s ninguém voltou, abre uma nova
        def janela_de_reserva():
            time.sleep(15)
            if not CLIENTES["ja_teve"]:
                NUCLEO.reabrir_janela()
        threading.Thread(target=janela_de_reserva, daemon=True).start()
        ajustar_icone_barra()
    else:
        abrir_janela(url)
        ajustar_icone_barra()
    try:
        vigiar()
    except KeyboardInterrupt:
        NUCLEO.encerrar()


HTML = r"""<!doctype html>
<html lang="pt-BR">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<meta name="theme-color" content="#070a0c">
<title>Th Boost</title>
<link rel="icon" href="data:image/svg+xml,%3Csvg%20xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22%20viewBox%3D%220%200%20100%20100%22%3E%3Cdefs%3E%0A%3CradialGradient%20id%3D%22gFi%22%20cx%3D%22.5%22%20cy%3D%22.42%22%20r%3D%22.66%22%3E%3Cstop%20offset%3D%220%22%20stop-color%3D%22%230d2c60%22%2F%3E%3Cstop%20offset%3D%22.6%22%20stop-color%3D%22%23050f25%22%2F%3E%3Cstop%20offset%3D%221%22%20stop-color%3D%22%2301040a%22%2F%3E%3C%2FradialGradient%3E%0A%3ClinearGradient%20id%3D%22gAi%22%20x1%3D%220%22%20y1%3D%220%22%20x2%3D%221%22%20y2%3D%221%22%3E%3Cstop%20offset%3D%220%22%20stop-color%3D%22%23c2e6ff%22%2F%3E%3Cstop%20offset%3D%22.45%22%20stop-color%3D%22%232f8cff%22%2F%3E%3Cstop%20offset%3D%221%22%20stop-color%3D%22%230a3a9c%22%2F%3E%3C%2FlinearGradient%3E%0A%3ClinearGradient%20id%3D%22gS1i%22%20x1%3D%221%22%20y1%3D%220%22%20x2%3D%220%22%20y2%3D%221%22%3E%3Cstop%20offset%3D%220%22%20stop-color%3D%22%23ffffff%22%20stop-opacity%3D%220%22%2F%3E%3Cstop%20offset%3D%22.12%22%20stop-color%3D%22%23ffffff%22%2F%3E%3Cstop%20offset%3D%22.55%22%20stop-color%3D%22%236cc0ff%22%2F%3E%3Cstop%20offset%3D%221%22%20stop-color%3D%22%232f8cff%22%20stop-opacity%3D%220%22%2F%3E%3C%2FlinearGradient%3E%0A%3ClinearGradient%20id%3D%22gS2i%22%20x1%3D%220%22%20y1%3D%221%22%20x2%3D%221%22%20y2%3D%220%22%3E%3Cstop%20offset%3D%220%22%20stop-color%3D%22%23ffffff%22%20stop-opacity%3D%220%22%2F%3E%3Cstop%20offset%3D%22.12%22%20stop-color%3D%22%23ffffff%22%2F%3E%3Cstop%20offset%3D%22.55%22%20stop-color%3D%22%236cc0ff%22%2F%3E%3Cstop%20offset%3D%221%22%20stop-color%3D%22%232f8cff%22%20stop-opacity%3D%220%22%2F%3E%3C%2FlinearGradient%3E%0A%3ClinearGradient%20id%3D%22gTi%22%20x1%3D%220%22%20y1%3D%220%22%20x2%3D%220%22%20y2%3D%221%22%3E%3Cstop%20offset%3D%220%22%20stop-color%3D%22%23394152%22%2F%3E%3Cstop%20offset%3D%22.22%22%20stop-color%3D%22%2310141d%22%2F%3E%3Cstop%20offset%3D%22.6%22%20stop-color%3D%22%2305070c%22%2F%3E%3Cstop%20offset%3D%221%22%20stop-color%3D%22%23000000%22%2F%3E%3C%2FlinearGradient%3E%0A%3Cfilter%20id%3D%22fBi%22%20x%3D%22-40%25%22%20y%3D%22-40%25%22%20width%3D%22180%25%22%20height%3D%22180%25%22%3E%3CfeGaussianBlur%20stdDeviation%3D%222.4%22%2F%3E%3C%2Ffilter%3E%0A%3C%2Fdefs%3E%3Ccircle%20cx%3D%2250%22%20cy%3D%2250%22%20r%3D%2246%22%20fill%3D%22url%28%23gFi%29%22%2F%3E%3Ccircle%20cx%3D%2250%22%20cy%3D%2250%22%20r%3D%2243%22%20fill%3D%22none%22%20stroke%3D%22%230a2a66%22%20stroke-width%3D%223%22%2F%3E%3Ccircle%20cx%3D%2250%22%20cy%3D%2250%22%20r%3D%2243%22%20fill%3D%22none%22%20stroke%3D%22%233b9bff%22%20stroke-width%3D%221.4%22%20opacity%3D%22.85%22%2F%3E%3Cg%3E%3Ccircle%20cx%3D%2250%22%20cy%3D%2250%22%20r%3D%2243%22%20fill%3D%22none%22%20stroke%3D%22%232f8cff%22%20stroke-width%3D%228%22%20stroke-linecap%3D%22round%22%20stroke-dasharray%3D%2278%20193%22%20filter%3D%22url%28%23fBi%29%22%20opacity%3D%22.9%22%2F%3E%3Ccircle%20cx%3D%2250%22%20cy%3D%2250%22%20r%3D%2243%22%20fill%3D%22none%22%20stroke%3D%22url%28%23gAi%29%22%20stroke-width%3D%223.6%22%20stroke-linecap%3D%22round%22%20stroke-dasharray%3D%2278%20193%22%2F%3E%3C%2Fg%3E%3Cg%3E%3Ccircle%20cx%3D%2250%22%20cy%3D%2250%22%20r%3D%2235%22%20fill%3D%22none%22%20stroke%3D%22%23bfe3ff%22%20stroke-width%3D%221.8%22%20stroke-linecap%3D%22round%22%20stroke-dasharray%3D%2222%20198%22%2F%3E%3C%2Fg%3E%3Cpath%20d%3D%22M95%205%20L47%2040%20L50.5%2044.5Z%22%20fill%3D%22url%28%23gS1i%29%22%2F%3E%3Cpath%20d%3D%22M5%2095%20L53%2060%20L49.5%2055.5Z%22%20fill%3D%22url%28%23gS2i%29%22%2F%3E%3Cg%20transform%3D%22translate%2846%2046%29%20scale%280.88%29%20translate%28-50%20-50%29%22%3E%3Cg%20transform%3D%22translate%2850%2050%29%20skewX%28-11%29%20translate%28-50%20-50%29%22%3E%3Cpath%20d%3D%22M17%2027H83L80.6%2041H57.5V75H42.5V41H14.6Z%22%20fill%3D%22none%22%20stroke%3D%22%232f8cff%22%20stroke-width%3D%226%22%20stroke-linejoin%3D%22round%22%20filter%3D%22url%28%23fBi%29%22%20opacity%3D%22.55%22%20transform%3D%22translate%284%205%29%22%2F%3E%3Cpath%20d%3D%22M17%2027H83L80.6%2041H57.5V75H42.5V41H14.6Z%22%20transform%3D%22translate%288.0%209.0%29%22%20fill%3D%22%2305162f%22%20stroke%3D%22%2305162f%22%20stroke-width%3D%221.4%22%20stroke-linejoin%3D%22round%22%2F%3E%3Cpath%20d%3D%22M17%2027H83L80.6%2041H57.5V75H42.5V41H14.6Z%22%20transform%3D%22translate%287.2%208.1%29%22%20fill%3D%22%2308224b%22%20stroke%3D%22%2308224b%22%20stroke-width%3D%221.4%22%20stroke-linejoin%3D%22round%22%2F%3E%3Cpath%20d%3D%22M17%2027H83L80.6%2041H57.5V75H42.5V41H14.6Z%22%20transform%3D%22translate%286.4%207.2%29%22%20fill%3D%22%230d3066%22%20stroke%3D%22%230d3066%22%20stroke-width%3D%221.4%22%20stroke-linejoin%3D%22round%22%2F%3E%3Cpath%20d%3D%22M17%2027H83L80.6%2041H57.5V75H42.5V41H14.6Z%22%20transform%3D%22translate%285.6%206.3%29%22%20fill%3D%22%23123f82%22%20stroke%3D%22%23123f82%22%20stroke-width%3D%221.4%22%20stroke-linejoin%3D%22round%22%2F%3E%3Cpath%20d%3D%22M17%2027H83L80.6%2041H57.5V75H42.5V41H14.6Z%22%20transform%3D%22translate%284.8%205.4%29%22%20fill%3D%22%23184f9f%22%20stroke%3D%22%23184f9f%22%20stroke-width%3D%221.4%22%20stroke-linejoin%3D%22round%22%2F%3E%3Cpath%20d%3D%22M17%2027H83L80.6%2041H57.5V75H42.5V41H14.6Z%22%20transform%3D%22translate%284.0%204.5%29%22%20fill%3D%22%231e5fbb%22%20stroke%3D%22%231e5fbb%22%20stroke-width%3D%221.4%22%20stroke-linejoin%3D%22round%22%2F%3E%3Cpath%20d%3D%22M17%2027H83L80.6%2041H57.5V75H42.5V41H14.6Z%22%20transform%3D%22translate%283.2%203.6%29%22%20fill%3D%22%23256ed2%22%20stroke%3D%22%23256ed2%22%20stroke-width%3D%221.4%22%20stroke-linejoin%3D%22round%22%2F%3E%3Cpath%20d%3D%22M17%2027H83L80.6%2041H57.5V75H42.5V41H14.6Z%22%20transform%3D%22translate%282.4%202.7%29%22%20fill%3D%22%232c7ce6%22%20stroke%3D%22%232c7ce6%22%20stroke-width%3D%221.4%22%20stroke-linejoin%3D%22round%22%2F%3E%3Cpath%20d%3D%22M17%2027H83L80.6%2041H57.5V75H42.5V41H14.6Z%22%20transform%3D%22translate%281.6%201.8%29%22%20fill%3D%22%23348cf6%22%20stroke%3D%22%23348cf6%22%20stroke-width%3D%221.4%22%20stroke-linejoin%3D%22round%22%2F%3E%3Cpath%20d%3D%22M17%2027H83L80.6%2041H57.5V75H42.5V41H14.6Z%22%20transform%3D%22translate%280.8%200.9%29%22%20fill%3D%22%233c9bff%22%20stroke%3D%22%233c9bff%22%20stroke-width%3D%221.4%22%20stroke-linejoin%3D%22round%22%2F%3E%3Cpath%20d%3D%22M17%2027H83L80.6%2041H57.5V75H42.5V41H14.6Z%22%20fill%3D%22url%28%23gTi%29%22%20stroke%3D%22%2358b8ff%22%20stroke-width%3D%221.7%22%20stroke-linejoin%3D%22round%22%2F%3E%3Cpath%20d%3D%22M19.5%2029.1H80.5%22%20stroke%3D%22%23d3ecff%22%20stroke-width%3D%221.3%22%20stroke-linecap%3D%22round%22%20opacity%3D%22.9%22%2F%3E%3Cpath%20d%3D%22M45%2045V72%22%20stroke%3D%22%2358b8ff%22%20stroke-width%3D%221%22%20stroke-linecap%3D%22round%22%20opacity%3D%22.55%22%2F%3E%3C%2Fg%3E%3C%2Fg%3E%3C%2Fsvg%3E">
<script>
/* v9.2: cor do painel. As cores azuis do CSS giram com a variável --tr (graus, no OKLCH); tom() faz o mesmo nas cores
   usadas em gráficos e partículas (o canvas não entende variáveis do CSS). */
var TEMA_TR=0;try{TEMA_TR=parseInt(document.documentElement.style.getPropertyValue('--tr'))||0}catch(e){}
/* v9.6: no tom escolhido as cores ficam tão fortes quanto a tela deixa (o vermelho não fica mais "clarinho") */
function temaTc(tr){tr=+tr||0;if(!tr)return 1;var mx=function(L,h){var lo=0,hi=.4;for(var i=0;i<22;i++){var c=(lo+hi)/2,a=c*Math.cos(h),b=c*Math.sin(h),l=Math.pow(L+.3963377774*a+.2158037573*b,3),m=Math.pow(L-.1055613458*a-.0638541728*b,3),s=Math.pow(L-.0894841775*a-1.291485548*b,3),R=4.0767416621*l-3.3077115913*m+.2309699292*s,G=-1.2684380046*l+2.6097574011*m-.3413193965*s,B=-.0041960863*l-.7034186147*m+1.707614701*s;if(R>=-1e-6&&R<=1+1e-6&&G>=-1e-6&&G<=1+1e-6&&B>=-1e-6&&B<=1+1e-6)lo=c;else hi=c}return lo};
 var h0=256.9*Math.PI/180,r=mx(.638,h0+tr*Math.PI/180)/mx(.638,h0);return Math.round(Math.max(1,Math.min(1.4,r))*1000)/1000}
var TEMA_TC=temaTc(TEMA_TR);
function tom(h){if(!TEMA_TR||typeof h!=='string'||!/^#[0-9a-f]{6}$/i.test(h))return h;
 var f=function(c){c/=255;return c<=0.04045?c/12.92:Math.pow((c+0.055)/1.055,2.4)},r=f(parseInt(h.slice(1,3),16)),g=f(parseInt(h.slice(3,5),16)),b=f(parseInt(h.slice(5,7),16));
 var l=Math.cbrt(0.4122214708*r+0.5363325363*g+0.0514459929*b),m=Math.cbrt(0.2119034982*r+0.6806995451*g+0.1073969566*b),s=Math.cbrt(0.0883024619*r+0.2817188376*g+0.6299787005*b);
 var L=0.2104542553*l+0.7936177850*m-0.0040720468*s,A=1.9779984951*l-2.4285922050*m+0.4505937099*s,B=0.0259040371*l+0.7827717662*m-0.8086757660*s;
 var C=Math.hypot(A,B)*TEMA_TC,H=Math.atan2(B,A)+TEMA_TR*Math.PI/180,a=C*Math.cos(H),bb=C*Math.sin(H);
 var l3=Math.pow(L+0.3963377774*a+0.2158037573*bb,3),m3=Math.pow(L-0.1055613458*a-0.0638541728*bb,3),s3=Math.pow(L-0.0894841775*a-1.2914855480*bb,3);
 var g2=function(c){c=Math.min(1,Math.max(0,c));c=c<=0.0031308?c*12.92:1.055*Math.pow(c,1/2.4)-0.055;return ('0'+Math.round(c*255).toString(16)).slice(-2)};
 return '#'+g2(4.0767416621*l3-3.3077115913*m3+0.2309699292*s3)+g2(-1.2684380046*l3+2.6097574011*m3-0.3413193965*s3)+g2(-0.0041960863*l3-0.7034186147*m3+1.7076147010*s3)}
/* modo leve: aplicado antes da primeira pintura (1 = ligado, 0 = desligado, a = ligado sozinho) */
(function(){try{var v=localStorage.getItem('thboost-leve'),n=navigator,fraco=(n.hardwareConcurrency||8)<=4||(n.deviceMemory||8)<=4||(matchMedia&&matchMedia('(prefers-reduced-motion:reduce)').matches);if(v==='1'||v==='a'||(v===null&&fraco))document.documentElement.classList.add('leve')}catch(e){}})()
</script>
<style>
@property --led{syntax:'<angle>';initial-value:0deg;inherits:false}
:root{--tr:0deg;--tc:1;--bg:#06090b;--p:#0d1115;--p2:#12161c;--l:#1f252d;--l2:#2a323c;--t:#f4f7fa;--m:#8b97a5;--r:oklch(0.6381 calc(0.1873 * var(--tc)) calc(256.90deg + var(--tr)));--r2:oklch(0.4982 calc(0.1704 * var(--tc)) calc(257.85deg + var(--tr)));--r3:oklch(0.7066 calc(0.1488 * var(--tc)) calc(255.58deg + var(--tr)));--g:#22c55e;--b:oklch(0.6441 calc(0.1768 * var(--tc)) calc(256.55deg + var(--tr)));--a:#f59e0b;--v:oklch(0.7406 calc(0.1286 * var(--tc)) calc(244.09deg + var(--tr)));--ease:cubic-bezier(.2,.8,.2,1)}
*{box-sizing:border-box}
html,body{height:100%;margin:0}
body{background:var(--bg);color:var(--t);font-family:"Segoe UI",system-ui,-apple-system,Roboto,Inter,sans-serif;font-size:14px;overflow:hidden;user-select:none;-webkit-user-select:none}
button{font:inherit;color:inherit;cursor:pointer}
svg{display:block}
.ico{width:20px;height:20px;fill:none;stroke:currentColor;stroke-width:1.8;stroke-linecap:round;stroke-linejoin:round;flex:none}
::-webkit-scrollbar{width:10px;height:10px}::-webkit-scrollbar-thumb{background:#2a323c;border-radius:10px;border:2px solid var(--bg)}::-webkit-scrollbar-thumb:hover{background:var(--r2)}::-webkit-scrollbar-track{background:transparent}

/* fundo */
#fundo{position:fixed;inset:0;z-index:0;background:radial-gradient(900px 520px at 92% -8%,oklch(0.6381 calc(0.1873 * var(--tc)) calc(256.90deg + var(--tr)) / .20),transparent 62%),radial-gradient(760px 480px at -6% 108%,oklch(0.4982 calc(0.1704 * var(--tc)) calc(257.85deg + var(--tr)) / .18),transparent 62%),radial-gradient(500px 360px at 55% 40%,oklch(0.7066 calc(0.1488 * var(--tc)) calc(255.58deg + var(--tr)) / .05),transparent 70%),var(--bg)}
#fundo::after{content:"";position:absolute;inset:0;background:repeating-linear-gradient(90deg,rgba(255,255,255,.018) 0 1px,transparent 1px 96px),repeating-linear-gradient(0deg,rgba(255,255,255,.014) 0 1px,transparent 1px 96px);-webkit-mask:radial-gradient(70% 70% at 60% 30%,#000000,transparent);mask:radial-gradient(70% 70% at 60% 30%,#000000,transparent)}
.app{position:relative;z-index:1;display:grid;grid-template-columns:76px 1fr;height:100vh}

/* menu lateral */
.nv{position:relative;display:flex;flex-direction:column;padding:18px 12px 14px;background:linear-gradient(180deg,rgba(10,14,18,.92),rgba(8,11,13,.96));border-right:1px solid #1a1519;overflow:auto}
.marca{display:flex;align-items:center;gap:12px;padding:2px 8px 18px}
.emb{width:46px;height:46px;position:relative;flex:none}
.emb svg{width:100%;height:100%;overflow:visible}
.emb .orb{transform-origin:50% 50%;animation:gira 5s linear infinite}
.emb .orb2{transform-origin:50% 50%;animation:gira 3.2s linear infinite reverse}
@keyframes gira{to{transform:rotate(360deg)}}
.marca b{display:block;font-size:21px;letter-spacing:.02em;font-weight:900}
.marca b i{font-style:normal;color:var(--r)}
.marca small{color:var(--m);font-size:11px}
.gp{display:flex;align-items:center;gap:8px;margin:14px 10px 6px;font-size:10.5px;font-weight:800;letter-spacing:.16em;color:#616d7d}
.gp::before{content:"";width:6px;height:6px;border-radius:50%;background:var(--r);box-shadow:0 0 10px var(--r)}
.gp::after{content:"";flex:1;height:1px;background:linear-gradient(90deg,#222c3a,transparent)}
.itens{display:flex;flex-direction:column;gap:3px}
.pilula{position:absolute;left:0;right:0;top:0;height:46px;border-radius:13px;background:linear-gradient(135deg,oklch(0.6588 calc(0.1751 * var(--tc)) calc(256.28deg + var(--tr))),oklch(0.4982 calc(0.1704 * var(--tc)) calc(257.85deg + var(--tr))) 70%,oklch(0.3991 calc(0.1348 * var(--tc)) calc(257.87deg + var(--tr))));box-shadow:0 10px 26px -10px oklch(0.6381 calc(0.1873 * var(--tc)) calc(256.90deg + var(--tr)) / .85),inset 0 1px 0 rgba(255,255,255,.28);transition:transform .45s var(--ease);z-index:0;overflow:hidden}
.pilula::after{content:"";position:absolute;inset:0;background:linear-gradient(110deg,transparent 34%,rgba(255,255,255,.4) 50%,transparent 66%) no-repeat;background-size:250% 100%;background-position:150% 0;animation:reflexo 4.2s ease-in-out infinite;will-change:transform}
@keyframes reflexo{0%{background-position:150% 0}55%,100%{background-position:-50% 0}}
.it{position:relative;z-index:1;display:flex;align-items:center;gap:12px;height:46px;padding:0 12px;border:0;border-radius:13px;background:transparent;color:#a9b3c0;font-weight:600;text-align:left;transition:color .2s,background .2s,transform .2s var(--ease)}
.it .tl{width:30px;height:30px;border-radius:9px;display:grid;place-items:center;background:#171c22;border:1px solid #232b34;transition:background .25s,border-color .25s,transform .25s var(--ease)}
.it:hover{color:#ffffff;background:rgba(255,255,255,.04);transform:translateX(2px)}
.it:hover .tl{border-color:oklch(0.3363 calc(0.0370 * var(--tc)) calc(254.96deg + var(--tr)));background:#141920}
.it:hover .ico{animation:vibra .5s ease-in-out}
@keyframes vibra{0%,100%{rotate:0deg}20%{rotate:-14deg}45%{rotate:12deg}70%{rotate:-8deg}}
.it.on{color:#ffffff}.it.on .tl{background:rgba(255,255,255,.16);border-color:rgba(255,255,255,.28)}
.nv .fim{margin-top:auto;padding:14px 8px 0;display:grid;gap:10px}
.adm{display:flex;align-items:center;gap:9px;padding:10px 12px;border-radius:12px;background:#10141a;border:1px solid #1d232b;font-size:12px;font-weight:700}
.adm i{width:8px;height:8px;border-radius:50%;background:var(--g);box-shadow:0 0 0 0 rgba(34,197,94,.6);animation:pulsa 2.4s ease-out infinite;flex:none}
.adm.no i{background:var(--a);animation:none}
.adm small{display:block;color:var(--m);font-weight:500;font-size:11px;margin-top:1px}
@keyframes pulsa{70%{box-shadow:0 0 0 7px rgba(34,197,94,0)}100%{box-shadow:0 0 0 0 rgba(34,197,94,0)}}
.ver{color:#4b5460;font-size:11px;text-align:center}

/* topo */
.main{display:flex;flex-direction:column;min-width:0;height:100vh}
.topo{display:flex;align-items:flex-end;justify-content:space-between;gap:10px 16px;flex-wrap:wrap;padding:22px 32px 14px}
.topo>div:first-child{min-width:0}
.topo h1{margin:0;font-size:30px;font-weight:800;letter-spacing:-.01em;background:linear-gradient(90deg,#ffffff,oklch(0.9176 calc(0.0392 * var(--tc)) calc(253.01deg + var(--tr))) 70%,oklch(0.7917 calc(0.1020 * var(--tc)) calc(255.59deg + var(--tr))));-webkit-background-clip:text;background-clip:text;color:transparent}
.topo .sub{color:var(--m);font-size:13px;margin-top:2px}
.topo .dir{display:flex;align-items:center;gap:12px}
.relogio{font-variant-numeric:tabular-nums;font-size:20px;font-weight:700;color:#cfd7e1}
.modo{display:inline-flex;align-items:center;gap:7px;padding:7px 13px;border-radius:999px;border:1px solid #222c3a;background:oklch(0.6381 calc(0.1873 * var(--tc)) calc(256.90deg + var(--tr)) / .08);font-size:11.5px;font-weight:800;letter-spacing:.1em;color:oklch(0.8611 calc(0.0663 * var(--tc)) calc(255.51deg + var(--tr)));transition:all .3s}
.modo i{width:7px;height:7px;border-radius:50%;background:#616d7d}
.modo.leve{border-color:#5a3f12;background:rgba(245,158,11,.1);color:#fcd38b}.modo.leve i{background:var(--a)}
.modo.ext{border-color:oklch(0.3791 calc(0.1079 * var(--tc)) calc(256.88deg + var(--tr)));background:oklch(0.6381 calc(0.1873 * var(--tc)) calc(256.90deg + var(--tr)) / .18);color:#ffffff}.modo.ext i{background:var(--r);box-shadow:0 0 10px var(--r)}
.prog{height:3px;background:transparent;position:relative;overflow:hidden;opacity:0;transition:opacity .3s}
.prog.on{opacity:1}.prog b{position:absolute;left:0;top:0;bottom:0;width:0;background:linear-gradient(90deg,oklch(0.3991 calc(0.1348 * var(--tc)) calc(257.87deg + var(--tr))),var(--r),oklch(0.8611 calc(0.0663 * var(--tc)) calc(255.51deg + var(--tr))));box-shadow:0 0 14px var(--r);transition:width .5s var(--ease)}
.palco{position:relative;flex:1;min-height:0}
.pg{position:absolute;inset:0;overflow:auto;padding:8px 32px 32px;display:none}
.pg.on{display:block}
.pg.ent>*{animation:sobe .55s var(--ease) both;animation-delay:calc(var(--i,0)*70ms)}
@keyframes sobe{from{opacity:0;transform:translateY(18px) scale(.985)}to{opacity:1;transform:none}}

/* cartões com luz correndo na borda */
.cd{position:relative;background:linear-gradient(180deg,#13171d,#0b0e12);border:1px solid #1d232b;border-radius:18px;padding:20px;transition:transform .3s var(--ease),border-color .3s,box-shadow .3s}
.cd:hover{transform:translateY(-2px);border-color:#222c3a;box-shadow:0 18px 38px -22px oklch(0.6381 calc(0.1873 * var(--tc)) calc(256.90deg + var(--tr)) / .55)}
.cd.led::after{content:"";position:absolute;inset:0;border-radius:inherit;padding:1.5px;background:conic-gradient(from var(--led),transparent 0deg,transparent 290deg,oklch(0.7066 calc(0.1488 * var(--tc)) calc(255.58deg + var(--tr)) / .4) 320deg,#e1eefe 352deg,transparent 360deg);-webkit-mask:linear-gradient(#000000 0 0) content-box,linear-gradient(#000000 0 0);-webkit-mask-composite:xor;mask-composite:exclude;pointer-events:none;animation:ledGira 6s linear infinite;will-change:transform}
@keyframes ledGira{to{--led:360deg}}
.cd h3{margin:0 0 4px;font-size:11.5px;letter-spacing:.14em;color:var(--m);font-weight:800;text-transform:uppercase}
.cd p{margin:6px 0 0;color:var(--m);line-height:1.5}
.grade{display:grid;gap:16px;margin-bottom:16px}
.g4{grid-template-columns:repeat(4,minmax(0,1fr))}.g3{grid-template-columns:repeat(3,minmax(0,1fr))}.g2{grid-template-columns:repeat(2,minmax(0,1fr))}.gA{grid-template-columns:340px minmax(0,1fr)}
@media (max-width:1180px){.g4{grid-template-columns:repeat(2,minmax(0,1fr))}.gA,.gA[style]{grid-template-columns:1fr!important}}
@media (max-width:920px){.g3{grid-template-columns:1fr}.hero{grid-template-columns:auto 1fr}.hero .saude{display:none}}
@media (max-width:760px){.g2,.g4{grid-template-columns:1fr}}

/* botões */
.bt{position:relative;overflow:hidden;display:inline-flex;align-items:center;justify-content:center;gap:9px;min-height:46px;padding:0 22px;border-radius:13px;border:1px solid #2a323c;background:linear-gradient(180deg,#1a1f27,#10141a);color:#e8edf3;font-weight:700;transition:transform .2s var(--ease),border-color .25s,background .25s,box-shadow .25s,filter .2s}
.bt:hover:not(:disabled){border-color:oklch(0.3791 calc(0.1079 * var(--tc)) calc(256.88deg + var(--tr)));background:linear-gradient(180deg,#151c24,#10151a);transform:translateY(-1px)}
.bt:active:not(:disabled){transform:scale(.97)}
.bt:disabled{opacity:.55;cursor:default}
.bt:focus-visible{outline:2px solid oklch(0.7917 calc(0.1020 * var(--tc)) calc(255.59deg + var(--tr)));outline-offset:2px}
.bt.p{border:0;color:#ffffff;background:linear-gradient(135deg,oklch(0.6588 calc(0.1751 * var(--tc)) calc(256.28deg + var(--tr))),oklch(0.5318 calc(0.1826 * var(--tc)) calc(257.98deg + var(--tr))) 55%,oklch(0.4252 calc(0.1420 * var(--tc)) calc(257.74deg + var(--tr))));box-shadow:0 14px 30px -12px oklch(0.6381 calc(0.1873 * var(--tc)) calc(256.90deg + var(--tr)) / .9),inset 0 1px 0 rgba(255,255,255,.3)}
.bt.p:hover:not(:disabled){filter:brightness(1.12);background:linear-gradient(135deg,oklch(0.6588 calc(0.1751 * var(--tc)) calc(256.28deg + var(--tr))),oklch(0.5318 calc(0.1826 * var(--tc)) calc(257.98deg + var(--tr))) 55%,oklch(0.4252 calc(0.1420 * var(--tc)) calc(257.74deg + var(--tr))))}
.bt.p::after{content:"";position:absolute;inset:0;border-radius:inherit;pointer-events:none;background:linear-gradient(110deg,transparent 34%,rgba(255,255,255,.5) 50%,transparent 66%) no-repeat;background-size:250% 100%;background-position:150% 0;animation:reflexo 3.8s ease-in-out infinite;will-change:transform}
.bt.g{min-height:40px;padding:0 16px;font-size:13px}
.bt.grande{min-height:56px;padding:0 32px;font-size:16px;border-radius:15px}
.linha{display:flex;gap:12px;flex-wrap:wrap;align-items:center}

/* início: faixa principal */
.hero{position:relative;overflow:hidden;display:grid;grid-template-columns:auto 1fr auto;gap:28px;align-items:center;padding:30px 34px;border-radius:22px;margin-bottom:16px;border:1px solid oklch(0.6867 calc(0.1603 * var(--tc)) calc(255.90deg + var(--tr)));background:radial-gradient(560px 300px at 84% 50%,oklch(0.7575 calc(0.1211 * var(--tc)) calc(255.46deg + var(--tr)) / .42),transparent 70%),radial-gradient(420px 260px at 8% 0%,oklch(0.7070 calc(0.1484 * var(--tc)) calc(255.84deg + var(--tr)) / .30),transparent 70%),linear-gradient(115deg,oklch(0.2924 calc(0.0952 * var(--tc)) calc(257.51deg + var(--tr))) 0%,oklch(0.4428 calc(0.1522 * var(--tc)) calc(258.03deg + var(--tr))) 40%,oklch(0.5671 calc(0.1933 * var(--tc)) calc(257.92deg + var(--tr))) 100%);box-shadow:0 30px 60px -30px oklch(0.6381 calc(0.1873 * var(--tc)) calc(256.90deg + var(--tr)) / .65)}
.hero::before{content:"";position:absolute;inset:0;background:repeating-linear-gradient(115deg,rgba(255,255,255,.06) 0 2px,transparent 2px 38px);pointer-events:none}
.hero .feixe{position:absolute;top:-30%;bottom:-30%;width:26%;left:-30%;background:linear-gradient(100deg,transparent,rgba(255,255,255,.12),transparent);transform:skewX(-18deg);animation:feixe 7s ease-in-out infinite;pointer-events:none;will-change:transform}
@keyframes feixe{0%{transform:translateX(0) skewX(-18deg)}60%,100%{transform:translateX(620%) skewX(-18deg)}}
.hero .emb{width:112px;height:112px;filter:drop-shadow(0 10px 24px oklch(0.1806 calc(0.0504 * var(--tc)) calc(251.96deg + var(--tr)) / .55))}
.hero h2{margin:0;font-size:58px;line-height:1;font-weight:900;letter-spacing:.01em;color:#ffffff;text-shadow:0 4px 24px oklch(0.2210 calc(0.0694 * var(--tc)) calc(255.88deg + var(--tr)) / .45)}
.hero h2 i{font-style:normal;color:#ffffff}
.hero .bt.p{background:#ffffff;color:oklch(0.4982 calc(0.1704 * var(--tc)) calc(257.85deg + var(--tr)));box-shadow:0 16px 34px -12px oklch(0.1806 calc(0.0504 * var(--tc)) calc(251.96deg + var(--tr)) / .7)}
.hero .bt.p:hover:not(:disabled){filter:none;background:#f1f8ff;box-shadow:0 20px 40px -12px oklch(0.1806 calc(0.0504 * var(--tc)) calc(251.96deg + var(--tr)) / .8)}
.hero .bt.p::after{background:linear-gradient(110deg,transparent 34%,oklch(0.6381 calc(0.1873 * var(--tc)) calc(256.90deg + var(--tr)) / .28) 50%,transparent 66%) no-repeat;background-size:250% 100%;background-position:150% 0}
.hero .tag{color:#e2eefe;margin:8px 0 14px;font-size:15px}
.hero .est{display:flex;align-items:center;gap:9px;margin-bottom:18px;font-weight:700;color:#ffffff}
.hero .est i{width:9px;height:9px;border-radius:50%;background:#ffffff;box-shadow:0 0 0 0 rgba(255,255,255,.6);animation:pulsaB 2s ease-out infinite}
@keyframes pulsaB{70%{box-shadow:0 0 0 9px rgba(255,255,255,0)}100%{box-shadow:0 0 0 0 rgba(255,255,255,0)}}
.hero .saude{position:relative;z-index:1;display:grid;place-items:center;gap:6px;text-align:center;padding-right:6px}
.hero .saude .vl{stroke:#ffffff;filter:drop-shadow(0 0 8px rgba(255,255,255,.55))}
.hero .est i{background:#ffffff}
/* faixa de características da tela Início (v8.7) */
.vant{position:relative;display:grid;grid-template-columns:repeat(4,minmax(0,1fr));margin-bottom:16px;border-radius:18px;border:1px solid #1d232b;background:radial-gradient(520px 170px at 6% 0%,oklch(0.6381 calc(0.1873 * var(--tc)) calc(256.90deg + var(--tr)) / .12),transparent 70%),linear-gradient(180deg,#13171d,#0b0e12);overflow:hidden}
.vant::after{content:"";position:absolute;left:8%;right:8%;top:0;height:1px;background:linear-gradient(90deg,transparent,oklch(0.7066 calc(0.1488 * var(--tc)) calc(255.58deg + var(--tr)) / .75),transparent);pointer-events:none}
.va{position:relative;display:flex;align-items:center;gap:13px;min-width:0;padding:20px 18px;cursor:pointer;text-align:left;transition:background .25s}
.va+.va::before{content:"";position:absolute;left:0;top:20%;bottom:20%;width:1px;background:linear-gradient(180deg,transparent,oklch(0.3989 calc(0.0676 * var(--tc)) calc(253.31deg + var(--tr))),transparent)}
.va:hover,.va:focus-visible{background:linear-gradient(180deg,oklch(0.6381 calc(0.1873 * var(--tc)) calc(256.90deg + var(--tr)) / .12),oklch(0.6381 calc(0.1873 * var(--tc)) calc(256.90deg + var(--tr)) / .02))}
.va:focus-visible,.vl:focus-visible{outline:2px solid var(--r3);outline-offset:-3px;border-radius:14px}
.vi{flex:none;width:52px;height:52px;display:grid;place-items:center;filter:drop-shadow(0 0 9px oklch(0.6381 calc(0.1873 * var(--tc)) calc(256.90deg + var(--tr)) / .55));transition:transform .35s var(--ease),filter .35s}
.vi svg{width:100%;height:100%;fill:none;stroke:url(#vgr);stroke-width:1.5;stroke-linecap:round;stroke-linejoin:round;overflow:visible}
.va:hover .vi{transform:scale(1.1);filter:drop-shadow(0 0 15px oklch(0.6381 calc(0.1873 * var(--tc)) calc(256.90deg + var(--tr)) / .85))}
.vt{min-width:0}
.vt b{display:block;font-size:16px;line-height:1.15;font-weight:900;letter-spacing:.02em;text-transform:uppercase;color:#ffffff}
.vt small{display:block;margin-top:5px;color:#b8c2cf;font-size:12.5px;line-height:1.45}
.vl{font-weight:600;color:#d3dce9;border-radius:4px;transition:color .2s}
.vl:hover{color:#ffffff;text-decoration:underline;text-decoration-color:var(--r3);text-underline-offset:3px}
.vl:last-child{font-weight:900;color:var(--r3)}
.vi .agulha{transform-box:view-box;transform-origin:12px 13.4px;transform:rotate(24deg);animation:vAgulha 3.8s ease-in-out infinite}
@keyframes vAgulha{0%,100%{transform:rotate(-34deg)}45%{transform:rotate(26deg)}60%{transform:rotate(18deg)}}
.vi .foguete{animation:vFoguete 2.6s ease-in-out infinite}
@keyframes vFoguete{0%,100%{transform:translateY(0)}50%{transform:translateY(-1.3px)}}
.vi .chama{transform-box:fill-box;transform-origin:50% 0;animation:vChama .8s ease-in-out infinite alternate}
@keyframes vChama{from{transform:scaleY(.65);opacity:.65}to{transform:scaleY(1.15);opacity:1}}
.vi .ok{stroke-dasharray:10;stroke-dashoffset:0;animation:vOk 4.2s ease-in-out infinite}
@keyframes vOk{0%,8%{stroke-dashoffset:10}30%,100%{stroke-dashoffset:0}}
.vi .roda{transform-box:view-box;transform-origin:12px 12px;animation:vRoda 16s linear infinite}
.va:hover .vi .roda{animation-duration:3.2s}
@keyframes vRoda{to{transform:rotate(360deg)}}
.pg.ent .va{animation:sobe .5s var(--ease) both;animation-delay:calc(var(--i,0)*70ms + 150ms + var(--k,0)*90ms)}
@media (max-width:1180px){.vant{grid-template-columns:repeat(2,minmax(0,1fr))}.va:nth-of-type(3)::before{display:none}.va:nth-of-type(n+3){border-top:1px solid #1d232b}}
@media (max-width:760px){.vant{grid-template-columns:1fr}.va::before{display:none!important}.va+.va{border-top:1px solid #1d232b}.va{padding:16px 18px}}
@media (prefers-reduced-motion:reduce){.vi *,.pg.ent .va{animation:none!important}.vi .agulha{transform:rotate(24deg)}}
html.leve .vi *,html.leve .pg.ent .va{animation:none!important}
html.leve .vi .agulha{transform:rotate(24deg)}
html.leve .vi,html.leve .va:hover .vi{filter:none}

.hero .saude small{color:#e2eefe;font-size:12px}
.hero>*{position:relative;z-index:1}

/* medidores em anel */
.anel{position:relative;width:150px;height:150px;margin:6px auto 4px}
.anel svg{width:100%;height:100%;transform:rotate(-90deg)}
.anel circle{fill:none;stroke-width:11;stroke-linecap:round}
.anel .tr{stroke:#1d242c}
.anel .vl{stroke:url(#gR);stroke-dasharray:352;stroke-dashoffset:352;transition:stroke-dashoffset .9s var(--ease);filter:drop-shadow(0 0 7px oklch(0.6381 calc(0.1873 * var(--tc)) calc(256.90deg + var(--tr)) / .55))}
.anel .num{position:absolute;inset:0;display:grid;place-items:center;font-size:30px;font-weight:800;font-variant-numeric:tabular-nums}
.anel.peq{width:104px;height:104px;margin:0}.anel.peq .num{font-size:22px}.anel.peq circle{stroke-width:12}
.anel.gr{width:190px;height:190px}.anel.gr .num{font-size:40px}
.mt{text-align:center}.mt .sb{color:var(--m);font-size:12.5px;min-height:18px;margin-top:2px}

/* atalhos coloridos */
.tile{position:relative;overflow:hidden;display:flex;flex-direction:column;gap:14px;align-items:flex-start;text-align:left;min-height:118px;padding:18px;border-radius:18px;border:1px solid color-mix(in srgb,var(--c) 45%,#1d232b);background:linear-gradient(145deg,color-mix(in srgb,var(--c) 30%,#0c0f13),#0b0e12 80%);transition:transform .3s var(--ease),box-shadow .3s,border-color .3s}
.tile:hover{transform:translateY(-3px);box-shadow:0 18px 36px -18px var(--c);border-color:var(--c)}
.tile .ti{width:42px;height:42px;border-radius:12px;display:grid;place-items:center;background:color-mix(in srgb,var(--c) 85%,#000000);color:#ffffff;box-shadow:0 10px 22px -10px var(--c)}
.tile b{font-size:16px;display:block}.tile small{color:#b8c2cf;font-size:12px}
.tile .seta{position:absolute;right:16px;top:16px;color:color-mix(in srgb,var(--c) 70%,#ffffff);opacity:.7;transition:transform .3s var(--ease),opacity .3s}
.tile:hover .seta{transform:translateX(4px);opacity:1}
.tile:hover .ico{animation:vibra .5s ease-in-out}

canvas.gf{display:block;width:100%;height:230px}
.leg{display:flex;gap:18px;margin-bottom:6px;font-size:12px;color:#cfd7e1}.leg i{display:inline-block;width:9px;height:9px;border-radius:50%;margin-right:7px}

/* barras */
.bar{display:grid;grid-template-columns:96px 1fr 70px;align-items:center;gap:14px;padding:10px 0}
.bar span{color:var(--m);font-size:13px}.bar b{text-align:right;font-variant-numeric:tabular-nums}
.bar .tr{height:9px;border-radius:9px;background:#1b2028;overflow:hidden}
.bar .tr i{display:block;height:100%;width:0;border-radius:9px;background:linear-gradient(90deg,oklch(0.3991 calc(0.1348 * var(--tc)) calc(257.87deg + var(--tr))),var(--r),oklch(0.7361 calc(0.1317 * var(--tc)) calc(255.43deg + var(--tr))));transition:width .8s var(--ease);box-shadow:0 0 12px oklch(0.6381 calc(0.1873 * var(--tc)) calc(256.90deg + var(--tr)) / .5)}

/* números */
.nm{font-size:34px;font-weight:800;font-variant-numeric:tabular-nums;margin-top:8px}
.nm small{font-size:15px;color:var(--m);font-weight:600}

/* passos da otimização */
.passos{display:grid;gap:10px;margin-top:16px}
.ps{display:flex;align-items:center;gap:12px;padding:12px 14px;border-radius:13px;background:#0e1218;border:1px solid #1b2028;transition:border-color .3s,background .3s}
.ps .pi{width:28px;height:28px;border-radius:50%;display:grid;place-items:center;border:2px solid #2a323c;color:transparent;transition:all .3s;flex:none}
.ps .pi svg{width:15px;height:15px}
.ps.rodando{border-color:oklch(0.3791 calc(0.1079 * var(--tc)) calc(256.88deg + var(--tr)));background:#0c1117}.ps.rodando .pi{border-color:var(--r);border-top-color:transparent;animation:gira .8s linear infinite}
.ps.ok .pi{background:var(--g);border-color:var(--g);color:#06220f}.ps.ok{border-color:#14532d}
.ps.erro .pi{background:#ef4444;border-color:#ef4444;color:#ffffff}
.ps div{flex:1;min-width:0}.ps b{display:block;font-size:14px}.ps small{color:var(--m);display:block;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}

/* histórico */
.hist{display:grid;gap:2px;margin-top:10px;max-height:300px;overflow:auto}
.hi{display:flex;gap:14px;padding:9px 6px;border-bottom:1px solid #161b22;animation:sobe .4s var(--ease) both}
.hi time{color:var(--r3);font-weight:800;font-size:12px;min-width:44px;font-variant-numeric:tabular-nums}.hi span{color:#d6dde5;line-height:1.4}

/* vazio */
.vz{display:flex;flex-direction:column;align-items:center;gap:8px;padding:40px 14px;text-align:center;color:var(--m)}
.vz .ic{width:60px;height:60px;border-radius:18px;display:grid;place-items:center;background:linear-gradient(135deg,oklch(0.3080 calc(0.0880 * var(--tc)) calc(256.57deg + var(--tr))),var(--r2));color:#ffffff;box-shadow:0 14px 28px -12px oklch(0.6381 calc(0.1873 * var(--tc)) calc(256.90deg + var(--tr)) / .8);animation:pop .55s var(--ease) both}
.vz .ic .ico{width:26px;height:26px}.vz b{color:var(--t);font-size:17px}.vz span{max-width:440px;line-height:1.5}
@keyframes pop{from{opacity:0;transform:scale(.6) rotate(-8deg)}to{opacity:1;transform:none}}

/* chave (liga e desliga) */
.sw{position:relative;width:62px;height:32px;border-radius:999px;border:1px solid #2a323c;background:#1a1f27;flex:none;padding:0;transition:background .3s,border-color .3s,box-shadow .3s}
.sw i{position:absolute;top:3px;left:3px;width:24px;height:24px;border-radius:50%;background:linear-gradient(135deg,#8b97a5,#4b5460);transition:transform .35s var(--ease),background .3s;box-shadow:0 2px 6px rgba(0,0,0,.5)}
.sw.on{background:linear-gradient(135deg,oklch(0.3991 calc(0.1348 * var(--tc)) calc(257.87deg + var(--tr))),var(--r));border-color:oklch(0.7160 calc(0.1430 * var(--tc)) calc(255.97deg + var(--tr)));box-shadow:0 0 18px -2px oklch(0.6381 calc(0.1873 * var(--tc)) calc(256.90deg + var(--tr)) / .6)}
.sw.on i{transform:translateX(30px);background:#ffffff}
.modo-c{display:flex;flex-direction:column;gap:6px}
.modo-c .lin{display:flex;align-items:center;gap:16px;margin-top:20px}
.modo-c .st{font-weight:800;letter-spacing:.1em;font-size:12px;color:var(--m)}.modo-c .st.on{color:#ffffff}
.modo-c h2{margin:0;font-size:22px}

/* controle deslizante */
input[type=range]{-webkit-appearance:none;appearance:none;width:100%;height:10px;border-radius:10px;background:linear-gradient(90deg,var(--r) var(--p,0%),#1d242c var(--p,0%));outline:none;margin:18px 0 8px}
input[type=range]::-webkit-slider-thumb{-webkit-appearance:none;width:24px;height:24px;border-radius:50%;background:#ffffff;border:3px solid var(--r);box-shadow:0 0 16px oklch(0.6381 calc(0.1873 * var(--tc)) calc(256.90deg + var(--tr)) / .8);cursor:grab;transition:transform .2s}
input[type=range]::-webkit-slider-thumb:hover{transform:scale(1.15)}
input[type=range]:disabled{opacity:.4}
.gt{font-size:20px;font-weight:800}
#gpuCtl.sem input,#gpuCtl.sem .ocn,#gpuCtl.sem .ocm,#gpuCtl.sem .ocv,#gpuCtl.sem .linha,#gpuCtl.sem .ocs{display:none}
.ocn{display:flex;align-items:baseline;gap:12px;margin:12px 0 0}
.ocn b{font-size:46px;line-height:1;font-weight:900;letter-spacing:-.02em;font-variant-numeric:tabular-nums}
.ocn span{font-size:14px;font-weight:700;color:var(--m);transition:color .3s}
.ocn.mod span{color:#ffb454}.ocn.ag span{color:var(--r3)}
.ocm{display:flex;justify-content:space-between;color:var(--m);font-size:11.5px;font-weight:700;margin:0 2px 14px}
.ocv{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:10px;margin:0 0 18px}
.ocv div{background:#0e1218;border:1px solid #1d232b;border-radius:12px;padding:10px 12px}
.ocv small{display:block;color:var(--m);font-size:11px;letter-spacing:.08em;text-transform:uppercase;font-weight:700;margin-bottom:2px}
.ocv b{font-size:16px}
.ocs{margin:14px 0 0;color:var(--m);font-size:12.5px;line-height:1.5}
.ocs.av{color:#ffb454}
.cpg{align-items:stretch}
.cpc{display:flex;flex-direction:column;gap:10px;position:relative;transition:border-color .3s,box-shadow .3s,background .3s}
.cpc.sel{border-color:var(--r);background:linear-gradient(145deg,oklch(0.2077 calc(0.0405 * var(--tc)) calc(256.80deg + var(--tr))),#0e1218);box-shadow:0 18px 36px -22px var(--r)}
.cpc .tg{align-self:flex-start;font-size:10.5px;letter-spacing:.12em;font-weight:800;color:oklch(0.8119 calc(0.0953 * var(--tc)) calc(256.93deg + var(--tr)));background:#121d2a;border:1px solid oklch(0.3084 calc(0.0528 * var(--tc)) calc(253.65deg + var(--tr)));border-radius:999px;padding:3px 10px}
.cpc.sel .tg{background:var(--r);color:#fff;border-color:var(--r)}
.cpc h3{margin:0;font-size:20px;color:var(--t);text-transform:none;letter-spacing:0}
.cpc p{margin:0;color:var(--m);font-size:13px;line-height:1.5}
.cpc ul{margin:0;padding:0;list-style:none;color:#c6ced9;font-size:12.5px;line-height:1.75}
.cpc li::before{content:"•";color:var(--r3);margin-right:8px}
.cpc .bt{margin-top:auto}
.cpv{display:flex;justify-content:space-between;gap:12px;padding:9px 0;border-bottom:1px solid #161b22;font-size:13.5px}
.cpv span{color:var(--m)}

/* jogos */
.jg{display:grid;grid-template-columns:repeat(auto-fill,minmax(250px,1fr));gap:16px}
.jc{position:relative;overflow:hidden;border-radius:18px;background:#0e1218;border:1px solid #1d232b;transition:transform .3s var(--ease),border-color .3s,box-shadow .3s;animation:sobe .5s var(--ease) both;animation-delay:calc(var(--i,0)*40ms)}
.jc:hover{transform:translateY(-4px);border-color:oklch(0.3791 calc(0.1079 * var(--tc)) calc(256.88deg + var(--tr)));box-shadow:0 20px 40px -20px oklch(0.6381 calc(0.1873 * var(--tc)) calc(256.90deg + var(--tr)) / .6)}
.jc .cv{position:relative;height:128px;background:linear-gradient(135deg,oklch(0.2077 calc(0.0405 * var(--tc)) calc(256.80deg + var(--tr))),#12161b);display:grid;place-items:center;font-size:44px;font-weight:900;color:oklch(0.7160 calc(0.1430 * var(--tc)) calc(255.97deg + var(--tr)));overflow:hidden}
.jc .cv img{position:absolute;inset:0;width:100%;height:100%;object-fit:cover;transition:transform .6s var(--ease)}
.jc:hover .cv img{transform:scale(1.07)}
.jc .cv::after{content:"";position:absolute;inset:auto 0 0;height:60%;background:linear-gradient(transparent,#0e1218)}
.jc .cv img.ic{inset:0;margin:auto;width:64px;height:64px;object-fit:contain;z-index:1;opacity:0;filter:drop-shadow(0 6px 14px rgba(0,0,0,.55))}
.jc .cv.tem img.ic{opacity:1}.jc .cv.tem span{display:none}
.jc:hover .cv img.ic{transform:scale(1.1)}
.jc .jx{position:absolute;top:8px;right:8px;z-index:3;width:28px;height:28px;display:grid;place-items:center;padding:0;border-radius:50%;background:rgba(6,8,10,.74);border:1px solid #252e3a;color:oklch(0.8246 calc(0.0296 * var(--tc)) calc(254.70deg + var(--tr)));cursor:pointer;opacity:0;transition:opacity .2s,background .2s,color .2s,transform .2s}
.jc .jx .ico{width:14px;height:14px}
.jc:hover .jx,.jc .jx:focus-visible{opacity:1}
.jc .jx:hover{background:oklch(0.3791 calc(0.1079 * var(--tc)) calc(256.88deg + var(--tr)));color:#fff;transform:scale(1.08)}
@media (hover:none){.jc .jx{opacity:.9}}
.jc .tg{position:absolute;left:10px;bottom:8px;z-index:2;font-size:10px;letter-spacing:.1em;font-weight:800;color:oklch(0.9308 calc(0.0339 * var(--tc)) calc(253.71deg + var(--tr)));background:oklch(0.3791 calc(0.1079 * var(--tc)) calc(256.88deg + var(--tr)) / .78);padding:2px 8px;border-radius:999px}
#jgOc{margin-top:8px}
.jc .cb{padding:2px 16px 16px}
.jc b{display:block;font-size:15px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.jc small{color:var(--r3);font-weight:800;letter-spacing:.12em;font-size:10.5px}
.jc .linha{margin-top:14px;flex-wrap:nowrap}.jc .bt{flex:1;min-height:40px;padding:0 10px}
.sk{border-radius:18px;height:250px;background:linear-gradient(90deg,#10141a,#181d25,#10141a);background-size:200% 100%;animation:brilhoSk 1.4s linear infinite}
@keyframes brilhoSk{to{background-position:-200% 0}}

/* diagnóstico */
.dg{display:grid;gap:2px;margin-top:10px}.dg div{display:flex;align-items:center;justify-content:space-between;gap:16px;padding:12px 4px;border-bottom:1px solid #161b22}
.dg span{color:var(--m)}.dg b{display:inline-flex;align-items:center;gap:8px;text-align:right}
.ok{color:var(--g)}.no{color:var(--a)}

/* aviso no canto */
#toasts{position:fixed;right:22px;bottom:22px;z-index:50;display:grid;gap:10px;justify-items:end;pointer-events:none}
.toast{display:flex;align-items:center;gap:12px;max-width:480px;padding:14px 18px;border-radius:14px;background:#15191f;border:1px solid #222c3a;box-shadow:0 20px 44px -16px #000000,0 0 0 1px oklch(0.6381 calc(0.1873 * var(--tc)) calc(256.90deg + var(--tr)) / .12);animation:tIn .45s var(--ease) both;position:relative;overflow:hidden}
.toast::before{content:"";position:absolute;left:0;top:0;bottom:0;width:4px;background:linear-gradient(var(--r),var(--r2))}
.toast.sai{animation:tOut .35s ease-in both}
.toast .ico{color:var(--r);width:18px;height:18px}
@keyframes tIn{from{opacity:0;transform:translateX(60px) scale(.96)}to{opacity:1;transform:none}}
@keyframes tOut{to{opacity:0;transform:translateX(60px)}}

/* confirmação */
#cf{position:fixed;inset:0;z-index:60;display:none;place-items:center;background:rgba(3,4,7,.72);backdrop-filter:blur(4px)}
#cf.on{display:grid}
#cf .cx{width:min(440px,92vw);padding:26px;border-radius:20px;background:linear-gradient(180deg,#171c22,#0d1014);border:1px solid oklch(0.2879 calc(0.0641 * var(--tc)) calc(256.47deg + var(--tr)));box-shadow:0 30px 70px -20px #000000;animation:pop .35s var(--ease) both}
#cf h3{margin:0 0 8px;font-size:19px;color:#ffffff;letter-spacing:0;text-transform:none}#cf p{margin:0 0 22px;color:#b8c2cf;line-height:1.5}
/* v9.6: janela da otimização (a % subindo e, no fim, "otimizado com sucesso") */
#otm{position:fixed;inset:0;z-index:55;display:none;place-items:center;background:rgba(3,5,8,.78);backdrop-filter:blur(5px)}
#otm.on{display:grid}
#otm .ox{position:relative;width:min(460px,92vw);max-height:94vh;overflow:auto;padding:26px 26px 22px;border-radius:22px;background:linear-gradient(180deg,#141920,#0a0d11);border:1px solid oklch(0.3250 calc(0.0798 * var(--tc)) calc(256.48deg + var(--tr)));box-shadow:0 34px 80px -24px #000000,0 0 70px -34px oklch(0.6381 calc(0.1873 * var(--tc)) calc(256.90deg + var(--tr)) / .7);animation:pop .35s var(--ease) both;text-align:center}
#otm h3{margin:0 0 18px;font-size:13px;letter-spacing:.16em;text-transform:uppercase;color:#cfd7e1}
.oan{position:relative;width:196px;height:196px;margin:0 auto}
.oan svg{width:100%;height:100%;display:block;overflow:visible}
.oan .trilho{fill:none;stroke:#1a2029;stroke-width:5}
.oan .arco{fill:none;stroke:url(#otmAr);stroke-width:5;stroke-linecap:round;filter:drop-shadow(0 0 6px oklch(0.6381 calc(0.1873 * var(--tc)) calc(256.90deg + var(--tr)) / .75))}
.oan .lq{transition:transform .9s var(--ease)}
.oan .on1{fill:url(#otmGl);animation:onda 3.2s linear infinite}
.oan .on2{fill:oklch(0.7066 calc(0.1488 * var(--tc)) calc(255.58deg + var(--tr)));opacity:.32;animation:onda 5.4s linear infinite}
@keyframes onda{from{transform:translateX(0)}to{transform:translateX(-200px)}}
.oan .pct{position:absolute;inset:0;display:grid;place-items:center;font-size:46px;font-weight:800;color:#ffffff;font-variant-numeric:tabular-nums;letter-spacing:-.01em;text-shadow:0 2px 14px rgba(0,0,0,.7)}
#otmPasso{margin:16px 0 0;color:#b8c2cf;min-height:20px;font-size:14px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.olist{position:relative;display:grid;gap:4px;margin-top:14px;max-height:206px;overflow:auto;text-align:left;padding-right:4px}
.oi{display:flex;align-items:center;gap:10px;padding:7px 10px;border-radius:10px;font-size:13.5px;color:#7d8896;transition:background .3s,color .3s}
.oi i{flex:none;width:18px;height:18px;border-radius:50%;border:2px solid #2a323c;display:grid;place-items:center;box-sizing:border-box}
.oi i svg{width:11px;height:11px;fill:none;stroke:currentColor;stroke-width:3.4;stroke-linecap:round;stroke-linejoin:round}
.oi.ok{color:#d6dde5}.oi.ok i{background:var(--g);border-color:var(--g);color:#06220f}
.oi.rodando{color:#ffffff;background:#0f1824;font-weight:700}.oi.rodando i{border-color:var(--r);border-top-color:transparent;animation:gira .8s linear infinite}
.oi.erro{color:#fca5a5}.oi.erro i{background:#ef4444;border-color:#ef4444;color:#ffffff}
.oi.pulado i{border-style:dashed}
.oi span{flex:1;min-width:0;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
#otm .olinha{display:flex;gap:10px;justify-content:center;flex-wrap:wrap;margin-top:18px}
.ofim{display:none}#otm.fim .orun{display:none}#otm.fim .ofim{display:block}
.ook{width:94px;height:94px;margin:8px auto 18px;border-radius:50%;display:grid;place-items:center;background:radial-gradient(circle at 50% 38%,#22c55e,#0f6b35);box-shadow:0 0 0 9px rgba(34,197,94,.12),0 0 56px -6px rgba(34,197,94,.75);animation:pop .5s var(--ease) both}
.ook svg{width:50px;height:50px;fill:none;stroke:#ffffff;stroke-width:3;stroke-linecap:round;stroke-linejoin:round}
.ook .v{stroke-dasharray:30;stroke-dashoffset:30;animation:risca .6s .3s var(--ease) forwards}.ook .ex{display:none}
@keyframes risca{to{stroke-dashoffset:0}}
#otm.parou .ook{background:radial-gradient(circle at 50% 38%,#f59e0b,#8a5a06);box-shadow:0 0 0 9px rgba(245,158,11,.12),0 0 56px -6px rgba(245,158,11,.6)}
#otm.parou .ook .v{display:none}#otm.parou .ook .ex{display:inline}
#otmFT{margin:0 0 10px;font-size:22px;font-weight:800;letter-spacing:.07em;color:#ffffff}
#otmFP{margin:0 auto 18px;max-width:370px;color:#b8c2cf;line-height:1.55;font-size:14px}
.ochips{display:grid;grid-template-columns:repeat(auto-fit,minmax(88px,1fr));gap:8px}
.ochip{padding:11px 8px;border-radius:13px;background:#0e1218;border:1px solid #1b2028}
.ochip b{display:block;font-size:19px;color:#ffffff;font-variant-numeric:tabular-nums}.ochip span{font-size:11.5px;color:#8b97a5}
html.leve .oan .on1,html.leve .oan .on2,html.leve .oan .lq{animation:none;transition:none}html.leve .ook .v{animation:none;stroke-dashoffset:0}
@media (prefers-reduced-motion:reduce){.oan .on1,.oan .on2{animation:none}.ook .v{animation:none;stroke-dashoffset:0}}

/* abertura */
#boot{position:fixed;inset:0;z-index:100;display:grid;place-items:center;background:radial-gradient(600px 400px at 50% 50%,oklch(0.2022 calc(0.0442 * var(--tc)) calc(253.78deg + var(--tr))),#05080a);transition:opacity .7s ease,transform .7s var(--ease),filter .7s}
#boot.some{opacity:0;transform:scale(1.15);filter:blur(10px);pointer-events:none}
#boot .em{text-align:center}
#boot .emb{width:128px;height:128px;margin:0 auto 18px}
#boot h2{margin:0;font-size:54px;letter-spacing:.06em;font-weight:900;padding-left:.06em;background:linear-gradient(90deg,#ffffff,oklch(0.7917 calc(0.1020 * var(--tc)) calc(255.59deg + var(--tr))));-webkit-background-clip:text;background-clip:text;color:transparent;animation:sobe .8s .2s var(--ease) both}
#boot p{margin:8px 0 0;color:oklch(0.6872 calc(0.0423 * var(--tc)) calc(256.62deg + var(--tr)));letter-spacing:.2em;font-size:12px;animation:sobe .8s .45s var(--ease) both}
#boot .lin{width:240px;height:3px;margin:26px auto 0;border-radius:3px;background:#1d121a;overflow:hidden}
#boot .lin i{display:block;height:100%;width:0;background:linear-gradient(90deg,oklch(0.3991 calc(0.1348 * var(--tc)) calc(257.87deg + var(--tr))),var(--r),#ffffff);animation:carrega 1.4s .2s var(--ease) forwards}
@keyframes carrega{to{width:100%}}
#off{position:fixed;inset:0;z-index:120;display:none;place-items:center;background:rgba(5,8,10,.94);text-align:center;color:#cfd7e1}#off.on{display:grid}

/* ajustes do Windows */
.cab{display:flex;align-items:center;justify-content:space-between;gap:18px;flex-wrap:wrap;margin-bottom:16px}
.cab h2{margin:0;font-size:21px}.cab p{margin:5px 0 0;max-width:600px}
.ctr{margin-top:10px;font-variant-numeric:tabular-nums;color:oklch(0.8611 calc(0.0663 * var(--tc)) calc(255.51deg + var(--tr)));font-size:12.5px;font-weight:800;letter-spacing:.06em}
.ajs{display:grid;grid-template-columns:repeat(auto-fill,minmax(400px,1fr));gap:12px;margin-bottom:16px}
.ajs.um{grid-template-columns:1fr}
.aj{display:grid;grid-template-columns:minmax(0,1fr) auto;column-gap:18px;row-gap:5px;align-items:center;padding:15px 18px;border-radius:16px;background:#0e1218;border:1px solid #1b2028;transition:border-color .3s,background .3s,opacity .3s}
.aj:hover{border-color:#222c3a}
.aj.on{border-color:oklch(0.2879 calc(0.0641 * var(--tc)) calc(256.47deg + var(--tr)));background:linear-gradient(90deg,#0e131b,#0e1218 65%)}
.aj>div{min-width:0;display:flex;flex-wrap:wrap;align-items:center;gap:5px 8px}.aj b{font-size:14.5px}
.aj p{grid-column:1;margin:0;font-size:12.5px;line-height:1.45;color:var(--m)}
.aj p.nt{display:flex;gap:6px;align-items:center;color:oklch(0.8224 calc(0.0870 * var(--tc)) calc(255.07deg + var(--tr)))}.aj p.nt .ico{width:14px;height:14px}
.aj p.av{color:#fcd38b}
.aj p.cmd{font-family:Consolas,"Cascadia Mono",monospace;font-size:11.5px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.aj .sw{grid-column:2;grid-row:1 / span 4;width:54px;height:30px}
.aj .sw i{width:22px;height:22px}.aj .sw.on i{transform:translateX(24px)}
.aj.nd{opacity:.5}
.aj.pd .sw i{animation:respira .9s ease-in-out infinite}
@keyframes respira{50%{opacity:.45}}
.sw:disabled{cursor:not-allowed}
.sw:focus-visible{outline:2px solid oklch(0.7917 calc(0.1020 * var(--tc)) calc(255.59deg + var(--tr)));outline-offset:3px}
.rk{display:inline-block;padding:2px 8px;border-radius:999px;font-size:10px;font-weight:800;letter-spacing:.07em;vertical-align:middle;border:1px solid;white-space:nowrap}
.rk.baixo{color:#86efac;border-color:#14532d;background:rgba(34,197,94,.08)}
.rk.medio{color:#fcd38b;border-color:#5a3f12;background:rgba(245,158,11,.1)}
.rk.rec{color:oklch(0.8611 calc(0.0663 * var(--tc)) calc(255.51deg + var(--tr)));border-color:oklch(0.3791 calc(0.1079 * var(--tc)) calc(256.88deg + var(--tr)));background:oklch(0.6381 calc(0.1873 * var(--tc)) calc(256.90deg + var(--tr)) / .1)}
.rk.nt{color:oklch(0.8224 calc(0.0870 * var(--tc)) calc(255.07deg + var(--tr)));border-color:oklch(0.4220 calc(0.1135 * var(--tc)) calc(256.34deg + var(--tr)));background:oklch(0.6441 calc(0.1768 * var(--tc)) calc(256.55deg + var(--tr)) / .1)}
.rk.erro{color:#fca5a5;border-color:#7f1d1d;background:rgba(239,68,68,.1)}
/* FPS na tela */
.ovg{display:grid;grid-template-columns:minmax(0,1.1fr) minmax(0,1fr);gap:16px}
@media (max-width:900px){.ovg{grid-template-columns:1fr}}
.ovprev{position:relative;min-height:230px;border-radius:14px;overflow:hidden;background:radial-gradient(120% 90% at 70% 20%,oklch(0.3530 calc(0.0930 * var(--tc)) calc(259.24deg + var(--tr))) 0,#0a1426 45%,#05080f 100%);border:1px solid oklch(0.2826 calc(0.0395 * var(--tc)) calc(257.77deg + var(--tr)))}
.ovprev::after{content:'seu jogo';position:absolute;left:50%;top:55%;transform:translate(-50%,-50%);font-size:12px;letter-spacing:.3em;text-transform:uppercase;color:rgba(255,255,255,.18)}
.ovbox{position:absolute;display:grid;grid-template-columns:auto auto;gap:0 14px;padding:7px 11px;background:rgba(11,18,32,.93);border:1px solid oklch(0.3791 calc(0.1378 * var(--tc)) calc(265.52deg + var(--tr)));font-size:12px;line-height:1.35}
.ovbox b{font-family:Consolas,ui-monospace,monospace;text-align:right;font-size:14px}.ovbox span{color:oklch(0.7702 calc(0.1165 * var(--tc)) calc(264.42deg + var(--tr)));font-weight:700}
.ovbox.se{left:10px;top:10px}.ovbox.sd{right:10px;top:10px}.ovbox.ie{left:10px;bottom:10px}.ovbox.id{right:10px;bottom:10px}
.ovbox.t1{font-size:10.5px}.ovbox.t1 b{font-size:12px}.ovbox.t3{font-size:14px}.ovbox.t3 b{font-size:18px}
.ovopc{display:grid;gap:12px}.ovopc h4{margin:0 0 6px;font-size:12px;letter-spacing:.1em;color:var(--m);text-transform:uppercase}
.ovbts{display:flex;flex-wrap:wrap;gap:6px}.ovbts button{padding:6px 11px;border-radius:9px;font-size:13px}
.ovbts button.on{background:oklch(0.6381 calc(0.1873 * var(--tc)) calc(256.90deg + var(--tr)) / .22);border-color:oklch(0.6381 calc(0.1873 * var(--tc)) calc(256.90deg + var(--tr)));color:#fff}
.ovpm{display:flex;gap:14px;align-items:center;flex-wrap:wrap}.ovpm .tr{flex:1;min-width:160px;height:8px;border-radius:99px;background:#18202b;overflow:hidden}.ovpm .tr i{display:block;height:100%;background:oklch(0.6381 calc(0.1873 * var(--tc)) calc(256.90deg + var(--tr)));width:0}
/* autoteste */
.atl{display:grid;gap:2px;margin-top:14px}.atg{font-size:11px;font-weight:800;letter-spacing:.12em;color:var(--m);margin:12px 0 4px;text-transform:uppercase}
.atr{display:grid;grid-template-columns:74px minmax(0,1fr) auto;gap:12px;align-items:start;padding:9px 12px;border-radius:12px;background:#0d1116;border:1px solid #161c24}
.atr b{font-size:14px}.atr p{margin:2px 0 0;font-size:13px;line-height:1.45;color:#a9b4c2;overflow-wrap:anywhere}.atr .rk{justify-self:start;margin-top:2px}
.atr.testando{opacity:.75}.atr .bt{padding:6px 12px;font-size:12px}
@media (max-width:560px){.atr{grid-template-columns:64px minmax(0,1fr)}.atr .bt{grid-column:2}}
.avs{display:flex;gap:12px;align-items:flex-start;padding:13px 16px;border-radius:14px;border:1px solid #5a3f12;background:rgba(245,158,11,.08);color:#fcd38b;margin-bottom:16px;line-height:1.45}
.avs[hidden],.aj p[hidden],.bt[hidden]{display:none}
.avs .ico{margin-top:1px}
.avs.verm{border-color:oklch(0.3839 calc(0.1054 * var(--tc)) calc(255.56deg + var(--tr)));background:oklch(0.6401 calc(0.1948 * var(--tc)) calc(256.93deg + var(--tr)) / .08);color:oklch(0.8867 calc(0.0559 * var(--tc)) calc(255.89deg + var(--tr)))}

/* planos e DNS */
.pl{display:grid;grid-template-columns:repeat(auto-fill,minmax(210px,1fr));gap:14px;margin-top:16px}
.pc{position:relative;display:flex;flex-direction:column;gap:6px;align-items:flex-start;text-align:left;padding:18px;border-radius:16px;border:1px solid #1d232b;background:#0e1218;transition:transform .3s var(--ease),border-color .3s,background .3s,box-shadow .3s}
.pc:hover:not(:disabled){transform:translateY(-2px);border-color:oklch(0.3791 calc(0.1079 * var(--tc)) calc(256.88deg + var(--tr)))}
.pc .pi2{width:38px;height:38px;border-radius:11px;display:grid;place-items:center;background:#121a24;color:oklch(0.7160 calc(0.1430 * var(--tc)) calc(255.97deg + var(--tr)));margin-bottom:4px}
.pc b{font-size:15px}.pc small{color:var(--m);font-size:12.5px;line-height:1.4}
.pc .tg{position:absolute;right:14px;top:14px;padding:3px 9px;border-radius:999px;background:var(--r);color:#ffffff;font-size:10px;font-weight:800;letter-spacing:.08em}
.pc.on{border-color:var(--r);background:linear-gradient(145deg,oklch(0.2077 calc(0.0405 * var(--tc)) calc(256.80deg + var(--tr))),#0e1218);box-shadow:0 18px 36px -22px var(--r)}
.pc:focus-visible{outline:2px solid oklch(0.7917 calc(0.1020 * var(--tc)) calc(255.59deg + var(--tr)));outline-offset:2px}
.pc:disabled{opacity:.5;cursor:not-allowed}

/* debloat */
.apg{display:grid;grid-template-columns:repeat(auto-fill,minmax(260px,1fr));gap:12px;margin-bottom:16px}
.ap{position:relative;display:flex;gap:12px;align-items:center;padding:14px;border-radius:14px;background:#0e1218;border:1px solid #1b2028;cursor:pointer;transition:border-color .25s,background .25s}
.ap:hover{border-color:#222c3a}
.ap input{position:absolute;inset:0;width:100%;height:100%;opacity:0;margin:0;cursor:pointer}
.ap .ck{width:22px;height:22px;border-radius:7px;border:2px solid #2a323c;display:grid;place-items:center;color:transparent;flex:none;transition:all .2s}
.ap .ck .ico{width:14px;height:14px;stroke-width:3}
.ap div{min-width:0;flex:1}.ap b{display:block;font-size:14px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.ap small{display:block;color:var(--m);font-size:11px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.ap.sel{border-color:var(--r);background:#0d121a}.ap.sel .ck{background:var(--r);border-color:var(--r);color:#ffffff}
.ap:focus-within{outline:2px solid oklch(0.7917 calc(0.1020 * var(--tc)) calc(255.59deg + var(--tr)));outline-offset:2px}
.sk.fino{height:64px;border-radius:16px}

/* segundo plano */
.bgc{display:flex;align-items:center;justify-content:space-between;gap:28px;margin-bottom:16px;flex-wrap:wrap}
.bgt{display:flex;gap:16px;align-items:flex-start;flex:1;min-width:280px}.bgt h2{margin:0;font-size:21px}.bgt p{max-width:640px}
.bgi{width:46px;height:46px;border-radius:13px;display:grid;place-items:center;background:linear-gradient(135deg,oklch(0.3080 calc(0.0880 * var(--tc)) calc(256.57deg + var(--tr))),var(--r2));color:#ffffff;box-shadow:0 12px 24px -12px oklch(0.6381 calc(0.1873 * var(--tc)) calc(256.90deg + var(--tr)) / .8);flex:none}
.bgs{display:grid;grid-template-columns:auto auto;gap:6px 14px;align-items:center;justify-items:start}
.bgs .st{font-weight:800;letter-spacing:.1em;font-size:12px;color:var(--m)}.bgs .st.on{color:#ffffff}
.bgs small{grid-column:1 / -1;color:var(--m);font-size:12px}

/* menu mais compacto em janelas baixas */
@media (max-height:900px){.it{height:40px}.it .tl{width:26px;height:26px;border-radius:8px}.itens{gap:2px}.gp{margin:10px 10px 4px}.marca{padding-bottom:10px}.nv .fim{padding-top:8px;gap:8px}.adm{padding:8px 12px}}
@media (max-height:800px){.nv{padding:12px 10px 10px}.marca{padding:0 8px 6px}.marca .emb{width:36px;height:36px}.marca small{display:none}.it{height:35px;font-size:13px;gap:10px}.it .tl{width:24px;height:24px;border-radius:7px}.it .ico{width:17px;height:17px}.itens{gap:1px}.gp{margin:7px 10px 3px}.nv .fim{padding-top:6px;gap:6px}.adm{padding:6px 10px;font-size:11.5px}.adm small{display:none}.ver{display:none}}


/* ===== OTIMIZAÇÃO EXTREMA ===== */
:root{--x1:#ffb36b;--x2:oklch(0.8054 calc(0.1171 * var(--tc)) calc(233.51deg + var(--tr)));--x3:oklch(0.7911 calc(0.1025 * var(--tc)) calc(255.14deg + var(--tr)));--x4:oklch(0.8350 calc(0.1405 * var(--tc)) calc(212.94deg + var(--tr)))}
.it.xt .tl{background:linear-gradient(135deg,oklch(0.5201 calc(0.2698 * var(--tc)) calc(274.34deg + var(--tr))),oklch(0.7406 calc(0.1286 * var(--tc)) calc(244.09deg + var(--tr))));border-color:transparent;color:#ffffff;box-shadow:0 0 16px -3px oklch(0.5201 calc(0.2698 * var(--tc)) calc(274.34deg + var(--tr)) / .7)}
.it.xt:hover .tl{background:linear-gradient(135deg,oklch(0.5680 calc(0.2416 * var(--tc)) calc(278.55deg + var(--tr))),oklch(0.7460 calc(0.1258 * var(--tc)) calc(255.96deg + var(--tr))));border-color:transparent}
.it.xt .nov{margin-left:auto;font-size:9px;font-weight:900;letter-spacing:.1em;padding:2px 7px;border-radius:999px;background:linear-gradient(90deg,oklch(0.5201 calc(0.2698 * var(--tc)) calc(274.34deg + var(--tr))),oklch(0.7743 calc(0.1289 * var(--tc)) calc(239.61deg + var(--tr))));color:#ffffff;animation:respira 2.2s ease-in-out infinite}
.rk.xt{color:#ffc89a;border-color:#7a3f12;background:oklch(0.5201 calc(0.2698 * var(--tc)) calc(274.34deg + var(--tr)) / .1)}

.xhero{position:relative;overflow:hidden;display:grid;grid-template-columns:minmax(0,1.15fr) minmax(250px,.85fr);gap:26px;align-items:center;padding:30px 36px;border-radius:22px;margin-bottom:16px;border:1px solid oklch(0.4457 calc(0.0920 * var(--tc)) calc(255.54deg + var(--tr)));background:radial-gradient(520px 340px at 80% 50%,oklch(0.7406 calc(0.1286 * var(--tc)) calc(244.09deg + var(--tr)) / .32),transparent 70%),radial-gradient(440px 280px at 4% 0%,oklch(0.5201 calc(0.2698 * var(--tc)) calc(274.34deg + var(--tr)) / .18),transparent 70%),linear-gradient(135deg,oklch(0.2330 calc(0.0463 * var(--tc)) calc(255.82deg + var(--tr))),#09121d 62%,#0a1626);--xa:#ffb36b;--xb:oklch(0.8054 calc(0.1171 * var(--tc)) calc(233.51deg + var(--tr)));--xc:oklch(0.7911 calc(0.1025 * var(--tc)) calc(255.14deg + var(--tr)));transition:border-color .6s,box-shadow .6s}
.xhero.fase-scan{--xa:oklch(0.8350 calc(0.1405 * var(--tc)) calc(212.94deg + var(--tr)));--xb:oklch(0.7397 calc(0.1294 * var(--tc)) calc(255.82deg + var(--tr)));--xc:oklch(0.7911 calc(0.1025 * var(--tc)) calc(255.14deg + var(--tr)));border-color:oklch(0.4706 calc(0.1150 * var(--tc)) calc(256.21deg + var(--tr)))}
.xhero.fase-run{--xa:oklch(0.8350 calc(0.1405 * var(--tc)) calc(212.94deg + var(--tr)));--xb:oklch(0.7121 calc(0.1456 * var(--tc)) calc(255.38deg + var(--tr)));--xc:oklch(0.5201 calc(0.2698 * var(--tc)) calc(274.34deg + var(--tr)));border-color:oklch(0.6811 calc(0.1618 * var(--tc)) calc(256.12deg + var(--tr)));box-shadow:0 0 0 1px oklch(0.6811 calc(0.1618 * var(--tc)) calc(256.12deg + var(--tr)) / .35),0 30px 80px -30px oklch(0.6811 calc(0.1618 * var(--tc)) calc(256.12deg + var(--tr)) / .85)}
.xhero.fase-done{--xa:#4ade80;--xb:#22d3ee;--xc:#86efac;border-color:#1f7a47;box-shadow:0 30px 80px -34px rgba(34,197,94,.55)}
.xhero::before{content:"";position:absolute;inset:0;background:repeating-linear-gradient(115deg,rgba(255,255,255,.04) 0 2px,transparent 2px 40px);pointer-events:none}
.xhero>*{position:relative;z-index:1}
.xhero>canvas.xpart{position:absolute;inset:0;width:100%;height:100%;z-index:0;pointer-events:none}
.xtag{display:inline-flex;align-items:center;gap:7px;padding:5px 12px 5px 9px;border-radius:999px;border:1px solid oklch(0.5201 calc(0.2698 * var(--tc)) calc(274.34deg + var(--tr)) / .45);background:oklch(0.5201 calc(0.2698 * var(--tc)) calc(274.34deg + var(--tr)) / .1);color:#ffc89a;font-size:10.5px;font-weight:800;letter-spacing:.14em}
.xtag .ico{width:14px;height:14px}
.xhero h2{margin:12px 0 8px;font-size:48px;line-height:1.02;font-weight:900;letter-spacing:-.01em;color:#ffffff}
.xhero h2 b{background:linear-gradient(90deg,var(--xa),var(--xb) 55%,var(--xc));-webkit-background-clip:text;background-clip:text;color:transparent}
.xhero p.xsub{margin:0 0 14px;max-width:520px;color:oklch(0.8701 calc(0.0386 * var(--tc)) calc(255.62deg + var(--tr)));line-height:1.55;font-size:14.5px;min-height:3.1em}
.xhero .xstat{display:flex;align-items:center;gap:9px;margin-bottom:18px;font-weight:700;color:#ffffff;min-height:22px}
.xhero .xstat i{flex:none;width:9px;height:9px;border-radius:50%;background:var(--xa);animation:pulsaX 2s ease-out infinite}
@keyframes pulsaX{0%{box-shadow:0 0 0 0 var(--xa)}70%,100%{box-shadow:0 0 0 10px transparent}}
.bt.xgo{border:0;color:#ffffff;min-height:60px;padding:0 34px;font-size:15.5px;letter-spacing:.05em;text-transform:uppercase;background:linear-gradient(110deg,oklch(0.5201 calc(0.2698 * var(--tc)) calc(274.34deg + var(--tr))),oklch(0.7604 calc(0.1379 * var(--tc)) calc(239.36deg + var(--tr))) 25%,oklch(0.7406 calc(0.1286 * var(--tc)) calc(244.09deg + var(--tr))) 50%,oklch(0.7604 calc(0.1379 * var(--tc)) calc(239.36deg + var(--tr))) 75%,oklch(0.5201 calc(0.2698 * var(--tc)) calc(274.34deg + var(--tr))) 100%);background-size:200% 100%;box-shadow:0 18px 40px -14px oklch(0.7355 calc(0.1429 * var(--tc)) calc(249.10deg + var(--tr)) / .85),inset 0 1px 0 rgba(255,255,255,.35);animation:xgrad 4s linear infinite}
@keyframes xgrad{to{background-position:200% 0}}
.bt.xgo::after{content:"";position:absolute;inset:0;border-radius:inherit;pointer-events:none;background:linear-gradient(110deg,transparent 34%,rgba(255,255,255,.45) 50%,transparent 66%) no-repeat;background-size:250% 100%;background-position:150% 0;animation:reflexo 3.2s ease-in-out infinite}
.bt.xgo:hover:not(:disabled){filter:brightness(1.1);transform:translateY(-2px) scale(1.02);background:linear-gradient(110deg,oklch(0.5201 calc(0.2698 * var(--tc)) calc(274.34deg + var(--tr))),oklch(0.7604 calc(0.1379 * var(--tc)) calc(239.36deg + var(--tr))) 25%,oklch(0.7406 calc(0.1286 * var(--tc)) calc(244.09deg + var(--tr))) 50%,oklch(0.7604 calc(0.1379 * var(--tc)) calc(239.36deg + var(--tr))) 75%,oklch(0.5201 calc(0.2698 * var(--tc)) calc(274.34deg + var(--tr))) 100%);background-size:200% 100%}
.bt.xgo:disabled{animation:none;opacity:1;background:linear-gradient(110deg,oklch(0.4137 calc(0.0876 * var(--tc)) calc(255.93deg + var(--tr))),oklch(0.4129 calc(0.0842 * var(--tc)) calc(255.59deg + var(--tr))));box-shadow:none;color:oklch(0.8701 calc(0.0386 * var(--tc)) calc(255.62deg + var(--tr)))}
.bt.xgo:disabled::after{display:none}
.bt.xgo .ico{width:22px;height:22px}
.xrein{margin-top:14px;display:flex;align-items:center;gap:12px;flex-wrap:wrap;padding:10px 14px;border-radius:12px;border:1px solid #5a3f12;background:rgba(245,158,11,.1);color:#fcd38b;font-weight:700}
.xrein[hidden]{display:none}

/* reator */
.xreator{position:relative;width:min(300px,100%);aspect-ratio:1;margin:0 auto;--v:1}
.xhero.fase-scan .xreator{--v:2.2}.xhero.fase-run .xreator{--v:4.5}.xhero.fase-done .xreator{--v:.5}
.xreator svg{position:relative;width:100%;height:100%;overflow:visible;z-index:1}
.xr1,.xr2,.xr3,.xo1,.xo2,.xo3,.xcore,.xhalo{transform-origin:50% 50%}
.xr1{animation:gira calc(44s / var(--v)) linear infinite}
.xr2{animation:gira calc(28s / var(--v)) linear infinite reverse}
.xr3{animation:gira calc(18s / var(--v)) linear infinite}
.xo1{animation:gira calc(7s / var(--v)) linear infinite}
.xo2{animation:gira calc(11s / var(--v)) linear infinite reverse}
.xo3{animation:gira calc(15s / var(--v)) linear infinite}
.xcore{animation:xbat calc(3.4s / var(--v)) ease-in-out infinite}
.xhalo{animation:xhalo calc(4.4s / var(--v)) ease-in-out infinite}
@keyframes xbat{0%,100%{transform:scale(1)}50%{transform:scale(1.045)}}
@keyframes xhalo{0%,100%{opacity:.8;transform:scale(1)}50%{opacity:.5;transform:scale(1.07)}}
.xsweep{position:absolute;inset:20.7%;border-radius:50%;z-index:2;pointer-events:none;opacity:0;background:conic-gradient(from 0deg,transparent 0 290deg,color-mix(in srgb,var(--xa) 60%,transparent) 360deg);mix-blend-mode:screen;transition:opacity .6s;animation:gira calc(3.2s / var(--v)) linear infinite}
.xhero.fase-scan .xsweep,.xhero.fase-run .xsweep{opacity:1}
.xc{position:absolute;inset:0;z-index:3;display:grid;place-content:center;text-align:center;pointer-events:none}
.xc b{font-size:48px;line-height:1;font-weight:900;font-variant-numeric:tabular-nums;color:#ffffff;text-shadow:0 0 26px oklch(0.7911 calc(0.1025 * var(--tc)) calc(255.14deg + var(--tr)) / .95)}
.xc b .ico{width:58px;height:58px;stroke-width:1.5;margin:0 auto;filter:drop-shadow(0 0 12px oklch(0.7911 calc(0.1025 * var(--tc)) calc(255.14deg + var(--tr)) / .9))}
.xc small{display:block;margin-top:6px;letter-spacing:.22em;font-size:10px;color:oklch(0.8854 calc(0.0414 * var(--tc)) calc(256.25deg + var(--tr)));font-weight:800;max-width:130px}

/* cartões de números */
.xcards .cd .nm{font-size:30px;margin-top:6px}
.xcards .cd p{font-size:12.5px;min-height:1.5em}
.xcards .xd{color:#86efac;font-weight:800}
.xcards .cd.vivo{border-color:oklch(0.3907 calc(0.0816 * var(--tc)) calc(255.32deg + var(--tr)))}
.xcorpo{display:grid;grid-template-columns:minmax(0,1.1fr) minmax(0,.9fr);gap:16px;margin-bottom:16px;align-items:start}
@media (max-width:1100px){.xcorpo{grid-template-columns:1fr}}
@media (max-width:920px){.xhero{grid-template-columns:1fr;padding:24px}.xhero h2{font-size:36px}.xreator{width:230px}}

/* passos */
.xps{display:grid;gap:8px;max-height:610px;overflow:auto;padding-right:4px;margin-top:12px;scroll-behavior:smooth}
.xps .ps{position:relative;overflow:hidden}
.xps .ps div{min-width:0}
.xps .ps small{white-space:normal;overflow:visible;text-overflow:clip;line-height:1.4}
.ps.pulado .pi{border-color:#a16207;color:#fbbf24;background:rgba(245,158,11,.08)}
.ps.pulado{border-color:#3d2c0c}
.ps.ok .pi{animation:pop .45s var(--ease) both}
.xps .ps.rodando{border-color:oklch(0.6811 calc(0.1618 * var(--tc)) calc(256.12deg + var(--tr)));background:#0d1622;box-shadow:0 0 0 1px oklch(0.6811 calc(0.1618 * var(--tc)) calc(256.12deg + var(--tr)) / .3),0 12px 32px -16px oklch(0.6811 calc(0.1618 * var(--tc)) calc(256.12deg + var(--tr)) / .95)}
.xps .ps.rodando::after{content:"";position:absolute;inset:0;background:linear-gradient(100deg,transparent 30%,oklch(0.7406 calc(0.1286 * var(--tc)) calc(244.09deg + var(--tr)) / .2) 50%,transparent 70%);transform:translateX(-100%);animation:xsheen 1.5s linear infinite;pointer-events:none}
@keyframes xsheen{to{transform:translateX(100%)}}
.xps .ps.rodando .pi{border-color:var(--x4);border-top-color:transparent}
.xps .ps.pendente{opacity:.78}
.ps .mb{flex:none;margin-left:auto;font-size:12px;font-weight:800;color:#86efac;background:rgba(34,197,94,.1);border:1px solid #14532d;border-radius:999px;padding:3px 10px;white-space:nowrap;animation:pop .4s var(--ease) both}

/* painel ao vivo e resultado */
.xlive{position:relative;overflow:hidden;border-color:oklch(0.3907 calc(0.0816 * var(--tc)) calc(255.32deg + var(--tr)))}
.xlive::before{content:"";position:absolute;left:0;right:0;top:0;height:2px;background:linear-gradient(90deg,transparent,oklch(0.7911 calc(0.1025 * var(--tc)) calc(255.14deg + var(--tr))),oklch(0.8350 calc(0.1405 * var(--tc)) calc(212.94deg + var(--tr))),transparent);animation:xscan 2.6s linear infinite;pointer-events:none}
@keyframes xscan{0%{transform:translateY(0);opacity:0}10%{opacity:1}90%{opacity:1}100%{transform:translateY(300px);opacity:0}}
.xlive .big{font-size:56px;font-weight:900;font-variant-numeric:tabular-nums;line-height:1;margin-top:8px;background:linear-gradient(90deg,oklch(0.8350 calc(0.1405 * var(--tc)) calc(212.94deg + var(--tr))),oklch(0.7911 calc(0.1025 * var(--tc)) calc(255.14deg + var(--tr))) 60%,oklch(0.5201 calc(0.2698 * var(--tc)) calc(274.34deg + var(--tr))));-webkit-background-clip:text;background-clip:text;color:transparent}
.xtick{margin-top:14px;display:grid;gap:5px;font:12px/1.45 "Cascadia Mono",Consolas,monospace;color:oklch(0.8278 calc(0.0844 * var(--tc)) calc(254.17deg + var(--tr)));min-height:110px}
.xtick div{animation:sobe .35s var(--ease) both;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.xtick div::before{content:"› ";color:oklch(0.7911 calc(0.1025 * var(--tc)) calc(255.14deg + var(--tr)))}
.xtick div:last-child{color:#ffffff}
.xres .rl{display:flex;align-items:center;gap:13px;padding:11px 0;border-bottom:1px solid #161b22;animation:sobe .5s var(--ease) both;animation-delay:calc(var(--k,0)*80ms)}
.xres .rl:last-of-type{border-bottom:0}
.xres .rl .ri{flex:none;width:38px;height:38px;border-radius:11px;display:grid;place-items:center;background:rgba(34,197,94,.12);color:#4ade80}
.xres .rl b{display:block;font-size:19px;font-variant-numeric:tabular-nums}
.xres .rl span{color:var(--m);font-size:12.5px;display:block;line-height:1.4}
.xres .linha{margin-top:16px}
.xo{display:flex;align-items:center;gap:14px;padding:13px 0;border-bottom:1px solid #161b22}
.xo:last-child{border-bottom:0}
.xo>div{flex:1;min-width:0}.xo b{display:block;font-size:14px}.xo small{display:block;color:var(--m);line-height:1.4;margin-top:2px;font-size:12.5px}
.xb{display:grid;grid-template-columns:150px 1fr 74px;gap:12px;align-items:center;padding:7px 0}
.xb span{color:#cfd7e1;font-size:13px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.xb .tr{height:8px;border-radius:8px;background:#1b2028;overflow:hidden}
.xb .tr i{display:block;height:100%;width:0;border-radius:8px;background:linear-gradient(90deg,var(--x3),var(--x2),var(--x1));box-shadow:0 0 10px oklch(0.8054 calc(0.1171 * var(--tc)) calc(233.51deg + var(--tr)) / .45);transition:width 1.1s var(--ease)}
.xb b{text-align:right;font-variant-numeric:tabular-nums;font-size:13px}
.xsk{height:16px;border-radius:8px;margin:13px 0;background:linear-gradient(90deg,#10141a,#1b2430,#10141a);background-size:200% 100%;animation:brilhoSk 1.4s linear infinite}
.xseg{margin:10px 0 0;padding:0;list-style:none;display:grid;grid-template-columns:repeat(auto-fit,minmax(300px,1fr));gap:10px 22px}
.xseg li{display:flex;gap:10px;align-items:flex-start;color:#cfd7e1;line-height:1.5;font-size:13.5px}
.xseg li .ico{flex:none;width:18px;height:18px;margin-top:2px;color:#4ade80}
.xseg li b{color:#ffffff}
.otlib{display:flex;align-items:baseline;justify-content:space-between;gap:12px;margin-top:16px;padding:12px 16px;border-radius:13px;background:#0c1520;border:1px solid oklch(0.2879 calc(0.0641 * var(--tc)) calc(256.47deg + var(--tr)))}
.otlib span{color:var(--m)}.otlib b{font-size:22px;font-variant-numeric:tabular-nums;color:oklch(0.8611 calc(0.0663 * var(--tc)) calc(255.51deg + var(--tr)))}
.hero .linha{gap:12px}
.hero .bt.xbtn{background:rgba(7,16,28,.38);border:1px solid rgba(255,255,255,.4);color:#ffffff;backdrop-filter:blur(6px)}
.hero .bt.xbtn:hover:not(:disabled){background:rgba(7,16,28,.55);border-color:#ffffff}
.hero .bt.xbtn .ico{color:#ffc89a}

/* enquanto roda a Otimização Extrema, o programa todo "esquenta" */
body.xrun #fundo::before{content:"";position:absolute;inset:0;background:radial-gradient(700px 420px at 50% 0%,oklch(0.7406 calc(0.1286 * var(--tc)) calc(244.09deg + var(--tr)) / .26),transparent 70%),radial-gradient(600px 400px at 50% 112%,oklch(0.5201 calc(0.2698 * var(--tc)) calc(274.34deg + var(--tr)) / .2),transparent 70%);animation:respira 2.4s ease-in-out infinite}
body.xrun .prog b{background:linear-gradient(90deg,oklch(0.5201 calc(0.2698 * var(--tc)) calc(274.34deg + var(--tr))),oklch(0.7604 calc(0.1379 * var(--tc)) calc(239.36deg + var(--tr))),oklch(0.7406 calc(0.1286 * var(--tc)) calc(244.09deg + var(--tr))),oklch(0.8350 calc(0.1405 * var(--tc)) calc(212.94deg + var(--tr))),oklch(0.5201 calc(0.2698 * var(--tc)) calc(274.34deg + var(--tr))));background-size:300% 100%;animation:xgrad 2s linear infinite}
html.leve .xr1,html.leve .xr2,html.leve .xr3,html.leve .xo1,html.leve .xo2,html.leve .xo3,html.leve .xcore,html.leve .xhalo,html.leve .xsweep,html.leve .bt.xgo,html.leve .bt.xgo::after,html.leve .xlive::before,html.leve .xps .ps.rodando::after,html.leve .it.xt .nov,html.leve .xhero .xstat i,html.leve body.xrun #fundo::before,html.leve body.xrun .prog b{animation:none!important}
html.leve .xhero>canvas.xpart{display:none}
@media (prefers-reduced-motion:reduce){.xr1,.xr2,.xr3,.xo1,.xo2,.xo3,.xcore,.xhalo,.xsweep,.xps .ps.rodando::after{animation:none}}

/* modo leve: sem efeitos que ficam rodando sozinhos nem desfoques */
html.leve .cd.led::after,html.leve .hero .feixe,html.leve .emb .orb,html.leve .emb .orb2,html.leve .pilula::after,html.leve .bt.p::after,html.leve .adm i,html.leve .hero .est i{animation:none!important}
html.leve .cd.led::after{display:none}
html.leve *,html.leve *::before,html.leve *::after{backdrop-filter:none!important;filter:none!important;text-shadow:none!important}
html.leve .it:hover .ico,html.leve .tile:hover .ico{animation:none}
html.leve #boot{transition:opacity .25s}html.leve #boot.some{transform:none}
html.leve .cd:hover,html.leve .tile:hover,html.leve .jc:hover{transform:none}
@media (prefers-reduced-motion:reduce){.pg.ent>*,.hi,.jc{animation:none}}

/* ===== v8.0: menu em grupos que abrem e fecham, painéis de tarefa e novas páginas ===== */
[hidden]{display:none!important}
.gp{cursor:pointer;user-select:none;-webkit-user-select:none;border-radius:8px;transition:color .2s}
.gp:hover{color:#8b97a5}
.gp .chev{flex:none;width:14px;height:14px;color:#616d7d;transition:transform .25s var(--ease)}
.gp.fecha .chev{transform:rotate(-90deg)}
.itens.fecha{display:none}
.it.novo .nov{margin-left:auto;font-size:9px;font-weight:900;letter-spacing:.1em;padding:2px 7px;border-radius:999px;background:var(--r);color:#fff}
.rk.sp{color:oklch(0.9030 calc(0.0516 * var(--tc)) calc(242.16deg + var(--tr)));border-color:oklch(0.5182 calc(0.0789 * var(--tc)) calc(223.95deg + var(--tr)));background:oklch(0.7156 calc(0.1541 * var(--tc)) calc(250.00deg + var(--tr)) / .1)}
.rk.cz{color:#9aa6b5;border-color:#2a323c;background:rgba(255,255,255,.03)}
.rk.vd{color:#86efac;border-color:#14532d;background:rgba(34,197,94,.08)}
.rk.am{color:#fcd38b;border-color:#5a3f12;background:rgba(245,158,11,.1)}
.rk.az{color:oklch(0.8224 calc(0.0870 * var(--tc)) calc(255.07deg + var(--tr)));border-color:oklch(0.4220 calc(0.1135 * var(--tc)) calc(256.34deg + var(--tr)));background:oklch(0.6441 calc(0.1768 * var(--tc)) calc(256.55deg + var(--tr)) / .1)}
.rk.vl2{color:oklch(0.9128 calc(0.0454 * var(--tc)) calc(240.16deg + var(--tr)));border-color:oklch(0.5556 calc(0.0979 * var(--tc)) calc(243.46deg + var(--tr)));background:oklch(0.7406 calc(0.1286 * var(--tc)) calc(244.09deg + var(--tr)) / .12)}
.sub2{color:var(--m);font-size:12.5px;line-height:1.45}
.ti2{flex:none;width:42px;height:42px;border-radius:12px;display:grid;place-items:center;background:#121a24;color:oklch(0.7160 calc(0.1430 * var(--tc)) calc(255.97deg + var(--tr)))}
.ti2.laranja{background:linear-gradient(135deg,oklch(0.5201 calc(0.2698 * var(--tc)) calc(274.34deg + var(--tr))),oklch(0.7406 calc(0.1286 * var(--tc)) calc(244.09deg + var(--tr))));color:#fff}
.ti2.verde{background:linear-gradient(135deg,#16a34a,oklch(0.5198 calc(0.0936 * var(--tc)) calc(223.13deg + var(--tr))));color:#fff}

/* barra de sessão de jogo (aparece em todas as páginas) */
.sessb{display:flex;align-items:center;gap:14px;margin:0 32px 10px;padding:10px 16px;border-radius:14px;border:1px solid #1f7a47;background:linear-gradient(90deg,rgba(34,197,94,.16),rgba(34,197,94,.04));color:#bbf7d0;line-height:1.4}
.sessb>i{width:9px;height:9px;border-radius:50%;background:#4ade80;flex:none;animation:pulsa 2.4s ease-out infinite}
.sessb>span{flex:1;min-width:0}
.sessb b{color:#fff}

/* painel de tarefa (correções, backup, processos, espaço) */
.jp{margin-bottom:16px;border-color:oklch(0.2879 calc(0.0641 * var(--tc)) calc(256.47deg + var(--tr)))}
.jph{display:flex;justify-content:space-between;align-items:flex-start;gap:14px;margin-bottom:12px}
.jph h3{margin:0 0 4px}
.jst{font-size:15px}.jst.run{color:oklch(0.8224 calc(0.0870 * var(--tc)) calc(255.07deg + var(--tr)))}.jst.ok{color:#86efac}.jst.pulado{color:#fcd38b}.jst.erro{color:#fca5a5}
.jbar{height:6px;border-radius:6px;background:#1b2028;overflow:hidden;margin-bottom:12px}
.jbar i{display:block;height:100%;border-radius:6px;background:linear-gradient(90deg,oklch(0.3991 calc(0.1348 * var(--tc)) calc(257.87deg + var(--tr))),var(--r),oklch(0.7361 calc(0.1317 * var(--tc)) calc(255.43deg + var(--tr))));transition:width .5s var(--ease)}
.jps{margin-top:0}
.jps .ps small{white-space:normal;overflow:visible;text-overflow:clip;line-height:1.4}
.jres{margin-top:14px;padding:12px 14px;border-radius:13px;background:#0c1520;border:1px solid oklch(0.2879 calc(0.0641 * var(--tc)) calc(256.47deg + var(--tr)));line-height:1.55;color:#cfd7e1}
.jres b{color:#fff}
.jres.ant{display:flex;align-items:center;gap:18px;flex-wrap:wrap}
.jres .gr2{font-size:26px;font-weight:800;font-variant-numeric:tabular-nums;color:#fff}
.jres .gr2 small{display:block;font-size:11.5px;color:var(--m);font-weight:600}
.jres .sa{color:#4ade80}

/* dashboard */
.dh{display:grid;grid-template-columns:auto minmax(0,1fr) minmax(280px,.85fr);gap:30px;align-items:center;padding:26px 30px;margin-bottom:16px}
.dh .anel{margin:0}
.dh .anel .vl{stroke:var(--cs,oklch(0.6588 calc(0.1751 * var(--tc)) calc(256.28deg + var(--tr))));filter:drop-shadow(0 0 8px var(--cs,oklch(0.6588 calc(0.1751 * var(--tc)) calc(256.28deg + var(--tr)))))}
.dh h2{margin:0 0 6px;font-size:30px}
.dh .tx{max-width:520px;color:#c3ccd8;line-height:1.55}
.dh .sts{display:grid;grid-template-columns:1fr 1fr;gap:12px}
.dh .st1{padding:12px 14px;border-radius:14px;background:#0e1218;border:1px solid #1b2028}
.dh .st1 b{display:block;font-size:22px;font-variant-numeric:tabular-nums}
.dh .st1 span{color:var(--m);font-size:12px}
.sc-bom{--cs:#22c55e}.sc-ok{--cs:oklch(0.6588 calc(0.1751 * var(--tc)) calc(256.28deg + var(--tr)))}.sc-med{--cs:#f59e0b}.sc-ruim{--cs:#ef4444}.sc-nd{--cs:#4b5460}
.cats{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:14px;margin-bottom:16px}
.ctg{text-align:left;display:flex;flex-direction:column;gap:9px;padding:16px;border-radius:16px;border:1px solid #1d232b;background:#0e1218;transition:transform .3s var(--ease),border-color .3s,box-shadow .3s}
.ctg:hover{border-color:var(--cs);transform:translateY(-2px);box-shadow:0 16px 32px -22px var(--cs)}
.ctg .tp{display:flex;justify-content:space-between;align-items:baseline;gap:8px}
.ctg b{font-size:14px}
.ctg .vn{font-size:22px;font-weight:800;font-variant-numeric:tabular-nums}
.ctg .tr{height:7px;border-radius:7px;background:#1b2028;overflow:hidden}
.ctg .tr i{display:block;height:100%;width:0;border-radius:7px;background:var(--cs);box-shadow:0 0 10px var(--cs);transition:width .9s var(--ease)}
.ctg small{color:var(--m);font-size:12px;line-height:1.4;min-height:2.8em}
.ac{display:flex;gap:14px;align-items:flex-start;padding:14px 4px;border-bottom:1px solid #161b22}
.ac:last-child{border-bottom:0}
.ac .pt{flex:none;width:10px;height:10px;border-radius:50%;margin-top:6px;background:var(--cs);box-shadow:0 0 10px var(--cs)}
.ac.ruim{--cs:#ef4444}.ac.aviso{--cs:#f59e0b}.ac.info{--cs:oklch(0.6588 calc(0.1751 * var(--tc)) calc(256.28deg + var(--tr)))}
.ac>div{flex:1;min-width:0}.ac b{display:block}.ac span{color:var(--m);font-size:13px;line-height:1.45}
.ac .bt{flex:none}
.lendo{display:inline-flex;align-items:center;gap:8px;color:oklch(0.8224 calc(0.0870 * var(--tc)) calc(255.07deg + var(--tr)));font-size:12px;font-weight:700}
.lendo::before{content:"";width:12px;height:12px;border-radius:50%;border:2px solid oklch(0.8224 calc(0.0870 * var(--tc)) calc(255.07deg + var(--tr)));border-top-color:transparent;animation:gira .8s linear infinite}

/* listas em linhas (processos, programas, arquivos) */
.lr{display:grid;grid-template-columns:minmax(0,1fr) auto auto auto;gap:6px 14px;align-items:center;padding:11px 14px;border-radius:13px;background:#0e1218;border:1px solid #1b2028}
.lr+.lr{margin-top:8px}
.lr:hover{border-color:#222c3a}
.lr b{display:block;font-size:14px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.lr small{display:block;color:var(--m);font-size:12px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.lr .n{font-variant-numeric:tabular-nums;font-weight:700;text-align:right;min-width:74px;white-space:nowrap}
.lr .bt{min-height:34px;padding:0 14px;font-size:12.5px}
.lr .rk{justify-self:end}
.lr.fixo{background:#0b0e12}
.lr.fixo b{color:#cfd7e1}
.lr.cinza{opacity:.82}
.lrs{max-height:560px;overflow:auto;padding-right:4px}
@media (max-width:900px){.lr{grid-template-columns:minmax(0,1fr) auto}.lr .rk,.lr .n:nth-of-type(1){display:none}}
.chips{display:flex;gap:8px;flex-wrap:wrap;margin:10px 0 14px}
.chip{padding:6px 13px;border-radius:999px;border:1px solid #232b34;background:#10141a;color:#a9b3c0;font-size:12.5px;font-weight:700;transition:border-color .2s,color .2s,background .2s}
.chip:hover{border-color:oklch(0.3791 calc(0.1079 * var(--tc)) calc(256.88deg + var(--tr)));color:#fff}
.chip.on{background:var(--r);border-color:var(--r);color:#fff}
.chip small{opacity:.75;margin-left:4px;font-weight:600}
.tabs{display:flex;gap:6px;padding:5px;border-radius:14px;background:#0b0e12;border:1px solid #1d232b;width:max-content;max-width:100%;margin-bottom:16px;overflow:auto}
.tabs button{border:0;background:transparent;color:#a9b3c0;padding:9px 18px;border-radius:10px;font-weight:700;white-space:nowrap;transition:background .2s,color .2s}
.tabs button:hover{color:#fff}
.tabs button.on{background:linear-gradient(135deg,oklch(0.6588 calc(0.1751 * var(--tc)) calc(256.28deg + var(--tr))),oklch(0.5318 calc(0.1826 * var(--tc)) calc(257.98deg + var(--tr))));color:#fff;box-shadow:0 8px 20px -10px oklch(0.6381 calc(0.1873 * var(--tc)) calc(256.90deg + var(--tr)) / .9)}
.inp{width:100%;min-height:42px;padding:0 14px;border-radius:12px;border:1px solid #232b34;background:#0b0e12;color:var(--t);font:inherit;user-select:text;-webkit-user-select:text}
.inp:focus{outline:2px solid oklch(0.7917 calc(0.1020 * var(--tc)) calc(255.59deg + var(--tr)));outline-offset:1px;border-color:oklch(0.3791 calc(0.1079 * var(--tc)) calc(256.88deg + var(--tr)))}
.bsc{display:flex;gap:12px;align-items:center;flex-wrap:wrap;margin-bottom:6px}
.bsc .inp{max-width:360px}

/* processos */
.ph{display:grid;grid-template-columns:minmax(0,1.05fr) minmax(0,.95fr);gap:26px;padding:26px 30px;margin-bottom:16px;position:relative;overflow:hidden;border-radius:22px;border:1px solid oklch(0.2879 calc(0.0641 * var(--tc)) calc(256.47deg + var(--tr)));background:radial-gradient(520px 300px at 90% 20%,oklch(0.6381 calc(0.1873 * var(--tc)) calc(256.90deg + var(--tr)) / .22),transparent 70%),linear-gradient(135deg,#0a1626,#090d12 70%)}
.ph h2{margin:0;font-size:46px;line-height:1.02;font-weight:900;color:#fff;font-variant-numeric:tabular-nums}
.ph h2 small{font-size:18px;color:oklch(0.8224 calc(0.0870 * var(--tc)) calc(255.07deg + var(--tr)));font-weight:700;margin-left:8px}
.ph .sub2{margin:8px 0 16px;max-width:480px;color:#b8c2cf}
.pcat{display:grid;gap:9px;align-content:center}
.pcat .xb{grid-template-columns:130px 1fr 96px}
.pcat .xb b{font-size:12px;white-space:nowrap}
.pcat .xb .tr i{background:linear-gradient(90deg,oklch(0.3991 calc(0.1348 * var(--tc)) calc(257.87deg + var(--tr))),var(--r),oklch(0.7361 calc(0.1317 * var(--tc)) calc(255.43deg + var(--tr))));box-shadow:0 0 10px oklch(0.6381 calc(0.1873 * var(--tc)) calc(256.90deg + var(--tr)) / .45)}
@media (max-width:1100px){.ph{grid-template-columns:1fr}}

/* jogos */
.jhero{position:relative;overflow:hidden;display:grid;grid-template-columns:minmax(0,1.05fr) minmax(0,.95fr);gap:26px;align-items:start;padding:28px 32px;border-radius:22px;margin-bottom:16px;border:1px solid #1f7a47;background:radial-gradient(520px 320px at 88% 30%,rgba(34,211,238,.18),transparent 70%),radial-gradient(420px 260px at 0% 0%,rgba(74,222,128,.18),transparent 70%),linear-gradient(135deg,#071a18,#08101a 60%,#0a1320);transition:border-color .5s,box-shadow .5s}
.jhero.run{border-color:#22d3ee;box-shadow:0 0 0 1px rgba(34,211,238,.3),0 30px 70px -34px rgba(34,211,238,.7)}
.jhero::before{content:"";position:absolute;inset:0;background:repeating-linear-gradient(115deg,rgba(255,255,255,.035) 0 2px,transparent 2px 40px);pointer-events:none}
.jhero>*{position:relative;z-index:1}
.jtag{display:inline-flex;align-items:center;gap:7px;padding:5px 12px 5px 9px;border-radius:999px;border:1px solid rgba(74,222,128,.45);background:rgba(74,222,128,.1);color:#a7f3d0;font-size:10.5px;font-weight:800;letter-spacing:.14em}
.jtag .ico{width:14px;height:14px}
.jhero h2{margin:12px 0 8px;font-size:44px;line-height:1.02;font-weight:900;color:#fff}
.jhero h2 b{background:linear-gradient(90deg,#4ade80,#22d3ee);-webkit-background-clip:text;background-clip:text;color:transparent}
.jhero p.sub2{margin:0 0 14px;max-width:520px;color:#c3d4d0;font-size:14.5px;line-height:1.55;min-height:3.1em}
.jhero .xstat{display:flex;align-items:center;gap:9px;margin-bottom:18px;font-weight:700;color:#fff;min-height:22px}
.jhero .xstat i{flex:none;width:9px;height:9px;border-radius:50%;background:#4ade80;animation:pulsaV 2s ease-out infinite}
@keyframes pulsaV{0%{box-shadow:0 0 0 0 #4ade80}70%,100%{box-shadow:0 0 0 10px transparent}}
.bt.jgo{border:0;color:#fff;min-height:58px;padding:0 30px;font-size:15px;letter-spacing:.05em;text-transform:uppercase;background:linear-gradient(135deg,#22c55e,#0e9f6e 55%,oklch(0.5731 calc(0.1011 * var(--tc)) calc(218.24deg + var(--tr))));box-shadow:0 18px 40px -14px rgba(34,197,94,.85),inset 0 1px 0 rgba(255,255,255,.3)}
.bt.jgo:hover:not(:disabled){filter:brightness(1.1);transform:translateY(-2px);background:linear-gradient(135deg,#22c55e,#0e9f6e 55%,oklch(0.5731 calc(0.1011 * var(--tc)) calc(218.24deg + var(--tr))))}
.bt.jgo.fim{background:linear-gradient(135deg,#ef4444,#be185d)}
.bt.jgo:disabled{background:#16352f;color:#7fb5a6;box-shadow:none}
.bt.jgo .ico{width:22px;height:22px}
.jlado .xo b{font-size:13.5px}
.jlado .xo small{font-size:12px}
.jlado .ps{margin-bottom:8px}
.jlado .ps small{white-space:normal;overflow:visible;text-overflow:clip;line-height:1.4}
.jlado .rl{display:flex;align-items:center;gap:12px;padding:9px 0;border-bottom:1px solid #123027}
.jlado .rl:last-of-type{border-bottom:0}
.jlado .rl .ri{flex:none;width:34px;height:34px;border-radius:10px;display:grid;place-items:center;background:rgba(34,197,94,.14);color:#4ade80}
.jlado .rl b{display:block;font-size:17px;font-variant-numeric:tabular-nums}
.jlado .rl span{display:block;color:#9fb8b0;font-size:12.5px;line-height:1.4}
@media (max-width:1000px){.jhero{grid-template-columns:1fr}.jhero h2{font-size:34px}}
.jc .linha .bt.pj{flex:1.4}

/* extremo: seletor de nível e visual Suprema */
.nivel{display:inline-flex;padding:4px;border-radius:999px;background:rgba(7,16,28,.55);border:1px solid rgba(255,255,255,.14);margin:12px 0 0}
.nivel button{border:0;background:transparent;color:oklch(0.8701 calc(0.0386 * var(--tc)) calc(255.62deg + var(--tr)));padding:7px 18px;border-radius:999px;font-weight:800;letter-spacing:.09em;font-size:11.5px;transition:background .25s,color .25s,box-shadow .25s}
.nivel button:hover:not(:disabled):not(.on){color:#fff}
.nivel button.on{background:linear-gradient(135deg,oklch(0.5201 calc(0.2698 * var(--tc)) calc(274.34deg + var(--tr))),oklch(0.7406 calc(0.1286 * var(--tc)) calc(244.09deg + var(--tr))));color:#fff;box-shadow:0 8px 20px -8px oklch(0.5201 calc(0.2698 * var(--tc)) calc(274.34deg + var(--tr)) / .8)}
.nivel button.on[data-nivel=suprema]{background:linear-gradient(135deg,#ffb020,oklch(0.6824 calc(0.1717 * var(--tc)) calc(252.91deg + var(--tr))) 55%,oklch(0.6085 calc(0.1433 * var(--tc)) calc(246.89deg + var(--tr))));box-shadow:0 8px 22px -8px oklch(0.6824 calc(0.1717 * var(--tc)) calc(252.91deg + var(--tr)) / .9)}
.nivel button:disabled{opacity:.55;cursor:default}
.xhero.sup.fase-idle{--xa:#ffd34d;--xb:oklch(0.7156 calc(0.1541 * var(--tc)) calc(250.00deg + var(--tr)));--xc:oklch(0.6982 calc(0.1405 * var(--tc)) calc(245.43deg + var(--tr)));border-color:oklch(0.5182 calc(0.0789 * var(--tc)) calc(223.95deg + var(--tr)));box-shadow:0 30px 80px -36px oklch(0.6824 calc(0.1717 * var(--tc)) calc(252.91deg + var(--tr)) / .55);background:radial-gradient(520px 340px at 80% 50%,oklch(0.6982 calc(0.1405 * var(--tc)) calc(245.43deg + var(--tr)) / .30),transparent 70%),radial-gradient(440px 280px at 4% 0%,rgba(255,176,32,.24),transparent 70%),linear-gradient(135deg,#0a1620,#08121a 62%,#0a1924)}
.xhero.sup .xtag{border-color:oklch(0.7156 calc(0.1541 * var(--tc)) calc(250.00deg + var(--tr)) / .55);background:oklch(0.7156 calc(0.1541 * var(--tc)) calc(250.00deg + var(--tr)) / .12);color:oklch(0.9030 calc(0.0516 * var(--tc)) calc(242.16deg + var(--tr)))}
.xhero.sup .bt.xgo:not(:disabled),.xhero.sup .bt.xgo:hover:not(:disabled){background:linear-gradient(110deg,#ffb020,oklch(0.6824 calc(0.1717 * var(--tc)) calc(252.91deg + var(--tr))) 25%,oklch(0.6085 calc(0.1433 * var(--tc)) calc(246.89deg + var(--tr))) 50%,oklch(0.6824 calc(0.1717 * var(--tc)) calc(252.91deg + var(--tr))) 75%,#ffb020 100%);background-size:200% 100%;box-shadow:0 18px 40px -14px oklch(0.6824 calc(0.1717 * var(--tc)) calc(252.91deg + var(--tr)) / .9),inset 0 1px 0 rgba(255,255,255,.35)}
.xhero.sup .xc b{text-shadow:0 0 26px oklch(0.7156 calc(0.1541 * var(--tc)) calc(250.00deg + var(--tr)) / .95)}
.xhero.sup .xc b .ico{filter:drop-shadow(0 0 12px oklch(0.7156 calc(0.1541 * var(--tc)) calc(250.00deg + var(--tr)) / .9))}
.it.xt.sup .tl{background:linear-gradient(135deg,#ffb020,oklch(0.6824 calc(0.1717 * var(--tc)) calc(252.91deg + var(--tr))) 55%,oklch(0.6085 calc(0.1433 * var(--tc)) calc(246.89deg + var(--tr))))}
.xsup{margin:12px 0 0;padding:10px 14px;border-radius:12px;border:1px solid oklch(0.5182 calc(0.0789 * var(--tc)) calc(223.95deg + var(--tr)));background:oklch(0.7156 calc(0.1541 * var(--tc)) calc(250.00deg + var(--tr)) / .08);color:oklch(0.9030 calc(0.0516 * var(--tc)) calc(242.16deg + var(--tr)));font-size:12.5px;line-height:1.5}
.xsup b{color:#fff}

/* backup / ferramentas / correções */
.cr{display:flex;flex-direction:column;gap:10px}
.cr .crt{display:flex;gap:13px;align-items:flex-start}
.cr .crt b{display:block;font-size:15.5px;margin-bottom:5px}
.cr .crt .rk{margin-right:5px}
.cr p{margin:0;flex:1;font-size:13px}
.crg{display:grid;grid-template-columns:repeat(auto-fill,minmax(380px,1fr));gap:14px;margin-bottom:16px}
.pl.dest{grid-template-columns:repeat(auto-fill,minmax(230px,1fr));margin-top:10px}
.pc.sel{border-color:var(--r);background:linear-gradient(145deg,oklch(0.2077 calc(0.0405 * var(--tc)) calc(256.80deg + var(--tr))),#0e1218);box-shadow:0 18px 36px -22px var(--r)}
.pt-l{display:flex;justify-content:space-between;gap:14px;align-items:center;padding:11px 4px;border-bottom:1px solid #161b22}
.pt-l:last-child{border-bottom:0}
.pt-l b{display:block;font-size:14px}.pt-l small{color:var(--m)}
.pt-l time{color:var(--r3);font-weight:800;font-size:12.5px;font-variant-numeric:tabular-nums;white-space:nowrap}
.gb2{display:grid;grid-template-columns:repeat(auto-fill,minmax(250px,1fr));gap:14px;margin-bottom:16px}
.atg{display:flex;flex-direction:column;gap:8px}
.atg b{font-size:15px}.atg p{margin:0;flex:1;font-size:12.5px}
.sp3{height:16px}
.lr.p3{grid-template-columns:minmax(0,1fr) auto auto}
.gp::after{order:1}.gp .chev{order:2}

/* ===== Otimização Extrema / Suprema em VERMELHO ===== */
:root{--x1:oklch(0.7226 calc(0.1432 * var(--tc)) calc(268.58deg + var(--tr)));--x2:oklch(0.6416 calc(0.1927 * var(--tc)) calc(259.09deg + var(--tr)));--x3:oklch(0.5270 calc(0.1601 * var(--tc)) calc(254.29deg + var(--tr)));--x4:oklch(0.7028 calc(0.1550 * var(--tc)) calc(263.09deg + var(--tr)))}
.it.xt .tl,.it.xt.sup .tl{background:linear-gradient(135deg,oklch(0.6823 calc(0.1676 * var(--tc)) calc(260.78deg + var(--tr))),oklch(0.5270 calc(0.1601 * var(--tc)) calc(254.29deg + var(--tr))));border-color:transparent;color:#fff;box-shadow:0 0 16px -3px oklch(0.6416 calc(0.1927 * var(--tc)) calc(259.09deg + var(--tr)) / .75)}
.it.xt:hover .tl{background:linear-gradient(135deg,oklch(0.7131 calc(0.1495 * var(--tc)) calc(260.83deg + var(--tr))),oklch(0.5495 calc(0.1778 * var(--tc)) calc(256.64deg + var(--tr))));border-color:transparent}
.rk.xt{color:oklch(0.8787 calc(0.0591 * var(--tc)) calc(261.89deg + var(--tr)));border-color:oklch(0.4358 calc(0.1059 * var(--tc)) calc(254.58deg + var(--tr)));background:oklch(0.6416 calc(0.1927 * var(--tc)) calc(259.09deg + var(--tr)) / .12)}
.rk.sp{color:oklch(0.9085 calc(0.0443 * var(--tc)) calc(259.95deg + var(--tr)));border-color:oklch(0.4711 calc(0.1315 * var(--tc)) calc(256.56deg + var(--tr)));background:oklch(0.6274 calc(0.2017 * var(--tc)) calc(258.47deg + var(--tr)) / .14)}
.ti2.laranja{background:linear-gradient(135deg,oklch(0.6823 calc(0.1676 * var(--tc)) calc(260.78deg + var(--tr))),oklch(0.5270 calc(0.1601 * var(--tc)) calc(254.29deg + var(--tr))));color:#fff}
.xhero{border-color:oklch(0.3745 calc(0.0880 * var(--tc)) calc(253.06deg + var(--tr)));background:radial-gradient(520px 340px at 80% 50%,oklch(0.6078 calc(0.1870 * var(--tc)) calc(256.04deg + var(--tr)) / .30),transparent 70%),radial-gradient(440px 280px at 4% 0%,oklch(0.5636 calc(0.2395 * var(--tc)) calc(267.91deg + var(--tr)) / .16),transparent 70%),linear-gradient(135deg,#0a151d,#081013 62%,#0a1417);--xa:oklch(0.7547 calc(0.1251 * var(--tc)) calc(269.67deg + var(--tr)));--xb:oklch(0.6416 calc(0.1927 * var(--tc)) calc(259.09deg + var(--tr)));--xc:oklch(0.5601 calc(0.1892 * var(--tc)) calc(256.90deg + var(--tr)))}
.xhero.fase-scan{--xa:oklch(0.7814 calc(0.1119 * var(--tc)) calc(277.32deg + var(--tr)));--xb:oklch(0.7028 calc(0.1550 * var(--tc)) calc(263.09deg + var(--tr)));--xc:oklch(0.6274 calc(0.2017 * var(--tc)) calc(258.47deg + var(--tr)));border-color:oklch(0.4358 calc(0.1059 * var(--tc)) calc(254.58deg + var(--tr)))}
.xhero.fase-run{--xa:#ffd0a8;--xb:oklch(0.6480 calc(0.1876 * var(--tc)) calc(262.54deg + var(--tr)));--xc:oklch(0.6351 calc(0.1987 * var(--tc)) calc(255.66deg + var(--tr)));border-color:oklch(0.5616 calc(0.1621 * var(--tc)) calc(255.20deg + var(--tr)));box-shadow:0 0 0 1px oklch(0.6078 calc(0.1870 * var(--tc)) calc(256.04deg + var(--tr)) / .4),0 30px 80px -30px oklch(0.6078 calc(0.1870 * var(--tc)) calc(256.04deg + var(--tr)) / .85)}
.xhero.fase-done{background:radial-gradient(520px 340px at 80% 50%,rgba(34,197,94,.22),transparent 70%),linear-gradient(135deg,#07180f,#08110d 62%,#09160f)}
.xhero.sup.fase-idle{--xa:oklch(0.7449 calc(0.1328 * var(--tc)) calc(277.93deg + var(--tr)));--xb:oklch(0.6274 calc(0.2017 * var(--tc)) calc(258.47deg + var(--tr)));--xc:oklch(0.5270 calc(0.1601 * var(--tc)) calc(254.29deg + var(--tr)));border-color:oklch(0.4711 calc(0.1315 * var(--tc)) calc(256.56deg + var(--tr)));box-shadow:0 30px 80px -36px oklch(0.6274 calc(0.2017 * var(--tc)) calc(258.47deg + var(--tr)) / .7);background:radial-gradient(520px 340px at 80% 50%,oklch(0.6328 calc(0.2000 * var(--tc)) calc(255.85deg + var(--tr)) / .38),transparent 70%),radial-gradient(440px 280px at 4% 0%,rgba(255,150,40,.20),transparent 70%),linear-gradient(135deg,#0a1924,#071016 62%,#0a161c)}
.xtag,.xhero.sup .xtag{border-color:oklch(0.6480 calc(0.1876 * var(--tc)) calc(262.54deg + var(--tr)) / .5);background:oklch(0.6416 calc(0.1927 * var(--tc)) calc(259.09deg + var(--tr)) / .12);color:oklch(0.8787 calc(0.0591 * var(--tc)) calc(261.89deg + var(--tr)))}
.xhero p.xsub{color:oklch(0.8791 calc(0.0315 * var(--tc)) calc(252.70deg + var(--tr)))}
.xc b,.xhero.sup .xc b{text-shadow:0 0 26px oklch(0.6416 calc(0.1927 * var(--tc)) calc(259.09deg + var(--tr)) / .95)}
.xc b .ico,.xhero.sup .xc b .ico{filter:drop-shadow(0 0 12px oklch(0.6416 calc(0.1927 * var(--tc)) calc(259.09deg + var(--tr)) / .9))}
.xc small{color:oklch(0.9047 calc(0.0289 * var(--tc)) calc(254.68deg + var(--tr)))}
.bt.xgo,.bt.xgo:hover:not(:disabled){background:linear-gradient(110deg,oklch(0.6222 calc(0.2027 * var(--tc)) calc(266.13deg + var(--tr))),oklch(0.5628 calc(0.1887 * var(--tc)) calc(258.10deg + var(--tr))) 25%,oklch(0.6785 calc(0.1759 * var(--tc)) calc(250.79deg + var(--tr))) 50%,oklch(0.5628 calc(0.1887 * var(--tc)) calc(258.10deg + var(--tr))) 75%,oklch(0.6222 calc(0.2027 * var(--tc)) calc(266.13deg + var(--tr))) 100%);background-size:200% 100%}
.bt.xgo{box-shadow:0 18px 40px -14px oklch(0.6078 calc(0.1870 * var(--tc)) calc(256.04deg + var(--tr)) / .85),inset 0 1px 0 rgba(255,255,255,.35)}
.bt.xgo:disabled{background:linear-gradient(110deg,oklch(0.3099 calc(0.0529 * var(--tc)) calc(249.89deg + var(--tr))),oklch(0.3499 calc(0.0640 * var(--tc)) calc(247.33deg + var(--tr))));color:oklch(0.8669 calc(0.0287 * var(--tc)) calc(251.48deg + var(--tr)))}
.xhero.sup .bt.xgo:not(:disabled),.xhero.sup .bt.xgo:hover:not(:disabled){background:linear-gradient(110deg,oklch(0.4917 calc(0.2868 * var(--tc)) calc(270.26deg + var(--tr))),oklch(0.6351 calc(0.1987 * var(--tc)) calc(255.66deg + var(--tr))) 25%,oklch(0.5381 calc(0.1761 * var(--tc)) calc(256.02deg + var(--tr))) 50%,oklch(0.6351 calc(0.1987 * var(--tc)) calc(255.66deg + var(--tr))) 75%,oklch(0.4917 calc(0.2868 * var(--tc)) calc(270.26deg + var(--tr))) 100%);background-size:200% 100%;box-shadow:0 18px 40px -14px oklch(0.6351 calc(0.1987 * var(--tc)) calc(255.66deg + var(--tr)) / .9),inset 0 1px 0 rgba(255,255,255,.35)}
.nivel button{color:oklch(0.8669 calc(0.0287 * var(--tc)) calc(251.48deg + var(--tr)))}
.nivel button.on{background:linear-gradient(135deg,oklch(0.6222 calc(0.2027 * var(--tc)) calc(266.13deg + var(--tr))),oklch(0.5385 calc(0.1757 * var(--tc)) calc(256.25deg + var(--tr))));color:#fff;box-shadow:0 8px 20px -8px oklch(0.6416 calc(0.1927 * var(--tc)) calc(259.09deg + var(--tr)) / .8)}
.nivel button.on[data-nivel=suprema]{background:linear-gradient(135deg,oklch(0.4917 calc(0.2868 * var(--tc)) calc(270.26deg + var(--tr))),oklch(0.6351 calc(0.1987 * var(--tc)) calc(255.66deg + var(--tr))) 55%,oklch(0.4634 calc(0.1410 * var(--tc)) calc(254.61deg + var(--tr))));box-shadow:0 8px 22px -8px oklch(0.6351 calc(0.1987 * var(--tc)) calc(255.66deg + var(--tr)) / .9)}
.xsup{border-color:oklch(0.4358 calc(0.1059 * var(--tc)) calc(254.58deg + var(--tr)));background:oklch(0.6416 calc(0.1927 * var(--tc)) calc(259.09deg + var(--tr)) / .08);color:oklch(0.8956 calc(0.0508 * var(--tc)) calc(259.40deg + var(--tr)))}
.xcards .cd.vivo,.xlive{border-color:oklch(0.3477 calc(0.0644 * var(--tc)) calc(249.47deg + var(--tr)))}
.xlive::before{background:linear-gradient(90deg,transparent,oklch(0.7028 calc(0.1550 * var(--tc)) calc(263.09deg + var(--tr))),oklch(0.7449 calc(0.1328 * var(--tc)) calc(277.93deg + var(--tr))),transparent)}
.xlive .big{background:linear-gradient(90deg,oklch(0.7449 calc(0.1328 * var(--tc)) calc(277.93deg + var(--tr))),oklch(0.6416 calc(0.1927 * var(--tc)) calc(259.09deg + var(--tr))) 60%,oklch(0.5270 calc(0.1601 * var(--tc)) calc(254.29deg + var(--tr))));-webkit-background-clip:text;background-clip:text;color:transparent}
.xtick div::before{color:oklch(0.7028 calc(0.1550 * var(--tc)) calc(263.09deg + var(--tr)))}
.xb .tr i{box-shadow:0 0 10px oklch(0.6416 calc(0.1927 * var(--tc)) calc(259.09deg + var(--tr)) / .45)}
.xps .ps.rodando{border-color:oklch(0.5616 calc(0.1621 * var(--tc)) calc(255.20deg + var(--tr)));background:#0a131a;box-shadow:0 0 0 1px oklch(0.6078 calc(0.1870 * var(--tc)) calc(256.04deg + var(--tr)) / .3),0 12px 32px -16px oklch(0.6078 calc(0.1870 * var(--tc)) calc(256.04deg + var(--tr)) / .95)}
.xps .ps.rodando::after{background:linear-gradient(100deg,transparent 30%,oklch(0.6533 calc(0.1844 * var(--tc)) calc(262.59deg + var(--tr)) / .2) 50%,transparent 70%)}
body.xrun #fundo::before{background:radial-gradient(700px 420px at 50% 0%,oklch(0.6078 calc(0.1870 * var(--tc)) calc(256.04deg + var(--tr)) / .26),transparent 70%),radial-gradient(600px 400px at 50% 112%,oklch(0.5318 calc(0.2603 * var(--tc)) calc(270.18deg + var(--tr)) / .2),transparent 70%)}
body.xrun .prog b{background:linear-gradient(90deg,oklch(0.5201 calc(0.2698 * var(--tc)) calc(274.34deg + var(--tr))),oklch(0.6416 calc(0.1927 * var(--tc)) calc(259.09deg + var(--tr))),oklch(0.5270 calc(0.1601 * var(--tc)) calc(254.29deg + var(--tr))),oklch(0.7028 calc(0.1550 * var(--tc)) calc(263.09deg + var(--tr))),oklch(0.5201 calc(0.2698 * var(--tc)) calc(274.34deg + var(--tr))));background-size:300% 100%}
#esRes .xb .tr i{background:linear-gradient(90deg,oklch(0.6381 calc(0.1873 * var(--tc)) calc(256.90deg + var(--tr))),oklch(0.7066 calc(0.1488 * var(--tc)) calc(255.58deg + var(--tr))));box-shadow:0 0 10px oklch(0.6381 calc(0.1873 * var(--tc)) calc(256.90deg + var(--tr)) / .4)}
.prmeta{margin:0 0 16px;padding:11px 14px;border-radius:12px;border:1px solid #14532d;background:rgba(34,197,94,.08);color:#bbf7d0;font-size:13px;line-height:1.5;max-width:560px}.prmeta b{color:#fff}
/* ===== Jogos e barra de sessão também em vermelho ===== */
.sessb{border-color:oklch(0.4711 calc(0.1315 * var(--tc)) calc(256.56deg + var(--tr)));background:linear-gradient(90deg,oklch(0.6416 calc(0.1927 * var(--tc)) calc(259.09deg + var(--tr)) / .20),oklch(0.6416 calc(0.1927 * var(--tc)) calc(259.09deg + var(--tr)) / .05));color:oklch(0.9200 calc(0.0387 * var(--tc)) calc(257.92deg + var(--tr)))}
.sessb>i{background:oklch(0.6927 calc(0.1622 * var(--tc)) calc(258.76deg + var(--tr)))}
.jhero{border-color:oklch(0.3745 calc(0.0880 * var(--tc)) calc(253.06deg + var(--tr)));background:radial-gradient(520px 320px at 88% 30%,oklch(0.6398 calc(0.1936 * var(--tc)) calc(259.55deg + var(--tr)) / .24),transparent 70%),radial-gradient(420px 260px at 0% 0%,oklch(0.5201 calc(0.2698 * var(--tc)) calc(274.34deg + var(--tr)) / .16),transparent 70%),linear-gradient(135deg,#0a151d,#081013 62%,#0a1417)}
.jhero.run{border-color:oklch(0.6927 calc(0.1622 * var(--tc)) calc(258.76deg + var(--tr)));box-shadow:0 0 0 1px oklch(0.6416 calc(0.1927 * var(--tc)) calc(259.09deg + var(--tr)) / .35),0 30px 70px -34px oklch(0.6416 calc(0.1927 * var(--tc)) calc(259.09deg + var(--tr)) / .75)}
.jtag{border-color:oklch(0.6480 calc(0.1876 * var(--tc)) calc(262.54deg + var(--tr)) / .5);background:oklch(0.6416 calc(0.1927 * var(--tc)) calc(259.09deg + var(--tr)) / .12);color:oklch(0.8787 calc(0.0591 * var(--tc)) calc(261.89deg + var(--tr)))}
.jhero h2 b{background:linear-gradient(90deg,oklch(0.7547 calc(0.1251 * var(--tc)) calc(269.67deg + var(--tr))),oklch(0.6416 calc(0.1927 * var(--tc)) calc(259.09deg + var(--tr))) 70%,oklch(0.5601 calc(0.1892 * var(--tc)) calc(256.90deg + var(--tr))));-webkit-background-clip:text;background-clip:text;color:transparent}
.jhero p.sub2{color:oklch(0.8791 calc(0.0315 * var(--tc)) calc(252.70deg + var(--tr)))}
.jhero .xstat i{background:oklch(0.6927 calc(0.1622 * var(--tc)) calc(258.76deg + var(--tr)))}
.bt.jgo{background:linear-gradient(135deg,oklch(0.6222 calc(0.2027 * var(--tc)) calc(266.13deg + var(--tr))),oklch(0.5628 calc(0.1887 * var(--tc)) calc(258.10deg + var(--tr))) 55%,oklch(0.4850 calc(0.1536 * var(--tc)) calc(255.54deg + var(--tr))));box-shadow:0 18px 40px -14px oklch(0.6078 calc(0.1870 * var(--tc)) calc(256.04deg + var(--tr)) / .85),inset 0 1px 0 rgba(255,255,255,.3)}
.bt.jgo:hover:not(:disabled){background:linear-gradient(135deg,oklch(0.6538 calc(0.1835 * var(--tc)) calc(267.06deg + var(--tr))),oklch(0.6023 calc(0.1877 * var(--tc)) calc(257.65deg + var(--tr))) 55%,oklch(0.5270 calc(0.1601 * var(--tc)) calc(254.29deg + var(--tr))))}
.bt.jgo.fim{background:linear-gradient(135deg,#3a1219,#240a10);border:1px solid #ff3b47;box-shadow:0 14px 34px -16px rgba(255,59,71,.7)}
.bt.jgo:disabled{background:oklch(0.2815 calc(0.0359 * var(--tc)) calc(246.13deg + var(--tr)));color:oklch(0.7368 calc(0.0493 * var(--tc)) calc(254.35deg + var(--tr)))}

/* ===== página Memória RAM ===== */
.mmh{display:grid;grid-template-columns:minmax(0,1.05fr) minmax(0,.95fr);gap:26px;align-items:center;padding:28px 32px}
.mmh .mmk{margin:0 0 6px;font-size:11.5px;letter-spacing:.14em;color:oklch(0.8119 calc(0.0953 * var(--tc)) calc(256.93deg + var(--tr)));font-weight:800}
.mmh h2{margin:0 0 8px;font-size:46px;line-height:1.05;font-weight:900}.mmh h2 small{font-size:18px;color:oklch(0.8119 calc(0.0953 * var(--tc)) calc(256.93deg + var(--tr)));margin-left:12px;font-weight:700}
.mmp{display:flex;gap:14px;flex-wrap:wrap;justify-content:center}
.mms{position:relative;flex:1 1 118px;max-width:168px;min-height:190px;padding:12px 12px 30px;border-radius:10px;border:1px solid oklch(0.3745 calc(0.0880 * var(--tc)) calc(253.06deg + var(--tr)));background:linear-gradient(180deg,#0d1d2a,#070e15);display:flex;flex-direction:column;justify-content:space-between;text-align:center;box-shadow:0 14px 34px -18px oklch(0.6416 calc(0.1927 * var(--tc)) calc(259.09deg + var(--tr)) / .7)}
.mms::before{content:"";height:36px;border-radius:5px;background:repeating-linear-gradient(90deg,#050a0d 0 20px,transparent 20px 24px);border:1px solid oklch(0.2705 calc(0.0413 * var(--tc)) calc(249.58deg + var(--tr)))}
.mms::after{content:"";position:absolute;left:8px;right:8px;bottom:7px;height:9px;background:repeating-linear-gradient(90deg,#e0b252 0 3px,transparent 3px 6px);border-radius:2px;opacity:.85}
.mms b{display:block;font-size:26px}.mms small{display:block;color:var(--m);font-size:12px}
.mmo{counter-reset:p;list-style:none;margin:12px 0 0;padding:0;display:grid;gap:11px}
.mmo li{counter-increment:p;display:flex;gap:12px;line-height:1.5;font-size:13.5px;color:#cfd7e1}
.mmo li::before{content:counter(p);flex:none;width:24px;height:24px;border-radius:50%;background:var(--r);color:#fff;font-weight:800;display:grid;place-items:center;font-size:12px}
.mmo b{color:#fff}
.ac.ok{--cs:#4ade80}.ac.info{--cs:#b3bdc9}
.mmg{align-items:start}
@media (max-width:1000px){.mmh{grid-template-columns:1fr}}

/* saudação embaixo da logo: fica visível em qualquer altura de janela (o antigo subtítulo sumia em telas baixas) */
.marca .ola{display:flex;align-items:center;gap:4px;margin-top:2px;font-size:12.5px;line-height:1.2;font-weight:600;color:var(--m);white-space:nowrap;max-width:168px}
.marca .ola strong{color:#fff;font-weight:800;min-width:0;overflow:hidden;text-overflow:ellipsis}
.marca .ola .lap{flex:none;width:22px;height:22px;display:grid;place-items:center;padding:0;border:0;border-radius:7px;background:transparent;color:var(--m);cursor:pointer;transition:color .2s,background .2s,transform .2s}
.marca .ola .lap .ico{width:13px;height:13px}
.marca .ola .lap:hover{color:#fff;background:#1a212a;transform:scale(1.12)}
.marca .ola .lap:focus-visible{outline:2px solid var(--r);outline-offset:1px}
.marca .ola .lap[hidden]{display:none}
.marca .ola .olaI{width:112px;min-width:0;font:inherit;font-weight:800;color:#fff;background:#12161a;border:1px solid var(--r);border-radius:7px;padding:2px 7px;outline:none;box-shadow:0 0 0 3px oklch(0.6381 calc(0.1873 * var(--tc)) calc(256.90deg + var(--tr)) / .18)}

/* limite de CPU (a barrinha) e resultado de verdade do Reduzir processos */
.cpuc{margin-bottom:16px}
.cpuh{display:flex;gap:18px;align-items:flex-start;justify-content:space-between}.cpuh h3{margin:0 0 6px}.cpuh .sub2{max-width:760px}
.cpur{display:flex;align-items:center;gap:26px;margin-top:16px;flex-wrap:wrap}
.cpuv{min-width:150px}.cpuv b{display:block;font-size:40px;line-height:1;font-weight:900}.cpuv small{display:block;margin-top:4px;color:var(--m);font-size:12px}
.cpub{flex:1 1 320px;min-width:240px}
.cpub input[type=range]{-webkit-appearance:none;appearance:none;width:100%;height:10px;border-radius:999px;border:1px solid var(--l2);background:linear-gradient(90deg,var(--r) var(--p,40%),var(--p2) var(--p,40%));outline:none;margin:0;cursor:pointer}
.cpub input[type=range]:disabled{opacity:.45;cursor:not-allowed}
.cpub input[type=range]::-webkit-slider-thumb{-webkit-appearance:none;appearance:none;width:26px;height:26px;border-radius:50%;background:#fff;border:3px solid var(--r);box-shadow:0 2px 10px rgba(0,0,0,.6),0 0 16px -2px oklch(0.6381 calc(0.1873 * var(--tc)) calc(256.90deg + var(--tr)) / .8);cursor:grab}
.cpub input[type=range]::-moz-range-thumb{width:20px;height:20px;border-radius:50%;background:#fff;border:3px solid var(--r);box-shadow:0 2px 10px rgba(0,0,0,.6);cursor:grab}
.cpub input[type=range]:focus-visible{box-shadow:0 0 0 3px oklch(0.7155 calc(0.1417 * var(--tc)) calc(255.74deg + var(--tr)) / .45)}
.cpue{display:flex;justify-content:space-between;margin-top:8px;color:var(--m);font-size:11.5px;letter-spacing:.02em}
.prbase{margin:0 0 16px;padding:11px 14px;border-radius:12px;border:1px solid var(--l2);background:rgba(255,255,255,.04);color:var(--t);font-size:13px;line-height:1.5;max-width:560px}.prbase b{color:#fff}.prbase p{margin:0}.prbase .linha{margin-top:10px!important}
.mot{margin-top:12px;padding:11px 14px;border-radius:12px;border:1px solid #5a3f12;background:rgba(245,158,11,.07);color:#fcd38b;font-size:13px;line-height:1.5}.mot b{color:#fff}.mot ul{margin:6px 0 0;padding-left:18px}.mot li{margin:3px 0}

/* página Mouse & Precisão: cartão do mouse, chip com o nome e linhas com status (v8.7) */
.mm-top{display:flex;justify-content:space-between;align-items:flex-start;gap:16px;flex-wrap:wrap;margin-bottom:16px}
.mm-top h2{margin:0;font-size:21px}
.mm-top p{margin:6px 0 0;color:var(--m);line-height:1.5;max-width:560px}
.mm-chip{display:inline-flex;align-items:center;gap:9px;min-height:42px;max-width:100%;padding:0 16px;border-radius:12px;border:1px solid #2a323c;background:linear-gradient(180deg,#181d24,#0e1217);color:#e8edf3;font-weight:700;transition:border-color .25s,background .25s,transform .2s var(--ease)}
.mm-chip:hover{border-color:oklch(0.3791 calc(0.1079 * var(--tc)) calc(256.88deg + var(--tr)));transform:translateY(-1px)}
.mm-chip:focus-visible{outline:2px solid oklch(0.7917 calc(0.1020 * var(--tc)) calc(255.59deg + var(--tr)));outline-offset:2px}
.mm-chip .ico{flex:none;width:18px;height:18px;color:oklch(0.7160 calc(0.1430 * var(--tc)) calc(255.97deg + var(--tr)))}
.mm-chip span{min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.mm-esc[hidden],.mm-dica[hidden],.mm-t-area[hidden],.mm-t-res[hidden],.mm-t-nota[hidden],.mm-row .av[hidden]{display:none}
.mm-esc{margin-bottom:16px}
.mm-esc-f{display:grid;grid-template-columns:minmax(0,.7fr) minmax(0,1fr);gap:12px;margin-top:12px}
.mm-esc-f label{display:block;font-size:12px;font-weight:700;color:var(--m)}
.mm-esc-f .inp{margin-top:5px}
select.inp option{background:#0b0e12;color:var(--t)}
.mm-det{font-size:12.5px;color:var(--m)}
.mm-grade{display:grid;grid-template-columns:minmax(0,1fr) minmax(290px,.66fr);gap:16px;align-items:start;margin-bottom:16px}
.mm-col{display:grid;gap:12px;min-width:0}
.mm-row,.mm-card{position:relative;display:grid;grid-template-columns:auto minmax(0,1fr) auto;align-items:center;column-gap:14px;row-gap:8px;padding:15px 16px;border-radius:16px;background:linear-gradient(180deg,#11151b,#0d1115);border:1px solid #1d232b;transition:border-color .3s,background .3s}
.mm-card{display:block}
.mm-row.on{border-color:oklch(0.3248 calc(0.0448 * var(--tc)) calc(248.19deg + var(--tr)))}
.mm-row.nd .sw{opacity:.45}
.mm-ic{flex:none;width:40px;height:40px;border-radius:12px;display:grid;place-items:center;background:#121a24;color:oklch(0.7160 calc(0.1430 * var(--tc)) calc(255.97deg + var(--tr)))}
.mm-ic .ico{width:20px;height:20px}
.mm-tx{min-width:0}
.mm-tx b{display:flex;flex-wrap:wrap;align-items:baseline;column-gap:9px;font-size:15.5px;line-height:1.3}
.mm-tx small{display:block;margin-top:3px;color:var(--m);font-size:12.5px;line-height:1.45}
.mm-st{font-style:normal;font-size:11.5px;font-weight:800;letter-spacing:.08em;color:oklch(0.6381 calc(0.1873 * var(--tc)) calc(256.90deg + var(--tr)));font-variant-numeric:tabular-nums}
.mm-row.on .mm-st,.mm-st.lig{color:#4ade80}
.mm-row .av{grid-column:2 / -1;margin:0;font-size:12.5px;color:#fcd38b}
.mm-sl{grid-column:2 / -1}
.mm-sl input[type=range]{margin:4px 0 2px}
.mm-sl input[type=range]:disabled{opacity:.7}
.mm-sl-pe{display:flex;justify-content:space-between;font-size:11.5px;color:var(--m)}
.mm-img{position:sticky;top:4px;display:flex;flex-direction:column;align-items:center;justify-content:center;min-height:480px;padding:26px 20px 16px;border-radius:22px;border:1px solid #1d232b;overflow:hidden;text-align:center;
 background:radial-gradient(250px 230px at 50% 60%,rgba(var(--mcr,51,137,250),.2),transparent 72%),#000}
.mm-fig{width:min(206px,62%);aspect-ratio:2/3;filter:drop-shadow(0 22px 24px rgba(0,0,0,.65))}
.mm-fig svg{width:100%;height:100%;display:block;overflow:visible;animation:mmFlutua 6s ease-in-out infinite}
.mm-fig.ent svg{animation:mmEntra .6s var(--ease) both,mmFlutua 6s ease-in-out .6s infinite}
@keyframes mmFlutua{0%,100%{transform:translateY(0)}50%{transform:translateY(-5px)}}
@keyframes mmEntra{from{opacity:0;transform:translateY(14px) scale(.94)}to{opacity:1;transform:none}}
.mm-leg{margin-top:16px;min-width:0;max-width:100%}
.mm-leg small{display:block;font-size:11.5px;font-weight:800;letter-spacing:.16em;text-transform:uppercase;color:rgb(var(--mcr,51,137,250))}
.mm-leg b{display:block;margin-top:3px;font-size:19px;line-height:1.25;color:#fff;overflow-wrap:anywhere}
.mm-leg span{display:block;margin-top:4px;font-size:12.5px;color:var(--m)}
.mm-dica{margin:12px 0 0;max-width:300px;font-size:12.5px;line-height:1.5;color:#fcd38b}
.mm-img-bt{display:flex;gap:8px;flex-wrap:wrap;justify-content:center;margin-top:14px}
.mm-nota{margin-top:12px;font-size:11px;color:#5a646f}
.mm-t-cab{display:grid;grid-template-columns:minmax(0,1fr) auto;gap:6px 14px;align-items:center}
.mm-t-cab b{font-size:15.5px}
.mm-t-cab small{display:block;margin-top:3px;color:var(--m);font-size:12.5px;line-height:1.45}
.mm-t-area{position:relative;margin-top:14px;height:210px;border-radius:16px;border:1px dashed oklch(0.3989 calc(0.0676 * var(--tc)) calc(253.31deg + var(--tr)));background:radial-gradient(320px 120px at 50% 50%,oklch(0.6381 calc(0.1873 * var(--tc)) calc(256.90deg + var(--tr)) / .12),#06080a);cursor:crosshair;display:grid;place-items:center;text-align:center;padding:0 18px;user-select:none;-webkit-user-select:none;touch-action:none;outline:none}
.mm-t-area:focus-visible{border-color:oklch(0.7160 calc(0.1430 * var(--tc)) calc(255.97deg + var(--tr)))}
.mm-t-msg{font-weight:700;line-height:1.45;pointer-events:none}
.mm-t-bar{position:absolute;left:0;right:0;bottom:0;height:5px;border-radius:0 0 16px 16px;background:#121a24;overflow:hidden}
.mm-t-bar i{display:block;height:100%;width:0;background:linear-gradient(90deg,oklch(0.4982 calc(0.1704 * var(--tc)) calc(257.85deg + var(--tr))),oklch(0.7160 calc(0.1430 * var(--tc)) calc(255.97deg + var(--tr))))}
.mm-t-x{position:absolute;top:8px;right:8px;min-height:30px;padding:0 12px;font-size:12px}
.mm-t-res{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:10px;margin-top:12px}
.mm-t-res div{padding:10px 12px;border-radius:12px;background:#0b0e12;border:1px solid #1b2028}
.mm-t-res small{display:block;color:var(--m);font-size:11.5px}
.mm-t-res b{font-size:18px;font-variant-numeric:tabular-nums}
.mm-t-res .ruim b{color:#fb6473}
.mm-t-nota{margin:10px 0 0;font-size:12.5px;line-height:1.5;color:#fcd38b}
.pg.ent .mm-grade,.pg.ent .mm-palco,.pg.ent .mm-wrap{animation:none}
.pg.ent .mm-menu{animation:sobe .5s var(--ease) both;animation-delay:100ms}
.pg.ent .mm-row,.pg.ent .mm-card,.pg.ent .mm-img,.pg.ent .mm-barra{animation:sobe .5s var(--ease) both;animation-delay:calc(var(--i,0)*70ms + 100ms + var(--k,0)*80ms)}
/* v9.6: o mouse grande no meio, com a luz da marca atrás, e os ajustes em cartões dos dois lados */
.mm-palco{display:grid;grid-template-columns:minmax(0,1fr) minmax(310px,1.18fr) minmax(0,1fr);grid-template-areas:"e c d";gap:16px;align-items:center;margin-bottom:22px}
.mm-le{grid-area:e}.mm-ld{grid-area:d}.mm-dir{grid-area:c;display:grid;min-width:0}
.mm-lado{display:grid;gap:14px;min-width:0;align-content:center}
.mm-lado .mm-row,.mm-lado .mm-barra{grid-template-columns:auto minmax(0,1fr) auto;row-gap:12px;padding:16px 16px 17px;border-radius:18px;align-items:start}
.mm-lado .mm-ic{grid-row:1;grid-column:1}
.mm-lado .mm-row>.sw,.mm-lado .mm-row>.bt,.mm-lado .mm-barra>.bt{grid-row:1;grid-column:3;align-self:center}
.mm-lado .mm-tx{grid-row:2;grid-column:1 / -1}
.mm-lado .mm-sl{grid-row:3;grid-column:1 / -1}
.mm-lado .mm-row .av{grid-row:4;grid-column:1 / -1}
.mm-dir .mm-img{position:relative;min-height:540px;padding:30px 18px 18px;border-radius:24px;background:radial-gradient(420px 360px at 50% 36%,rgba(var(--mcr,51,137,250),.16),transparent 70%),linear-gradient(180deg,#07090c,#000000)}
.mm-dir .mm-fig{position:relative;isolation:isolate;width:min(220px,62%);filter:none}
.mm-dir .mm-fig.foto{width:min(290px,84%)}
.mm-dir .mm-fig svg{filter:drop-shadow(0 22px 24px rgba(0,0,0,.65))}
.mm-dir .mm-fig::before{content:"";position:absolute;left:50%;top:50%;width:150%;aspect-ratio:1;transform:translate(-50%,-50%);border-radius:50%;background:radial-gradient(closest-side,rgba(var(--mcr,51,137,250),.5),rgba(var(--mcr,51,137,250),.16) 55%,transparent);z-index:-1;pointer-events:none}
.mm-dir .mm-fig::after{content:"";position:absolute;left:50%;top:50%;width:122%;aspect-ratio:1;transform:translate(-50%,-50%);border-radius:50%;border:1px solid rgba(var(--mcr,51,137,250),.3);box-shadow:0 0 30px -6px rgba(var(--mcr,51,137,250),.5),inset 0 0 30px -10px rgba(var(--mcr,51,137,250),.45);z-index:-1;pointer-events:none}
.mm-dir .mm-fig.foto::after{width:104%}
.mm-wrap{display:grid;grid-template-columns:196px minmax(0,1fr);gap:16px;align-items:start;margin-bottom:22px}
.mm-wrap .mm-palco{margin-bottom:0}
.mm-menu{position:sticky;top:4px;display:grid;gap:4px;padding:14px 10px;border-radius:20px;background:linear-gradient(180deg,#11151b,#0b0e12);border:1px solid #1d232b}
.mm-menu small{padding:8px 10px 4px;font-size:11px;font-weight:800;letter-spacing:.16em;text-transform:uppercase;color:oklch(0.7160 calc(0.1430 * var(--tc)) calc(255.97deg + var(--tr)))}
.mm-menu small~small{margin-top:8px;border-top:1px solid #1b2028;padding-top:14px}
.mm-menu button{display:flex;align-items:center;gap:10px;min-height:40px;padding:0 12px;border-radius:12px;border:1px solid transparent;background:transparent;color:#a9b3c0;font-weight:700;font-size:13.5px;text-align:left;transition:background .2s,color .2s,border-color .2s,transform .2s var(--ease)}
.mm-menu button .ico{flex:none;width:17px;height:17px}
.mm-menu button:hover{background:#151b23;color:#ffffff}
.mm-menu button[aria-pressed="true"]{background:linear-gradient(135deg,oklch(0.6588 calc(0.1751 * var(--tc)) calc(256.28deg + var(--tr))),oklch(0.4982 calc(0.1704 * var(--tc)) calc(257.85deg + var(--tr))) 70%,oklch(0.3991 calc(0.1348 * var(--tc)) calc(257.87deg + var(--tr))));border-color:oklch(0.7160 calc(0.1430 * var(--tc)) calc(255.97deg + var(--tr)));color:#ffffff;box-shadow:0 8px 20px -10px oklch(0.6381 calc(0.1873 * var(--tc)) calc(256.90deg + var(--tr)) / .85)}
.mm-menu button:focus-visible{outline:2px solid oklch(0.7917 calc(0.1020 * var(--tc)) calc(255.59deg + var(--tr)));outline-offset:2px}
.mm-menu .mm-menu-esc{margin-top:12px;justify-content:center;border-color:#2a323c;background:linear-gradient(180deg,#1a1f27,#10141a);color:#e8edf3}
.mm-palco:not([data-t="aj"]) [data-mmg="aj"],.mm-palco:not([data-t="te"]) [data-mmg="te"],.mm-palco:not([data-t="fo"]) [data-mmg="fo"],.mm-palco:not([data-t="tc"]) [data-mmg="tc"]{display:none}
.mm-palco .mm-troca{animation:sobe .45s var(--ease) both;animation-delay:calc(var(--k,0)*70ms)}
.mm-lado .mm-card{padding:16px 16px 17px;border-radius:18px}
.mm-lado .mm-t-cab{grid-template-columns:1fr}.mm-lado .mm-t-cab .bt{justify-self:start}
.mm-lado .mm-t-res{grid-template-columns:repeat(2,minmax(0,1fr))}
.mm-foto-c b{display:block;margin-top:12px;font-size:15.5px}.mm-foto-c small{display:block;margin-top:4px;color:var(--m);font-size:12.5px;line-height:1.45}
.mm-foto-c .mm-img-bt{justify-content:flex-start}
.mm-passos{margin:12px 0 0;padding-left:20px;display:grid;gap:5px;color:#c9d0d9;font-size:12.5px;line-height:1.45}
.mm-passos li::marker{color:oklch(0.7160 calc(0.1430 * var(--tc)) calc(255.97deg + var(--tr)));font-weight:800}
.mm-barra{position:relative;display:grid;grid-template-columns:auto minmax(0,1fr) auto;align-items:center;column-gap:14px;padding:14px 16px;border-radius:16px;background:linear-gradient(180deg,#11151b,#0d1115);border:1px solid #1d232b;transition:border-color .3s,background .3s}
.mm-barra.on{border-color:oklch(0.3248 calc(0.0448 * var(--tc)) calc(248.19deg + var(--tr)));background:linear-gradient(180deg,#122126,#0d1317)}
.mm-sec{margin:2px 2px 0;font-size:12px;font-weight:800;letter-spacing:.16em;text-transform:uppercase;color:oklch(0.7160 calc(0.1430 * var(--tc)) calc(255.97deg + var(--tr)))}
.mm-fig.foto{aspect-ratio:1/1;width:min(260px,82%)}
.mm-foto{width:100%;height:100%;object-fit:contain;display:block;border-radius:18px;background:#fff;padding:6px;box-sizing:border-box}
.mm-foto.sem-fundo{background:none;padding:0;border-radius:0;filter:drop-shadow(0 18px 18px rgba(0,0,0,.55))}
.mm-dados{list-style:none;margin:12px 0 0;padding:0;display:grid;gap:5px;text-align:left;font-size:12.5px;color:#c9d0d9;max-width:300px}
.mm-dados li::before{content:"";display:inline-block;width:6px;height:6px;border-radius:50%;background:rgb(var(--mcr,51,137,250));margin-right:8px;vertical-align:middle}
.mm-dados-n{margin:6px 0 0;font-size:11px;color:#5a646f;max-width:300px}
.mm-dados[hidden],.mm-dados-n[hidden],#mmFotoRm[hidden]{display:none}
.rf{--r:oklch(0.7535 calc(0.1390 * var(--tc)) calc(232.66deg + var(--tr)));--r3:oklch(0.8276 calc(0.1013 * var(--tc)) calc(230.32deg + var(--tr)))}
.rf>.cd{margin-bottom:16px}.rf-barra{display:grid;gap:14px}
.rf-barra .rf-t{display:flex;justify-content:space-between;gap:12px;flex-wrap:wrap;align-items:baseline}
.rf-barra h2{margin:0;font-size:21px}
.rf-barra input[type=range]{background:linear-gradient(90deg,oklch(0.7535 calc(0.1390 * var(--tc)) calc(232.66deg + var(--tr))) var(--p,0%),#1c2a33 var(--p,0%));margin:10px 0 6px}
.rf-barra input[type=range]::-webkit-slider-thumb{border-color:oklch(0.7535 calc(0.1390 * var(--tc)) calc(232.66deg + var(--tr)));box-shadow:0 0 16px oklch(0.7535 calc(0.1390 * var(--tc)) calc(232.66deg + var(--tr)) / .8)}
.rf-pe{display:grid;grid-template-columns:repeat(3,1fr);font-size:12.5px;font-weight:700;color:var(--m)}
.rf-pe span:nth-child(2){text-align:center}.rf-pe span:nth-child(3){text-align:right}
.rf-pe .on{color:oklch(0.8276 calc(0.1013 * var(--tc)) calc(230.32deg + var(--tr)))}
.rf-card{padding:14px 16px;border-radius:14px;background:#0f171d;border:1px solid oklch(0.3046 calc(0.0361 * var(--tc)) calc(244.51deg + var(--tr)))}
.rf-card .tg{display:inline-block;font-size:10.5px;letter-spacing:.12em;font-weight:800;color:oklch(0.8276 calc(0.1013 * var(--tc)) calc(230.32deg + var(--tr)));background:#10222c;border:1px solid oklch(0.3624 calc(0.0533 * var(--tc)) calc(235.88deg + var(--tr)));border-radius:999px;padding:3px 10px}
.rf-card h3{margin:8px 0 4px;font-size:19px;text-transform:none;letter-spacing:0;color:var(--t)}
.rf-card p{margin:0 0 8px;color:var(--m);font-size:13px;line-height:1.5}
.rf-card ul{margin:0;padding:0;list-style:none;color:oklch(0.9043 calc(0.0261 * var(--tc)) calc(231.64deg + var(--tr)));font-size:12.5px;line-height:1.75}
.rf-card li::before{content:"•";color:oklch(0.8276 calc(0.1013 * var(--tc)) calc(230.32deg + var(--tr)));margin-right:8px}
.rf-av{margin:0;padding:10px 12px;border-radius:12px;background:#2a1b0d;border:1px solid #5a3a14;color:#fcd38b;font-size:12.5px;line-height:1.5}
.rf-dicas{display:grid;gap:10px}
.rf-dica{display:grid;grid-template-columns:auto minmax(0,1fr);gap:4px 10px;font-size:13px;line-height:1.5;color:#c6ced9}
.rf-dica::before{content:"❄";color:oklch(0.8276 calc(0.1013 * var(--tc)) calc(230.32deg + var(--tr)))}
.rf-dica .bt{grid-column:2;justify-self:start;min-height:34px;padding:0 14px;font-size:12.5px}
.rf-aviso{margin:4px 0 0;font-size:12px;color:#757f8a;line-height:1.5}
@keyframes mmHue{to{filter:hue-rotate(360deg)}}
.mm-rgb{animation:mmHue 7s linear infinite}
.mm-fig.ent .mm-foto{animation:mmEntra .6s var(--ease) both}
.mm-img-bt2{margin-top:8px}
.mm-img-bt .bt{min-height:34px;padding:0 14px;font-size:12.5px}
.tk-ar{position:relative;margin-top:14px;min-height:170px;border-radius:16px;border:1px dashed oklch(0.3989 calc(0.0676 * var(--tc)) calc(253.31deg + var(--tr)));background:radial-gradient(320px 120px at 50% 50%,oklch(0.6381 calc(0.1873 * var(--tc)) calc(256.90deg + var(--tr)) / .12),#06080a);display:grid;place-items:center;text-align:center;padding:16px 18px;user-select:none;-webkit-user-select:none;outline:none}
.tk-ar:focus-visible,.tk-ar.on{border-color:oklch(0.7160 calc(0.1430 * var(--tc)) calc(255.97deg + var(--tr)))}
.tk-ar[hidden]{display:none}
.tk-msg{font-weight:700;line-height:1.45;pointer-events:none}
.tk-teclas{display:flex;flex-wrap:wrap;gap:8px;justify-content:center;margin-top:12px;min-height:38px}
.tk-teclas kbd{font:700 14px/1 "Segoe UI",system-ui,sans-serif;padding:9px 12px;border-radius:9px;background:oklch(0.7160 calc(0.1430 * var(--tc)) calc(255.97deg + var(--tr)));color:#051322;box-shadow:0 3px 0 oklch(0.4518 calc(0.1285 * var(--tc)) calc(255.59deg + var(--tr)))}
.rf-t2{font-style:normal;font-weight:800}
.rf-ok{color:#4ade80}.rf-qt{color:#fbbf24}.rf-mq{color:#fb6473}
.rf-barra .bt.p{background:linear-gradient(180deg,oklch(0.7535 calc(0.1390 * var(--tc)) calc(232.66deg + var(--tr))),oklch(0.6847 calc(0.1479 * var(--tc)) calc(237.32deg + var(--tr))));border-color:oklch(0.7535 calc(0.1390 * var(--tc)) calc(232.66deg + var(--tr)));color:oklch(0.2291 calc(0.0406 * var(--tc)) calc(230.03deg + var(--tr)))}


@media (max-width:1180px){.mm-palco{grid-template-columns:repeat(2,minmax(0,1fr));grid-template-areas:"c c" "e d";align-items:start}.mm-dir .mm-img{min-height:420px}}
@media (max-width:1300px){.mm-wrap{grid-template-columns:1fr}.mm-menu{position:static;display:flex;flex-wrap:wrap;align-items:center;padding:8px}.mm-menu small{display:none}.mm-menu .mm-menu-esc{margin:0 0 0 auto}}
@media (max-width:620px){.mm-palco{grid-template-columns:1fr;grid-template-areas:"c" "e" "d"}.mm-dir .mm-img{min-height:360px}.mm-dir .mm-fig{width:min(180px,56%)}}
@media (max-width:620px){.mm-esc-f{grid-template-columns:1fr}.mm-t-res{grid-template-columns:repeat(2,minmax(0,1fr))}.mm-t-cab{grid-template-columns:1fr}.mm-row{grid-template-columns:auto minmax(0,1fr)}.mm-row .sw,.mm-row>.bt{grid-column:2;justify-self:start}}
@media (prefers-reduced-motion:reduce){.mm-fig svg,.mm-fig.ent svg{animation:none!important}.pg.ent .mm-row,.pg.ent .mm-card,.pg.ent .mm-img,.pg.ent .mm-barra{animation:none!important}.mm-rgb{animation:none!important}.mm-fig.ent .mm-foto{animation:none!important}.mm-t-bar i{transition:none!important}}
html.leve .mm-fig svg,html.leve .mm-fig.ent svg{animation:none!important}
html.leve .pg.ent .mm-row,html.leve .pg.ent .mm-card,html.leve .pg.ent .mm-img{animation:none!important}
html.leve .mm-fig{filter:none}

/* ===== v8.9: logo em 3D (preto e azul) ===== */
.w3{position:relative;display:inline-block;font-weight:900;letter-spacing:.02em;white-space:nowrap;text-shadow:none}
.w3::before{content:attr(data-t);position:absolute;left:0;top:0;z-index:0;pointer-events:none;-webkit-user-select:none;user-select:none;color:oklch(0.3042 calc(0.1122 * var(--tc)) calc(261.52deg + var(--tr)));text-shadow:.018em .02em 0 oklch(0.6821 calc(0.1720 * var(--tc)) calc(252.76deg + var(--tr))),.036em .04em 0 oklch(0.6421 calc(0.1787 * var(--tc)) calc(255.43deg + var(--tr))),.054em .06em 0 oklch(0.5952 calc(0.1781 * var(--tc)) calc(257.11deg + var(--tr))),.072em .08em 0 oklch(0.5494 calc(0.1700 * var(--tc)) calc(257.69deg + var(--tr))),.09em .1em 0 oklch(0.4984 calc(0.1590 * var(--tc)) calc(258.22deg + var(--tr))),.108em .12em 0 oklch(0.4402 calc(0.1420 * var(--tc)) calc(258.58deg + var(--tr))),.126em .14em 0 oklch(0.3793 calc(0.1231 * var(--tc)) calc(258.87deg + var(--tr))),.144em .16em 0 oklch(0.3193 calc(0.1032 * var(--tc)) calc(259.26deg + var(--tr))),.162em .18em 0 oklch(0.2599 calc(0.0826 * var(--tc)) calc(259.40deg + var(--tr))),.18em .2em .08em rgba(0,0,0,.95),0 0 .7em oklch(0.6467 calc(0.1912 * var(--tc)) calc(256.16deg + var(--tr)) / .38)}
.w3 .th,.w3 .bo{position:relative;z-index:1;font-style:normal}
.w3 .th{color:#04060b;-webkit-text-stroke:.045em oklch(0.7545 calc(0.1368 * var(--tc)) calc(243.47deg + var(--tr)));paint-order:stroke fill}
.w3 .bo{background:linear-gradient(180deg,oklch(0.9306 calc(0.0370 * var(--tc)) calc(240.68deg + var(--tr))) 0%,oklch(0.7297 calc(0.1462 * var(--tc)) calc(249.30deg + var(--tr))) 40%,oklch(0.5481 calc(0.2057 * var(--tc)) calc(260.77deg + var(--tr))) 100%);-webkit-background-clip:text;background-clip:text;color:transparent;-webkit-text-fill-color:transparent}
.marca b.w3{display:inline-block;font-size:21px;margin-bottom:6px}
.hero h2.w3{display:inline-block;color:inherit;text-shadow:none}
#boot{background:radial-gradient(600px 400px at 50% 50%,oklch(0.2358 calc(0.0663 * var(--tc)) calc(260.18deg + var(--tr))),#02050b)}
#boot h2.w3{display:inline-block;font-size:54px;letter-spacing:.06em;padding-left:0;background:none;-webkit-background-clip:border-box;background-clip:border-box;color:inherit}
#boot p{color:oklch(0.6856 calc(0.0677 * var(--tc)) calc(256.51deg + var(--tr)))}
#boot .lin{background:#0b1426}#boot .lin i{background:linear-gradient(90deg,oklch(0.3895 calc(0.1670 * var(--tc)) calc(262.35deg + var(--tr))),oklch(0.6467 calc(0.1912 * var(--tc)) calc(256.16deg + var(--tr))),#ffffff)}
.hero .emb{filter:drop-shadow(0 10px 24px oklch(0.1653 calc(0.0606 * var(--tc)) calc(262.31deg + var(--tr)) / .6))}
/* ===== v8.9: menu em quadradinhos (só os ícones); encostar o mouse (ou navegar pelo teclado) abre o menu cheio por cima da tela ===== */
.nv{width:76px;z-index:40;overflow-x:hidden;overflow-y:auto;scrollbar-width:none;background:linear-gradient(180deg,#0b0f13,#080b0d);transition:width .26s var(--ease),box-shadow .26s}
.nv::-webkit-scrollbar{display:none}
.nv:hover,.nv.kb{width:250px;box-shadow:20px 0 50px -14px rgba(0,0,0,.9),1px 0 0 oklch(0.3244 calc(0.0710 * var(--tc)) calc(261.76deg + var(--tr)))}
.nv:hover{transition-delay:.06s}
.marca{flex:none;padding:2px 3px 18px;overflow:hidden;white-space:nowrap}
.marca>div:not(.emb){transition:opacity .2s .12s}
.it{padding:0 11px;overflow:hidden;white-space:nowrap}
.it .tl{flex:none}
.it>span:not(.tl){transition:opacity .2s .1s}
.gp{overflow:hidden;white-space:nowrap}
.adm{overflow:hidden;white-space:nowrap;transition:padding .26s var(--ease)}
.adm div{transition:opacity .2s .12s}
.nv .fim{padding:14px 0 0}
.ver{overflow:hidden;white-space:nowrap}
.nv:not(:hover):not(.kb) .marca>div:not(.emb),.nv:not(:hover):not(.kb) .it>span:not(.tl),.nv:not(:hover):not(.kb) .adm div{opacity:0;transition:opacity .1s}
.nv:not(:hover):not(.kb) .gp{color:transparent;background:linear-gradient(90deg,oklch(0.3231 calc(0.0539 * var(--tc)) calc(258.28deg + var(--tr))),oklch(0.3231 calc(0.0539 * var(--tc)) calc(258.28deg + var(--tr)) / 0)) left center/100% 1px no-repeat}
.nv:not(:hover):not(.kb) .gp::before,.nv:not(:hover):not(.kb) .gp::after,.nv:not(:hover):not(.kb) .gp .chev{visibility:hidden}
.nv:not(:hover):not(.kb) .adm{padding-left:22px;padding-right:22px}
@media (max-height:900px){.it{padding:0 13px}}
@media (max-height:800px){.nv{padding:12px 12px 10px}.marca{padding:0 8px 6px}.it{padding:0 14px}}
html.leve .nv,html.leve .marca>div:not(.emb),html.leve .it>span:not(.tl),html.leve .adm,html.leve .adm div{transition:none}
html.leve .w3::before{text-shadow:.018em .02em 0 oklch(0.6821 calc(0.1720 * var(--tc)) calc(252.76deg + var(--tr))),.036em .04em 0 oklch(0.6421 calc(0.1787 * var(--tc)) calc(255.43deg + var(--tr))),.054em .06em 0 oklch(0.5952 calc(0.1781 * var(--tc)) calc(257.11deg + var(--tr))),.072em .08em 0 oklch(0.5494 calc(0.1700 * var(--tc)) calc(257.69deg + var(--tr))),.09em .1em 0 oklch(0.4984 calc(0.1590 * var(--tc)) calc(258.22deg + var(--tr))),.108em .12em 0 oklch(0.4402 calc(0.1420 * var(--tc)) calc(258.58deg + var(--tr))),.126em .14em 0 oklch(0.3793 calc(0.1231 * var(--tc)) calc(258.87deg + var(--tr))),.144em .16em 0 oklch(0.3193 calc(0.1032 * var(--tc)) calc(259.26deg + var(--tr))),.162em .18em 0 oklch(0.2599 calc(0.0826 * var(--tc)) calc(259.40deg + var(--tr))),.18em .2em .08em rgba(0,0,0,.95),0 0 .7em oklch(0.6467 calc(0.1912 * var(--tc)) calc(256.16deg + var(--tr)) / .38)!important}

/* ===== v9.0: aviso de versão nova (parece uma notificação, no meio da tela) ===== */
.atu-not{position:fixed;inset:0;z-index:900;display:grid;place-items:center;padding:18px;background:rgba(2,6,14,.55);-webkit-backdrop-filter:blur(3px);backdrop-filter:blur(3px);animation:atuFd .35s ease both}
.atu-not[hidden],.atu-not [hidden]{display:none!important}
@keyframes atuFd{from{opacity:0}to{opacity:1}}
.atu-card{position:relative;width:min(560px,100%);display:flex;gap:20px;padding:28px 30px 26px 26px;border-radius:24px;background:linear-gradient(160deg,#131c2e,#0a0f17);border:1px solid oklch(0.4519 calc(0.1063 * var(--tc)) calc(258.91deg + var(--tr)));box-shadow:0 40px 90px -24px #000,0 0 0 1px oklch(0.6381 calc(0.1873 * var(--tc)) calc(256.90deg + var(--tr)) / .2),0 0 60px -12px oklch(0.6381 calc(0.1873 * var(--tc)) calc(256.90deg + var(--tr)) / .6);animation:atuIn .5s var(--ease) both}
@keyframes atuIn{from{opacity:0;transform:translateY(22px) scale(.94)}to{opacity:1;transform:none}}
.atu-ic{flex:none;width:60px;height:60px;border-radius:17px;display:grid;place-items:center;background:linear-gradient(135deg,oklch(0.6588 calc(0.1751 * var(--tc)) calc(256.28deg + var(--tr))),oklch(0.4982 calc(0.1704 * var(--tc)) calc(257.85deg + var(--tr))));color:#fff;box-shadow:0 12px 28px -10px oklch(0.6381 calc(0.1873 * var(--tc)) calc(256.90deg + var(--tr)) / .9)}
.atu-ic svg{width:30px;height:30px;stroke:currentColor;fill:none;stroke-width:2;stroke-linecap:round;stroke-linejoin:round;transform-origin:50% 10%}
.atu-not.toca .atu-ic svg{animation:atuSino 1.1s ease-in-out .3s 2}
@keyframes atuSino{0%,100%{transform:rotate(0)}15%{transform:rotate(15deg)}30%{transform:rotate(-12deg)}45%{transform:rotate(8deg)}60%{transform:rotate(-5deg)}75%{transform:rotate(2deg)}}
.atu-cx{flex:1;min-width:0;display:flex;flex-direction:column;gap:6px;padding-right:14px}
.atu-cx b{font-size:21px;color:#fff;line-height:1.25}
.atu-cx span{font-size:15.5px;color:oklch(0.7785 calc(0.0368 * var(--tc)) calc(258.87deg + var(--tr)));line-height:1.45}
.atu-cx ul{margin:6px 0 2px;padding-left:20px;font-size:14.5px;color:oklch(0.9024 calc(0.0284 * var(--tc)) calc(256.49deg + var(--tr)));line-height:1.55}
.atu-bar{height:8px;border-radius:9px;background:#1a2436;overflow:hidden;margin-top:8px}.atu-bar i{display:block;height:100%;width:0;background:linear-gradient(90deg,oklch(0.4982 calc(0.1704 * var(--tc)) calc(257.85deg + var(--tr))),oklch(0.6381 calc(0.1873 * var(--tc)) calc(256.90deg + var(--tr))),oklch(0.8399 calc(0.0838 * var(--tc)) calc(247.80deg + var(--tr))));transition:width .3s}
.atu-cx small{color:#fca5a5;font-size:13.5px;line-height:1.45}
.atu-bt{display:flex;gap:10px;margin-top:12px;flex-wrap:wrap}.atu-bt .bt{min-height:48px;padding:0 26px;font-size:15px}
.atu-x{position:absolute;top:12px;right:14px;width:34px;height:34px;border:0;border-radius:10px;background:none;color:oklch(0.6822 calc(0.0413 * var(--tc)) calc(259.27deg + var(--tr)));font-size:24px;line-height:1;cursor:pointer}.atu-x:hover{color:#fff;background:#1a2436}
html.leve .atu-not,html.leve .atu-card{animation:none}html.leve .atu-not{-webkit-backdrop-filter:none;backdrop-filter:none}html.leve .atu-not.toca .atu-ic svg{animation:none}
@media (max-width:560px){.atu-card{flex-direction:column;gap:14px;padding:22px 20px 20px}.atu-cx b{font-size:19px}}
#ocV .ocm{display:block;margin-top:4px;font-size:11px;line-height:1.35;color:var(--m);text-transform:none;letter-spacing:0;font-weight:500}
.grl{display:flex;gap:14px;align-items:flex-start;margin-top:18px;padding-top:16px;border-top:1px solid var(--l)}
.grl .sw{flex:none;margin-top:2px}.grl>div>b{display:block;margin-bottom:4px}.grl small b{color:var(--t)}.grl small{display:block;color:var(--m);line-height:1.5}
.grl .grs{color:var(--r4,var(--t));margin-top:6px;font-weight:600}.grl .grs:empty{display:none}
.grp{display:flex;flex-wrap:wrap;gap:8px;margin:12px 0 8px}.grp button{padding:8px 14px;border-radius:10px;border:1px solid var(--l2);background:var(--p2);color:var(--t);font:inherit;font-size:13px;font-weight:600;cursor:pointer}
.grp button.on{border-color:var(--r);background:oklch(0.6381 calc(0.1873 * var(--tc)) calc(256.90deg + var(--tr)) / .16);box-shadow:inset 0 0 0 1px var(--r)}
.lim{margin:10px 0 0;padding:10px 12px;border-radius:12px;background:var(--p2);border:1px solid var(--l);font-size:13px;line-height:1.5;text-align:left}.lim b{display:block;margin-bottom:2px}
/* v9.2: cor do painel */
.tmg{display:grid;grid-template-columns:repeat(auto-fill,minmax(118px,1fr));gap:12px}
.tmb{display:grid;justify-items:center;gap:10px;padding:16px 10px 14px;border-radius:16px;border:1px solid var(--l);background:var(--p2);color:var(--t);cursor:pointer;font:inherit;font-weight:600;transition:border-color .2s,transform .2s}
.tmb:hover{border-color:var(--l2);transform:translateY(-2px)}
.tmb i{width:54px;height:54px;border-radius:50%;background:radial-gradient(circle at 35% 30%,oklch(0.8 calc(0.12 * var(--tk,1)) calc(256.9deg + var(--tt))),oklch(0.638 calc(0.187 * var(--tk,1)) calc(256.9deg + var(--tt))) 45%,oklch(0.52 calc(0.27 * var(--tk,1)) calc(274.3deg + var(--tt))));box-shadow:0 0 0 3px var(--p2),0 0 0 4px var(--l2),0 6px 22px oklch(0.638 calc(0.187 * var(--tk,1)) calc(256.9deg + var(--tt)) / .45)}
.tmb.on{border-color:var(--r);box-shadow:inset 0 0 0 1px var(--r)}
.tmb.on i{box-shadow:0 0 0 3px var(--p2),0 0 0 5px var(--r),0 6px 22px oklch(0.638 calc(0.187 * var(--tk,1)) calc(256.9deg + var(--tt)) / .55)}
#p-cores input.tmr{width:100%;height:14px;border:0;margin:6px 0 2px;-webkit-appearance:none;appearance:none;border-radius:99px;outline:none;cursor:pointer;
 background:linear-gradient(90deg,oklch(.64 .17 76.9deg),oklch(.64 .17 121.9deg),oklch(.64 .17 166.9deg),oklch(.64 .17 211.9deg),oklch(.64 .17 256.9deg),oklch(.64 .17 301.9deg),oklch(.64 .17 346.9deg),oklch(.64 .17 31.9deg),oklch(.64 .17 76.9deg))}
#p-cores input.tmr::-webkit-slider-thumb{-webkit-appearance:none;width:24px;height:24px;border-radius:50%;background:#fff;border:3px solid var(--r);box-shadow:0 2px 10px rgba(0,0,0,.5)}
#p-cores input.tmr:focus-visible{box-shadow:0 0 0 3px var(--r3)}
</style>
</head>
<body>
<div id="fundo"></div>
<svg width="0" height="0" style="position:absolute" aria-hidden="true" focusable="false"><defs><linearGradient id="vgr" gradientUnits="userSpaceOnUse" x1="3" y1="2" x2="21" y2="22"><stop offset="0" style="stop-color:oklch(0.8319 calc(0.0850 * var(--tc)) calc(255.19deg + var(--tr)))"/><stop offset=".55" style="stop-color:oklch(0.7066 calc(0.1488 * var(--tc)) calc(255.58deg + var(--tr)))"/><stop offset="1" style="stop-color:oklch(0.6381 calc(0.1873 * var(--tc)) calc(256.90deg + var(--tr)))"/></linearGradient></defs></svg>

<svg width="0" height="0" style="position:absolute" aria-hidden="true"><defs>
<linearGradient id="gR" x1="0" y1="0" x2="1" y2="1"><stop offset="0" style="stop-color:oklch(0.7361 calc(0.1317 * var(--tc)) calc(255.43deg + var(--tr)))"/><stop offset=".5" style="stop-color:oklch(0.6381 calc(0.1873 * var(--tc)) calc(256.90deg + var(--tr)))"/><stop offset="1" style="stop-color:oklch(0.4473 calc(0.1681 * var(--tc)) calc(258.79deg + var(--tr)))"/></linearGradient>
<linearGradient id="gE" x1="0" y1="0" x2="0" y2="1"><stop offset="0" style="stop-color:oklch(0.7070 calc(0.1484 * var(--tc)) calc(255.84deg + var(--tr)))"/><stop offset="1" style="stop-color:oklch(0.3991 calc(0.1348 * var(--tc)) calc(257.87deg + var(--tr)))"/></linearGradient>
</defs></svg>

<div id="boot"><div class="em"><div class="emb" id="embBoot"></div><h2 class="w3" data-t="Th Boost"><span class="th">Th</span> <span class="bo">Boost</span></h2><p>PAINEL DE DESEMPENHO</p><div class="lin"><i></i></div></div></div>
<div id="off"><div><div class="vz"><div class="ic" id="icOff"></div><b>O Th Boost foi encerrado</b><span>Você pode fechar esta janela. Abra o programa de novo pelo atalho para voltar a usar.</span></div></div></div>

<div class="app">
  <nav class="nv">
    <div class="marca"><div class="emb" id="embMarca"></div><div><b class="w3" data-t="Th Boost"><span class="th">Th</span> <span class="bo">Boost</span></b><span class="ola">Olá, <strong id="olaN">...</strong><button type="button" class="lap" id="olaL" title="Mudar o nome" aria-label="Mudar o nome"><svg class="ico" viewBox="0 0 24 24" aria-hidden="true"><path d="M4 20h4L18.5 9.5a2.1 2.1 0 0 0-3-3L5 17v3z"/><path d="M13.5 6.5l3 3"/></svg></button></span></div></div>
    <div id="menu"></div>
    <div class="fim">
      <div class="adm" id="adm"><i></i><div><span id="admT">Administrador</span><small id="admS"></small></div></div>
      <div class="ver" id="ver">v5.0</div>
    </div>
  </nav>

  <div class="main">
    <header class="topo">
      <div><h1 id="tit">Início</h1><div class="sub" id="sub"></div></div>
      <div class="dir"><span class="modo" id="modo"><i></i><span id="modoT">NORMAL</span></span><span class="relogio" id="rel">--:--:--</span></div>
    </header>
    <div class="prog" id="prog"><b id="progB"></b></div>
    <div class="sessb" id="sessB" hidden></div>
    <div class="palco">

      <!-- INÍCIO -->
      <section class="pg" id="p-inicio">
        <div class="hero" style="--i:0">
          <i class="feixe"></i>
          <div class="emb" id="embHero"></div>
          <div>
            <h2 class="w3" data-t="Th Boost"><span class="th">Th</span> <span class="bo">Boost</span></h2>
            <div class="tag">Deixe o computador rápido em um clique</div>
            <div class="est"><i></i><span id="heroEst">Pronto para otimizar</span></div>
            <div class="linha"><button class="bt p grande" id="heroBt" data-a="otimizar_tudo"><svg class="ico" viewBox="0 0 24 24"><path d="M13 2 4 14h7l-1 8 9-12h-7z"/></svg><span>Começar otimização</span></button><button class="bt grande xbtn" data-ir="extremo"><svg class="ico" viewBox="0 0 24 24"><path d="M12 22c4.4 0 7-2.9 7-6.8 0-3.2-1.9-5.2-3.4-7C14.4 6.8 13.6 5 13.3 2c-3 1.9-5.3 5.2-5.3 8.8 0 .9.1 1.7.5 2.5-.9-.2-1.8-.9-2.2-2.3C4.7 12.2 5 14 5 15.2 5 19.1 7.6 22 12 22z"/></svg><span>Otimização Extrema</span></button></div>
          </div>
          <div class="saude"><div class="anel"><svg viewBox="0 0 140 140"><circle class="tr" cx="70" cy="70" r="56" style="stroke:rgba(255,255,255,.14)"/><circle class="vl" id="vlSaude" cx="70" cy="70" r="56"/></svg><div class="num" id="nSaude">--</div></div><small>Saúde do PC</small></div>
        </div>

        <div class="vant" style="--i:1" role="list" aria-label="O que o Th Boost faz"><div class="va" role="link" tabindex="0" data-ir="jogos" style="--k:0" title="Abrir Jogos: otimizar antes de jogar e ajustes de FPS"><span class="vi"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M4.2 18.2a9.2 9.2 0 1 1 15.6 0"/><path d="M12 5.2v1.5M6.3 7.7l1.1 1.1M17.7 7.7l-1.1 1.1M3.9 13.4h1.5M18.6 13.4h1.5"/><g class="agulha"><path d="M12 13.4V7.6"/></g><circle cx="12" cy="13.4" r="1.7"/></svg></span><span class="vt"><b>+FPS</b><small>Mais desempenho em seus jogos</small></span></div><div class="va" role="link" tabindex="0" data-ir="mouse" style="--k:1" title="Abrir Ponteiro e teclado: tira opções que atrapalham a mira e a digitação"><span class="vi"><svg viewBox="0 0 24 24" aria-hidden="true"><g transform="rotate(40 12 12)"><g class="foguete"><path d="M12 2.4c3.1 2.1 4.8 5.2 4.8 9.2 0 1.4-.3 2.8-.8 3.9H8c-.5-1.1-.8-2.5-.8-3.9 0-4 1.7-7.1 4.8-9.2z"/><circle cx="12" cy="9.2" r="1.7"/><path d="M7.6 11.4 4.7 14.4l.7 3.4 3-1.6M16.4 11.4l2.9 3-.7 3.4-3-1.6"/><path class="chama" d="M10.2 18.1c0 1.6.7 2.8 1.8 3.6 1.1-.8 1.8-2 1.8-3.6"/></g></g></svg></span><span class="vt"><b>-INPUT LAG</b><small>Menos travamentos e stutter</small></span></div><div class="va" role="link" tabindex="0" data-ir="otimizacao" style="--k:2" title="Abrir Otimizar tudo"><span class="vi"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 2.8 4.6 5.6v5.6c0 4.5 3 8 7.4 9.9 4.4-1.9 7.4-5.4 7.4-9.9V5.6z"/><path class="ok" pathLength="10" d="m8.7 12.1 2.4 2.4 4.3-4.9"/></svg></span><span class="vt"><b>SISTEMA LEVE</b><small>Windows otimizado e responsivo</small></span></div><div class="va" role="link" tabindex="0" data-ir="extremo" style="--k:3" title="Abrir Otimização Extrema (CPU, GPU, memória e serviços têm página própria no menu)"><span class="vi"><svg viewBox="0 0 24 24" aria-hidden="true"><g class="roda"><path d="M19.4 13a7.6 7.6 0 0 0 .1-1 7.6 7.6 0 0 0-.1-1l2-1.6-2-3.4-2.4 1a7.5 7.5 0 0 0-1.7-1l-.4-2.5h-4l-.4 2.5a7.5 7.5 0 0 0-1.7 1l-2.4-1-2 3.4 2 1.6a7.6 7.6 0 0 0 0 2l-2 1.6 2 3.4 2.4-1a7.5 7.5 0 0 0 1.7 1l.4 2.5h4l.4-2.5a7.5 7.5 0 0 0 1.7-1l2.4 1 2-3.4z"/><circle cx="12" cy="12" r="3.1"/></g></svg></span><span class="vt"><b>AJUSTES AVANÇADOS</b><small><span class="vl" role="link" tabindex="0" data-ir="cpu" title="Abrir a página Processador">CPU</span>, <span class="vl" role="link" tabindex="0" data-ir="gpu" title="Abrir a página GPU &amp; NVIDIA">GPU</span>, <span class="vl" role="link" tabindex="0" data-ir="memoria" title="Abrir a página Memória RAM">memória</span>, <span class="vl" role="link" tabindex="0" data-ir="servicos" title="Abrir a página Serviços">serviços</span> e <span class="vl" role="link" tabindex="0" data-ir="memoria" title="Guia passo a passo para ativar o perfil da memória na BIOS (XMP/DOCP/EXPO). O Th Boost só guia e reinicia direto na BIOS: ele não grava nada nela.">BIOS</span></small></span></div></div>

        <div class="grade g4" style="--i:2" id="tiles"></div>

        <div class="grade g4" id="gauges" style="--i:3"></div>

        <div class="cd led" style="--i:4"><h3>Uso ao vivo</h3><div class="leg"><span><i style="background:oklch(0.6381 calc(0.1873 * var(--tc)) calc(256.90deg + var(--tr)))"></i>CPU</span><span><i style="background:oklch(0.9149 calc(0.0404 * var(--tc)) calc(254.04deg + var(--tr)))"></i>Memória</span></div><canvas class="gf" id="gfInicio"></canvas></div>
      </section>

      <!-- OTIMIZAÇÃO -->
      <section class="pg" id="p-otimizacao">
        <div class="grade gA" style="grid-template-columns:minmax(0,1.15fr) minmax(0,1fr)">
          <div class="cd led" style="--i:0">
            <h3>Otimização completa</h3>
            <p>Limpa temporários, navegadores, caches de programas e lixo do Windows, libera a memória se ela estiver apertada, ativa o plano Alto desempenho (se você não escolheu um perfil de processador) e limpa o DNS. A lixeira não é esvaziada, nada é desinstalado e senhas e históricos ficam como estão.</p>
            <div class="passos" id="passos"></div>
            <div class="otlib"><span>Lixo apagado nesta rodada</span><b id="otMb">0 MB</b></div>
            <div class="linha" style="margin-top:20px"><button class="bt p grande" data-a="otimizar_tudo" id="otBt"><svg class="ico" viewBox="0 0 24 24"><path d="M13 2 4 14h7l-1 8 9-12h-7z"/></svg><span>Otimizar tudo</span></button></div>
          </div>
          <div style="display:grid;gap:16px;align-content:start" id="acoesOt"></div>
        </div>
        <div class="cd" style="--i:2"><h3>Histórico de ações</h3><div class="hist" id="hist"></div></div>
      </section>

      <!-- OTIMIZAÇÃO EXTREMA -->
      <section class="pg" id="p-extremo">
        <div class="avs" id="xAdm" hidden></div>
        <div class="xhero fase-idle" id="xHero" style="--i:0">
          <canvas class="xpart" id="xPart"></canvas>
          <div>
            <span class="xtag"><svg class="ico" viewBox="0 0 24 24" aria-hidden="true"><path d="M13 2 4 14h7l-1 8 9-12h-7z"/></svg><span id="xTagT">MODO MÁXIMO</span></span>
            <div class="nivel" id="xNivel" role="group" aria-label="Nível da otimização"><button data-nivel="extrema">EXTREMA</button><button data-nivel="suprema">SUPREMA</button></div>
            <h2>Otimização <b id="xNome">Extrema</b></h2>
            <p class="xsub" id="xSub"></p>
            <div class="xstat"><i></i><span id="xStatus">Pronta para começar</span></div>
            <div class="linha">
              <button class="bt xgo" id="xGo"><svg class="ico" viewBox="0 0 24 24" aria-hidden="true"><path d="M13 2 4 14h7l-1 8 9-12h-7z"/></svg><span>Ativar Otimização Extrema</span></button>
              <button class="bt grande" id="xParar" hidden>Parar</button>
            </div>
            <div class="xrein" id="xRein" hidden></div>
          </div>
          <div class="xreator" id="xReator">
            <svg viewBox="0 0 300 300" aria-hidden="true">
              <defs>
                <radialGradient id="xhg" cx=".5" cy=".5" r=".5"><stop offset="0" style="stop-color:var(--xc);stop-opacity:.55"/><stop offset=".6" style="stop-color:var(--xb);stop-opacity:.18"/><stop offset="1" style="stop-color:var(--xb);stop-opacity:0"/></radialGradient>
                <linearGradient id="xrg" x1="0" y1="0" x2="1" y2="1"><stop offset="0" style="stop-color:var(--xa)"/><stop offset=".55" style="stop-color:var(--xb)"/><stop offset="1" style="stop-color:var(--xc)"/></linearGradient>
                <radialGradient id="xcg" cx=".5" cy=".4" r=".7"><stop offset="0" style="stop-color:oklch(0.3087 calc(0.0565 * var(--tc)) calc(242.22deg + var(--tr)))"/><stop offset="1" stop-color="#060e12"/></radialGradient>
                <filter id="xbl" x="-30%" y="-30%" width="160%" height="160%"><feGaussianBlur stdDeviation="3.2"/></filter>
              </defs>
              <circle class="xhalo" cx="150" cy="150" r="146" fill="url(#xhg)"/>
              <g class="xr1"><circle cx="150" cy="150" r="136" fill="none" style="stroke:var(--xc)" stroke-opacity=".55" stroke-width="1.5" stroke-dasharray="2 9"/></g>
              <g class="xr2">
                <circle cx="150" cy="150" r="122" fill="none" stroke="url(#xrg)" stroke-width="5" stroke-linecap="round" stroke-dasharray="120 82 60 90 40 60" opacity=".9"/>
                <circle cx="150" cy="150" r="122" fill="none" stroke="url(#xrg)" stroke-width="11" stroke-linecap="round" stroke-dasharray="120 646" filter="url(#xbl)" opacity=".5"/>
              </g>
              <circle cx="150" cy="150" r="104" fill="none" stroke="#10212a" stroke-width="12"/>
              <circle id="xProg" cx="150" cy="150" r="104" fill="none" stroke="url(#xrg)" stroke-width="12" stroke-linecap="round" stroke-dasharray="653.45" stroke-dashoffset="653.45" transform="rotate(-90 150 150)" style="transition:stroke-dashoffset .8s var(--ease)"/>
              <g class="xr3"><circle cx="150" cy="150" r="88" fill="none" style="stroke:var(--xa)" stroke-opacity=".5" stroke-width="3" stroke-dasharray="1 6.2"/></g>
              <circle class="xcore" cx="150" cy="150" r="70" fill="url(#xcg)" stroke="url(#xrg)" stroke-width="2.5"/>
              <g class="xo1"><circle cx="150" cy="14" r="5" style="fill:var(--xa)"/><circle cx="150" cy="14" r="10" style="fill:var(--xa)" opacity=".3" filter="url(#xbl)"/></g>
              <g class="xo2"><circle cx="150" cy="286" r="4" style="fill:var(--xc)"/></g>
              <g class="xo3"><circle cx="16" cy="150" r="3.5" style="fill:var(--xb)"/></g>
            </svg>
            <div class="xsweep"></div>
            <div class="xc"><b id="xPct"></b><small id="xFase">PRONTO</small></div>
          </div>
        </div>

        <div class="vant" style="--i:1" role="list" aria-label="O que a Otimização faz"><div class="va" role="link" tabindex="0" data-ir="jogos" style="--k:0" title="Abrir Jogos: otimizar antes de jogar e ajustes de FPS"><span class="vi"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M4.2 18.2a9.2 9.2 0 1 1 15.6 0"/><path d="M12 5.2v1.5M6.3 7.7l1.1 1.1M17.7 7.7l-1.1 1.1M3.9 13.4h1.5M18.6 13.4h1.5"/><g class="agulha"><path d="M12 13.4V7.6"/></g><circle cx="12" cy="13.4" r="1.7"/></svg></span><span class="vt"><b>+FPS</b><small>Mais desempenho em seus jogos</small></span></div><div class="va" role="link" tabindex="0" data-ir="mouse" style="--k:1" title="Abrir Ponteiro e teclado: tira opções que atrapalham a mira e a digitação"><span class="vi"><svg viewBox="0 0 24 24" aria-hidden="true"><g transform="rotate(40 12 12)"><g class="foguete"><path d="M12 2.4c3.1 2.1 4.8 5.2 4.8 9.2 0 1.4-.3 2.8-.8 3.9H8c-.5-1.1-.8-2.5-.8-3.9 0-4 1.7-7.1 4.8-9.2z"/><circle cx="12" cy="9.2" r="1.7"/><path d="M7.6 11.4 4.7 14.4l.7 3.4 3-1.6M16.4 11.4l2.9 3-.7 3.4-3-1.6"/><path class="chama" d="M10.2 18.1c0 1.6.7 2.8 1.8 3.6 1.1-.8 1.8-2 1.8-3.6"/></g></g></svg></span><span class="vt"><b>-INPUT LAG</b><small>Menos travamentos e stutter</small></span></div><div class="va" role="link" tabindex="0" data-ir="otimizacao" style="--k:2" title="Abrir Otimizar tudo"><span class="vi"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 2.8 4.6 5.6v5.6c0 4.5 3 8 7.4 9.9 4.4-1.9 7.4-5.4 7.4-9.9V5.6z"/><path class="ok" pathLength="10" d="m8.7 12.1 2.4 2.4 4.3-4.9"/></svg></span><span class="vt"><b>SISTEMA LEVE</b><small>Windows otimizado e responsivo</small></span></div><div class="va" role="link" tabindex="0" data-rola="xCards" style="--k:3" title="Ver o que esta otimização ajusta (CPU, GPU, memória e serviços têm página própria no menu)"><span class="vi"><svg viewBox="0 0 24 24" aria-hidden="true"><g class="roda"><path d="M19.4 13a7.6 7.6 0 0 0 .1-1 7.6 7.6 0 0 0-.1-1l2-1.6-2-3.4-2.4 1a7.5 7.5 0 0 0-1.7-1l-.4-2.5h-4l-.4 2.5a7.5 7.5 0 0 0-1.7 1l-2.4-1-2 3.4 2 1.6a7.6 7.6 0 0 0 0 2l-2 1.6 2 3.4 2.4-1a7.5 7.5 0 0 0 1.7 1l.4 2.5h4l.4-2.5a7.5 7.5 0 0 0 1.7-1l2.4 1 2-3.4z"/><circle cx="12" cy="12" r="3.1"/></g></svg></span><span class="vt"><b>AJUSTES AVANÇADOS</b><small><span class="vl" role="link" tabindex="0" data-ir="cpu" title="Abrir a página Processador">CPU</span>, <span class="vl" role="link" tabindex="0" data-ir="gpu" title="Abrir a página GPU &amp; NVIDIA">GPU</span>, <span class="vl" role="link" tabindex="0" data-ir="memoria" title="Abrir a página Memória RAM">memória</span>, <span class="vl" role="link" tabindex="0" data-ir="servicos" title="Abrir a página Serviços">serviços</span> e <span class="vl" role="link" tabindex="0" data-ir="memoria" title="Guia passo a passo para ativar o perfil da memória na BIOS (XMP/DOCP/EXPO). O Th Boost só guia e reinicia direto na BIOS: ele não grava nada nela.">BIOS</span></small></span></div></div>

        <div class="grade g4 xcards" id="xCards" style="--i:2"></div>

        <div class="xcorpo" style="--i:3">
          <div class="cd led"><h3>Passo a passo</h3><div class="xps" id="xPassos"></div></div>
          <div style="display:grid;gap:16px;align-content:start" id="xLado"></div>
        </div>

        <div class="cd" style="--i:4">
          <h3>Seguro e reversível</h3>
          <ul class="xseg" id="xSeg"></ul>
        </div>
      </section>

      <!-- JOGOS -->
      <section class="pg" id="p-jogos">
        <div class="avs" id="jAdm" hidden></div>
        <div class="jhero" id="jHero" style="--i:0">
          <div>
            <span class="jtag"><svg class="ico" viewBox="0 0 24 24" aria-hidden="true"><path d="M12 2c3 2 5 6 5 10l-2 3H9l-2-3c0-4 2-8 5-10z"/><circle cx="12" cy="9" r="1.5"/><path d="M9 15l-3 3M15 15l3 3M12 17v4"/></svg>MAIS FPS, MENOS TRAVADAS</span>
            <h2>Otimizar <b>antes de jogar</b></h2>
            <p class="sub2" id="jSub"></p>
            <div class="xstat"><i></i><span id="jStatus">Pronto para otimizar</span></div>
            <div class="linha">
              <button class="bt jgo" id="jGo" data-act="jogo_pc"><svg class="ico" viewBox="0 0 24 24" aria-hidden="true"><path d="M13 2 4 14h7l-1 8 9-12h-7z"/></svg><span>Otimizar meu PC para jogar</span></button>
            </div>
          </div>
          <div class="jlado" id="jLado"></div>
        </div>

        <div class="grade g3">
          <div class="cd led" style="--i:1"><h3>Biblioteca</h3><div class="nm" id="jgN">--</div><p id="jgS">Steam, Epic, Riot, Roblox, FiveM e mais</p><div class="linha" style="margin-top:12px;flex-wrap:wrap"><button class="bt g" data-a="jogos_procurar">Procurar de novo</button><button class="bt g" data-a="jogo_adicionar" id="jgAdd" title="Escolha o programa (.exe) de um jogo que não apareceu">Adicionar jogo</button></div><button class="bt g" data-a="jogos_mostrar_ocultos" id="jgOc" hidden>Mostrar os que tirei</button></div>
          <div class="cd led" style="--i:2"><h3>Modo automático</h3><p id="jAutoT">Quando um jogo da lista abrir, o Th Boost otimiza sozinho e devolve tudo ao normal quando o jogo fechar.</p><div class="linha" style="margin-top:14px"><button class="sw" id="swAuto" aria-label="Modo automático" aria-pressed="false"><i></i></button><span class="st" id="stAuto" style="font-weight:800;color:var(--m);letter-spacing:.1em;font-size:12px">DESLIGADO</span></div></div>
          <div class="cd led" style="--i:3"><h3>Modo FPS On</h3><p id="jgFps">Dá prioridade ao jogo e liga o plano de desempenho. Ao desligar, volta como estava.</p><div class="linha" style="margin-top:14px"><button class="sw" id="swFps2" aria-label="Modo FPS On"><i></i></button><span class="st" id="stFps2" style="font-weight:800;color:var(--m);letter-spacing:.1em;font-size:12px">DESLIGADO</span></div></div>
        </div>

        <div id="jogosBox" style="--i:4"></div>

        <div class="cd led cab" style="--i:5;margin-top:16px"><div><h2>Ajustes de FPS do Windows</h2><p>Ligam o que tira trabalho do jogo: Game DVR, Game Bar, prioridade de jogos, mouse sem aceleração e rede sem atraso. Cada um pode ser desfeito aqui. Os de <b>risco médio</b> pedem sua confirmação.</p><div class="ctr" id="ctFps">&nbsp;</div></div></div>
        <div class="ajs" id="lsFps" style="--i:6"><div class="sk fino"></div><div class="sk fino"></div></div>

        <div class="grade g2" style="--i:7">
          <div class="cd" id="jMon"><h3>Monitor</h3><div class="sk fino"></div></div>
          <div class="cd" id="jPerf"><h3>Perfis por jogo</h3><div class="sk fino"></div></div>
        </div>
        <div class="cd" style="--i:8"><h3>O que esperar</h3><p>O ganho de FPS depende do seu PC: costuma ser maior em computadores com pouca memória, muitos programas abertos ou plano de energia econômico, e menor em máquinas já enxutas. O Th Boost não inventa FPS: ele tira peso de segundo plano e liga o que ajuda. Antes de mexer, guarda o original, e <b>Terminar sessão</b> devolve plano de energia, serviços e prioridades.</p></div>
      </section>

      <!-- GPU -->
      <section class="pg" id="p-overlay"></section>
      <section class="pg" id="p-gpu">
        <div class="grade gA">
          <div class="cd led mt" style="--i:0"><h3>Potência da placa</h3><div class="anel gr"><svg viewBox="0 0 140 140"><circle class="tr" cx="70" cy="70" r="56"/><circle class="vl" id="vlPot" cx="70" cy="70" r="56"/></svg><div class="num" id="nPot">N/D</div></div><div class="sb" id="sbPot">Lendo a placa...</div></div>
          <div class="cd" style="--i:1" id="gpuCtl">
            <div class="gt" id="gpuNome">Lendo GPU...</div>
            <p id="gpuLim"></p>
            <div class="ocn" id="ocN"><b id="ocPct">0%</b><span id="ocRot">Padrão da placa</span></div>
            <input type="range" id="rg" min="0" max="150" step="5" value="0" disabled aria-label="Nível de overclock da placa de vídeo">
            <div class="ocm"><span>0%</span><span>50%</span><span>100%</span><span>150%</span></div>
            <div class="ocv" id="ocV"></div>
            <div class="linha"><button class="bt p grande" id="ocAp" disabled>Aplicar overclock</button><button class="bt grande" id="ocRe" disabled>Voltar a 0%</button></div>
            <div class="ocs" id="ocAg"></div>
          </div>
        </div>
        <div class="grade g3" id="gpuChips" style="--i:2"></div>
        <div class="cd" style="--i:3"><h3>Atenção</h3><p>Overclock é por sua conta e risco: acima do padrão a placa esquenta e gasta mais, e se ela não aguentar o jogo (ou o Windows) pode travar. O Th Boost <b>sempre abre em 0%</b>, não grava nada na placa (reiniciar o PC volta ao padrão), zera sozinho ao fechar e desliga sozinho se a placa passar de <b id="ocLim">88</b>°C. A barra vai até 150% da faixa que a própria placa libera: 100% já é forte, acima disso só para quem sabe o que está fazendo. Precisa de Administrador e de placa NVIDIA com driver atualizado: funciona das GTX 600 em diante, inclusive as mais antigas como a GTX 750 (em notebook, muitas vezes o próprio driver trava o núcleo e a memória). Placa AMD: use o <b>AMD Software: Adrenalin</b>, em Desempenho › Ajuste. Placa Intel Arc: use o <b>Intel Graphics Software</b> (ou Arc Control). O vídeo integrado do processador (Intel UHD/Iris) não aceita overclock.</p></div>
      </section>

      <!-- MONITOR -->
      <section class="pg" id="p-monitor">
        <div class="grade gA" style="grid-template-columns:260px minmax(0,1fr)">
          <div class="cd led mt" style="--i:0"><h3>FPS</h3><div class="nm" id="fpsN" style="font-size:64px;margin:6px 0 2px">--</div><p id="fpsS">Ligue o contador para ver os quadros.</p><p id="fps1S" class="sub2" style="margin:4px 0 0"></p><p class="lim" id="limS" hidden></p><div class="linha" style="justify-content:center;margin-top:12px"><button class="bt g" data-a="fps_contador" id="fpsBt">Ligar contador</button></div></div>
          <div class="cd" style="--i:1"><div class="leg"><span><i style="background:oklch(0.6381 calc(0.1873 * var(--tc)) calc(256.90deg + var(--tr)))"></i>CPU</span><span><i style="background:oklch(0.9149 calc(0.0404 * var(--tc)) calc(254.04deg + var(--tr)))"></i>RAM</span><span><i style="background:#ffa23d"></i>GPU</span></div><canvas class="gf" id="gfMonitor"></canvas></div>
        </div>
        <div class="cd" style="--i:2" id="barras"></div>
      </section>

      <!-- MODOS -->
      <section class="pg" id="p-modos">
        <div class="grade g2">
          <div class="cd led modo-c" style="--i:0"><h2>Modo Leve</h2><p>Programas em segundo plano recebem prioridade baixa. O app em foco fica com prioridade alta.</p><div class="lin"><button class="sw" id="swLeve" aria-label="Modo Leve"><i></i></button><span class="st" id="stLeve">DESLIGADO</span></div></div>
          <div class="cd led modo-c" style="--i:1"><h2>Modo FPS On</h2><p id="fpsDesc">O jogo ganha prioridade sobre o resto (Modo Leve) e o PC vai para o plano de desempenho. Ao desligar, tudo volta como estava.</p><div class="lin"><button class="sw" id="swFps" aria-label="Modo FPS On"><i></i></button><span class="st" id="stFps">DESLIGADO</span></div>
            <div class="grl"><button class="sw" id="swGr" aria-label="Gráfico leve nos jogos"><i></i></button><div><b>Gráfico leve nos jogos</b><small>Junto com o Modo FPS On, o <b>Valorant</b>, o <b>CS2</b> e o <b>Roblox</b> ficam com o gráfico no mínimo (sombras, efeitos, texturas e detalhes baixos), com a resolução em 100% para a imagem continuar nítida. Ao desligar, cada um volta ao gráfico que você usava. O jogo precisa estar fechado: se estiver aberto, muda quando ele fechar.</small>
              <div class="grp" role="group" aria-label="Perfil do gráfico leve"><button data-grp="minimo">Tudo no mínimo</button><button data-grp="proc">Processador fraco</button></div>
              <small id="grPx"></small><small class="grs" id="grSt"></small></div></div></div>
        </div>
        <div class="cd" style="--i:2"><h3>Como funciona</h3><p>Nada é encerrado: o Modo Leve só muda a prioridade de execução dos seus programas, e tudo volta ao normal ao desligar ou ao fechar o Th Boost.</p></div>
      </section>

      <!-- DISCO -->
      <section class="pg" id="p-disco">
        <div class="grade gA">
          <div class="cd led mt" style="--i:0"><h3>Disco do sistema</h3><div class="anel gr"><svg viewBox="0 0 140 140"><circle class="tr" cx="70" cy="70" r="56"/><circle class="vl" id="vlDisco" cx="70" cy="70" r="56"/></svg><div class="num" id="nDisco">--</div></div><div class="sb" id="sbDisco"></div></div>
          <div class="cd" style="--i:1"><div class="gt" id="dkT">Lendo disco...</div><div class="bar" style="grid-template-columns:50px 1fr 60px"><span>Uso</span><div class="tr"><i id="dkB"></i></div><b id="dkP">--</b></div><p>Esvaziar a lixeira apaga de forma definitiva. Temporários em uso são pulados.</p></div>
        </div>
        <div class="grade g3" id="acoesDk" style="--i:2"></div>
      </section>

      <!-- REDE -->
      <section class="pg" id="p-rede">
        <div class="grade g3">
          <div class="cd led" style="--i:0"><h3>Download</h3><div class="nm" id="rDown">--</div></div>
          <div class="cd led" style="--i:1"><h3>Upload</h3><div class="nm" id="rUp">--</div></div>
          <div class="cd led" style="--i:2"><h3>Ping</h3><div class="nm" id="rPing">--</div></div>
        </div>
        <div class="cd" style="--i:3"><div class="leg"><span><i style="background:oklch(0.6381 calc(0.1873 * var(--tc)) calc(256.90deg + var(--tr)))"></i>Download</span><span><i style="background:oklch(0.9149 calc(0.0404 * var(--tc)) calc(254.04deg + var(--tr)))"></i>Upload</span><span style="color:var(--m)">KB/s</span></div><canvas class="gf" id="gfRede"></canvas></div>
        <div class="grade g3" id="acoesRd" style="--i:4;margin-top:16px"></div>
      </section>

      <!-- DASHBOARD -->
      <section class="pg" id="p-dashboard">
        <div class="cd led dh sc-nd" id="dHero" style="--i:0">
          <div class="anel gr"><svg viewBox="0 0 140 140"><circle class="tr" cx="70" cy="70" r="56"/><circle class="vl" id="vlDash" cx="70" cy="70" r="56"/></svg><div class="num" id="nDash">--</div></div>
          <div>
            <h3>Nota geral do PC</h3>
            <h2 id="dTit">Lendo o seu PC...</h2>
            <p class="tx" id="dTxt">Estou medindo desempenho, inicialização, espaço, memória, energia, processos, jogos e segurança dos dados.</p>
            <div class="linha" style="margin-top:16px"><button class="bt p" data-ir="extremo"><svg class="ico" viewBox="0 0 24 24"><path d="M13 2 4 14h7l-1 8 9-12h-7z"/></svg><span>Melhorar agora</span></button><button class="bt" data-act="dash_atualizar">Atualizar</button><span class="lendo" id="dLendo" hidden>Lendo discos e pontos de restauração...</span></div>
          </div>
          <div class="sts" id="dStats"></div>
        </div>
        <div class="cats" id="dCats" style="--i:1"></div>
        <div class="grade" style="grid-template-columns:minmax(0,1.3fr) minmax(0,1fr);--i:2">
          <div class="cd led"><h3>O que fazer agora</h3><div id="dAch"></div></div>
          <div class="cd"><h3>Seu computador</h3><div class="dg" id="dSis"></div></div>
        </div>
      </section>

      <!-- PROCESSOS -->
      <section class="pg" id="p-processos">
        <div class="avs" id="prAdm" hidden></div>
        <div class="ph" id="prHero" style="--i:0">
          <div>
            <h3 style="margin:0 0 6px;font-size:11.5px;letter-spacing:.14em;color:oklch(0.8224 calc(0.0870 * var(--tc)) calc(255.07deg + var(--tr)));font-weight:800">PROCESSOS RODANDO AGORA</h3>
            <h2><span id="prN">--</span><small id="prMb"></small></h2>
            <p class="sub2" id="prSub">Lendo os processos do Windows...</p>
            <div class="prmeta" id="prMeta" hidden></div>
            <div class="prbase" id="prBase" hidden></div>
            <div class="linha"><button class="bt p grande" id="prGo" data-act="proc_reduzir"><svg class="ico" viewBox="0 0 24 24"><path d="M3 6h18M3 12h12M3 18h8"/><path d="M17 18h5"/></svg><span>Reduzir processos</span></button><button class="bt" id="prDes" data-act="proc_desfazer" hidden>Desfazer</button></div>
          </div>
          <div class="pcat" id="prCat"></div>
        </div>
        <div class="cd led jp" id="prJob" hidden></div>
        <div class="cd led cpuc" id="prCpu" style="--i:1" hidden></div>
        <div class="grade g2" style="--i:1">
          <div class="cd" id="prOpc"></div>
          <div class="cd" id="prSvc"></div>
        </div>
        <div class="cd" style="--i:2;margin-bottom:16px"><h3>Programas rodando agora</h3><p>Fecha tudo de um programa de uma vez. Salve o seu trabalho antes: o que não foi salvo se perde. Programas do Windows, a proteção do PC, drivers e navegadores ficam travados de propósito.</p><div class="chips" id="prChips"></div><div class="lrs" id="prLista"><div class="sk fino"></div></div></div>
        <div class="cd" style="--i:3"><h3>Serviços de programas instalados</h3><p>Serviços de terceiros que iniciam sozinhos com o Windows. “Deixar manual” faz o serviço só iniciar quando o programa precisar; o programa continua instalado e dá para desfazer aqui. Antivírus, drivers, VPN, anti-cheat, backup e impressão ficam fora desta lista.</p><div id="prSvc3" style="margin-top:12px"><div class="sk fino"></div></div></div>
      </section>

      <!-- MEMÓRIA RAM -->
      <section class="pg" id="p-memoria">
        <div class="avs" id="mmAdm" hidden></div>
        <div class="cd led mmh" id="mmHero" style="--i:0"><div class="sk fino"></div></div>
        <div class="grade g2 mmg" style="--i:1">
          <div class="cd" id="mmAch"><h3>Diagnóstico</h3><div class="sk fino"></div></div>
          <div class="cd" id="mmGuia"></div>
        </div>
        <div class="grade g2 mmg" style="--i:2">
          <div class="cd" id="mmPentes"></div>
          <div class="cd" id="mmFaz"></div>
        </div>
      </section>

      <!-- PROCESSADOR -->
      <section class="pg" id="p-cpu">
        <div class="avs" id="cpAdm" hidden></div>
        <div class="cd led mmh" id="cpHero" style="--i:0;grid-template-columns:1fr"><div class="sk fino"></div></div>
        <div class="grade g3 cpg" id="cpPerfis" style="--i:1"></div>
        <div class="grade g2 mmg" style="--i:2">
          <div class="cd" id="cpAgora"></div>
          <div class="cd" id="cpBios"></div>
        </div>
      </section>

      <!-- RESFRIAMENTO -->
      <section class="pg rf" id="p-resfriamento">
        <div class="avs" id="rfAdm" hidden></div>
        <div class="cd led mmh" id="rfHero" style="--i:0;grid-template-columns:1fr"><div class="sk fino"></div></div>
        <div class="cd rf-barra" id="rfBarra" style="--i:1"></div>
        <div class="grade g2 mmg" style="--i:2">
          <div class="cd" id="rfAgora"></div>
          <div class="cd" id="rfDicas"></div>
        </div>
      </section>

      <!-- CORREÇÕES -->
      <section class="pg" id="p-correcoes">
        <div class="avs" id="crAdm" hidden></div>
        <div class="cd led jp" id="crJob" hidden></div>
        <div class="cd led cab" style="--i:0"><div><h2>Consertar problemas do Windows</h2><p>Atalhos para os reparos que mais resolvem travamentos, erros de atualização, internet que some e ícones quebrados. Cada um explica o que faz antes de começar.</p></div></div>
        <div class="crg" id="crLista" style="--i:1"></div>
        <div class="cd" style="--i:2"><h3>Faltando uma DLL, jogo que não abre ou driver velho?</h3><p>Baixe direto do site oficial do fabricante. O Th Boost só abre a página; nada é baixado ou instalado por ele.</p><div class="linha" id="crLinks" style="margin-top:12px"></div></div>
      </section>

      <!-- BACKUP -->
      <section class="pg" id="p-backup">
        <div class="avs" id="bkAdm" hidden></div>
        <div class="cd led jp" id="bkJob" hidden></div>
        <div class="cd led" style="--i:0;margin-bottom:16px" id="bkArq"><div class="sk fino"></div></div>
        <div class="grade g2" style="--i:1">
          <div class="cd" id="bkPontos"><h3>Pontos de restauração</h3><div class="sk fino"></div></div>
          <div style="display:grid;gap:16px;align-content:start">
            <div class="cd" id="bkDrv"></div>
            <div class="cd" id="bkAj"></div>
          </div>
        </div>
      </section>

      <!-- FERRAMENTAS -->
      <section class="pg" id="p-ferramentas">
        <div class="tabs" id="ftTabs" style="--i:0"><button class="on" data-act="ft_aba" data-id="programas">Programas instalados</button><button data-act="ft_aba" data-id="espaco">Espaço em disco</button><button data-act="ft_aba" data-id="atalhos">Atalhos do Windows</button></div>
        <div id="ft-programas">
          <div class="cd led cab"><div><h2>Programas instalados</h2><p>A mesma lista do “Programas e recursos” do Windows. Desinstalar abre o desinstalador do próprio programa, que pede a sua confirmação.</p><div class="ctr" id="ctProg">&nbsp;</div></div></div>
          <div class="bsc"><input class="inp" id="prBusca" type="search" placeholder="Procurar um programa..." aria-label="Procurar um programa" autocomplete="off"><div class="chips" id="prOrd" style="margin:0"><button class="chip on" data-act="prog_ord" data-id="nome">A–Z</button><button class="chip" data-act="prog_ord" data-id="mb">Maiores</button><button class="chip" data-act="prog_ord" data-id="data">Mais novos</button></div></div>
          <div class="lrs" id="prgLista" style="margin-top:10px;max-height:none"><div class="sk fino"></div></div>
        </div>
        <div id="ft-espaco" hidden>
          <div class="cd led" style="margin-bottom:16px"><h2 style="margin:0;font-size:21px">Onde foi parar o espaço do disco?</h2><p>Escolha uma pasta e o Th Boost mostra o que mais pesa e os maiores arquivos. Só lê; nada é apagado nem mudado.</p><div class="chips" id="esAlvos"></div><div class="linha"><button class="bt p" id="esGo" data-act="espaco_go">Analisar</button></div></div>
          <div class="cd led jp" id="esJob" hidden></div>
          <div id="esRes"></div>
        </div>
        <div id="ft-atalhos" hidden><div class="gb2" id="atGrade"></div></div>
      </section>

      <!-- PÁGINAS DE AJUSTES (montadas pelo script) -->
      <section class="pg" id="p-windows"></section>
      <section class="pg" id="p-energia"></section>
      <section class="pg" id="p-mouse"></section>
      <section class="pg" id="p-servicos"></section>
      <section class="pg" id="p-inicializacao"></section>
      <section class="pg" id="p-privacidade"></section>
      <section class="pg" id="p-debloat"></section>

      <!-- CONFIGURAÇÕES -->
      <section class="pg" id="p-cores"></section>
      <section class="pg" id="p-config">
        <div class="cd led bgc" style="--i:0">
          <div class="bgt"><span class="bgi"><svg class="ico" viewBox="0 0 24 24" aria-hidden="true"><rect x="3" y="4" width="18" height="13" rx="2"/><path d="M8 21h8M12 17v4M9 10l2 2 4-4"/></svg></span><div><h2>Deixar em segundo plano</h2><p>Ao fechar a janela, o Th Boost continua rodando escondido. O Modo Leve e as prioridades seguem ativos, então o PC fica otimizado enquanto você joga, e ele usa pouco processador e memória. Para abrir de novo, use o atalho ou o ícone perto do relógio.</p></div></div>
          <div class="bgs"><button class="sw" id="swBg" aria-label="Deixar em segundo plano" aria-pressed="false"><i></i></button><span class="st" id="stBg">DESLIGADO</span><small id="sbBg">Ao fechar a janela, encerra</small></div>
        </div>
        <div class="grade g2">
          <div class="cd led modo-c" style="--i:0"><h2>Efeitos visuais</h2><p>Desligue para deixar o programa mais leve em computadores fracos. Tira as luzes que correm nas bordas, os brilhos e os desfoques.</p><div class="lin"><button class="sw" id="swFx" aria-label="Efeitos visuais"><i></i></button><span class="st" id="stFx">COMPLETOS</span></div></div>
          <div class="cd" style="--i:1"><h3>Diagnóstico</h3><div class="dg" id="dg"></div></div>
        </div>
        <div class="cd" style="--i:2" id="atuCfg"><div class="linha" style="flex-wrap:wrap;align-items:center;gap:16px"><div style="flex:1;min-width:220px"><b style="font-size:16px">Atualizações</b><p style="margin-top:3px" id="atuSt">Ainda não procurei versão nova.</p></div><div style="display:flex;align-items:center;gap:12px;flex-wrap:wrap"><button class="sw on" id="swAtu" aria-label="Avisar quando o dono publicar versão nova" aria-pressed="true"><i></i></button><span class="st on" id="stAtu">AVISAR</span><button class="bt" id="atuAgora">Procurar agora</button></div></div></div>
        <div class="cd" style="--i:3;margin-top:16px" id="atCfg"><div class="linha" style="flex-wrap:wrap;align-items:center;gap:16px"><div style="flex:1;min-width:220px"><b style="font-size:16px">Autoteste</b><p style="margin-top:3px" id="atSt">Confere, neste computador, se cada parte do Th Boost funciona. Só lê: não muda nada no Windows. O relatório não leva seu nome nem o nome do PC.</p></div><div style="display:flex;align-items:center;gap:12px;flex-wrap:wrap"><button class="bt p" id="atRun">Fazer autoteste</button><button class="bt" id="atCopy" hidden>Copiar relatório</button></div></div><div class="atl" id="atLista" hidden></div></div>
        <div class="cd" style="--i:2"><div class="linha" style="flex-wrap:nowrap;align-items:center;gap:16px"><div style="flex:1;min-width:0"><b style="font-size:16px">Encerrar o Th Boost</b><p style="margin-top:3px">Fecha o programa de vez, mesmo que ele esteja em segundo plano. As prioridades voltam ao normal.</p></div><button class="bt" data-c="encerrar_tudo" data-ct="Encerrar o Th Boost?" data-cp="O programa fecha por completo e o Modo Leve é desligado. Para usar de novo, abra pelo atalho.">Encerrar</button></div></div>
      </section>
    </div>
  </div>
</div>

<div id="atuNot" class="atu-not" hidden role="alertdialog" aria-modal="false" aria-labelledby="atuTit" aria-describedby="atuTx"><div class="atu-card">
 <div class="atu-ic"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M6 8a6 6 0 1 1 12 0c0 7 3 9 3 9H3s3-2 3-9"/><path d="M10.3 21a1.94 1.94 0 0 0 3.4 0"/></svg></div>
 <div class="atu-cx"><b id="atuTit">O dono atualizou o Th Boost</b><span id="atuTx"></span><ul id="atuNov" hidden></ul>
  <div class="atu-bar" id="atuBar" hidden><i id="atuPct"></i></div><small id="atuErr" hidden></small>
  <div class="atu-bt"><button class="bt p" id="atuSim">Atualizar</button><button class="bt" id="atuNao">Depois</button></div></div>
 <button class="atu-x" id="atuX" aria-label="Fechar o aviso">&times;</button>
</div></div>
<div id="toasts"></div>
<div id="otm" role="dialog" aria-modal="true" aria-labelledby="otmT"><div class="ox">
 <div class="orun">
  <h3 id="otmT">Otimizando</h3>
  <div class="oan" aria-hidden="true"><svg viewBox="0 0 200 200">
   <defs><clipPath id="otmCl"><circle cx="100" cy="100" r="80"/></clipPath>
    <linearGradient id="otmGl" x1="0" y1="0" x2="0" y2="1"><stop offset="0" style="stop-color:oklch(0.7066 calc(0.1488 * var(--tc)) calc(255.58deg + var(--tr)))"/><stop offset="1" style="stop-color:oklch(0.3991 calc(0.1348 * var(--tc)) calc(257.87deg + var(--tr)))"/></linearGradient>
    <linearGradient id="otmAr" x1="0" y1="0" x2="1" y2="1"><stop offset="0" style="stop-color:oklch(0.8611 calc(0.0663 * var(--tc)) calc(255.51deg + var(--tr)))"/><stop offset="1" style="stop-color:oklch(0.6381 calc(0.1873 * var(--tc)) calc(256.90deg + var(--tr)))"/></linearGradient></defs>
   <circle cx="100" cy="100" r="80" fill="#0a0e13"/>
   <g clip-path="url(#otmCl)"><g class="lq" id="otmLq" style="transform:translateY(172px)"><path class="on2" d="M0 6Q50-6 100 6T200 6T300 6T400 6V240H0Z"/><path class="on1" d="M0 10Q50 0 100 10T200 10T300 10T400 10V240H0Z"/></g></g>
   <circle cx="100" cy="100" r="80" fill="none" stroke="rgba(255,255,255,.07)" stroke-width="1.5"/>
   <circle class="trilho" cx="100" cy="100" r="93"/>
   <circle class="arco" id="otmArco" cx="100" cy="100" r="93" pathLength="100" stroke-dasharray="0 100" transform="rotate(-90 100 100)"/>
  </svg><div class="pct" id="otmPct">0%</div></div>
  <p id="otmPasso">Começando...</p>
  <div class="olist" id="otmLista"></div>
  <div class="olinha"><button type="button" class="bt" id="otmEsc" title="A otimização continua rodando; no fim o resultado aparece aqui">Esconder esta janela</button><button type="button" class="bt" id="otmParar" hidden>Parar</button></div>
 </div>
 <div class="ofim">
  <div class="ook" aria-hidden="true"><svg viewBox="0 0 24 24"><path class="v" d="m5 12.5 4.5 4.5L19 7.5"/><path class="ex" d="M12 6.5v7M12 17.4v.1"/></svg></div>
  <h2 id="otmFT">OTIMIZADO COM SUCESSO</h2><p id="otmFP"></p><div class="ochips" id="otmCh"></div>
  <div class="olinha"><button type="button" class="bt" id="otmReini" hidden data-c="reiniciar_pc" data-ct="Reiniciar o PC agora?" data-cp="Salve o que estiver aberto. O PC reinicia em 20 segundos e você pode cancelar aqui. O reinício termina de aplicar os ajustes.">Reiniciar agora</button><button type="button" class="bt p" id="otmOk">Concluir</button></div>
 </div>
</div></div>
<div id="cf"><div class="cx"><h3 id="cfT"></h3><p id="cfP"></p><div class="linha" style="justify-content:flex-end"><button class="bt" id="cfN">Cancelar</button><button class="bt p" id="cfS">Continuar</button></div></div></div>

<script>
const K='__TOKEN__';
const $=(s,r=document)=>r.querySelector(s),$$=(s,r=document)=>[...r.querySelectorAll(s)];
const esc=(s)=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const IC={
 inicio:'<rect x="3" y="3" width="7" height="7" rx="1.5"/><rect x="14" y="3" width="7" height="7" rx="1.5"/><rect x="3" y="14" width="7" height="7" rx="1.5"/><rect x="14" y="14" width="7" height="7" rx="1.5"/>',
 otimizacao:'<path d="M13 2 4 14h7l-1 8 9-12h-7z"/>',
 cores:'<path d="M12 3a9 9 0 1 0 0 18c1.2 0 1.8-.8 1.8-1.7 0-1.3-1.2-1.6-1.2-2.8 0-1 .8-1.7 1.8-1.7H17a4 4 0 0 0 4-4C21 6.6 17 3 12 3z"/><circle cx="7.5" cy="11" r="1.2"/><circle cx="10" cy="7" r="1.2"/><circle cx="15" cy="7.5" r="1.2"/>',
 jogos:'<path d="M7 6h10a5 5 0 0 1 5 5v2a4 4 0 0 1-7 2.6L14 14h-4l-1 1.6A4 4 0 0 1 2 13v-2a5 5 0 0 1 5-5z"/><path d="M7 10v4M5 12h4"/><circle cx="15.5" cy="11" r=".7"/><circle cx="18" cy="13" r=".7"/>',
 cpu:'<rect x="7" y="7" width="10" height="10" rx="1.5"/><path d="M10 3v4M14 3v4M10 17v4M14 17v4M3 10h4M3 14h4M17 10h4M17 14h4M10.5 12h3"/>',
 gpu:'<rect x="6" y="6" width="12" height="12" rx="2"/><rect x="9.5" y="9.5" width="5" height="5"/><path d="M9 2v3M15 2v3M9 19v3M15 19v3M2 9h3M2 15h3M19 9h3M19 15h3"/>',
 monitor:'<path d="M3 12h4l3-8 4 16 3-8h4"/>',
 disco:'<ellipse cx="12" cy="5" rx="8" ry="3"/><path d="M4 5v6c0 1.7 3.6 3 8 3s8-1.3 8-3V5M4 11v6c0 1.7 3.6 3 8 3s8-1.3 8-3v-6"/>',
 rede:'<path d="M2 8.8a15 15 0 0 1 20 0M5 12.6a10 10 0 0 1 14 0M8.5 16.2a5 5 0 0 1 7 0"/><circle cx="12" cy="19.5" r="1"/>',
 modos:'<rect x="2" y="7" width="20" height="10" rx="5"/><circle cx="16.5" cy="12" r="2.5"/>',
 config:'<path d="M4 6h8M18 6h2M4 12h2M12 12h8M4 18h10M20 18h0"/><circle cx="15" cy="6" r="2"/><circle cx="9" cy="12" r="2"/><circle cx="17" cy="18" r="2"/>',
 lixo:'<path d="M4 7h16M10 11v6M14 11v6M6 7l1 13h10l1-13M9 7V4h6v3"/>',
 ram:'<rect x="2" y="7" width="20" height="10" rx="2"/><path d="M6 17v3M10 17v3M14 17v3M18 17v3M6 11h2M11 11h2M16 11h2"/>',
 plano:'<path d="M12 2v6M5.6 5.6l4.2 4.2M2 12h6M5.6 18.4l4.2-4.2M12 22v-6M18.4 18.4l-4.2-4.2M22 12h-6M18.4 5.6l-4.2 4.2"/>',
 dns:'<circle cx="12" cy="12" r="9"/><path d="M3 12h18M12 3a14 14 0 0 1 0 18M12 3a14 14 0 0 0 0 18"/>',
 ping:'<path d="M3 17l5-5 4 3 8-9"/><path d="M15 6h5v5"/>',
 ip:'<path d="M20 12a8 8 0 1 1-2.3-5.7M20 4v5h-5"/>',
 win:'<rect x="3" y="4" width="18" height="14" rx="2"/><path d="M8 21h8M12 18v3"/>',
 check:'<path d="m5 12 5 5 9-10"/>',x:'<path d="M6 6l12 12M18 6 6 18"/>',
 seta:'<path d="m9 5 7 7-7 7"/>',busca:'<circle cx="11" cy="11" r="7"/><path d="m20 20-4-4"/>',
 bg:'<rect x="3" y="4" width="18" height="13" rx="2"/><path d="M8 21h8M12 17v4M9 10l2 2 4-4"/>',
 windows:'<rect x="3" y="4" width="18" height="16" rx="2"/><path d="M3 9h18M7 6.5h0M10 6.5h0"/>',
 energia:'<path d="M12 3v8"/><path d="M6.4 6.6a8 8 0 1 0 11.2 0"/>',
 mouse:'<rect x="6" y="3" width="12" height="18" rx="6"/><path d="M12 7v4"/>',
 servicos:'<circle cx="12" cy="12" r="3"/><path d="M12 2v3M12 19v3M2 12h3M19 12h3M4.9 4.9l2.1 2.1M17 17l2.1 2.1M4.9 19.1 7 17M17 7l2.1-2.1"/>',
 inicializacao:'<path d="M4 12h12M12 7l5 5-5 5"/><path d="M20 4v16"/>',
 privacidade:'<path d="M12 3 4 6v5c0 5 3.4 8.5 8 10 4.6-1.5 8-5 8-10V6z"/><path d="m9 12 2 2 4-4"/>',
 debloat:'<path d="M21 8 12 3 3 8v8l9 5 9-5z"/><path d="M3 8l9 5 9-5M12 13v8"/>',
 dashboard:'<path d="M4 18a8 8 0 1 1 16 0"/><path d="M12 18l4-6"/><circle cx="12" cy="18" r="1.2"/><path d="M6.3 12.3l1 .6M12 8.5V10M17.7 12.3l-1 .6"/>',
 processos:'<path d="M3 6h18M3 12h12M3 18h8"/><path d="M17 18h5"/>',
 memoria:'<rect x="2" y="6" width="20" height="10" rx="1.5"/><path d="M6 10h2M11 10h2M16 10h2M5 16v3M9 16v3M13 16v3M17 16v3"/>',
 correcoes:'<path d="M14.7 6.3a4 4 0 0 0-5.4 5.4L3 18l3 3 6.3-6.3a4 4 0 0 0 5.4-5.4l-2.5 2.5-2.4-.6-.6-2.4z"/>',
 backup:'<path d="M12 3v12M7 10l5 5 5-5"/><path d="M4 17v3h16v-3"/>',
 ferramentas:'<rect x="3" y="8" width="18" height="12" rx="2"/><path d="M9 8V5h6v3M3 13h18"/>',
 extremo:'<path d="M12 22c4.4 0 7-2.9 7-6.8 0-3.2-1.9-5.2-3.4-7C14.4 6.8 13.6 5 13.3 2c-3 1.9-5.3 5.2-5.3 8.8 0 .9.1 1.7.5 2.5-.9-.2-1.8-.9-2.2-2.3C4.7 12.2 5 14 5 15.2 5 19.1 7.6 22 12 22z"/>',traco:'<path d="M6 12h12"/>',teclado:'<rect x="2.5" y="6" width="19" height="12" rx="2.5"/><path d="M6 10h.01M10 10h.01M14 10h.01M18 10h.01M7 14h10"/>',resfriamento:'<path d="M12 2v20M4.9 6.5l14.2 11M19.1 6.5 4.9 17.5"/><path d="M9.5 4.2 12 6.2l2.5-2M9.5 19.8l2.5-2 2.5 2"/>',desfazer:'<path d="M9 14 4 9l5-5"/><path d="M4 9h10a6 6 0 0 1 0 12h-3"/>',play:'<path d="M7 4v16l13-8z"/>',info:'<circle cx="12" cy="12" r="9"/><path d="M12 11v5M12 8h0"/>',overlay:'<rect x="3" y="4" width="18" height="13" rx="2"/><path d="M7 13v-2M10.5 13V8M14 13v-3.5M17.5 13V9.5M8.5 21h7M12 17v4"/>'
};
const ico=(n,c='')=>`<svg class="ico ${c}" viewBox="0 0 24 24" aria-hidden="true">${IC[n]||''}</svg>`;
const PAGS=[['inicio','Início','Visão geral do seu computador, ao vivo','PRINCIPAL'],['dashboard','Dashboard','A nota do seu PC e o que fazer para melhorar'],['otimizacao','Otimizar tudo','Limpeza e ajustes rápidos em um clique'],['extremo','Otimização Extrema','Extrema ou Suprema: limpeza profunda e desempenho máximo'],['jogos','Jogos','Otimizar antes de jogar e ganhar FPS'],['overlay','FPS na tela','FPS, 1% baixo, CPU, GPU e temperaturas por cima do jogo'],
 ['processos','Processos','Menos processos e serviços rodando no Windows','OTIMIZAÇÃO'],['memoria','Memória RAM','Velocidade e canal da memória, e como ativar o perfil XMP'],['cpu','Processador','Perfis de desempenho da CPU: turbo, núcleos e velocidade'],['resfriamento','Resfriamento','Esfrie o PC ou o notebook com uma barra: menos calor, menos ventoinha'],['windows','Windows','Ajustes que deixam o Windows mais leve para jogos'],['energia','Energia','Plano de energia e hibernação'],['gpu','GPU & NVIDIA','Overclock da placa de vídeo NVIDIA (0 a 150%)'],['mouse','Mouse & Precisão','Ponteiro e teclado para jogar'],
 ['servicos','Serviços','Serviços do Windows que podem ser desligados'],['inicializacao','Inicialização','Programas que abrem junto com o Windows'],['rede','Rede','Velocidade, DNS e conexão'],
 ['privacidade','Privacidade','Menos coleta de dados e menos anúncios'],['debloat','Debloat','Remover apps que vêm com o Windows'],
 ['correcoes','Correções','Conserta problemas comuns do Windows','MANUTENÇÃO'],['backup','Backup','Copie seus arquivos e crie pontos de restauração'],['ferramentas','Ferramentas','Programas instalados, espaço em disco e atalhos do Windows'],['disco','Limpeza de disco','Espaço livre e arquivos temporários'],['monitor','Monitor','CPU, GPU, memória e FPS em tempo real'],
 ['modos','Modos','Ajustes de desempenho','PROGRAMA'],['cores','Cor do painel','Escolha a cor do Th Boost inteiro'],['config','Configurações','Efeitos visuais e diagnóstico']];

/* emblema (logo T com anéis girando) */
const EMB=`<svg viewBox="0 0 100 100"><defs>
<radialGradient id="gF{n}" cx=".5" cy=".42" r=".66"><stop offset="0" style="stop-color:oklch(0.3046 calc(0.0996 * var(--tc)) calc(260.24deg + var(--tr)))"/><stop offset=".6" style="stop-color:oklch(0.1734 calc(0.0484 * var(--tc)) calc(262.47deg + var(--tr)))"/><stop offset="1" stop-color="#01040a"/></radialGradient>
<linearGradient id="gA{n}" x1="0" y1="0" x2="1" y2="1"><stop offset="0" style="stop-color:oklch(0.9071 calc(0.0510 * var(--tc)) calc(238.45deg + var(--tr)))"/><stop offset=".45" style="stop-color:oklch(0.6467 calc(0.1912 * var(--tc)) calc(256.16deg + var(--tr)))"/><stop offset="1" style="stop-color:oklch(0.3895 calc(0.1670 * var(--tc)) calc(262.35deg + var(--tr)))"/></linearGradient>
<linearGradient id="gS1{n}" x1="1" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#ffffff" stop-opacity="0"/><stop offset=".12" stop-color="#ffffff"/><stop offset=".55" style="stop-color:oklch(0.7798 calc(0.1221 * var(--tc)) calc(242.88deg + var(--tr)))"/><stop offset="1" stop-opacity="0" style="stop-color:oklch(0.6467 calc(0.1912 * var(--tc)) calc(256.16deg + var(--tr)))"/></linearGradient>
<linearGradient id="gS2{n}" x1="0" y1="1" x2="1" y2="0"><stop offset="0" stop-color="#ffffff" stop-opacity="0"/><stop offset=".12" stop-color="#ffffff"/><stop offset=".55" style="stop-color:oklch(0.7798 calc(0.1221 * var(--tc)) calc(242.88deg + var(--tr)))"/><stop offset="1" stop-opacity="0" style="stop-color:oklch(0.6467 calc(0.1912 * var(--tc)) calc(256.16deg + var(--tr)))"/></linearGradient>
<linearGradient id="gT{n}" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#394152"/><stop offset=".22" stop-color="#10141d"/><stop offset=".6" stop-color="#05070c"/><stop offset="1" stop-color="#000000"/></linearGradient>
<filter id="fB{n}" x="-40%" y="-40%" width="180%" height="180%"><feGaussianBlur stdDeviation="2.4"/></filter>
</defs><circle cx="50" cy="50" r="46" fill="url(#gF{n})"/><circle cx="50" cy="50" r="43" fill="none" stroke-width="3" style="stroke:oklch(0.3042 calc(0.1122 * var(--tc)) calc(261.52deg + var(--tr)))"/><circle cx="50" cy="50" r="43" fill="none" stroke-width="1.4" opacity=".85" style="stroke:oklch(0.6819 calc(0.1723 * var(--tc)) calc(252.60deg + var(--tr)))"/><g class="orb"><circle cx="50" cy="50" r="43" fill="none" stroke-width="8" stroke-linecap="round" stroke-dasharray="78 193" filter="url(#fB{n})" opacity=".9" style="stroke:oklch(0.6467 calc(0.1912 * var(--tc)) calc(256.16deg + var(--tr)))"/><circle cx="50" cy="50" r="43" fill="none" stroke="url(#gA{n})" stroke-width="3.6" stroke-linecap="round" stroke-dasharray="78 193"/></g><g class="orb2"><circle cx="50" cy="50" r="35" fill="none" stroke-width="1.8" stroke-linecap="round" stroke-dasharray="22 198" style="stroke:oklch(0.8990 calc(0.0541 * var(--tc)) calc(241.63deg + var(--tr)))"/></g><path d="M95 5 L47 40 L50.5 44.5Z" fill="url(#gS1{n})"/><path d="M5 95 L53 60 L49.5 55.5Z" fill="url(#gS2{n})"/><g transform="translate(46 46) scale(0.88) translate(-50 -50)"><g transform="translate(50 50) skewX(-11) translate(-50 -50)"><path d="M17 27H83L80.6 41H57.5V75H42.5V41H14.6Z" fill="none" stroke-width="6" stroke-linejoin="round" filter="url(#fB{n})" opacity=".55" transform="translate(4 5)" style="stroke:oklch(0.6467 calc(0.1912 * var(--tc)) calc(256.16deg + var(--tr)))"/><path d="M17 27H83L80.6 41H57.5V75H42.5V41H14.6Z" transform="translate(8.0 9.0)" stroke-width="1.4" stroke-linejoin="round" style="fill:oklch(0.2020 calc(0.0553 * var(--tc)) calc(257.38deg + var(--tr)));stroke:oklch(0.2020 calc(0.0553 * var(--tc)) calc(257.38deg + var(--tr)))"/><path d="M17 27H83L80.6 41H57.5V75H42.5V41H14.6Z" transform="translate(7.2 8.1)" stroke-width="1.4" stroke-linejoin="round" style="fill:oklch(0.2599 calc(0.0826 * var(--tc)) calc(259.40deg + var(--tr)));stroke:oklch(0.2599 calc(0.0826 * var(--tc)) calc(259.40deg + var(--tr)))"/><path d="M17 27H83L80.6 41H57.5V75H42.5V41H14.6Z" transform="translate(6.4 7.2)" stroke-width="1.4" stroke-linejoin="round" style="fill:oklch(0.3193 calc(0.1032 * var(--tc)) calc(259.26deg + var(--tr)));stroke:oklch(0.3193 calc(0.1032 * var(--tc)) calc(259.26deg + var(--tr)))"/><path d="M17 27H83L80.6 41H57.5V75H42.5V41H14.6Z" transform="translate(5.6 6.3)" stroke-width="1.4" stroke-linejoin="round" style="fill:oklch(0.3793 calc(0.1231 * var(--tc)) calc(258.87deg + var(--tr)));stroke:oklch(0.3793 calc(0.1231 * var(--tc)) calc(258.87deg + var(--tr)))"/><path d="M17 27H83L80.6 41H57.5V75H42.5V41H14.6Z" transform="translate(4.8 5.4)" stroke-width="1.4" stroke-linejoin="round" style="fill:oklch(0.4402 calc(0.1420 * var(--tc)) calc(258.58deg + var(--tr)));stroke:oklch(0.4402 calc(0.1420 * var(--tc)) calc(258.58deg + var(--tr)))"/><path d="M17 27H83L80.6 41H57.5V75H42.5V41H14.6Z" transform="translate(4.0 4.5)" stroke-width="1.4" stroke-linejoin="round" style="fill:oklch(0.4984 calc(0.1590 * var(--tc)) calc(258.22deg + var(--tr)));stroke:oklch(0.4984 calc(0.1590 * var(--tc)) calc(258.22deg + var(--tr)))"/><path d="M17 27H83L80.6 41H57.5V75H42.5V41H14.6Z" transform="translate(3.2 3.6)" stroke-width="1.4" stroke-linejoin="round" style="fill:oklch(0.5494 calc(0.1700 * var(--tc)) calc(257.69deg + var(--tr)));stroke:oklch(0.5494 calc(0.1700 * var(--tc)) calc(257.69deg + var(--tr)))"/><path d="M17 27H83L80.6 41H57.5V75H42.5V41H14.6Z" transform="translate(2.4 2.7)" stroke-width="1.4" stroke-linejoin="round" style="fill:oklch(0.5952 calc(0.1781 * var(--tc)) calc(257.11deg + var(--tr)));stroke:oklch(0.5952 calc(0.1781 * var(--tc)) calc(257.11deg + var(--tr)))"/><path d="M17 27H83L80.6 41H57.5V75H42.5V41H14.6Z" transform="translate(1.6 1.8)" stroke-width="1.4" stroke-linejoin="round" style="fill:oklch(0.6421 calc(0.1787 * var(--tc)) calc(255.43deg + var(--tr)));stroke:oklch(0.6421 calc(0.1787 * var(--tc)) calc(255.43deg + var(--tr)))"/><path d="M17 27H83L80.6 41H57.5V75H42.5V41H14.6Z" transform="translate(0.8 0.9)" stroke-width="1.4" stroke-linejoin="round" style="fill:oklch(0.6821 calc(0.1720 * var(--tc)) calc(252.76deg + var(--tr)));stroke:oklch(0.6821 calc(0.1720 * var(--tc)) calc(252.76deg + var(--tr)))"/><path d="M17 27H83L80.6 41H57.5V75H42.5V41H14.6Z" fill="url(#gT{n})" stroke-width="1.7" stroke-linejoin="round" style="stroke:oklch(0.7545 calc(0.1368 * var(--tc)) calc(243.47deg + var(--tr)))"/><path d="M19.5 29.1H80.5" stroke-width="1.3" stroke-linecap="round" opacity=".9" style="stroke:oklch(0.9306 calc(0.0370 * var(--tc)) calc(240.68deg + var(--tr)))"/><path d="M45 45V72" stroke-width="1" stroke-linecap="round" opacity=".55" style="stroke:oklch(0.7545 calc(0.1368 * var(--tc)) calc(243.47deg + var(--tr)))"/></g></g></svg>`;
['embBoot','embMarca','embHero'].forEach((id,n)=>{$('#'+id).innerHTML=EMB.replace(/\{n\}/g,n)});

/* menu: grupos que abrem e fecham */
let GRFECHA={};try{GRFECHA=JSON.parse(localStorage.getItem('thboost-grupos')||'{}')||{}}catch(e){}
(function(){let h='',gr='';
 PAGS.forEach(p=>{if(p[3]){if(gr)h+='</div>';gr=p[3];const f=GRFECHA[gr]?' fecha':'';h+=`<div class="gp${f}" data-gr="${gr}" role="button" tabindex="0" aria-label="${gr}">${gr}<svg class="ico chev" viewBox="0 0 24 24" aria-hidden="true"><path d="m6 9 6 6 6-6"/></svg></div><div class="itens${f}" data-grp="${gr}">`}
  h+=`<button class="it${p[0]==='extremo'?' xt':''}" data-p="${p[0]}"><span class="tl">${ico(p[0])}</span><span>${p[1]}</span></button>`});
 const m=$('#menu');m.style.position='relative';m.innerHTML='<div class="pilula" id="pil"></div>'+h+'</div>'})();
function posPil(){const b=$('.it.on'),p=$('#pil');if(!b)return;p.style.opacity=b.offsetParent?1:0;if(!b.offsetParent)return;const m=$('#menu').getBoundingClientRect(),r=b.getBoundingClientRect();p.style.height=r.height+'px';p.style.transform=`translate(0,${r.top-m.top}px)`}
function grupoAlternar(g,fechar){const nome=g.dataset.gr,f=fechar===undefined?!g.classList.contains('fecha'):fechar,it=$(`.itens[data-grp="${nome}"]`);g.classList.toggle('fecha',f);if(it)it.classList.toggle('fecha',f);GRFECHA[nome]=f;try{localStorage.setItem('thboost-grupos',JSON.stringify(GRFECHA))}catch(e){}posPil()}
(function(){const nv=$('.nv');if(!nv)return;nv.addEventListener('focusin',e=>{let v=false;try{v=e.target.matches(':focus-visible')}catch(x){}if(v)nv.classList.add('kb')});nv.addEventListener('focusout',e=>{if(!nv.contains(e.relatedTarget))nv.classList.remove('kb')});nv.addEventListener('pointerdown',()=>nv.classList.remove('kb'))})(); /* v8.9: Tab no teclado abre o menu cheio */
$('#menu').addEventListener('click',e=>{const g=e.target.closest('.gp');if(g)return grupoAlternar(g);const b=e.target.closest('.it');if(b)ir(b.dataset.p)});
$('#menu').addEventListener('keydown',e=>{const g=e.target.closest('.gp');if(g&&(e.key==='Enter'||e.key===' ')){e.preventDefault();grupoAlternar(g)}});

let atual=null;
function ir(k){
 if(k===atual)return;atual=k;
 const bt=$(`.it[data-p="${k}"]`);if(bt){const it=bt.closest('.itens');if(it&&it.classList.contains('fecha')){const g=$(`.gp[data-gr="${it.dataset.grp}"]`);if(g)grupoAlternar(g,false)}}
 $$('.it').forEach(b=>b.classList.toggle('on',b.dataset.p===k));posPil();
 const P=PAGS.find(p=>p[0]===k);$('#tit').textContent=P[1];$('#sub').textContent=P[2];
 $$('.pg').forEach(s=>{s.classList.remove('on','ent')});
 const s=$('#p-'+k);s.classList.add('on');s.scrollTop=0;void s.offsetWidth;s.classList.add('ent');
 [...s.children].forEach((c,i)=>{if(!c.style.getPropertyValue('--i'))c.style.setProperty('--i',i)});
 if(S)atualizar(S);desenharGraficos();entrarPagina(k);
 try{sessionStorage.setItem('thboost-pag',k)}catch(e){}
}
addEventListener('resize',()=>{posPil();desenharGraficos()});

/* números que "sobem" */
function tween(el,para,fmt){
 if(el._alvo===para)return;el._alvo=para;
 if(para==null||isNaN(para)||document.documentElement.classList.contains('leve')){el.textContent=para==null?'--':fmt(para);el._v=para;return}
 const de=el._v==null||isNaN(el._v)?0:el._v,t0=performance.now(),d=700;cancelAnimationFrame(el._r);
 const passo=(n)=>{const k=Math.min(1,(n-t0)/d),e=1-Math.pow(1-k,3);el._v=de+(para-de)*e;el.textContent=fmt(el._v);if(k<1)el._r=requestAnimationFrame(passo)};el._r=requestAnimationFrame(passo)}
const pct=(v)=>Math.round(v)+'%';
function anel(idVl,idNum,valor,txt,fmt){
 const vl=$('#'+idVl);if(vl){const v=valor==null?0:Math.max(0,Math.min(100,valor));vl.style.strokeDashoffset=352*(1-v/100)}
 const n=$('#'+idNum);if(n){if(valor==null)n.textContent=txt||'N/D';else tween(n,valor,fmt||pct)}}

/* gráficos */
function grafico(cv,series,{auto=false,max=100}={}){
 if(!cv||!cv.offsetWidth)return;const dpr=devicePixelRatio||1,w=cv.offsetWidth,h=cv.offsetHeight;
 if(cv.width!==Math.round(w*dpr)||cv.height!==Math.round(h*dpr)){cv.width=Math.round(w*dpr);cv.height=Math.round(h*dpr)}
 const c=cv.getContext('2d');c.setTransform(dpr,0,0,dpr,0,0);c.clearRect(0,0,w,h);
 const E=44,T=10,B=22,R=8,pw=w-E-R,ph=h-T-B;
 let mx=max;if(auto){const todos=series.flatMap(s=>s.d);mx=Math.max(10,(todos.length?Math.max(...todos):0)*1.2)}
 c.font='11px "Segoe UI",sans-serif';c.textBaseline='middle';
 for(let i=0;i<=4;i++){const y=T+ph*(1-i/4);c.strokeStyle='rgba(255,255,255,.06)';c.beginPath();c.moveTo(E,y);c.lineTo(w-R,y);c.stroke();c.fillStyle='#7c8897';c.textAlign='right';c.fillText(Math.round(mx*i/4),E-8,y)}
 const N=120,passo=pw/(N-1);
 series.forEach(s=>{const d=s.d;if(d.length<2)return;const pts=d.map((v,i)=>[E+pw-(d.length-1-i)*passo,T+ph*(1-Math.min(v,mx)/mx)]);
  c.beginPath();pts.forEach((p,i)=>{if(!i)c.moveTo(p[0],p[1]);else{const q=pts[i-1],mxp=(q[0]+p[0])/2;c.bezierCurveTo(mxp,q[1],mxp,p[1],p[0],p[1])}});
  const linha=new Path2D();c.save();c.shadowColor=s.cor;c.shadowBlur=document.documentElement.classList.contains('leve')?0:10;c.strokeStyle=s.cor;c.lineWidth=2.2;c.lineJoin='round';c.stroke();c.restore();
  c.lineTo(pts[pts.length-1][0],T+ph);c.lineTo(pts[0][0],T+ph);c.closePath();const g=c.createLinearGradient(0,T,0,T+ph);g.addColorStop(0,s.cor+'55');g.addColorStop(1,s.cor+'00');c.fillStyle=g;c.fill()})}
function desenharGraficos(){if(!S)return;const sr=S.serie;
 if(atual==='inicio')grafico($('#gfInicio'),[{d:sr.ram,cor:tom('#d1e5fe')},{d:sr.cpu,cor:tom('#3389fa')}]);
 if(atual==='monitor')grafico($('#gfMonitor'),[{d:sr.gpu,cor:'#ffa23d'},{d:sr.ram,cor:tom('#d1e5fe')},{d:sr.cpu,cor:tom('#3389fa')}]);
 if(atual==='rede')grafico($('#gfRede'),[{d:sr.up,cor:tom('#d1e5fe')},{d:sr.down,cor:tom('#3389fa')}],{auto:true})}

/* peças montadas uma vez */
$('#tiles').innerHTML=[['Dashboard','a nota do PC e o que melhorar','dashboard','dashboard','oklch(0.5201 calc(0.2698 * var(--tc)) calc(274.34deg + var(--tr)))'],['Otimização Extrema','Extrema ou Suprema','extremo','extremo','oklch(0.6416 calc(0.1927 * var(--tc)) calc(259.09deg + var(--tr)))'],['Jogos','otimizar antes de jogar','jogos','jogos','oklch(0.6441 calc(0.1768 * var(--tc)) calc(256.55deg + var(--tr)))'],['Processos','menos coisas rodando','processos','processos','oklch(0.7406 calc(0.1286 * var(--tc)) calc(244.09deg + var(--tr)))']]
 .map(t=>`<button class="tile" data-ir="${t[3]}" style="--c:${t[4]}"><span class="seta">${ico('seta')}</span><span class="ti">${ico(t[2])}</span><div><b>${t[0]}</b><small>${t[1]}</small></div></button>`).join('');
$('#gauges').innerHTML=[['cpu','CPU'],['ram','Memória'],['gpu','GPU'],['disco','Disco']].map(g=>`<div class="cd led mt"><h3>${g[1]}</h3><div class="anel"><svg viewBox="0 0 140 140"><circle class="tr" cx="70" cy="70" r="56"/><circle class="vl" id="vl-${g[0]}" cx="70" cy="70" r="56"/></svg><div class="num" id="n-${g[0]}">--</div></div><div class="sb" id="sb-${g[0]}"></div></div>`).join('');
const card=(i,t,d,ic,a,txt,p)=>`<div class="cd" style="--i:${i}"><div class="linha" style="flex-wrap:nowrap;align-items:flex-start;gap:14px"><span class="tile" style="--c:oklch(0.6381 calc(0.1873 * var(--tc)) calc(256.90deg + var(--tr)));min-height:0;width:46px;height:46px;padding:0;display:grid;place-items:center;border-radius:13px"><span class="ti" style="width:46px;height:46px;background:transparent;box-shadow:none">${ico(ic)}</span></span><div style="flex:1"><b style="font-size:16px">${t}</b><p style="margin-top:3px">${d}</p></div></div><div class="linha" style="margin-top:14px"><button class="bt ${p?'p':''} g" data-a="${a}">${txt}</button></div></div>`;
$('#acoesOt').innerHTML=`<div class="cd" style="--i:0;border-color:oklch(0.3745 calc(0.0880 * var(--tc)) calc(253.06deg + var(--tr)));background:linear-gradient(135deg,#0a1924,#0b0e12)"><div class="linha" style="flex-wrap:nowrap;align-items:flex-start;gap:14px"><span class="tile" style="--c:oklch(0.6416 calc(0.1927 * var(--tc)) calc(259.09deg + var(--tr)));min-height:0;width:46px;height:46px;padding:0;display:grid;place-items:center;border-radius:13px"><span class="ti" style="width:46px;height:46px">${ico('extremo')}</span></span><div style="flex:1"><b style="font-size:16px">Quer ir além?</b><p style="margin-top:3px">A <b>Otimização Extrema</b> faz tudo isto e mais: limpeza profunda, ajustes de desempenho, inicialização enxuta e plano de energia máximo.</p></div></div><div class="linha" style="margin-top:14px"><button class="bt xgo g" style="min-height:42px;padding:0 20px;font-size:13px" data-ir="extremo">Abrir a Otimização Extrema</button></div></div>`+card(1,'Liberar cache da RAM','Esvazia a memória dos programas e, como Administrador, também o cache do sistema.','ram','ram','Liberar agora')+card(2,'Plano Alto desempenho','Ativa o plano de energia de maior desempenho do Windows.','plano','plano','Ativar plano')+card(3,'Limpar DNS','Limpa o cache de endereços da rede.','dns','dns','Limpar DNS');
$('#acoesDk').innerHTML=[['Limpeza completa','Temporários, navegadores, programas e Windows, mais a lixeira.','lixo','limpar_tudo',1,'Fazer a limpeza completa?','Apaga temporários, caches de navegadores e de programas, lixo do Windows e esvazia a lixeira. Senhas, históricos e seus arquivos não são tocados.'],['Limpar arquivos temporários','Apaga temporários do usuário e do Windows.','lixo','temp',0],['Limpar navegadores','Só o cache de Chrome, Edge, Firefox, Brave, Opera e Vivaldi. Senhas e histórico ficam.','rede','limpar_nav',0],['Limpar caches de programas','Discord, Teams, Slack, VS Code, Steam e Epic Games.','ram','limpar_apps',0],['Limpar lixo do Windows','Atualizações já baixadas, relatórios de erro e despejos de falha. Precisa de Administrador.','windows','limpar_win',0],['Esvaziar lixeira','Apaga de forma definitiva.','x','lixeira',0,'Esvaziar a lixeira?','Os arquivos não poderão ser recuperados.'],['Limpeza de disco do Windows','Abre a ferramenta do próprio Windows.','win','limpeza_windows',0]]
 .map((b,i)=>`<div class="cd" style="--i:${i}"><div style="display:flex;gap:12px;align-items:center;margin-bottom:14px"><span class="ti" style="width:42px;height:42px;border-radius:12px;display:grid;place-items:center;background:#121a24;color:oklch(0.7160 calc(0.1430 * var(--tc)) calc(255.97deg + var(--tr)))">${ico(b[2])}</span><div><b>${b[0]}</b><p style="margin:2px 0 0;font-size:12.5px">${b[1]}</p></div></div><button class="bt ${b[4]?'p':''}" style="width:100%" ${b[5]?`data-c="${b[3]}" data-ct="${b[5]}" data-cp="${b[6]}"`:`data-a="${b[3]}"`}>${b[4]?'Limpar agora':'Executar'}</button></div>`).join('');
$('#acoesRd').innerHTML=[['Testar ping','Mede a latência até 8.8.8.8.','ping','ping',1],['Limpar cache DNS','Limpa o cache de endereços.','dns','dns',0],['Renovar IP','A internet cai por alguns segundos.','ip','renovar_ip',0,'Renovar o IP?','A internet vai cair por alguns segundos. Continuar?']]
 .map((b,i)=>`<div class="cd" style="--i:${i}"><div style="display:flex;gap:12px;align-items:center;margin-bottom:14px"><span class="ti" style="width:42px;height:42px;border-radius:12px;display:grid;place-items:center;background:#121a24;color:oklch(0.7160 calc(0.1430 * var(--tc)) calc(255.97deg + var(--tr)))">${ico(b[2])}</span><div><b>${b[0]}</b><p style="margin:2px 0 0;font-size:12.5px">${b[1]}</p></div></div><button class="bt ${b[4]?'p':''}" style="width:100%" ${b[5]?`data-c="${b[3]}" data-ct="${b[5]}" data-cp="${b[6]}"`:`data-a="${b[3]}"`}>${b[4]?'Testar agora':'Executar'}</button></div>`).join('');
$('#barras').innerHTML=[['cpu','CPU'],['ram','RAM'],['gpu','GPU'],['vram','VRAM'],['tcpu','Temp. CPU'],['tgpu','Temp. GPU']].map(b=>`<div class="bar"><span>${b[1]}</span><div class="tr"><i id="br-${b[0]}"></i></div><b id="bv-${b[0]}">--</b></div>`).join('');

/* ações */
async function acao(nome,extra){try{const r=await fetch('/api/acao?k='+K,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({acao:nome,...(extra||{})})});if(r.ok){const j=await r.json();if(j&&j.estado){S=j.estado;atualizar(S)}}else toast('Não consegui enviar o comando. Feche e abra o Th Boost de novo.')}catch(e){}}
/* v9.6: janela da otimização: a % sobe com a lista do que está sendo feito; no fim, "Otimizado com sucesso" */
const OTM={tipo:null,fase:null,mostra:0,alvo:0,teto:0,raf:0,escondido:false,sg:''};
function otmFonte(s){if(s.ext&&s.ext.ativo)return ['ext',s.ext];if(s.pre&&s.pre.ativo)return ['pre',s.pre];if(s.otim&&s.otim.ativo)return ['otim',s.otim];return null}
function otmTitulo(t,e){return t==='ext'?(e.opcoes&&e.opcoes.nivel==='suprema'?'Otimização Suprema':'Otimização Extrema'):t==='pre'?'Otimizando para jogar'+(e.jogo?' '+e.jogo:''):'Otimizando o PC'}
function otmPinta(){const v=Math.max(0,Math.min(100,OTM.mostra));$('#otmPct').textContent=Math.floor(v)+'%';$('#otmArco').setAttribute('stroke-dasharray',v.toFixed(2)+' 100');$('#otmLq').style.transform=`translateY(${(170-v/100*160).toFixed(1)}px)`}
function otmAnima(){if(document.documentElement.classList.contains('leve')){OTM.mostra=Math.max(OTM.mostra,OTM.alvo);otmPinta();return}
 if(OTM.raf)return;const passo=()=>{OTM.raf=0;if(OTM.fase!=='run')return;
  if(OTM.mostra<OTM.alvo-.2)OTM.mostra+=Math.max(.25,(OTM.alvo-OTM.mostra)*.1);else if(OTM.mostra<OTM.teto)OTM.mostra=Math.min(OTM.teto,OTM.mostra+.03);
  otmPinta();OTM.raf=requestAnimationFrame(passo)};OTM.raf=requestAnimationFrame(passo)}
function otmAtualiza(s){const f=otmFonte(s),m=$('#otm');
 if(f){const [t,e]=f,ps=e.passos||[],n=Math.max(1,ps.length),feitos=ps.filter(p=>p.estado!=='pendente'&&p.estado!=='rodando').length;
  if(OTM.fase!=='run'||OTM.tipo!==t){Object.assign(OTM,{tipo:t,fase:'run',mostra:Math.max(0,(e.fracao||0)*100-1),escondido:false,sg:''});m.classList.remove('fim','parou');$('#otmT').textContent=otmTitulo(t,e)}
  OTM.alvo=Math.min(100,(e.fracao||0)*100);OTM.teto=Math.min(99,Math.max(OTM.alvo,(feitos+.9)/n*100));
  $('#otmPasso').textContent=e.parando?'Parando...':(e.passo||'Começando...');
  const sg=JSON.stringify(ps.map(p=>[p.nome,p.estado]));
  if(sg!==OTM.sg){OTM.sg=sg;const L=$('#otmLista');L.innerHTML=ps.map(p=>`<div class="oi ${esc(p.estado)}"><i>${p.estado==='ok'?'<svg viewBox="0 0 24 24"><path d="m5 12 5 5 9-10"/></svg>':p.estado==='erro'?'<svg viewBox="0 0 24 24"><path d="M7 7l10 10M17 7 7 17"/></svg>':''}</i><span>${esc(p.nome)}</span></div>`).join('');
   const r=L.querySelector('.rodando');if(r)L.scrollTop=Math.max(0,r.offsetTop-L.clientHeight/2+r.offsetHeight/2)}
  const pa=$('#otmParar');pa.hidden=t!=='ext';pa.disabled=!!e.parando;pa.textContent=e.parando?'Parando...':'Parar';
  if(!OTM.escondido)m.classList.add('on');otmAnima();return}
 if(OTM.fase==='run'){const t=OTM.tipo;OTM.fase='fim';otmFim(t,t==='ext'?s.ext:t==='pre'?s.pre:s.otim)}}
function otmFim(t,e){const m=$('#otm'),ps=e.passos||[],n=ps.length,ok=ps.filter(p=>p.estado==='ok').length,erros=ps.filter(p=>p.estado==='erro').length,parou=ps.some(p=>p.texto==='Interrompido'),r=e.resumo||{};
 const gbt=(v)=>'+'+(Math.round((v||0)*10)/10).toFixed(1).replace('.',',')+' GB';
 let tit='OTIMIZADO COM SUCESSO',txt,ch;
 if(t==='ext'){txt=r.reiniciar?'Reinicie o PC para terminar de aplicar tudo. Se quiser voltar atrás, use “Desfazer tudo” na página da Otimização Extrema.':'Seu PC está no modo de desempenho máximo. Se quiser voltar atrás, use “Desfazer tudo” na página da Otimização Extrema.';ch=[[fmtMB(r.limpo_mb||e.mb||0),'liberados'],[String(r.ajustes||0),'ajustes feitos'],[String(r.inicio||0),'fora da inicialização']]}
 else if(t==='pre'){txt=(r.jogo?`Pode jogar ${r.jogo}. `:'Pode jogar. ')+'Quando você terminar a sessão, tudo volta ao normal.';ch=[[String((r.fechados||[]).length),'programas fechados'],[gbt(r.ram_gb),'de RAM livre'],[`${ok}/${n}`,'passos feitos']]}
 else{txt='Seu PC está mais leve: lixo apagado, memória liberada e energia no modo certo.';ch=[[fmtMB(e.mb||0),'de lixo apagado'],[`${ok}/${n}`,'passos feitos']]}
 if(parou){tit='OTIMIZAÇÃO INTERROMPIDA';txt='Parei no meio, como você pediu. O que já foi feito continua valendo.'}
 else if(erros)txt+=` ${erros===1?'1 passo não deu certo':erros+' passos não deram certo'}: veja os detalhes na página.`;
 $('#otmFT').textContent=tit;$('#otmFP').textContent=txt;$('#otmCh').innerHTML=ch.map(c=>`<div class="ochip"><b>${esc(c[0])}</b><span>${esc(c[1])}</span></div>`).join('');
 $('#otmReini').hidden=!(t==='ext'&&!parou&&r.reiniciar);
 m.classList.toggle('parou',parou);m.classList.add('fim','on');setTimeout(()=>{try{$('#otmOk').focus()}catch(_){}},60)}
function otmFecha(){$('#otm').classList.remove('on','fim','parou');OTM.fase=null}
$('#otmEsc').onclick=()=>{OTM.escondido=true;$('#otm').classList.remove('on');toast('A otimização continua rodando. Quando terminar, o resultado aparece aqui.')};
$('#otmParar').onclick=()=>{const b=$('#otmParar');if(!b.disabled){b.disabled=true;b.textContent='Parando...';acao('extremo_parar')}};
$('#otmOk').onclick=otmFecha;$('#otmReini').addEventListener('click',otmFecha);
document.addEventListener('keydown',e=>{if(e.key!=='Escape'||!$('#otm').classList.contains('on')||$('#cf').classList.contains('on'))return;(OTM.fase==='fim'?$('#otmOk'):$('#otmEsc')).click()},true);
function confirmar(t,p,cb){$('#cfT').textContent=t;$('#cfP').textContent=p;$('#cf').classList.add('on');$('#cfS').onclick=()=>{$('#cf').classList.remove('on');cb()};$('#cfN').onclick=()=>$('#cf').classList.remove('on')}
document.addEventListener('keydown',e=>{if(e.key==='Escape')$('#cf').classList.remove('on')});
document.addEventListener('keydown',e=>{if(e.key!=='Enter'&&e.key!==' ')return;const v=e.target.closest&&e.target.closest('.va[data-ir],.vl[data-ir],.va[data-rola]');if(v){e.preventDefault();e.stopPropagation();if(v.dataset.ir)ir(v.dataset.ir);else v.click()}});
document.addEventListener('click',e=>{const r=e.target.closest&&e.target.closest('[data-rola]');if(!r)return;const t=document.getElementById(r.dataset.rola);if(t)t.scrollIntoView({behavior:matchMedia('(prefers-reduced-motion:reduce)').matches||document.documentElement.classList.contains('leve')?'auto':'smooth',block:'start'})});
document.addEventListener('click',e=>{
 const ir_=e.target.closest('[data-ir]');if(ir_)return ir(ir_.dataset.ir);
 const c=e.target.closest('[data-c]');if(c)return confirmar(c.dataset.ct,c.dataset.cp,()=>acao(c.dataset.c));
 const a=e.target.closest('[data-a]');if(a&&!a.disabled)return acao(a.dataset.a)});
(function(){
 const btn=$('#olaL');if(!btn)return;
 function editar(){
  if($('#olaI'))return;
  const st=$('#olaN'),atual=st.textContent;
  const inp=document.createElement('input');inp.id='olaI';inp.className='olaI';inp.maxLength=24;inp.value=atual;inp.setAttribute('aria-label','Seu nome');inp.autocomplete='off';
  st.hidden=true;btn.hidden=true;st.after(inp);inp.focus();inp.select();
  let feito=false;
  const fim=salvar=>{if(feito)return;feito=true;const v=inp.value.replace(/[<>]/g,'').replace(/\s+/g,' ').trim();inp.remove();st.hidden=false;btn.hidden=false;
   if(salvar&&v!==atual){if(v)st.textContent=v;acao('nome_definir',{nome:v})}};
  inp.onkeydown=e=>{if(e.key==='Enter'){e.preventDefault();fim(true)}else if(e.key==='Escape'){e.preventDefault();e.stopPropagation();fim(false)}};
  inp.onblur=()=>fim(true)}
 btn.onclick=editar})();
$('#swBg').onclick=()=>acao('segundo_plano',{ligar:!$('#swBg').classList.contains('on')});
$('#atuSim').onclick=()=>{$('#atuSim').disabled=true;acao('atu_instalar').finally(()=>{$('#atuSim').disabled=false})};
$('#atuNao').onclick=$('#atuX').onclick=()=>{const a=S&&S.atu;if(a&&a.nova){atuDepois=a.nova;try{sessionStorage.setItem('thboost-atu-depois',a.nova)}catch(e){}}$('#atuNot').hidden=true;toast('Tudo bem. O aviso volta quando você abrir o Th Boost de novo (ou em Configurações › Atualizações).')};
$('#swAtu').onclick=()=>acao('atu_avisar',{ligar:!$('#swAtu').classList.contains('on')});
$('#atRun').onclick=()=>acao('autoteste');$('#atCopy').onclick=atCopiar;$('#atuAgora').onclick=()=>{atuDepois='';try{sessionStorage.removeItem('thboost-atu-depois')}catch(e){}acao('atu_procurar')};$('#swLeve').onclick=()=>acao('leve');$('#swFps').onclick=()=>acao('fps');$('#swGr').onclick=()=>acao('grafico_leve',{on:!(S&&S.grafico&&S.grafico.ligado)});document.querySelectorAll('[data-grp]').forEach(b=>b.onclick=()=>acao('grafico_perfil',{perfil:b.dataset.grp}));$('#swFps2').onclick=()=>acao('fps');
$('#rg').addEventListener('input',()=>rgTxt());
$('#ocAp').onclick=()=>{const n=+$('#rg').value,oc=(S&&S.oc)||{};
 if(S&&!S.admin)return toast('O overclock precisa do Th Boost aberto como Administrador. Feche e abra pelo atalho da área de trabalho.');
 const ir=()=>acao('oc_nivel',{nivel:n});
 if(n>100)confirmar('Overclock agressivo ('+n+'%)','Acima de 100% a placa esquenta bastante e pode travar o jogo ou o Windows se não aguentar. Nada fica gravado: reiniciar o PC volta ao padrão, e acima de '+(oc.limite_temp||88)+'°C o Th Boost desliga sozinho. Continuar?',ir);else ir()};
$('#ocRe').onclick=()=>{$('#rg').value=0;rgTxt();acao('oc_zerar')};
function rgTxt(){const r=$('#rg'),n=+r.value,oc=(S&&S.oc)||{},i=oc.info,ap=oc.nivel||0;
 r.style.setProperty('--p',(n/150*100)+'%');
 $('#ocPct').textContent=n+'%';$('#ocRot').textContent=n===0?'Padrão da placa':n<=50?'Leve':n<=100?'Moderado':'Agressivo · mais calor';
 $('#ocN').className='ocn'+(n>100?' ag':n>50?' mod':'');
 if(i&&i.tabela){const l=i.tabela.find(x=>x[0]===n)||i.tabela[0],nd='não aceita';
  $('#ocV').innerHTML=[['Núcleo',i.nucleo.ok?'+'+l[1]+' MHz':nd,i.nucleo],['Memória',i.memoria.ok?'+'+l[2]+' MHz':nd,i.memoria],['Potência',i.potencia.ok?l[3]+' W':nd,i.potencia]].map(x=>`<div${!x[2].ok&&x[2].motivo?` title="${esc(x[2].motivo)}"`:''}><small>${x[0]}</small><b>${x[1]}</b>${!x[2].ok&&x[2].motivo?`<small class="ocm">${esc(x[2].motivo)}</small>`:''}</div>`).join('')}
 const pode=!!(i&&i.suporte&&i.algum);$('#ocAp').disabled=!pode||n===ap;$('#ocRe').disabled=!pode||(ap===0&&n===0)}
function fx(){return !document.documentElement.classList.contains('leve')}
function setFx(ligado,salvar){document.documentElement.classList.toggle('leve',!ligado);if(salvar){try{localStorage.setItem('thboost-leve',ligado?'0':'1')}catch(e){}}$('#swFx').classList.toggle('on',ligado);$('#stFx').textContent=ligado?'COMPLETOS':'LEVES';$('#stFx').classList.toggle('on',ligado)}
$('#swFx').onclick=()=>{setFx(!fx(),true);toast(fx()?'Efeitos visuais completos.':'Efeitos visuais leves ligados.');setTimeout(posPil,50)};

/* avisos no canto */
function toast(txt){const t=document.createElement('div');t.className='toast';t.innerHTML=ico('info')+`<span>${esc(txt)}</span>`;$('#toasts').appendChild(t);
 while($('#toasts').children.length>4)$('#toasts').firstChild.remove();
 setTimeout(()=>{t.classList.add('sai');setTimeout(()=>t.remove(),360)},4200)}

/* atualização a cada segundo */
let S=null,ultMsg=null,ultFim=null,jogosSig='',ocVisto=-1;
const gb=(v,d=1)=>(v==null?'--':v.toFixed(d).replace('.',',')+' GB');
function vel(b){const u=['B/s','KB/s','MB/s','GB/s'];let i=0;while(b>=1024&&i<3){b/=1024;i++}return b.toFixed(1).replace('.',',')+' '+u[i]}
/* ===== v9.0: aviso de versão nova + atualizar com um clique ===== */
let atuDepois=(()=>{try{return sessionStorage.getItem('thboost-atu-depois')||''}catch(e){return ''}})(),atuReinicio=false,atuOkMostrado=false;
function atuMostra(a){if(!a)return;const box=$('#atuNot');
 if(a.de&&!atuOkMostrado){atuOkMostrado=true;let ja=false;try{ja=sessionStorage.getItem('thboost-atu-ok')===a.atual;sessionStorage.setItem('thboost-atu-ok',a.atual)}catch(e){}if(!ja)toast(`Th Boost atualizado: ${a.de} → ${a.atual}. Tudo pronto!`)}
 // cartão de Configurações
 const sw=$('#swAtu');if(sw){sw.classList.toggle('on',!!a.avisar);sw.setAttribute('aria-pressed',!!a.avisar);$('#stAtu').textContent=a.avisar?'AVISAR':'NÃO AVISAR';$('#stAtu').classList.toggle('on',!!a.avisar);
  $('#atuSt').textContent=a.estado==='procurando'?'Procurando versão nova…':a.estado==='em_dia'?`Você está na versão mais nova (${a.atual}).`:a.estado==='disponivel'?`Versão ${a.nova} disponível (você está na ${a.atual}).`:a.estado==='falhou'?(a.erro||'Não deu para procurar agora.'):['baixando','instalando','reiniciando'].includes(a.estado)?`Atualizando para a ${a.nova}…`:`Versão ${a.atual}. O Th Boost procura sozinho quando abre e a cada 6 horas.`;
  $('#atuAgora').disabled=['procurando','baixando','instalando','reiniciando'].includes(a.estado)}
 const ativo=['disponivel','baixando','instalando','reiniciando'].includes(a.estado);
 if(!ativo||(a.estado==='disponivel'&&atuDepois===a.nova&&!a.erro)){box.hidden=true;return}
 if(box.hidden){box.hidden=false;box.classList.remove('toca');void box.offsetWidth;box.classList.add('toca')}
 const ed=a.estado;$('#atuTit').textContent=ed==='disponivel'?'O dono atualizou o Th Boost':ed==='baixando'?'Baixando a versão nova…':ed==='instalando'?'Instalando a versão nova…':'Reiniciando o Th Boost…';
 $('#atuTx').textContent=ed==='disponivel'?`Versão ${a.nova} disponível (você está na ${a.atual}). Clique em Atualizar ${a.modo==='link'?'para baixar a versão nova.':'para ir para a versão nova.'}`:ed==='baixando'?`Versão ${a.nova}: ${a.pct||0}%`:ed==='instalando'?'Conferindo e trocando os arquivos. A versão atual fica guardada na pasta "versao_anterior".':'A janela volta sozinha em alguns segundos.';
 const nv=ed==='disponivel'?(a.novidades||[]):[],ul=$('#atuNov');ul.innerHTML=nv.map(x=>`<li>${esc(x)}</li>`).join('');ul.hidden=!nv.length;
 $('#atuBar').hidden=!['baixando','instalando'].includes(ed);$('#atuPct').style.width=(ed==='instalando'?100:(a.pct||0))+'%';
 $('#atuErr').hidden=!a.erro||ed!=='disponivel';$('#atuErr').textContent=a.erro||'';
 const bts=ed==='disponivel';$('#atuSim').hidden=!bts;$('#atuNao').hidden=!bts;$('#atuX').hidden=!bts;$('#atuSim').textContent=a.erro?'Tentar de novo':'Atualizar';
 if(ed==='reiniciando'&&!atuReinicio){atuReinicio=true;atuEspera()}}
/* o Th Boost antigo fecha e o novo abre na mesma porta: quando o antigo some e o novo responde, recarrega a janela */
function atuEspera(){const t0=Date.now();const passo=async()=>{let caiu=false;try{const r=await fetch('/api/ping?k='+K,{cache:'no-store'});if(!r.ok)caiu=true}catch(e){caiu=true}
  if(caiu){try{const r2=await fetch('/',{cache:'no-store'});if(r2.ok){location.reload();return}}catch(e){}}
  if(Date.now()-t0<45000)setTimeout(passo,800);else $('#atuTx').textContent='Demorou mais que o normal. Feche e abra o Th Boost pelo atalho.'};setTimeout(passo,1500)}
function atMostra(a){if(!a)return;const lst=$('#atLista');if(!lst)return;
 const rod=a.estado==='rodando';$('#atRun').disabled=rod;$('#atRun').textContent=rod?'Testando…':(a.estado==='pronto'?'Fazer de novo':'Fazer autoteste');$('#atCopy').hidden=a.estado!=='pronto';
 if(a.estado==='nunca'||!a.itens.length){lst.hidden=true;return}
 const sig=JSON.stringify(a.itens);if(lst.dataset.s===sig)return;lst.dataset.s=sig;lst.hidden=false;
 const n={ok:0,aviso:0,erro:0};a.itens.forEach(i=>{if(i.st in n)n[i.st]++});
 $('#atSt').textContent=rod?'Testando cada parte…':`Pronto: ${n.ok} ok, ${n.aviso} aviso(s), ${n.erro} erro(s). Copie o relatório e mande para o dono se algo deu errado.`;
 const CH={ok:['baixo','OK'],aviso:['medio','AVISO'],erro:['erro','ERRO'],pulado:['nt','—'],testando:['nt','…'],esperando:['nt','…']};let g='',h='';
 a.itens.forEach(i=>{if(i.grupo!==g){g=i.grupo;h+=`<div class="atg">${esc(g)}</div>`}const c=CH[i.st]||CH.pulado;
  h+=`<div class="atr ${i.st==='testando'?'testando':''}"><span class="rk ${c[0]}">${c[1]}</span><div><b>${esc(i.rotulo)}</b><p>${esc(i.txt||(i.st==='testando'?'testando…':''))}</p></div>${i.acao?`<button class="bt" data-a="${esc(i.acao)}">Corrigir</button>`:''}</div>`});
 lst.innerHTML=h}
async function atCopiar(){let t='';try{t=(await pegar('autoteste')).texto||''}catch(e){}if(!t)return toast('O relatório ainda não está pronto.');
 let ok=false;try{await navigator.clipboard.writeText(t);ok=true}catch(e){}
 if(!ok){const ta=document.createElement('textarea');ta.value=t;ta.style.position='fixed';ta.style.opacity='0';document.body.appendChild(ta);ta.select();try{ok=document.execCommand('copy')}catch(e){}ta.remove()}
 toast(ok?'Relatório copiado. Cole na conversa com o dono (Ctrl+V).':'Não consegui copiar. Selecione o texto e copie.')}
/* FPS na tela */
const OV_IT=[['fps','FPS'],['fps1','1% baixo'],['ms','Tempo do quadro'],['cpu','CPU %'],['tcpu','Temp. CPU'],['gpu','GPU %'],['tgpu','Temp. GPU'],['ram','RAM %'],['lim','Gargalo (CPU ou GPU)']],OV_POS=[['se','↖ Em cima, à esquerda'],['sd','↗ Em cima, à direita'],['ie','↙ Embaixo, à esquerda'],['id','↘ Embaixo, à direita']];
function montaOverlay(){$('#p-overlay').innerHTML=`<div class="cd led cab" style="--i:0"><div><h2>FPS na tela</h2><p>Mostra o FPS, o 1% mais baixo (as travadinhas), o tempo de cada quadro, CPU, placa de vídeo e temperaturas num cantinho <b>por cima do jogo</b>. Não pega clique nem teclado: tudo continua indo para o jogo. <b>Ctrl+Shift+F</b> esconde e mostra durante o jogo.</p></div><div class="linha" style="gap:12px"><button class="sw" id="swOv" aria-label="FPS na tela"><i></i></button><span class="st" id="stOv">DESLIGADO</span></div></div>
 <div class="avs" id="ovPmAv" hidden></div>
 <div class="ovg" style="margin-top:16px"><div class="cd" style="--i:1"><h3 style="margin-top:0">Prévia</h3><div class="ovprev" id="ovPrev"></div><p class="sub2" style="margin:10px 0 0">Funciona por cima de jogos em janela ou em <b>tela cheia sem bordas</b> (a maioria dos jogos atuais). Se num jogo em tela cheia não aparecer, escolha “Janela sem bordas” (ou “Borderless”) nas opções de vídeo do jogo. Com a janela do Th Boost fechada, o FPS continua na tela; para tirar, abra o Th Boost e desligue aqui.</p></div>
 <div class="cd ovopc" style="--i:2"><div><h4>Onde fica</h4><div class="ovbts" id="ovPos">${OV_POS.map(p=>`<button data-ovpos="${p[0]}">${p[1]}</button>`).join('')}</div></div>
  <div><h4>Tamanho</h4><div class="ovbts" id="ovTam">${[[1,'Pequeno'],[2,'Médio'],[3,'Grande']].map(t=>`<button data-ovtam="${t[0]}">${t[1]}</button>`).join('')}</div></div>
  <div><h4>O que mostrar</h4><div class="ovbts" id="ovIt">${OV_IT.map(i=>`<button data-ovit="${i[0]}">${i[1]}</button>`).join('')}</div></div></div></div>`}
function ovCfg(){return (S&&S.ov&&S.ov.cfg)||{on:false,pos:'se',tam:2,itens:['fps','fps1','ms','cpu','tcpu','gpu','tgpu','ram']}}
function ovMuda(m){const c=Object.assign({},ovCfg(),m);acao('overlay',{cfg:c})}
function pintarOverlay(s){const el=$('#p-overlay');if(!el||!s.ov)return;const c=s.ov.cfg,pm=s.ov.pm||{};
 $('#swOv').classList.toggle('on',!!c.on);$('#swOv').setAttribute('aria-pressed',String(!!c.on));$('#stOv').textContent=c.on?'LIGADO':'DESLIGADO';$('#stOv').classList.toggle('on',!!c.on);
 el.querySelectorAll('[data-ovpos]').forEach(b=>b.classList.toggle('on',b.dataset.ovpos===c.pos));el.querySelectorAll('[data-ovtam]').forEach(b=>b.classList.toggle('on',+b.dataset.ovtam===c.tam));el.querySelectorAll('[data-ovit]').forEach(b=>b.classList.toggle('on',c.itens.includes(b.dataset.ovit)));
 const v={fps:s.fps_ligado?s.fps:null,fps1:s.fps_ligado?s.fps1:null,ms:s.fps_ligado?s.fps_ms:null,cpu:s.cpu,tcpu:s.tcpu,gpu:s.gpu_uso,tgpu:s.tgpu,ram:s.ram,lim:s.gargalo};
 const n=(x,suf='')=>x==null?'--':Math.round(x)+suf,cf=(x)=>x==null?'#9aa4b2':x>=60?'#4ade80':x>=30?'#facc15':'#f87171';
 const L={fps:['FPS',n(v.fps),cf(v.fps)],fps1:['1% baixo',n(v.fps1),cf(v.fps1)],ms:['Quadro',v.ms==null?'--':String(v.ms).replace('.',',')+' ms','#e2e8f0'],cpu:['CPU',n(v.cpu,'%'),'#e2e8f0'],tcpu:['CPU °C',n(v.tcpu,'°'),'#e2e8f0'],gpu:['GPU',n(v.gpu,'%'),'#e2e8f0'],tgpu:['GPU °C',n(v.tgpu,'°'),'#e2e8f0'],ram:['RAM',n(v.ram,'%'),'#e2e8f0'],lim:v.lim?['Gargalo',...({cpu:['CPU','#f87171'],gpu:['GPU','#4ade80'],folga:['nenhum','#e2e8f0']}[v.lim])]:null};
 $('#ovPrev').innerHTML=`<div class="ovbox ${c.pos} t${c.tam}">${c.itens.map(i=>L[i]?`<span>${L[i][0]}</span><b style="color:${L[i][2]}">${L[i][1]}</b>`:'').join('')}</div>`;
 const av=$('#ovPmAv');let h='';
 if(!s.presentmon){h=pm.estado==='baixando'?`${ico('info')}<div class="ovpm" style="flex:1"><span>Baixando o contador de FPS…</span><div class="tr"><i style="width:${pm.pct||0}%"></i></div></div>`:
  `${ico('info')}<div class="ovpm" style="flex:1"><span>Para mostrar o <b>FPS</b> falta o contador: o <b>PresentMon</b>, programa gratuito e oficial da Intel (1 MB). O Th Boost baixa do GitHub oficial e confere a impressão digital antes de usar.${pm.erro?`<br><b style="color:#f87171">${esc(pm.erro)}</b>`:''}</span><button class="bt p" data-a="pm_instalar">Instalar contador</button></div>`}
 else if(s.fps_erro&&c.on)h=`${ico('info')}<span>${esc(s.fps_erro)}</span>`;
 else if(c.on&&s.ov.atalho===false)h=`${ico('info')}<span>Outro programa deste PC já usa o atalho <b>Ctrl+Shift+F</b>, então ele não esconde o FPS na tela. Para esconder, desligue aqui.</span>`;
 if(!c.itens.includes('tcpu')||s.tcpu!=null||!c.on){}else if(!h)h=`${ico('info')}<span>Este PC não informa a temperatura do processador ao Windows, então a linha <b>CPU °C</b> não aparece.</span>`;
 av.hidden=!h;if(av._h!==h){av._h=h;av.innerHTML=h}} /* só troca quando muda (senão o clique em "Instalar contador" se perde) */
montaOverlay();$('#swOv').onclick=()=>ovMuda({on:!ovCfg().on});
$('#p-overlay').addEventListener('click',(e)=>{const p=e.target.closest('[data-ovpos]'),t=e.target.closest('[data-ovtam]'),it=e.target.closest('[data-ovit]');
 if(p)return ovMuda({pos:p.dataset.ovpos});if(t)return ovMuda({tam:+t.dataset.ovtam});
 if(it){const c=ovCfg(),k=it.dataset.ovit,its=c.itens.includes(k)?c.itens.filter(x=>x!==k):OV_IT.map(x=>x[0]).filter(x=>x===k||c.itens.includes(x));if(!its.length)return;return ovMuda({itens:its})}});
/* v9.2: cor do painel */
const TEMAS=[['azul','Azul',0],['ciano','Ciano',-45],['verde','Verde',-107],['dourado','Dourado',-171],['laranja','Laranja',151],['vermelho','Vermelho',128],['rosa','Rosa',97],['roxo','Roxo',47]];
let tmUlt=0,tmT=0;
function montaCores(){$('#p-cores').innerHTML=`<div class="cd led cab" style="--i:0"><div><h2>Cor do painel</h2><p>Escolha a cor do Th Boost inteiro: menu, botões, gráficos, logo e brilhos. Muda na hora e fica guardada para a próxima vez. As cores de aviso continuam as mesmas em qualquer cor: <b style="color:#4ade80">verde</b> é tudo certo, <b style="color:#facc15">amarelo</b> é atenção e <b style="color:#f87171">vermelho</b> é problema.</p></div></div>
 <div class="cd" style="--i:1;margin-top:16px"><h3 style="margin-top:0">Cores prontas</h3><div class="tmg">${TEMAS.map(t=>`<button class="tmb" data-tm="${t[2]}" style="--tt:${t[2]}deg;--tk:${temaTc(t[2])}" aria-pressed="false"><i></i><span>${t[1]}</span></button>`).join('')}</div></div>
 <div class="cd" style="--i:2;margin-top:16px"><h3 style="margin-top:0">Do seu jeito</h3><p class="sub2" style="margin:0 0 14px">Arraste para escolher qualquer tom.</p><input type="range" class="tmr" id="tmR" min="-180" max="180" step="1" value="0" aria-label="Tom da cor do painel"><div class="linha" style="margin-top:14px;gap:12px;justify-content:space-between"><span id="tmV" class="sub2"></span><button class="bt g" id="tmZ">Voltar ao azul</button></div></div>`}
function temaAplica(tr){TEMA_TR=tr;TEMA_TC=temaTc(tr);document.documentElement.style.setProperty('--tr',tr+'deg');document.documentElement.style.setProperty('--tc',String(TEMA_TC));pintarCores();if(S)desenharGraficos()}
function temaMuda(tr){tr=Math.max(-180,Math.min(180,Math.round(+tr||0)));tmUlt=Date.now();temaAplica(tr);clearTimeout(tmT);tmT=setTimeout(()=>{tmUlt=Date.now();acao('tema',{tr})},300)}
function pintarCores(){const el=$('#p-cores');if(!el)return;el.querySelectorAll('[data-tm]').forEach(b=>{const on=+b.dataset.tm===TEMA_TR;b.classList.toggle('on',on);b.setAttribute('aria-pressed',String(on))});
 const r=$('#tmR');if(r&&document.activeElement!==r)r.value=TEMA_TR;const n=TEMAS.find(t=>t[2]===TEMA_TR);$('#tmV').textContent=n?'Cor: '+n[1]+(TEMA_TR?'':' (padrão)'):'Cor: do seu jeito'}
montaCores();pintarCores();
$('#p-cores').addEventListener('click',(e)=>{const b=e.target.closest('[data-tm]');if(b)return temaMuda(+b.dataset.tm);if(e.target.closest('#tmZ'))temaMuda(0)});
$('#tmR').addEventListener('input',(e)=>temaMuda(+e.target.value));
function atualizar(s){
 if(typeof s.tema_tr==='number'&&s.tema_tr!==TEMA_TR&&Date.now()-tmUlt>2500)temaAplica(s.tema_tr); /* mudou em outra janela */
 atuMostra(s.atu);atMostra(s.at);if(atual==='overlay')pintarOverlay(s);
 /* avisos novos */
 const mx=s.hist.length?s.hist[0].id:0;
 if(ultMsg===null)ultMsg=mx;else if(mx>ultMsg){const nv=s.hist.filter(h=>h.id>ultMsg).reverse();nv.forEach(h=>toast(h.t));ultMsg=mx;aposMsg(nv)}
 /* barra lateral e topo */
 $('#ver').textContent='Th Boost '+s.versao;if(s.nome&&$('#olaN').textContent!==s.nome)$('#olaN').textContent=s.nome;$('#adm').classList.toggle('no',!s.admin);$('#admT').textContent=s.admin?'Administrador':'Sem administrador';$('#admS').textContent=s.admin?(s.usuario||''):'alguns ajustes não funcionam';
 const modo=s.ext&&s.ext.ativo?[(s.ext.opcoes&&s.ext.opcoes.nivel==='suprema'?'SUPREMA ATIVA':'EXTREMO ATIVO'),'ext']:s.sessao?['EM SESSÃO DE JOGO','ext']:s.modo_fps?['FPS ON','ext']:s.modo_leve?['LEVE','leve']:['NORMAL',''];$('#modo').className='modo '+modo[1];$('#modoT').textContent=modo[0];
 /* otimização */
 const o0=s.otim,outro=s.pre.ativo?s.pre:['correcao','backup','espaco','processos'].map(k=>s.trab[k]).find(t=>t.ativo),o=s.ext&&s.ext.ativo?{ativo:true,fracao:s.ext.fracao,passo:s.ext.passo}:(outro?{ativo:true,fracao:outro.fracao,passo:outro.passo}:s.otim);$('#prog').classList.toggle('on',o.ativo||o.fracao>0&&o.fracao<1);$('#progB').style.width=(o.ativo?o.fracao*100:(o.fracao>=1?100:0))+'%';
 if(!o.ativo&&o.fracao>=1){setTimeout(()=>{$('#prog').classList.remove('on');setTimeout(()=>$('#progB').style.width='0%',400)},1200)}
 $('#heroEst').textContent=o.ativo?o.passo:'Pronto para otimizar';
 ['heroBt','otBt'].forEach(id=>{const b=$('#'+id);b.disabled=o.ativo;b.querySelector('span').textContent=o.ativo?'Otimizando...':(id==='heroBt'?'Começar otimização':'Otimizar tudo')});
 if(o0.passos&&o0.passos.length){const sg=JSON.stringify(o0.passos);if($('#passos').dataset.s!==sg){$('#passos').dataset.s=sg;$('#passos').innerHTML=o0.passos.map(p=>`<div class="ps ${p.estado}"><span class="pi">${ico('check')}</span><div><b>${esc(p.nome)}</b><small>${esc(p.texto||(p.estado==='rodando'?'Em andamento...':'Aguardando'))}</small></div>${p.mb>=0.1?`<span class="mb">${fmtMB(p.mb)}</span>`:''}</div>`).join('')}tween($('#otMb'),o0.mb||0,fmtMB)}
 else if(!$('#passos').dataset.v){$('#passos').dataset.v=1;$('#passos').innerHTML=['Limpar temporários','Limpar os navegadores','Limpar caches de programas','Limpeza do Windows','Liberar a RAM','Plano de energia','Limpar o DNS'].map(n=>`<div class="ps"><span class="pi">${ico('check')}</span><div><b>${n}</b><small>Aguardando</small></div></div>`).join('')}
 otmAtualiza(s);
 /* histórico */
 const hs=s.hist.map(h=>h.id).join(',');if($('#hist').dataset.s!==hs){$('#hist').dataset.s=hs;$('#hist').innerHTML=s.hist.length?s.hist.map(h=>`<div class="hi"><time>${h.h}</time><span>${esc(h.t)}</span></div>`).join(''):'<div class="vz" style="padding:24px"><span>Nenhuma ação ainda. Clique em um botão para começar.</span></div>'}
 /* início */
 const disco=s.disco,dp=disco?disco.pct:0;
 const saude=DASH.d&&DASH.d.score!=null?DASH.d.score:Math.max(0,100-(s.ram*.5+s.cpu*.2+dp*.3));anel('vlSaude','nSaude',saude,'--');
 anel('vl-cpu','n-cpu',s.cpu);$('#sb-cpu').textContent=`${s.nucleos} núcleos lógicos`;
 anel('vl-ram','n-ram',s.ram);$('#sb-ram').textContent=`${gb(s.ram_usada)} de ${Math.round(s.ram_total)} GB em uso`;
 anel('vl-gpu','n-gpu',s.gpu_uso,'N/D');$('#sb-gpu').textContent=(s.gpu&&s.gpu.nome)||'Sem NVIDIA';
 anel('vl-disco','n-disco',disco?disco.pct:null,'N/D');$('#sb-disco').textContent=disco?`${Math.round(disco.livre)} GB livres`:'';
 /* GPU */
 const g=s.gpu,oc=s.oc||{},oi=oc.info,ocOk=!!(oi&&oi.suporte);
 $('#gpuCtl').classList.toggle('sem',!ocOk);
 if(!ocOk){$('#gpuNome').textContent=oi?'Overclock indisponível':'Lendo a placa...';$('#gpuLim').textContent=oi?(oi.motivo||'Só funciona com placa NVIDIA e driver instalado. AMD e Intel: use o programa do fabricante.'):''}
 else{$('#gpuNome').textContent=oi.nome;
  $('#gpuLim').textContent=oi.algum?'Escolha o nível e aperte Aplicar. 0% é o padrão da placa e é onde ela sempre começa.':'Esta placa ou este driver não aceita mudar clock ou potência por aqui.';
  if(oc.nivel!==ocVisto){ocVisto=oc.nivel;$('#rg').value=oc.nivel}
  $('#rg').disabled=!oi.algum;$('#ocLim').textContent=oc.limite_temp||88;
  const sg=v=>(v>=0?'+':'')+v;
  $('#ocAg').className='ocs'+(oc.aviso?' av':'');
  $('#ocAg').textContent=(oc.aviso?oc.aviso+' ':'')+`Agora na placa: núcleo ${oi.mhz!=null?oi.mhz+' MHz':'--'}${oi.nucleo.ok?' ('+sg(oi.nucleo.agora)+')':''} · memória ${oi.mhz_mem!=null?oi.mhz_mem+' MHz':'--'}${oi.memoria.ok?' ('+sg(oi.memoria.agora)+')':''} · potência ${oi.potencia.agora?oi.potencia.agora+' W':'--'} · ${oi.temp!=null?oi.temp+'°C':'--'}`;
  rgTxt()}
 const gd=g||(ocOk&&oi.potencia.ok?{padrao:oi.potencia.padrao,limite:oi.potencia.agora,max:oi.potencia.max,temp:oi.temp,nvml:true}:null);
 if(!gd){anel('vlPot','nPot',null,'N/D');$('#sbPot').textContent=s.gpu_lida?'Sem NVIDIA':'Lendo a placa...';$('#gpuChips').innerHTML=s.gpu_lida?`<div class="cd" style="grid-column:1/-1"><div class="vz" style="padding:18px"><div class="ic">${ico('gpu')}</div><b>Sem placa NVIDIA</b><span>O overclock só funciona com placas NVIDIA e o driver instalado.</span></div></div>`:''}
 else{const pd=gd.padrao||gd.limite||0,at=gd.limite||pd,mx2=gd.max||pd*1.2||1;
  anel('vlPot','nPot',at/mx2*100,'',()=>'');$('#nPot').textContent=Math.round(at)+' W';$('#sbPot').textContent=`máximo ${Math.round(mx2)} W`;
  const ch=gd.nvml?[['Temperatura',gd.temp!=null?Math.round(gd.temp)+'°C':'--'],['Clock do núcleo',oi.mhz!=null?oi.mhz+' MHz':'--'],['Clock da memória',oi.mhz_mem!=null?oi.mhz_mem+' MHz':'--']]
   :[['Temperatura',gd.temp!=null?Math.round(gd.temp)+'°C':'--'],['Uso da GPU',gd.uso!=null?Math.round(gd.uso)+'%':'--'],['Memória de vídeo',gd.vram_total?`${Math.round(gd.vram_usada)} / ${Math.round(gd.vram_total)} MB`:'--']];
  $('#gpuChips').innerHTML=ch.map(c=>`<div class="cd"><h3>${c[0]}</h3><div class="nm" style="font-size:26px">${c[1]}</div></div>`).join('')}
 /* monitor */
 const bar=(k,v,t)=>{$('#br-'+k).style.width=(v==null?0:Math.max(0,Math.min(100,v)))+'%';$('#bv-'+k).textContent=v==null?'N/D':(t||Math.round(v)+'%')};
 bar('cpu',s.cpu);bar('ram',s.ram);bar('gpu',s.gpu_uso);bar('vram',s.vram);bar('tcpu',s.tcpu,s.tcpu!=null?Math.round(s.tcpu)+'°C':null);bar('tgpu',s.tgpu,s.tgpu!=null?Math.round(s.tgpu)+'°C':null);
 const er=s.fps_erro;$('#fpsN').textContent=(!er&&s.fps_ligado&&s.fps!=null)?s.fps:'--';
 $('#fpsS').textContent=!s.presentmon?'Para ver o FPS, instale o contador (um clique) na página FPS na tela.':er?er:(s.fps_ligado&&s.fps!=null?`em ${s.fps_app}`:(s.fps_ligado?'Abra um jogo: o FPS aparece aqui.':'Ligue o contador para ver os quadros.'));
 $('#fps1S').textContent=s.fps_ligado&&s.fps!=null&&s.fps1!=null?`1% mais baixo: ${s.fps1} FPS · quadro: ${String(s.fps_ms).replace('.',',')} ms`:'';
 {const g=s.gargalo,ls=$('#limS'),joga=s.fps_ligado&&(s.fps||0)>0; /* v9.5: quem segura o FPS */
  const t=g==='cpu'?'<b>Quem segura o FPS: o processador</b>A placa de vídeo está sobrando, então o overclock dela não aumenta o FPS. O que ajuda é aliviar o processador: Modo FPS On, gráfico leve no perfil "Processador fraco" e menos programas abertos.'
   :g==='gpu'?'<b>Quem segura o FPS: a placa de vídeo</b>Ela está no limite: aqui o overclock da placa e o gráfico leve ajudam.'
   :g==='folga'&&joga?'<b>Nem o processador nem a placa estão no limite</b>O FPS está preso por um limite do próprio jogo (limite de FPS ou VSync).':'';
  ls.hidden=!t;if(ls._h!==t){ls._h=t;ls.innerHTML=t}}
 const fb=$('#fpsBt');fb.disabled=false;if(!s.presentmon){fb.textContent='Instalar contador';fb.removeAttribute('data-a');fb.dataset.ir='overlay'}else if(s.fps_ligado&&!s.contador_manual){delete fb.dataset.ir;fb.removeAttribute('data-a');fb.textContent='Ligado pelo '+(s.modo_fps?'Modo FPS On':'FPS na tela');fb.disabled=true}else{delete fb.dataset.ir;fb.dataset.a='fps_contador';fb.textContent=s.contador_manual?'Desligar contador':'Ligar contador'}
 /* modos */
 if(s.grafico){const g=s.grafico,nm={valorant:'Valorant',cs2:'CS2',roblox:'Roblox'};$('#swGr').classList.toggle('on',g.ligado);
  document.querySelectorAll('[data-grp]').forEach(b=>{const on=b.dataset.grp===g.perfil;b.classList.toggle('on',on);b.setAttribute('aria-pressed',String(on))});
  $('#grPx').textContent=g.perfil==='proc'?'Processador fraco: para quando o processador fica em 100% e a placa de vídeo sobra. O que pesa no processador (sombras, distância, partículas, efeitos) fica no mínimo e o que só pesa na placa (texturas, materiais, suavização, filtro de textura) sobe. O FPS fica igual ao mínimo, a imagem fica melhor e a placa trabalha mais. No Roblox fica no mínimo.':'Tudo no mínimo: para quando a placa de vídeo é que está no limite.';
  $('#grSt').textContent=g.texto||(g.aplicado.length?'Agora no mínimo: '+g.aplicado.map(x=>nm[x]||x).join(', ')+'.':'')}
 [['swLeve','stLeve',s.modo_leve],['swFps','stFps',s.modo_fps],['swFps2','stFps2',s.modo_fps]].forEach(([a,b,v])=>{$('#'+a).classList.toggle('on',v);const e=$('#'+b);e.textContent=v?'LIGADO':'DESLIGADO';e.classList.toggle('on',v);if(b==='stFps2')e.style.color=v?'#ffffff':''});
 $('#fpsDesc').textContent='O jogo ganha prioridade sobre o resto (Modo Leve) e o PC vai para o plano de desempenho. Ao desligar, tudo volta como estava.'+(s.presentmon?' O contador de FPS liga junto.':'');$('#jgFps').textContent='Dá prioridade ao jogo e liga o plano de desempenho. Ao desligar, volta como estava.';
 /* disco */
 $('#dkT').textContent=disco?`${Math.round(disco.livre)} GB livres de ${Math.round(disco.total)} GB`:'Disco indisponível';$('#dkB').style.width=dp+'%';$('#dkP').textContent=disco?Math.round(dp)+'%':'N/D';
 anel('vlDisco','nDisco',disco?disco.pct:null,'N/D');$('#sbDisco').textContent=disco?`${Math.round(disco.livre)} GB livres`:'';
 /* rede */
 $('#rDown').textContent=vel(s.down||0);$('#rUp').textContent=vel(s.up||0);$('#rPing').innerHTML=s.ping!=null?`${s.ping} <small>ms</small>`:'--';
 /* jogos */
 const J=s.jogos,sig=J.procurando+'|'+J.ocultos+'|'+J.lista.map(j=>j.nome+(j.manual?'*':'')).join('|');
 if(sig!==jogosSig){jogosSig=sig;const bx=$('#jogosBox');
  $('#jgN').textContent=J.procurando?'...':J.lista.length;$('#jgS').textContent=J.procurando?'Procurando jogos...':(J.lista.length?'jogo(s) · '+[...new Set(J.lista.map(j=>j.origem))].slice(0,5).join(' · '):'Steam, Epic, Riot, Roblox, FiveM e mais');
  {const oc=$('#jgOc');oc.hidden=!(J.ocultos>0);oc.textContent='Mostrar os que tirei ('+J.ocultos+')'}
  if(J.procurando)bx.innerHTML='<div class="jg">'+Array.from({length:6},()=>'<div class="sk"></div>').join('')+'</div>';
  else if(!J.lista.length)bx.innerHTML=`<div class="cd"><div class="vz"><div class="ic">${ico('jogos')}</div><b>Nenhum jogo encontrado</b><span>Não achei jogos neste computador. Se o seu jogo não apareceu, clique em <b>Adicionar jogo</b> e escolha o programa dele (o arquivo .exe).</span><div class="linha" style="justify-content:center;margin-top:14px"><button class="bt p" data-a="jogo_adicionar">Adicionar jogo</button></div></div></div>`;
  else bx.innerHTML='<div class="jg">'+J.lista.map((j,n)=>`<article class="jc" style="--i:${Math.min(n,14)}"><div class="cv"><span>${esc(j.nome.slice(0,1).toUpperCase())}</span>${j.steam?`<img src="/capa/${j.i}?k=${K}" alt="" loading="lazy" onerror="this.remove()">`:j.icone?`<img class="ic" src="/capa/${j.i}?k=${K}" alt="" loading="lazy" onload="this.parentNode.classList.add('tem')" onerror="this.remove()">`:''}<button type="button" class="jx" data-a="jogo_tirar" data-i="${j.i}" aria-label="Tirar ${esc(j.nome)} da lista" title="${j.manual?'Tirar da lista':'Esconder da lista (dá para trazer de volta)'}">${ico('x')}</button></div><div class="cb"><small>${esc(j.origem.toUpperCase())}</small><b title="${esc(j.nome)}">${esc(j.nome)}</b><div class="linha"><button class="bt p pj" data-a="jogo_otimizar" data-i="${j.i}" title="Otimiza o PC e abre o jogo; ao fechar o jogo, tudo volta ao normal">Otimizar e jogar</button><button class="bt" data-a="jogo_abrir" data-i="${j.i}" title="Abre o jogo sem otimizar">Jogar</button></div></div></article>`).join('')+'</div>'}
 /* segundo plano */
 {const v=!!s.segundo_plano;$('#swBg').classList.toggle('on',v);$('#swBg').setAttribute('aria-pressed',v);$('#stBg').textContent=v?'LIGADO':'DESLIGADO';$('#stBg').classList.toggle('on',v);$('#sbBg').textContent=v?'Ao fechar a janela, continua rodando':'Ao fechar a janela, encerra'}
 /* configurações */
 const adminOk=s.admin;$('#dg').innerHTML=[['Administrador',adminOk,adminOk?'ligado':'desligado'],['Placa NVIDIA',!!s.gpu,s.gpu?s.gpu.nome:'não encontrada'],['PresentMon.exe (FPS)',s.presentmon,s.presentmon?'encontrado':'não encontrado'],['Pasta do programa',null,s.pasta],['Versão',null,s.versao]]
  .map(r=>`<div><span>${r[0]}</span><b class="${r[1]===true?'ok':r[1]===false?'no':''}">${r[1]===true?ico('check'):r[1]===false?ico('x'):''}<span style="color:inherit;max-width:300px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">${esc(r[2])}</span></b></div>`).join('');
 pintarAjustes();desenharGraficos();pintarExtremo(s);pintarNovas(s);
}
/* botões com índice de jogo (usa data-i) */
document.addEventListener('click',e=>{const b=e.target.closest('[data-a][data-i]');if(b){e.stopImmediatePropagation();acao(b.dataset.a,{i:+b.dataset.i})}},true);

/* ===== ajustes do Windows ===== */
const AJGRP={windows:['windows'],energia:['energia'],mouse:['mouse'],servicos:['servicos'],privacidade:['privacidade'],rede:['rede']};
const AJTXT={
 windows:['Ajustes do Windows','Desliga recursos que gastam desempenho em jogos. Nada muda sem você clicar, e cada ajuste pode ser desfeito. Os marcados com EXTREMO entram na Otimização Extrema.'],
 energia:['Energia do sistema','Hibernação e inicialização rápida. Dá para desfazer a qualquer momento.'],
 mouse:['Outros ajustes do mouse e do teclado','Sem avisos no meio do jogo e repetição de teclas mais rápida. “Aplicar recomendados” e “Restaurar padrão” valem para esta lista e para os botões ATIVADO/DESLIGADO acima.'],
 servicos:['Serviços do Windows','Serviços desligados liberam memória e processador. Nenhum é desinstalado: ao desfazer, voltam como estavam.'],
 privacidade:['Dados e anúncios','Menos coleta de dados, menos anúncios e menos sugestões do Windows.'],
 rede:['Ajustes de rede','Reduzem o atraso (ping) em jogos online. Dá para desfazer a qualquer momento.']
};
const RODAPE='Antes de mudar qualquer valor, o Th Boost guarda o original (arquivo ajustes_backup.json, ao lado do programa). Desfazer devolve exatamente o que estava antes.';
let CAT=null,CATWIN=true,mvArr=false,mvHold=0;
const POR={},ROW={},pend={},LST={},SELAPPS=new Set(),AJMM=new Set(['mouse_acel','mouse_usb']);
const pegar=async(n)=>{const r=await fetch('/api/lista?nome='+n+'&k='+K);if(!r.ok)throw new Error('lista');return r.json()};

const cab=(g,i)=>`<div class="cd led cab" style="--i:${i}"><div><h2>${AJTXT[g][0]}</h2><p>${AJTXT[g][1]}</p><div class="ctr" id="ct-${g}">&nbsp;</div></div><div class="linha"><button class="bt p g" data-ajp="${g}:rec" id="pr-${g}">Aplicar recomendados</button><button class="bt g" data-ajp="${g}:padrao">Restaurar padrão</button></div></div><div class="avs" id="av-${g}" hidden></div>`;
const lista=(g,i)=>`<div class="ajs" id="ls-${g}" style="--i:${i}"><div class="sk fino"></div><div class="sk fino"></div></div>`;
const info=(i,t,p)=>`<div class="cd" style="--i:${i}"><h3>${t}</h3><p>${p}</p></div>`;
const vazio=(ic,t,p)=>`<div class="cd"><div class="vz"><div class="ic">${ico(ic)}</div><b>${t}</b><span>${p}</span></div></div>`;

(function montarPaginas(){
 $('#p-windows').innerHTML=cab('windows',0)+lista('windows',1)+info(2,'Como desfazer',RODAPE+' Se algo parecer estranho, use “Restaurar padrão” no alto da página.');
 $('#p-energia').innerHTML=`<div class="cd led" style="--i:0"><h2 style="margin:0;font-size:21px">Plano de energia</h2><p>Escolha como o Windows equilibra desempenho e consumo. Em notebook, planos de alto desempenho gastam mais bateria.</p><div class="ctr" id="plAtual">&nbsp;</div><div class="pl" id="plBox"><div class="sk fino"></div><div class="sk fino"></div></div></div><div style="height:16px"></div>`+cab('energia',1)+lista('energia',2);
 $('#p-mouse').innerHTML=mmHtml()+cab('mouse',3)+lista('mouse',4);
 $('#p-servicos').innerHTML=`<div class="avs verm" style="--i:0">${ico('info')}<span>Desligue só o que você sabe que não usa e leia a descrição de cada serviço antes de ligar o ajuste. Os de <b>risco médio</b> pedem sua confirmação.</span></div>`+cab('servicos',1)+lista('servicos',2)+info(3,'Como desfazer',RODAPE);
 $('#p-inicializacao').innerHTML=`<div class="cd led cab" style="--i:0"><div><h2>Programas que abrem com o Windows</h2><p>Desligar impede o programa de abrir sozinho ao ligar o PC. Ele continua instalado e dá para ligar de novo aqui.</p><div class="ctr" id="ct-inicio">&nbsp;</div></div><div class="linha"><button class="bt g" id="inRe">Atualizar lista</button></div></div><div class="ajs um" id="lsInicio" style="--i:1"></div>`;
 $('#p-privacidade').innerHTML=cab('privacidade',0)+lista('privacidade',1)+info(2,'Como desfazer',RODAPE);
 $('#p-debloat').innerHTML=`<div class="avs verm" style="--i:0">${ico('info')}<span>Este é o único ajuste que <b>não volta com um clique</b>: um app removido só volta pela Microsoft Store. Por isso a lista tem só apps seguros e nada é removido sem a sua confirmação. Os de risco médio (Spotify, Netflix, Xbox...) você pode ter instalado de propósito: marque um por um.</span></div><div class="avs" id="av-debloat" hidden></div><div class="cd led cab" style="--i:1"><div><h2>Apps que vêm com o Windows</h2><p>Marque os que você não usa. Só aparecem os que estão instalados neste computador.</p><div class="ctr" id="ct-apps">&nbsp;</div></div><div class="linha"><button class="bt g" id="apTodos">Marcar os de risco baixo</button><button class="bt g" id="apNenhum">Limpar</button><button class="bt p g" id="apRem" disabled>Remover selecionados</button></div></div><div class="apg" id="lsApps" style="--i:2"></div>`;
 /* extras da página Rede */
 $('#p-rede').insertAdjacentHTML('beforeend',`<div class="cd led" style="--i:5;margin-bottom:16px"><h2 style="margin:0;font-size:21px">DNS</h2><p>O DNS traduz endereços de sites em números. Trocar para Google ou Cloudflare costuma abrir sites mais rápido. “Automático” volta ao DNS do seu provedor.</p><div class="ctr" id="dnsAtual">&nbsp;</div><div class="pl" id="dnsBox"><div class="sk fino"></div><div class="sk fino"></div></div></div>`+cab('rede',6)+lista('rede',7)+`<div class="cd" style="--i:8"><div class="linha" style="flex-wrap:nowrap;align-items:center;gap:16px"><span class="ti" style="width:46px;height:46px;border-radius:13px;display:grid;place-items:center;background:#121a24;color:oklch(0.7160 calc(0.1430 * var(--tc)) calc(255.97deg + var(--tr)));flex:none">${ico('ip')}</span><div style="flex:1;min-width:0"><b style="font-size:16px">Resetar a rede</b><p style="margin-top:3px">Limpa as configurações de rede do Windows. Use quando a internet trava ou some. Precisa de Administrador e de reiniciar o PC depois. Se você usa IP ou DNS fixos, anote antes: eles voltam para o automático.</p></div><button class="bt" data-c="rede_reset" data-ct="Resetar a rede?" data-cp="A internet vai cair e você precisará reiniciar o computador. Conexões Wi-Fi salvas continuam salvas, mas IP e DNS fixos voltam para o automático. Continuar?">Resetar</button></div></div>`);
})();

/* catálogo vindo do programa */
async function carregarCatalogo(){
 try{const r=await fetch('/api/catalogo?k='+K);if(!r.ok)throw 0;const j=await r.json();CAT=j.ajustes;CATWIN=j.windows;}catch(e){setTimeout(carregarCatalogo,2000);return}
 const por={};CAT.forEach(a=>{POR[a.id]=a;(por[a.grupo]=por[a.grupo]||[]).push(a)});
 Object.keys(AJGRP).forEach(g=>{
  const box=$('#ls-'+g);if(!box)return;const itens=(por[g]||[]).filter(a=>!AJMM.has(a.id));
  if(!itens.length){box.innerHTML=vazio('info','Nada disponível','Este computador não tem ajustes desta categoria.');return}
  box.innerHTML=itens.map(a=>`<div class="aj" data-aj="${esc(a.id)}"><div><b>${esc(a.titulo)}</b>${a.rec?'<span class="rk rec">RECOMENDADO</span>':''}${a.ext?'<span class="rk xt">EXTREMO</span>':''}${a.sup?'<span class="rk sp">SUPREMA</span>':''}<span class="rk ${a.risco==='medio'?'medio">RISCO MÉDIO':'baixo">BAIXO RISCO'}</span></div><button class="sw" data-ajsw="${esc(a.id)}" aria-label="${esc(a.titulo)}"><i></i></button><p>${esc(a.desc)}</p>${a.nota?`<p class="nt">${ico('info')}${esc(a.nota)}</p>`:''}<p class="av" hidden>Precisa de Administrador. Feche e abra o Th Boost pelo atalho.</p></div>`).join('');
  itens.forEach(a=>{ROW[a.id]=box.querySelector(`[data-aj="${a.id}"]`)});
  const pr=$('#pr-'+g);if(pr&&!itens.some(a=>a.rec))pr.style.display='none';
 });
 AJMM.forEach(id=>{const r=document.querySelector('.mm-row[data-aj="'+id+'"]');if(r)ROW[id]=r});
 montarFps();
 if(S)pintarAjustes();
}
function valorAj(id){const p=pend[id],v=S&&S.aj&&id in S.aj?S.aj[id]:null;if(p){if(v===p.alvo||Date.now()-p.t>7000)delete pend[id];else return p.alvo}return v}
function pintarAjustes(){
 if(!S)return;
 $$('[data-ajp]').forEach(b=>{b.disabled=!CATWIN});
 if(atual==='mouse')pintarMouse();
 if(atual==='energia'&&LST.energia)pintarEnergia();
 const gs=AJGRP[atual];if(!gs||!CAT)return;
 gs.forEach(g=>{
  const itens=CAT.filter(a=>a.grupo===g);let lig=0,total=0,semAdm=false;
  itens.forEach(a=>{
   const row=ROW[a.id];if(!row)return;const v=valorAj(a.id),falta=CATWIN&&a.admin&&!S.admin;
   total++;if(v===true)lig++;if(falta)semAdm=true;
   const sw=row.querySelector('.sw');
   row.classList.toggle('on',v===true);row.classList.toggle('nd',v===null||!CATWIN);row.classList.toggle('pd',!!pend[a.id]);
   sw.classList.toggle('on',v===true);sw.disabled=v===null||!CATWIN||falta;sw.setAttribute('aria-pressed',v===true);
   row.querySelector('.av').hidden=!falta;
  });
  const ct=$('#ct-'+g);if(ct)ct.textContent=CATWIN?`${lig} DE ${total} LIGADOS`:'PRÉVIA';
  const av=$('#av-'+g);if(av){
   if(!CATWIN){av.hidden=false;av.innerHTML=ico('info')+'<span>Estes ajustes só funcionam no Windows. Aqui você vê apenas uma prévia.</span>'}
   else if(semAdm){av.hidden=false;av.innerHTML=ico('info')+'<span>Alguns ajustes precisam de <b>Administrador</b>. Feche e abra o Th Boost pelo atalho da área de trabalho.</span>'}
   else av.hidden=true}
 });
}
function alternarAj(id){
 const a=POR[id],v=valorAj(id);if(!a||v===null)return;const ligar=!v;
 const ir_=()=>{pend[id]={alvo:ligar,t:Date.now()};pintarAjustes();acao('aj',{id,ligar})};
 if(ligar&&a.risco==='medio')confirmar(`Ligar “${a.titulo}”?`,`${a.desc}${a.nota?' '+a.nota:''} Você pode desfazer aqui mesmo.`,ir_);else ir_()}
function presetAj(g,modo){
 if(modo==='rec')confirmar('Aplicar os ajustes recomendados?','Vou criar um ponto de restauração do Windows (se possível) e ligar só os ajustes marcados como recomendados desta página. Dá para desfazer depois.',()=>acao('aj_preset',{grupo:g,modo}));
 else confirmar('Restaurar o padrão do Windows?','Todos os ajustes ligados desta página voltam ao que o Windows trazia.',()=>acao('aj_preset',{grupo:g,modo}))}

/* mouse */
function mvTxt(){const r=$('#mvRg'),v=+r.value;r.style.setProperty('--p',((v-1)/19*100)+'%');$('#mvT').textContent=`${v} / 20`+(v===10?' · padrão':'')}
function pintarMouse(){const r=$('#mvRg'),v=S.mouse_vel;r.disabled=v==null||!CATWIN;$('#mvPd').disabled=r.disabled;
 if(v!=null&&!mvArr&&Date.now()>mvHold)r.value=v;
 if(v==null&&!mvArr)$('#mvT').textContent=CATWIN?'-- / 20':'Só funciona no Windows';else mvTxt();mmStatus()}
(function(){const r=$('#mvRg');
 r.addEventListener('input',()=>{mvArr=true;mvTxt()});
 r.addEventListener('change',()=>{mvArr=false;mvHold=Date.now()+2500;mvTxt();acao('mouse_vel',{valor:+r.value})});
 $('#mvPd').onclick=()=>{r.value=10;mvHold=Date.now()+2500;mvTxt();acao('mouse_vel',{valor:10})}})();

/* ===== mouse: reconhece a marca e o modelo, perfil competitivo e teste (v8.7) ===== */
function mmHtml(){
 const linha=(k,id,ic,titulo,desc,gr)=>`<div class="mm-row" data-aj="${id}"${gr?` data-mmg="${gr}"`:''} style="--k:${k}"><span class="mm-ic">${ico(ic)}</span><div class="mm-tx"><b>${titulo}<em class="mm-st" data-st="${id}">…</em></b><small>${desc}</small></div><button class="sw" data-ajsw="${id}" aria-label="${titulo}"><i></i></button><p class="av" hidden>Precisa de Administrador. Feche e abra o Th Boost pelo atalho.</p></div>`;
 return `<div class="mm-top" style="--i:0"><div><h2>Configurações do mouse</h2><p>O Th Boost reconhece o seu mouse e deixa a mira mais precisa. Cada ajuste pode ser desfeito.</p></div><button class="mm-chip" id="mmChip" type="button" aria-expanded="false" aria-controls="mmEsc" title="Escolher o mouse à mão">${ico('mouse')}<span id="mmChipT">Procurando mouse…</span></button></div>
<div class="cd mm-esc" id="mmEsc" style="--i:1" hidden><h3>Escolher o mouse à mão</h3><p>Use quando o Windows não informa o modelo (comum em mouse sem fio com receptor). O Th Boost lembra da escolha neste computador.</p><div class="mm-esc-f"><label>Marca<select class="inp" id="mmMarcaSel" aria-label="Marca do mouse"></select></label><label>Modelo<input class="inp" id="mmModeloIn" maxlength="40" placeholder="Ex.: G502 HERO" autocomplete="off" aria-label="Modelo do mouse"></label></div><div class="linha" style="margin-top:12px"><button class="bt p g" id="mmSalvar" type="button">Usar esta escolha</button><button class="bt g" id="mmAuto" type="button">Voltar ao automático</button></div><p class="mm-det" id="mmDet"></p></div>
<div class="mm-wrap" style="--i:2"><nav class="mm-menu" aria-label="Partes da página do mouse"><small>Mouse</small><button type="button" data-mmt="aj" aria-pressed="true">${ico('mouse')}<span>Desempenho</span></button><button type="button" data-mmt="te" aria-pressed="false">${ico('dashboard')}<span>Testes</span></button><button type="button" data-mmt="fo" aria-pressed="false">${ico('cores')}<span>Foto do mouse</span></button><small>Teclado</small><button type="button" data-mmt="tc" aria-pressed="false">${ico('teclado')}<span>Teclado</span></button><button type="button" class="mm-menu-esc" id="mmMenuEsc">${ico('busca')}<span>Escolher o mouse</span></button></nav>
<div class="mm-palco" id="mmPalco" data-t="aj">
<div class="mm-lado mm-le">
${linha(0,'mouse_acel','mouse','Mira precisa (sem aceleração)','Tira o “Aprimorar precisão do ponteiro”: o mouse anda sempre a mesma distância, ideal para mirar.','aj')}
${linha(1,'mouse_usb','energia','Suspensão de USB desligada','A suspensão seletiva de USB deixa de desligar a porta do mouse para economizar energia: ele responde na hora.','aj')}
<div data-mmg="te" class="mm-card" style="--k:0"><div class="mm-t-cab"><div><b>Teste de mouse</b><small>Mede a taxa de atualização (Hz) e confere os botões. Aperte Iniciar e mova o mouse bem rápido, em círculos, dentro do quadro por 5 segundos.</small></div><button class="bt p g" id="mmIni" type="button">Iniciar teste</button></div>
<div class="mm-t-area" id="mmArea" tabindex="0" aria-label="Área do teste de mouse" hidden><div class="mm-t-msg" id="mmTmsg"></div><button class="bt g mm-t-x" id="mmFechar" type="button">Fechar</button><div class="mm-t-bar"><i id="mmTbar"></i></div></div>
<div class="mm-t-res" id="mmRes" hidden><div><small>Taxa de atualização</small><b id="mmHz">--</b></div><div><small>Movimentos medidos</small><b id="mmAm">--</b></div><div><small>Botão esquerdo</small><b id="mmBL">0</b></div><div><small>Botão direito</small><b id="mmBR">0</b></div><div><small>Roda (clique)</small><b id="mmBM">0</b></div><div id="mmDupB"><small>Duplo clique falso</small><b id="mmDup">0</b></div></div>
<p class="mm-t-nota" id="mmTnota" hidden></p></div>
<div class="mm-card mm-foto-c" data-mmg="fo" style="--k:0"><span class="mm-ic">${ico('mouse')}</span><b>Sua foto, sem o fundo</b><small>O Th Boost tira o fundo sozinho e deixa só o mouse no meio da página.</small><ol class="mm-passos"><li>Coloque o mouse em cima de uma folha branca ou de uma mesa lisa.</li><li>Tire a foto de cima, com luz boa.</li><li>Evite sombra forte embaixo do mouse.</li></ol><div class="mm-img-bt"><button class="bt p g" id="mmFotoBt" type="button" title="Tire uma foto do seu mouse em cima de uma folha branca ou mesa lisa: o Th Boost tira o fundo sozinho">Usar minha foto</button><button class="bt g" id="mmFotoRm" type="button" hidden>Tirar foto</button><input type="file" id="mmFotoIn" accept="image/png,image/jpeg,image/webp" hidden></div></div>
<div data-mmg="tc" class="mm-row" style="--k:0"><span class="mm-ic">${ico('teclado')}</span><div class="mm-tx"><b>Teclado rápido (estilo magnético)<em class="mm-st" id="tkPerfilSt">—</em></b><small>Tira as esperas do Windows: a tecla segurada repete sem atraso, os avisos de Shift não aparecem no meio do jogo e a USB não dorme. Teclado magnético de verdade (que reage no meio do toque) é do próprio teclado; aqui o ganho é do lado do Windows. Desligar devolve o que era antes.</small></div><button class="bt g" id="tkPerfil" type="button" disabled>Ligar</button></div>
</div>
<div class="mm-dir" style="--k:1"><div class="mm-img" id="mmImg"><div class="mm-fig" id="mmFig" aria-hidden="true"></div><div class="mm-leg"><small id="mmMarca">Procurando…</small><b id="mmModelo">—</b><span id="mmMeta"></span></div><p class="mm-dica" id="mmDica" hidden></p><ul class="mm-dados" id="mmDados" hidden></ul><p class="mm-dados-n" id="mmDadosN" hidden></p><div class="mm-img-bt"><button class="bt g" id="mmAbrir" type="button">Não é esse? Escolher</button><button class="bt g" id="mmAtualizar" type="button">Atualizar</button></div><small class="mm-nota" id="mmNota">Imagem ilustrativa</small></div></div>
<div class="mm-lado mm-ld">
<div data-mmg="aj" class="mm-row mm-vel" style="--k:2"><span class="mm-ic">${ico('mouse')}</span><div class="mm-tx"><b>Velocidade do cursor<em class="mm-st lig" id="mvT">-- / 20</em></b><small>Quanto o ponteiro anda a cada movimento do mouse. O padrão do Windows é 10. Vale já ao soltar o controle.</small></div><button class="bt g" id="mvPd" disabled>Padrão</button><div class="mm-sl"><input type="range" id="mvRg" min="1" max="20" value="10" disabled aria-label="Velocidade do ponteiro"><div class="mm-sl-pe"><span>Lento</span><span>Rápido</span></div></div></div>
<div data-mmg="aj" class="mm-barra" id="mmBarra" style="--k:3"><span class="mm-ic">${ico('jogos')}</span><div class="mm-tx"><b>Modo competitivo<em class="mm-st" id="mmPerfilSt">—</em></b><small>Liga de uma vez a mira sem aceleração, a velocidade 10/20 (1 para 1) e o USB sem suspensão. Desligar devolve o que era antes.</small></div><button class="bt g" id="mmPerfil" type="button" disabled>Ativar</button></div>
<div data-mmg="te" class="mm-card" style="--k:1"><div class="mm-t-cab"><div><b>Teste de cliques por segundo (CPS)</b><small>Mede a velocidade do seu clique. Aperte Iniciar, depois clique o mais rápido que conseguir no quadro: a contagem de 5 segundos começa no primeiro clique.</small></div><button class="bt p g" id="cpIni" type="button">Iniciar teste</button></div>
<div class="mm-t-area" id="cpArea" tabindex="0" aria-label="Área do teste de cliques" hidden><div class="mm-t-msg" id="cpMsg"></div><button class="bt g mm-t-x" id="cpFechar" type="button">Fechar</button><div class="mm-t-bar"><i id="cpBar"></i></div></div>
<div class="mm-t-res" id="cpRes" hidden><div><small>Cliques</small><b id="cpN">0</b></div><div><small>Média (cliques/s)</small><b id="cpM">--</b></div><div><small>Melhor segundo</small><b id="cpB">--</b></div></div></div>
<div class="mm-card mm-foto-c" data-mmg="fo" style="--k:1"><span class="mm-ic">${ico('busca')}</span><b>Achar foto na internet</b><small>Abre a busca de imagens com a marca e o modelo do seu mouse. Salve uma foto de fundo branco e depois use “Usar minha foto”: o fundo sai do mesmo jeito.</small><div class="mm-img-bt"><button class="bt g" id="mmFotoBusca" type="button">Achar foto na internet</button></div></div>
<div data-mmg="tc" class="mm-card" style="--k:1"><div class="mm-t-cab"><div><b>Teste de teclado</b><small>Aperte teclas dentro do quadro. Mostra quais teclas chegaram e quantas o teclado aceita juntas (importante para jogos).</small></div><button class="bt p g" id="tkIni" type="button">Iniciar teste</button></div>
<div class="tk-ar" id="tkArea" tabindex="0" aria-label="Área do teste de teclado" hidden><div class="tk-msg" id="tkMsg"></div><div class="tk-teclas" id="tkTeclas"></div></div>
<div class="mm-t-res" id="tkRes" hidden><div><small>Última tecla</small><b id="tkUlt">--</b></div><div><small>Máximo juntas</small><b id="tkMax">0</b></div><div><small>Teclas diferentes</small><b id="tkQtd">0</b></div></div>
<p class="mm-t-nota" id="tkNota" hidden></p></div>
</div>
</div></div>`}

/* ilustração do mouse: 3 formatos, com o destaque na cor da marca e o nome da marca no corpo */
let mmUid=0;
const MMF={
 esportivo:{b:'M100 12C74 12 58 28 54 58C50 96 44 140 42 184C40 236 56 282 100 290C144 282 160 236 158 184C156 140 150 96 146 58C142 28 126 12 100 12Z',cx:100,top:12,mid:[100,150],sep:'M100 14V112',arc:'M55 114Q100 128 145 114',roda:[44,82],lado:[[39,134,9,24],[39,164,9,20]],logo:[100,232,13]},
 ergonomico:{b:'M104 12C76 12 58 30 54 60C50 92 34 128 28 168C22 214 38 270 100 292C158 290 178 244 176 190C174 140 164 98 156 62C152 30 134 12 104 12Z',cx:104,top:12,mid:[102,152],sep:'M104 14V112',arc:'M56 116Q104 130 154 116',roda:[42,80],lado:[[25,130,10,22],[23,158,10,22],[27,186,9,18]],logo:[106,238,13],grip:'M32 150C25 182 30 226 56 256'},
 simples:{b:'M100 36C68 36 56 62 56 92C56 150 50 210 58 242C66 272 84 286 100 286C116 286 134 272 142 242C150 210 144 150 144 92C144 62 132 36 100 36Z',cx:100,top:36,mid:[100,160],sep:'M100 38V118',arc:'M58 120Q100 132 142 120',roda:[56,88],lado:[],logo:[100,232,11]},
 pequeno:{b:'M100 72C71 72 53 90 51 118C48 154 45 192 51 216C57 238 77 248 100 248C123 248 143 238 149 216C155 192 152 154 149 118C147 90 129 72 100 72Z',cx:100,top:72,mid:[100,160],sep:'M100 74V130',arc:'M52 134Q100 148 148 134',roda:[90,122],lado:[],logo:[100,206,11],vb:'15 40 170 255',sh:262}
};
/* clareia (f>0) ou escurece (f<0) uma cor #rrggbb */
function mmTom(h,f){const m=/^#([0-9a-f]{6})$/i.exec(h||'');if(!m)return '#1d1d22';const n=parseInt(m[1],16),t=f>=0?255:0,k=Math.min(1,Math.abs(f)),c=[n>>16&255,n>>8&255,n&255].map(v=>Math.round(v+(t-v)*k));return '#'+c.map(v=>v.toString(16).padStart(2,'0')).join('')}
const mmHex=h=>/^#[0-9a-f]{6}$/i.test(h||'');
/* ilustração do mouse. pf = perfil do modelo (corpo, laterais, botões, cabo, luz) ou null; sem perfil vale o desenho por formato */
/* v9.6: sulcos da rodinha (linhas finas claras e escuras, como borracha) */
function mmSulcos(cx,y,h,w){let o='';for(let k=0;k<=h;k+=3){o+=`<line x1="${cx-w}" y1="${y+k}" x2="${cx+w}" y2="${y+k}" stroke="#000" stroke-opacity=".45" stroke-width=".9"/><line x1="${cx-w}" y1="${y+k+1}" x2="${cx+w}" y2="${y+k+1}" stroke="#fff" stroke-opacity=".12" stroke-width=".6"/>`}return o}
function mouseSvg(f,cor,marca,pf){
 const u='mm'+(++mmUid),c=mmHex(cor)?cor:tom('#3389fa'),nome=esc(String(marca||'').toUpperCase().slice(0,14)),S=MMF[f]||MMF.simples;
 pf=pf&&typeof pf==='object'?pf:null;
 const corpo=pf&&mmHex(pf.corpo)?pf.corpo:null,lat=pf&&mmHex(pf.lateral)?pf.lateral:'#0c0c0f',disc=!!(pf&&pf.logo==='discreto'),dois=!!(pf&&pf.dois);
 const rh=S.roda[1]-S.roda[0],cx=S.cx;
 const g0=corpo?mmTom(corpo,.16):(f==='simples'?'#3d3d45':'#34343b'),g1=corpo||'#1d1d22',g2=corpo?mmTom(corpo,-.6):'#0c0c0f';
 const txt=(extra)=>{const sz=disc?S.logo[2]-1:S.logo[2];return `<text x="${S.logo[0]}" y="${S.logo[1]}" text-anchor="middle" font-family="Segoe UI,Arial,sans-serif" font-weight="${disc?700:800}" font-size="${sz}" letter-spacing="${disc?.6:1.2}" fill="${disc?mmTom(g1,-.62):c}" ${nome.length>8?'textLength="70" lengthAdjust="spacingAndGlyphs"':''} ${extra}>${nome}</text>`};
 const lados=pf?S.lado.slice(0,Math.max(0,Math.min(S.lado.length,pf.laterais==null?S.lado.length:+pf.laterais||0))):S.lado;
 const rgb=!!(pf&&pf.rgb);
 let cabo='';
 if(pf&&(pf.fio==='trancado'||pf.fio==='liso')){const y=S.top,d=`M${cx} ${y+4}C${cx} ${y-10} ${cx+14} ${y-14} ${cx+14} ${y-30}`;
  cabo=`<linearGradient id="${u}k" gradientUnits="userSpaceOnUse" x1="0" y1="${y+4}" x2="0" y2="${y-30}"><stop offset="0" stop-color="#2c2c33"/><stop offset="1" stop-color="#2c2c33" stop-opacity="0"/></linearGradient>`;
  cabo={defs:cabo,svg:`<path d="${d}" fill="none" stroke="url(#${u}k)" stroke-width="5" stroke-linecap="round"/>`+(pf.fio==='trancado'?`<path d="${d}" fill="none" stroke="#ffffff" stroke-opacity=".3" stroke-width="5" stroke-dasharray="1.6 2.6" stroke-linecap="butt"/>`:'')}}
 const defs=`<defs><linearGradient id="${u}g" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="${g0}"/><stop offset=".45" stop-color="${g1}"/><stop offset="1" stop-color="${g2}"/></linearGradient><linearGradient id="${u}r" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#ffffff" stop-opacity=".34"/><stop offset=".5" stop-color="#ffffff" stop-opacity=".06"/><stop offset="1" stop-color="${c}" stop-opacity=".55"/></linearGradient>`
  +(rgb?`<linearGradient id="${u}a" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#ff2d55"/><stop offset=".33" stop-color="#ffd60a"/><stop offset=".66" stop-color="#30d158"/><stop offset="1" style="stop-color:oklch(0.6243 calc(0.2056 * var(--tc)) calc(255.49deg + var(--tr)))"/></linearGradient>`:'')
  +`<radialGradient id="${u}s" cx=".35" cy=".25" r=".7"><stop offset="0" stop-color="#ffffff" stop-opacity=".16"/><stop offset="1" stop-color="#ffffff" stop-opacity="0"/></radialGradient><filter id="${u}b" x="-50%" y="-50%" width="200%" height="200%"><feGaussianBlur stdDeviation="3"/></filter>${cabo?cabo.defs:''}`
  /* v9.6: acabamento — brilho de cima, volume nas bordas, rodinha com sulcos e sombra de contato */
  +`<clipPath id="${u}c"><path d="${S.b}"/></clipPath><filter id="${u}m" x="-50%" y="-50%" width="200%" height="200%"><feGaussianBlur stdDeviation="7"/></filter><filter id="${u}p" x="-50%" y="-50%" width="200%" height="200%"><feGaussianBlur stdDeviation="1.6"/></filter>`
  +`<linearGradient id="${u}w" x1="0" y1="0" x2="1" y2="0"><stop offset="0" stop-color="#1a1b1f"/><stop offset=".5" stop-color="#5d6270"/><stop offset="1" stop-color="#1a1b1f"/></linearGradient></defs>`;
 const claro=corpo?(()=>{const h=corpo.replace('#','');return (0.2126*parseInt(h.slice(0,2),16)+0.7152*parseInt(h.slice(2,4),16)+0.0722*parseInt(h.slice(4,6),16))/255>.55})():false;
 const acab=`<g clip-path="url(#${u}c)"><path d="${S.b}" fill="none" stroke="#000" stroke-opacity="${claro?.22:.5}" stroke-width="${claro?12:16}" filter="url(#${u}m)"/><ellipse cx="${cx-17}" cy="${S.top+(S.mid[1]-S.top)*.55}" rx="17" ry="${Math.max(30,(S.mid[1]-S.top)*.75)}" fill="#ffffff" opacity="${corpo?.2:.13}" filter="url(#${u}m)"/><ellipse cx="${cx+24}" cy="${S.mid[1]+48}" rx="10" ry="36" fill="#ffffff" opacity=".05" filter="url(#${u}m)"/></g>`;
 const corpoSvg=dois
  ?`<path d="${S.b}" fill="${lat}"/><g transform="translate(${S.mid[0]} ${S.mid[1]}) scale(.9 .965) translate(${-S.mid[0]} ${-S.mid[1]})"><path d="${S.b}" fill="url(#${u}g)"/></g><path d="${S.b}" fill="url(#${u}s)"/><path d="${S.b}" fill="none" stroke="url(#${u}r)" stroke-width="1.4"/>`
  :`<path d="${S.b}" fill="url(#${u}g)"/><path d="${S.b}" fill="url(#${u}s)"/><path d="${S.b}" fill="none" stroke="url(#${u}r)" stroke-width="1.4"/>`;
 const luz=rgb?`<g class="mm-rgb"><path d="${S.b}" fill="none" stroke="url(#${u}a)" stroke-width="5" opacity=".55" filter="url(#${u}b)"/><path d="${S.b}" fill="none" stroke="url(#${u}a)" stroke-width="1.8" opacity=".95"/></g>`:'';
 const dpi=pf&&pf.dpi?`<rect x="${cx-5}" y="${S.roda[1]+8}" width="10" height="6" rx="3" fill="#09090b" stroke="${c}" stroke-opacity=".7"/>`:'';
 const rec=pf&&pf.semfio?`<rect x="160" y="238" width="16" height="26" rx="2.5" fill="#2a2c31" stroke="#ffffff" stroke-opacity=".18"/><rect x="163" y="228" width="10" height="12" rx="1.5" fill="#a3a8b1"/><rect x="165" y="231" width="2" height="2" fill="#40444c"/><rect x="169" y="231" width="2" height="2" fill="#40444c"/>`:'';
 return `<svg viewBox="${S.vb||'0 0 200 300'}" xmlns="http://www.w3.org/2000/svg" aria-hidden="true" focusable="false">${defs}`
 +`<ellipse cx="100" cy="${S.sh||294}" rx="${S.vb?50:62}" ry="8" fill="${disc?'#000':c}" opacity="${disc?.55:.38}" filter="url(#${u}b)"/><ellipse cx="100" cy="${(S.sh||294)-3}" rx="${S.vb?34:42}" ry="3.5" fill="#000" opacity=".55" filter="url(#${u}p)"/>`
 +(cabo?cabo.svg:'')
 +corpoSvg
 +acab
 +(S.grip?`<path d="${S.grip}" fill="none" stroke="${c}" stroke-opacity=".55" stroke-width="2.2" stroke-linecap="round" stroke-dasharray="1 5"/>`:'')
 +`<path d="${S.sep}" stroke="#000" stroke-opacity=".75" stroke-width="2.2" fill="none"/><path d="${S.sep}" transform="translate(1.6 0)" stroke="#ffffff" stroke-opacity=".08" fill="none"/><path d="${S.arc}" stroke="#000" stroke-opacity=".65" stroke-width="2" fill="none" stroke-linecap="round"/>`
 +(disc?`<rect x="${cx-6}" y="${S.roda[0]}" width="12" height="${rh}" rx="6" fill="#0d0e10" stroke="#ffffff" stroke-opacity=".16"/><rect x="${cx-2.4}" y="${S.roda[0]+3}" width="4.8" height="${rh-6}" rx="2.4" fill="url(#${u}w)"/>${mmSulcos(cx,S.roda[0]+5,rh-10,1.9)}`:`<rect x="${cx-6.5}" y="${S.roda[0]}" width="13" height="${rh}" rx="6.5" fill="#09090b" stroke="${c}" stroke-opacity="${pf&&!rgb?.25:.55}"/><rect x="${cx-2.2}" y="${S.roda[0]+4}" width="4.4" height="${rh-8}" rx="2.2" fill="${c}" opacity="${pf&&!rgb?.35:.6}" filter="url(#${u}b)"/><rect x="${cx-2.2}" y="${S.roda[0]+4}" width="4.4" height="${rh-8}" rx="2.2" fill="${c}" opacity="${pf&&!rgb?.55:.9}"/>${mmSulcos(cx,S.roda[0]+6,rh-12,1.8)}`)
 +dpi
 +lados.map(([x,y,w,h])=>`<rect x="${x}" y="${y}" width="${w}" height="${h}" rx="4" fill="#26262c" stroke="#ffffff" stroke-opacity=".12"/>`).join('')
 +luz
 +`<circle cx="${S.logo[0]}" cy="${S.logo[1]-4}" r="${disc?3.2:4.4}" fill="${disc?mmTom(g1,-.5):c}" opacity="${disc?1:.9}"/>`+(disc?'':`<circle cx="${S.logo[0]}" cy="${S.logo[1]-4}" r="7" fill="${c}" opacity=".35" filter="url(#${u}b)"/>`)
 +rec
 +`</svg>`}
/* a figura do mouse: a foto da pessoa, se ela guardou uma; senão o desenho do modelo */
function mmFigura(f,d,pf){
 const desenho=()=>{f.classList.remove('foto');f.innerHTML=mouseSvg(d.formato,d.cor,d.marca,pf)};
 desenho();
 if(d.foto){const im=new Image();im.className='mm-foto';im.alt='Foto do seu mouse';
  im.onload=()=>{try{const t=document.createElement('canvas');t.width=t.height=8;const tx=t.getContext('2d');tx.drawImage(im,0,0,8,8);const a=tx.getImageData(0,0,8,8).data;
    im.classList.toggle('sem-fundo',a[3]<40&&a[31]<40&&a[227]<40&&a[255]<40)}catch(_){} /* cantos transparentes: foto recortada */
   f.classList.add('foto');f.innerHTML='';f.appendChild(im);f.classList.remove('ent');void f.offsetWidth;f.classList.add('ent')};
  im.onerror=desenho;im.src='/api/mouse_foto?k='+K+'&v='+encodeURIComponent(d.foto)}}

/* estado vindo do programa (marca, modelo, conexão) */
let MMJ=null,MMSIG='',MMTent=0,MMTimer=0;
function entrarMouse(){MMTent=0;carregarMouse()}
async function carregarMouse(){
 clearTimeout(MMTimer);
 try{MMJ=await pegar('mouse_info')}catch(e){MMJ=null}
 if(MMJ)pintarMouseInfo();
 else{const c=$('#mmChipT');if(c)c.textContent='Não consegui ler o mouse'}
 if(atual==='mouse'&&MMTent++<25&&(!MMJ||MMJ.estado==='lendo'||MMJ.estado==='nenhum'))MMTimer=setTimeout(carregarMouse,1500)}
function mmRgb(h){const m=/^#([0-9a-f]{2})([0-9a-f]{2})([0-9a-f]{2})$/i.exec(h||'');return m?`${parseInt(m[1],16)},${parseInt(m[2],16)},${parseInt(m[3],16)}`:'250,51,71'}
function pintarMouseInfo(){
 const j=MMJ,d=j&&j.dados;if(!d||!$('#mmChipT'))return;
 const lendo=j.estado==='lendo'||j.estado==='nenhum';
 $('#mmChipT').textContent=d.nome||(lendo?'Procurando mouse…':(j.win?'Mouse não identificado':'Prévia do mouse'));
 const pf=d.perfil||null,sig=[d.formato,d.cor,d.marca,d.modelo,d.foto||0,pf?1:0].join('|');
 if(sig!==MMSIG){MMSIG=sig;const f=$('#mmFig');mmFigura(f,d,pf);f.classList.remove('ent');void f.offsetWidth;f.classList.add('ent');$('#mmImg').style.setProperty('--mcr',mmRgb(d.cor))}
 const dl=$('#mmDados'),dn=$('#mmDadosN'),sf=!!d.foto;
 if(pf&&pf.dados&&pf.dados.length){dl.innerHTML=pf.dados.map(x=>`<li>${esc(x)}</li>`).join('');dl.hidden=false;dn.hidden=false;dn.textContent='Segundo a ficha do produto. O desenho é ilustrativo.'}
 else{dl.hidden=true;dl.innerHTML='';dn.hidden=!d.achado;dn.textContent=sf?'':'Ainda não tenho a ficha deste modelo. O desenho segue o formato mais parecido; use “Usar minha foto” para ver o seu mouse de verdade.'}
 if(sf)dn.hidden=true;
 $('#mmFotoRm').hidden=!sf;$('#mmNota').textContent=sf?'Foto guardada por você neste PC':'Imagem ilustrativa do Th Boost';
 const temChave=!!(d.chave);$('#mmFotoBt').disabled=!temChave;$('#mmFotoBusca').disabled=!temChave;
 $('#mmMarca').textContent=d.marca||(lendo?'Procurando…':(d.achado?'Marca não informada':'Sem marca'));
 $('#mmModelo').textContent=d.modelo||(d.achado?'Modelo não informado':(j.win?(lendo?'Lendo o Windows…':'Nenhum mouse encontrado'):'Só no Windows'));
 const meta=[d.conexao,d.vid?`${d.vid}:${d.pid}`:'',d.origem==='manual'?'escolhido por você':''].filter(Boolean);
 if(d.outros&&d.outros.length)meta.push('outros: '+d.outros.join(', '));
 $('#mmMeta').textContent=meta.join(' · ');
 const dica=!j.win?'Prévia: o reconhecimento automático só funciona no Windows. Você pode escolher o mouse à mão.':(j.estado==='erro'?'Não consegui ler os dispositivos agora. Toque em Atualizar para tentar de novo.':d.dica);
 const dc=$('#mmDica');dc.textContent=dica||'';dc.hidden=!dica;
 const sel=$('#mmMarcaSel');
 if(!sel.options.length)sel.innerHTML='<option value="">Outra marca / não sei</option>'+(j.marcas||[]).map(m=>`<option value="${esc(m)}">${esc(m)}</option>`).join('');
 if(document.activeElement!==sel&&document.activeElement!==$('#mmModeloIn')&&$('#mmEsc').hidden){sel.value=(j.manual&&j.manual.marca)||'';$('#mmModeloIn').value=(j.manual&&j.manual.modelo)||''}
 $('#mmDet').textContent=d.vid?`O Windows informou o fabricante ${d.vid} e o produto ${d.pid}${d.conexao?' ('+d.conexao+')':''}.`:''}
function mmAbrirEsc(abrir){const p=$('#mmEsc'),b=$('#mmChip');abrir=abrir==null?p.hidden:abrir;p.hidden=!abrir;b.setAttribute('aria-expanded',abrir);if(abrir){pintarMouseInfo();const s=$('#mmMarcaSel');s.value=(MMJ&&MMJ.manual&&MMJ.manual.marca)||(MMJ&&MMJ.dados&&MMJ.dados.marca)||'';$('#mmModeloIn').value=(MMJ&&MMJ.manual&&MMJ.manual.modelo)||(MMJ&&MMJ.dados&&MMJ.dados.modelo)||'';p.scrollIntoView({block:'nearest'});$('#mmModeloIn').focus()}}
$('#mmChip').onclick=()=>mmAbrirEsc();
/* v9.6: menu da página do mouse (as partes trocam os cartões dos lados; o mouse fica sempre no meio) */
function mmAba(t,anima){const p=$('#mmPalco');if(!p||!/^(aj|te|fo|tc)$/.test(t))return;p.dataset.t=t;
 $$('.mm-menu [data-mmt]').forEach(b=>b.setAttribute('aria-pressed',String(b.dataset.mmt===t)));
 if(anima&&!document.documentElement.classList.contains('leve'))$$('[data-mmg="'+t+'"]',p).forEach(c=>{c.classList.remove('mm-troca');void c.offsetWidth;c.classList.add('mm-troca')});
 try{localStorage.setItem('thboost-mm-aba',t)}catch(_){}}
$$('.mm-menu [data-mmt]').forEach(b=>b.onclick=()=>mmAba(b.dataset.mmt,true));
$('#mmMenuEsc').onclick=()=>{mmAbrirEsc(true);const e=$('#mmEsc');if(e)e.scrollIntoView({block:'nearest',behavior:'smooth'})};
try{const t=localStorage.getItem('thboost-mm-aba');if(t)mmAba(t,false)}catch(_){}
$('#mmAbrir').onclick=()=>mmAbrirEsc(true);
$('#mmAtualizar').onclick=()=>{MMTent=0;MMSIG='';acao('mouse_ler');setTimeout(carregarMouse,500)};
$('#mmSalvar').onclick=async()=>{const marca=$('#mmMarcaSel').value,modelo=$('#mmModeloIn').value.trim();if(!marca&&!modelo){toast('Escolha a marca ou escreva o modelo.');return}
 await acao('mouse_manual',{marca,modelo});MMSIG='';await carregarMouse();mmAbrirEsc(false)};
$('#mmAuto').onclick=async()=>{await acao('mouse_manual',{marca:'',modelo:''});$('#mmMarcaSel').value='';$('#mmModeloIn').value='';MMSIG='';await carregarMouse();mmAbrirEsc(false)};
$('#mmModeloIn').addEventListener('keydown',e=>{if(e.key==='Enter')$('#mmSalvar').click()});

/* status ATIVADO / DESLIGADO e perfil competitivo */
function mmStatus(){
 $$('.mm-st[data-st]').forEach(e=>{const v=valorAj(e.dataset.st);e.textContent=v==null?(CATWIN?'—':'PRÉVIA'):(v?'ATIVADO':'DESLIGADO')});
 const ac=valorAj('mouse_acel'),us=valorAj('mouse_usb'),vel=S.mouse_vel,ativo=ac===true&&vel===10&&us!==false;
 const b=$('#mmPerfil');b.disabled=!CATWIN;b.textContent=ativo?'Desligar':'Ativar';b.classList.toggle('p',!ativo);
 const st=$('#mmPerfilSt');st.textContent=!CATWIN?'PRÉVIA':(ativo?'ATIVADO':'DESLIGADO');st.classList.toggle('lig',ativo&&CATWIN);b.dataset.ativo=ativo?'1':'';
 $('#mmBarra').classList.toggle('on',ativo&&CATWIN);
 const tr=valorAj('teclado_rapido'),ta=valorAj('teclas_aderencia'),tu=valorAj('mouse_usb'),tk=tr===true&&ta===true&&tu!==false;
 const kb=$('#tkPerfil');kb.disabled=!CATWIN;kb.textContent=tk?'Desligar':'Ligar';kb.classList.toggle('p',!tk);kb.dataset.ativo=tk?'1':'';
 const ks=$('#tkPerfilSt');ks.textContent=!CATWIN?'PRÉVIA':(tk?'ATIVADO':'DESLIGADO');ks.classList.toggle('lig',tk&&CATWIN)}
$('#tkPerfil').onclick=()=>{
 if($('#tkPerfil').dataset.ativo)confirmar('Desligar o teclado rápido?','A repetição de teclas e os avisos de Shift voltam ao que eram antes, e a suspensão de USB volta ao que era.',()=>acao('teclado_perfil',{ligar:false}));
 else confirmar('Ligar o teclado rápido?','Vou tirar a espera da repetição das teclas, desligar os avisos de acessibilidade do Shift e desligar a suspensão de USB. Dá para desfazer aqui mesmo.',()=>acao('teclado_perfil',{ligar:true}))};

/* foto do mouse: a pessoa escolhe um arquivo; a tela reduz e manda ao programa (fica só neste PC) */
/* v9.6: tira o fundo da foto do mouse (foto do celular com o mouse em cima de uma folha ou mesa lisa).
   Acha a cor do fundo pelas bordas, "pinta" o fundo a partir das bordas (aceitando a variação suave de luz e sombra),
   fica com o maior pedaço que sobrou (o mouse), suaviza a borda e corta em volta. Tudo aqui no computador. */
function mmRecorta(bmp){
 const L=640,e=Math.min(1,L/Math.max(bmp.width,bmp.height)),W=Math.max(8,Math.round(bmp.width*e)),H=Math.max(8,Math.round(bmp.height*e)),N=W*H;
 const c=document.createElement('canvas');c.width=W;c.height=H;const x=c.getContext('2d',{willReadFrequently:true});x.drawImage(bmp,0,0,W,H);
 const im=x.getImageData(0,0,W,H),d=im.data;
 let tr=0;for(let i=3;i<d.length;i+=4)if(d[i]<20)tr++;if(tr>N*0.05)return {cv:c,ok:true,ja:true}; // já veio sem fundo
 // cópia suavizada (tira o chiado da câmera e os quadradinhos do JPEG antes de comparar as cores)
 const s=new Float32Array(N*3);for(let y=0;y<H;y++)for(let x2=0;x2<W;x2++){let r=0,g=0,b=0,n=0;for(let j=-1;j<=1;j++){const yy=y+j;if(yy<0||yy>=H)continue;for(let i=-1;i<=1;i++){const xx=x2+i;if(xx<0||xx>=W)continue;const q=(yy*W+xx)*4;r+=d[q];g+=d[q+1];b+=d[q+2];n++}}const p=(y*W+x2)*3;s[p]=r/n;s[p+1]=g/n;s[p+2]=b/n}
 // cores no espaço Lab (como o olho vê): separa melhor um mouse claro de uma mesa de madeira
 const lin=new Float32Array(256);for(let i=0;i<256;i++){const v=i/255;lin[i]=v<=.04045?v/12.92:Math.pow((v+.055)/1.055,2.4)}
 const fL=(t)=>t>.008856?Math.cbrt(t):7.787*t+16/116,lab=new Float32Array(N*3);
 for(let p=0;p<N;p++){const r=lin[Math.round(s[p*3])],g=lin[Math.round(s[p*3+1])],b=lin[Math.round(s[p*3+2])];
  const fx=fL((.4124*r+.3576*g+.1805*b)/.95047),fy=fL(.2126*r+.7152*g+.0722*b),fz=fL((.0193*r+.1192*g+.9505*b)/1.08883);lab[p*3]=116*fy-16;lab[p*3+1]=500*(fx-fy);lab[p*3+2]=200*(fy-fz)}
 const borda=[];for(let i=0;i<W;i++)borda.push(i,(H-1)*W+i);for(let j=1;j<H-1;j++)borda.push(j*W,j*W+W-1);
 const med=(k)=>{const v=borda.map(p=>lab[p*3+k]).sort((a,b)=>a-b);return v[v.length>>1]},bg=[med(0),med(1),med(2)];
 // distância até o fundo: o que só ficou mais escuro com a mesma cor (sombra) conta menos
 const dc=(p,L,A,B)=>{let dl=lab[p*3]-L;if(dl<0)dl*=.5;const da=lab[p*3+1]-A,dB=lab[p*3+2]-B;return Math.sqrt(dl*dl+da*da+dB*dB)};
 const dv=(p,q)=>{const a=lab[p*3]-lab[q*3],b=lab[p*3+1]-lab[q*3+1],e=lab[p*3+2]-lab[q*3+2];return Math.sqrt(a*a+b*b+e*e)};
 const db=borda.map(p=>dc(p,bg[0],bg[1],bg[2])).sort((a,b)=>a-b);
 if(db[Math.floor(db.length*.5)]>12)return {cv:c,ok:false,por:'fundo'}; // fundo com muita coisa: não dá para saber o que é o mouse
 const thr=Math.max(7,Math.min(22,db[Math.floor(db.length*.9)]*1.5+4));
 const fundo=new Uint8Array(N),fila=new Int32Array(N);let ini=0,fim=0;
 for(const p of borda)if(!fundo[p]&&dc(p,bg[0],bg[1],bg[2])<thr*1.2){fundo[p]=1;fila[fim++]=p}
 if(fim<borda.length*0.6)return {cv:c,ok:false,por:'fundo'};
 // o fundo cresce a partir das bordas; entra aos poucos na luz desigual e na sombra suave, mas para na borda do mouse
 while(ini<fim){const p=fila[ini++],px=p%W,py=(p/W)|0;
  for(const q of [px>0?p-1:-1,px<W-1?p+1:-1,py>0?p-W:-1,py<H-1?p+W:-1]){if(q<0||fundo[q])continue;
   const a=dc(q,bg[0],bg[1],bg[2]);if(a<thr||(a<thr*2.2&&dv(p,q)<1.4&&Math.hypot(lab[q*3+1]-bg[1],lab[q*3+2]-bg[2])<thr*.45)){fundo[q]=1;fila[fim++]=q}}}
 // fica com o maior pedaço que não é fundo (o mouse); pontinhos soltos somem
 const rot=new Int32Array(N).fill(-1);let melhor=-1,maior=0,id=0;
 for(let s0=0;s0<N;s0++){if(fundo[s0]||rot[s0]>=0)continue;let a=0,b=0;fila[b++]=s0;rot[s0]=id;
  while(a<b){const p=fila[a++],px=p%W,py=(p/W)|0;for(const q of [px>0?p-1:-1,px<W-1?p+1:-1,py>0?p-W:-1,py<H-1?p+W:-1])if(q>=0&&!fundo[q]&&rot[q]<0){rot[q]=id;fila[b++]=q}}
  if(b>maior){maior=b;melhor=id}id++}
 if(melhor<0||maior<N*0.03||maior>N*0.92)return {cv:c,ok:false,por:'tamanho'};
 let al=new Float32Array(N),x0=W,y0=H,x1=0,y1=0;for(let p=0;p<N;p++)if(rot[p]===melhor){al[p]=1;const px=p%W,py=(p/W)|0;if(px<x0)x0=px;if(px>x1)x1=px;if(py<y0)y0=py;if(py>y1)y1=py}
 const tocaBorda=(x0===0)+(y0===0)+(x1===W-1)+(y1===H-1);if(tocaBorda>=3)return {cv:c,ok:false,por:'borda'};
 // buraquinhos dentro do mouse (reflexo da luz da mesma cor do fundo) voltam a ser mouse
 const fora=new Uint8Array(N);ini=0;fim=0;for(const p of borda)if(!al[p]&&!fora[p]){fora[p]=1;fila[fim++]=p}
 while(ini<fim){const p=fila[ini++],px=p%W,py=(p/W)|0;for(const q of [px>0?p-1:-1,px<W-1?p+1:-1,py>0?p-W:-1,py<H-1?p+W:-1])if(q>=0&&!al[q]&&!fora[q]){fora[q]=1;fila[fim++]=q}}
 for(let p=0;p<N;p++)if(!fora[p])al[p]=1;
 {const t=new Float32Array(N);for(let y=0;y<H;y++)for(let x2=0;x2<W;x2++){const p=y*W+x2;t[p]=al[p]&&(x2===0||al[p-1])&&(x2===W-1||al[p+1])&&(y===0||al[p-W])&&(y===H-1||al[p+W])?1:0}al=t} // 1 pixel para dentro: a borda clara do fundo não fica em volta do mouse
 const nucleo=al;
 for(let it=0;it<2;it++){const t=new Float32Array(N);for(let y=0;y<H;y++)for(let x2=0;x2<W;x2++){let s2=0,n=0;for(let j=-1;j<=1;j++)for(let i=-1;i<=1;i++){const xx=x2+i,yy=y+j;if(xx>=0&&yy>=0&&xx<W&&yy<H){s2+=al[yy*W+xx];n++}}t[y*W+x2]=s2/n}al=t}
 for(let p=0;p<N;p++){const v=al[p]<0.5?al[p]*al[p]*2:1-(1-al[p])*(1-al[p])*2;d[p*4+3]=Math.round(255*v)} // borda macia, sem "auréola"
 // na borda macia, a cor vem de dentro do mouse (sem o resto da cor da folha/mesa em volta)
 for(let p=0;p<N;p++){const a=d[p*4+3];if(a<3||a>250)continue;const px=p%W,py=(p/W)|0;let r=0,g=0,b=0,n=0;
  for(let j=-2;j<=2;j++){const yy=py+j;if(yy<0||yy>=H)continue;for(let i=-2;i<=2;i++){const xx=px+i;if(xx<0||xx>=W)continue;const q=yy*W+xx;if(nucleo[q]){r+=d[q*4];g+=d[q*4+1];b+=d[q*4+2];n++}}}
  if(n){d[p*4]=r/n;d[p*4+1]=g/n;d[p*4+2]=b/n}}
 x.putImageData(im,0,0);
 const pad=Math.round(Math.max(x1-x0,y1-y0)*0.06),cx0=Math.max(0,x0-pad),cy0=Math.max(0,y0-pad),cw=Math.min(W,x1+pad+1)-cx0,ch=Math.min(H,y1+pad+1)-cy0;
 const o=document.createElement('canvas');o.width=cw;o.height=ch;o.getContext('2d').drawImage(c,cx0,cy0,cw,ch,0,0,cw,ch);
 return {cv:o,ok:true,area:maior/N}}
async function mmBlob(c,tipo,q0){let q=q0,blob=null;for(let i=0;i<7;i++){blob=await new Promise(r=>c.toBlob(r,tipo,q));if(blob&&blob.size<=280*1024)break;q-=.12}return blob}
async function mmEnviarFoto(arq){
 if(!arq)return;
 if(!/^image\//.test(arq.type||'')){toast('Escolha um arquivo de imagem (PNG, JPG ou WEBP).');return}
 try{
  const bmp=await createImageBitmap(arq);
  let blob=null,recorte=null;
  try{recorte=mmRecorta(bmp);if(recorte.ok)blob=await mmBlob(recorte.cv,'image/webp',.92)}catch(_){recorte=null}
  if(blob&&blob.type!=='image/webp')blob=await mmBlob(recorte.cv,'image/png',1); // navegador sem WEBP: PNG (também guarda o transparente)
  if(!blob||blob.size>280*1024){ // não deu para tirar o fundo: guarda a foto inteira, como antes
   const lado=560,e=Math.min(1,lado/Math.max(bmp.width,bmp.height)),c=document.createElement('canvas');c.width=Math.max(1,Math.round(bmp.width*e));c.height=Math.max(1,Math.round(bmp.height*e));
   const x=c.getContext('2d');x.fillStyle='#ffffff';x.fillRect(0,0,c.width,c.height);x.drawImage(bmp,0,0,c.width,c.height);
   blob=await mmBlob(c,'image/jpeg',.9);recorte={ok:false}}
  if(!blob||blob.size>280*1024){toast('A foto ficou grande demais. Escolha uma imagem menor.');return}
  const r=await fetch('/api/mouse_foto?k='+K,{method:'POST',headers:{'Content-Type':'application/octet-stream'},body:blob});
  if(r.ok){toast(recorte&&recorte.ok?'Foto guardada, já sem o fundo. Ela aparece no lugar do desenho.':'Foto guardada, mas não deu para tirar o fundo dela. Para sair recortada: mouse em cima de uma folha branca ou mesa lisa, foto de cima e sem sombra forte.');MMSIG='';await carregarMouse()}
  else{let m='Não consegui guardar a foto.';try{const j=await r.json();if(j&&j.erro)m=j.erro}catch(_){}toast(m)}
 }catch(err){toast('Não consegui abrir essa imagem. Use PNG, JPG ou WEBP.')}}
$('#mmFotoBt').onclick=()=>$('#mmFotoIn').click();
$('#mmFotoIn').addEventListener('change',e=>{const a=e.target.files&&e.target.files[0];e.target.value='';mmEnviarFoto(a)});
$('#mmFotoBusca').onclick=()=>acao('mouse_buscar_foto');
$('#mmFotoRm').onclick=()=>confirmar('Tirar a foto do mouse?','A foto sai deste computador e volta o desenho do Th Boost para este modelo.',async()=>{await acao('mouse_foto_remover');MMSIG='';setTimeout(carregarMouse,300)});

/* teste de cliques por segundo */
const CP={st:0,ts:[],t0:0,tm:0,raf:0};
function cpMostrar(fim){
 const n=CP.ts.length;$('#cpN').textContent=n;
 let melhor=0;for(let i=0,j=0;i<n;i++){while(CP.ts[i]-CP.ts[j]>=1000)j++;melhor=Math.max(melhor,i-j+1)}
 $('#cpM').textContent=fim?(n/5).toFixed(1):'--';$('#cpB').textContent=n?melhor:'--'}
function cpIniciar(){
 clearTimeout(CP.tm);CP.st=1;CP.ts=[];CP.t0=0;
 $('#cpArea').hidden=false;$('#cpRes').hidden=false;cpMostrar(false);
 $('#cpMsg').textContent='Clique aqui o mais rápido que conseguir. A contagem começa no primeiro clique.';$('#cpIni').textContent='Repetir teste';
 const b=$('#cpBar');b.style.transition='none';b.style.width='0%';$('#cpArea').focus({preventScroll:true})}
function cpFim(){
 CP.st=2;cpMostrar(true);const n=CP.ts.length;
 $('#cpMsg').textContent=n?`Pronto: ${(n/5).toFixed(1)} cliques por segundo na média. Aperte Repetir teste para tentar de novo.`:'Nenhum clique contado. Aperte Repetir teste.'}
function cpFechar(){clearTimeout(CP.tm);CP.st=0;$('#cpArea').hidden=true;$('#cpRes').hidden=true;$('#cpIni').textContent='Iniciar teste'}
(function(){
 const a=$('#cpArea');
 a.addEventListener('pointerdown',e=>{if(e.button>2)return;e.preventDefault();
  if(CP.st===1){CP.st=3;CP.t0=e.timeStamp;const b=$('#cpBar');b.style.transition='none';b.style.width='0%';void b.offsetWidth;b.style.transition='width 5s linear';b.style.width='100%';CP.tm=setTimeout(cpFim,5000);$('#cpMsg').textContent='Vai! Clique, clique, clique...'}
  if(CP.st===3&&e.timeStamp-CP.t0<=5000){CP.ts.push(e.timeStamp);cpMostrar(false)}});
 a.addEventListener('contextmenu',e=>e.preventDefault());
 a.addEventListener('auxclick',e=>e.preventDefault());
 $('#cpIni').onclick=cpIniciar;$('#cpFechar').onclick=cpFechar})();

/* teste de teclado: mostra as teclas que chegaram e quantas o teclado aceita juntas */
const TK={on:false,down:new Map(),vistas:new Set(),max:0};
const TK_NOMES={Space:'Espaço',Enter:'Enter',NumpadEnter:'Enter (num.)',Backspace:'Apagar',Tab:'Tab',CapsLock:'Caps Lock',ShiftLeft:'Shift esq.',ShiftRight:'Shift dir.',ControlLeft:'Ctrl esq.',ControlRight:'Ctrl dir.',AltLeft:'Alt esq.',AltRight:'Alt dir. / AltGr',MetaLeft:'Windows',MetaRight:'Windows dir.',ContextMenu:'Menu',ArrowUp:'↑',ArrowDown:'↓',ArrowLeft:'←',ArrowRight:'→',Escape:'Esc',Delete:'Delete',Insert:'Insert',Home:'Home',End:'End',PageUp:'Page Up',PageDown:'Page Down'};
function tkNome(e){if(TK_NOMES[e.code])return TK_NOMES[e.code];if(/^Key[A-Z]$/.test(e.code))return e.code.slice(3);if(/^Digit\d$/.test(e.code))return e.code.slice(5);if(/^F\d{1,2}$/.test(e.code))return e.code;if(/^Numpad/.test(e.code))return 'Num '+e.code.slice(6);return e.key&&e.key.length===1?e.key.toUpperCase():(e.code||e.key||'?')}
function tkMostrar(){
 $('#tkTeclas').innerHTML=[...TK.down.values()].map(n=>`<kbd>${esc(n)}</kbd>`).join('');
 $('#tkMax').textContent=TK.max;$('#tkQtd').textContent=TK.vistas.size}
function tkIniciar(){
 TK.on=true;TK.down.clear();TK.vistas.clear();TK.max=0;
 $('#tkArea').hidden=false;$('#tkRes').hidden=false;$('#tkNota').hidden=true;$('#tkUlt').textContent='--';tkMostrar();
 $('#tkMsg').textContent='Aperte as teclas aqui dentro. Aperte várias juntas para ver o limite do teclado. Esc encerra.';$('#tkIni').textContent='Repetir teste';
 $('#tkArea').classList.add('on');$('#tkArea').focus({preventScroll:true})}
function tkFim(){
 TK.on=false;TK.down.clear();$('#tkArea').classList.remove('on');tkMostrar();
 const n=$('#tkNota');n.hidden=false;
 n.textContent=TK.vistas.size?`Seu teclado entregou até ${TK.max} tecla${TK.max===1?'':'s'} ao mesmo tempo. Se ao apertar 3 ou 4 juntas alguma não aparece, o teclado tem limite (o famoso “ghosting”) e pode perder comandos em jogos.`:'Nenhuma tecla chegou. Clique dentro do quadro e tente de novo.';
 $('#tkMsg').textContent='Teste encerrado. Aperte Repetir teste para recomeçar.'}
(function(){
 const a=$('#tkArea');
 a.addEventListener('keydown',e=>{
  if(!TK.on)return;
  if(e.key==='Escape'){e.preventDefault();return tkFim()}
  if(e.ctrlKey||e.metaKey)return;
  e.preventDefault();
  TK.down.set(e.code,tkNome(e));TK.vistas.add(e.code);TK.max=Math.max(TK.max,TK.down.size);$('#tkUlt').textContent=tkNome(e);tkMostrar()});
 a.addEventListener('keyup',e=>{if(!TK.on)return;e.preventDefault();TK.down.delete(e.code);tkMostrar()});
 a.addEventListener('blur',()=>{if(TK.on){TK.down.clear();tkMostrar()}});
 $('#tkIni').onclick=tkIniciar})();
$('#mmPerfil').onclick=()=>{
 if($('#mmPerfil').dataset.ativo)confirmar('Desligar o perfil competitivo?','A mira volta a ter aceleração se ela estava ligada antes, a velocidade volta ao valor anterior e a suspensão de USB volta ao que era.',()=>acao('mouse_perfil',{ligar:false}));
 else confirmar('Ligar o perfil de mouse competitivo?','Vou desligar a aceleração do ponteiro, deixar a velocidade em 10/20 (1 para 1) e desligar a suspensão de USB. Dá para desfazer aqui mesmo.',()=>acao('mouse_perfil',{ligar:true}))};

/* teste de mouse: taxa de atualização estimada e conferência dos botões */
const MT={run:false,ts:[],cl:[0,0,0],dup:0,ult:[-1e9,-1e9,-1e9],t:0,raw:'onpointerrawupdate' in window};
function estimarHz(ts){
 const d=[];for(let i=1;i<ts.length;i++){const x=ts[i]-ts[i-1];if(x>0.2&&x<25)d.push(x)}
 if(d.length<40)return null;
 d.sort((a,b)=>a-b);
 const base=d.slice(0,Math.max(20,Math.floor(d.length*.5))),med=base[Math.floor(base.length/2)],hz=1000/med;
 const pad=[125,250,500,1000,2000,4000,8000];let p=pad[0];for(const q of pad)if(Math.abs(q-hz)<Math.abs(p-hz))p=q;
 return {hz:Math.round(hz),aprox:Math.abs(p-hz)/p<=.3?p:Math.round(hz),amostras:d.length}}
function mtMostrar(r){
 $('#mmHz').textContent=r?'≈ '+r.aprox+' Hz':'--';$('#mmAm').textContent=r?r.amostras:'--';
 $('#mmBL').textContent=MT.cl[0];$('#mmBR').textContent=MT.cl[2];$('#mmBM').textContent=MT.cl[1];$('#mmDup').textContent=MT.dup;
 $('#mmDupB').classList.toggle('ruim',MT.dup>0)}
function mtIniciar(){
 MT.run=true;MT.r=null;MT.ts=[];MT.cl=[0,0,0];MT.dup=0;MT.ult=[-1e9,-1e9,-1e9];
 $('#mmArea').hidden=false;$('#mmRes').hidden=false;$('#mmTnota').hidden=true;mtMostrar(null);
 $('#mmTmsg').textContent='Mova o mouse bem rápido, em círculos, dentro deste quadro';$('#mmIni').textContent='Repetir teste';
 const bar=$('#mmTbar');bar.style.transition='none';bar.style.width='0%';void bar.offsetWidth;bar.style.transition='width 5s linear';bar.style.width='100%';
 clearTimeout(MT.t);MT.t=setTimeout(mtFim,5000);$('#mmArea').focus({preventScroll:true})}
function mtFim(){
 MT.run=false;const r=MT.r=estimarHz(MT.ts.slice().sort((a,b)=>a-b));mtMostrar(r);
 const n=$('#mmTnota');let t='';
 if(!r)t='Não deu para medir: mexa o mouse mais rápido e por mais tempo e repita o teste.';
 else if(!MT.raw)t='Este navegador entrega menos movimentos ao programa; o valor medido pode ficar abaixo da taxa real do mouse.';
 else t='É uma estimativa feita pela janela do programa. Mover o mouse devagar ou com o PC ocupado baixa o número.';
 n.textContent=t;n.hidden=false;
 $('#mmTmsg').textContent=r?'Agora clique com cada botão aqui dentro (esquerdo, direito e roda) para conferir.':'Tente de novo: mova o mouse bem rápido dentro do quadro.'}
function mtFechar(){clearTimeout(MT.t);MT.run=false;$('#mmArea').hidden=true;$('#mmRes').hidden=true;$('#mmTnota').hidden=true;$('#mmIni').textContent='Iniciar teste'}
(function(){
 const a=$('#mmArea');
 a.addEventListener(MT.raw?'pointerrawupdate':'pointermove',e=>{if(!MT.run)return;const l=e.getCoalescedEvents?e.getCoalescedEvents():[];(l.length?l:[e]).forEach(x=>MT.ts.push(x.timeStamp))});
 a.addEventListener('pointerdown',e=>{if(e.button>2)return;e.preventDefault();MT.cl[e.button]++;if(e.timeStamp-MT.ult[e.button]<35)MT.dup++;MT.ult[e.button]=e.timeStamp;mtMostrar(MT.r);
  if(MT.dup>0){const n=$('#mmTnota');n.textContent='Dois cliques com menos de 35 milissegundos no mesmo botão sugerem defeito no botão (clique duplo falso).';n.hidden=false}});
 a.addEventListener('contextmenu',e=>e.preventDefault());
 a.addEventListener('auxclick',e=>e.preventDefault());
 $('#mmIni').onclick=mtIniciar;$('#mmFechar').onclick=mtFechar})();


/* energia */
const PLD={equilibrado:'O padrão do Windows. Bom para o dia a dia.',alto:'Mais desempenho e mais consumo. Bom para jogos.',maximo:'O máximo que o PC entrega. Pode esquentar em notebook.',economia:'Gasta menos energia. Deixa o PC mais lento.'};
async function carregarEnergia(){try{LST.energia=await pegar('energia');pintarEnergia()}catch(e){$('#plBox').innerHTML=vazio('info','Não consegui ler os planos','Tente de novo em alguns segundos.')}}
function pintarEnergia(){const j=LST.energia;if(!j)return;
 $('#plAtual').textContent=j.ativo?('PLANO EM USO: '+j.ativo.toUpperCase()):(CATWIN?'':'PRÉVIA — SÓ FUNCIONA NO WINDOWS');
 const box=$('#plBox'),sig=JSON.stringify(j.conhecidos)+CATWIN;if(box.dataset.s===sig)return;box.dataset.s=sig;
 box.innerHTML=j.conhecidos.map(p=>`<button class="pc ${p.ativo?'on':''}" data-plano="${esc(p.chave)}" ${CATWIN?'':'disabled'}><span class="pi2">${ico('plano')}</span><b>${esc(p.nome)}</b><small>${esc(PLD[p.chave]||'')}${p.existe?'':' Será criado ao ativar.'}</small>${p.ativo?'<span class="tg">EM USO</span>':''}</button>`).join('')}

/* DNS */
const DNSD=[['auto','Automático','O DNS do seu provedor (padrão).'],['google','Google','8.8.8.8 e 8.8.4.4'],['cloudflare','Cloudflare','1.1.1.1 e 1.0.0.1']];
async function carregarDns(){try{LST.dns=await pegar('dns');pintarDns()}catch(e){$('#dnsBox').innerHTML=vazio('info','Não consegui ler o DNS','Tente de novo em alguns segundos.')}}
function pintarDns(){const j=LST.dns;if(!j)return;
 $('#dnsAtual').textContent=j.servidores&&j.servidores.length?('EM USO: '+j.servidores.join(' · ')+(j.modo==='auto'?' (DO PROVEDOR)':'')):(CATWIN?'EM USO: AUTOMÁTICO':'PRÉVIA — SÓ FUNCIONA NO WINDOWS');
 const sig=JSON.stringify(j)+CATWIN;const box=$('#dnsBox');if(box.dataset.s===sig)return;box.dataset.s=sig;
 const ops=DNSD.map(d=>d[0]==='auto'&&CATWIN&&j.dhcp===false?[d[0],d[1],'Indisponível: este PC usa IP fixo.',1]:d);
 if(j.antes&&j.antes.length)ops.push(['antes','O de antes',j.antes.join(' e ')]);
 box.innerHTML=ops.map(d=>`<button class="pc ${j.modo===d[0]?'on':''}" data-dns="${d[0]}" ${CATWIN&&!d[3]?'':'disabled'}><span class="pi2">${ico('dns')}</span><b>${d[1]}</b><small>${esc(d[2])}</small>${j.modo===d[0]?'<span class="tg">EM USO</span>':''}</button>`).join('')}

/* inicialização */
async function carregarInicio(){const b=$('#lsInicio');if(!LST.inicio)b.innerHTML='<div class="sk fino"></div><div class="sk fino"></div><div class="sk fino"></div>';
 try{LST.inicio=(await pegar('inicio')).itens;pintarInicio()}catch(e){b.innerHTML=vazio('info','Não consegui ler a lista','Tente de novo em alguns segundos.')}}
function pintarInicio(){const it=LST.inicio,b=$('#lsInicio');if(!it)return;
 const lig=it.filter(i=>i.ligado).length;$('#ct-inicio').textContent=it.length?`${lig} DE ${it.length} ABREM COM O WINDOWS`:'';
 if(!it.length){b.innerHTML=vazio('inicializacao',CATWIN?'Nenhum programa na inicialização':'Prévia',CATWIN?'Nenhum programa desta lista abre sozinho com o Windows.':'Esta lista só funciona no Windows.');return}
 b.innerHTML=it.map(i=>`<div class="aj ${i.ligado?'on':''}"><div><b>${esc(i.nome)}</b><span class="rk nt">${esc(i.origem.toUpperCase())}</span></div><button class="sw ${i.ligado?'on':''}" data-inisw="${esc(i.id)}" aria-label="${esc(i.nome)}" aria-pressed="${i.ligado}"><i></i></button><p class="cmd" title="${esc(i.comando)}">${esc(i.comando)}</p></div>`).join('')}

/* debloat */
async function carregarApps(){const b=$('#lsApps');if(!LST.apps)b.innerHTML=Array.from({length:6},()=>'<div class="sk fino"></div>').join('');
 try{const r=await pegar('apps');LST.apps=r.apps;LST.appsErro=r.erro||'';[...SELAPPS].forEach(n=>{if(!LST.apps.some(a=>a.nome===n))SELAPPS.delete(n)});pintarApps()}catch(e){b.innerHTML=vazio('info','Não consegui ler os apps','Tente de novo em alguns segundos.')}}
function pintarApps(){const ap=LST.apps,b=$('#lsApps');if(!ap)return;
 $('#ct-apps').textContent=ap.length?`${SELAPPS.size} DE ${ap.length} SELECIONADOS`:'';$('#apRem').disabled=!SELAPPS.size||!CATWIN;
 if(!ap.length){b.className='';const er=LST.appsErro&&!/Mostrando/.test(LST.appsErro);b.innerHTML=er?vazio('info','Não consegui ler os apps',LST.appsErro):vazio('check',CATWIN?'Nada para remover':'Prévia',CATWIN?'Nenhum app da lista segura está instalado. Seu Windows já está limpo.':'Esta lista só funciona no Windows.');return}
 b.className='apg';
 b.innerHTML=ap.map(a=>`<label class="ap ${SELAPPS.has(a.nome)?'sel':''}"><input type="checkbox" data-app="${esc(a.nome)}" ${SELAPPS.has(a.nome)?'checked':''} ${CATWIN?'':'disabled'}><span class="ck">${ico('check')}</span><div><b>${esc(a.titulo)}</b><small>${esc(a.nome)}</small></div><span class="rk ${a.risco==='medio'?'medio">MÉDIO':'baixo">BAIXO'}</span></label>`).join('');
 const av=$('#av-debloat');if(!CATWIN){av.hidden=false;av.innerHTML=ico('info')+'<span>Só funciona no Windows. Aqui você vê apenas uma prévia.</span>'}
 else if(S&&!S.admin){av.hidden=false;av.innerHTML=ico('info')+'<span>Remover apps precisa de <b>Administrador</b>. Feche e abra o Th Boost pelo atalho da área de trabalho.</span>'}else if(LST.appsErro){av.hidden=false;av.innerHTML=ico('info')+'<span>'+esc(LST.appsErro)+'</span>'}else av.hidden=true}

/* depois de uma ação, relê a lista da página aberta */
let recTimer=null;
function aposMsg(novos){
 if(novos.length&&atual==='dashboard'){DASH.t=0;setTimeout(carregarDash,900)}
 if(novos.length&&atual==='jogos')setTimeout(carregarPerf,900);
 if(!novos.length||!['energia','rede','inicializacao','debloat'].includes(atual))return;
 if(atual==='debloat'&&!novos.some(h=>/removido/i.test(h.t)))return;
 clearTimeout(recTimer);recTimer=setTimeout(()=>entrarPagina(atual),700)}
function entrarPagina(k){
 if(k==='energia')carregarEnergia();else if(k==='rede')carregarDns();else if(k==='inicializacao')carregarInicio();else if(k==='debloat')carregarApps();else if(k==='extremo')entrarExtremo();else if(k==='dashboard'){DASH.t=0;carregarDash()}else if(k==='correcoes')carregarCorr();else if(k==='backup'){BK.sig='';carregarBk()}else if(k==='ferramentas')entrarFerr();else if(k==='processos')entrarProc();else if(k==='memoria')entrarMemoria();else if(k==='cpu')entrarCpf();else if(k==='resfriamento')entrarRf();else if(k==='jogos')entrarJogos();else if(k==='mouse')entrarMouse();else if(k==='overlay')setTimeout(()=>{try{if(S)pintarOverlay(S)}catch(e){}},0)}

document.addEventListener('click',e=>{
 const sw=e.target.closest('[data-ajsw]');if(sw){if(!sw.disabled)alternarAj(sw.dataset.ajsw);return}
 const pr=e.target.closest('[data-ajp]');if(pr){const [g,m]=pr.dataset.ajp.split(':');return presetAj(g,m)}
 const pl=e.target.closest('[data-plano]');if(pl&&!pl.disabled){const j=LST.energia;if(j){j.conhecidos.forEach(p=>{p.ativo=p.chave===pl.dataset.plano});pintarEnergia()}return acao('energia',{plano:pl.dataset.plano})}
 const dn=e.target.closest('[data-dns]');if(dn&&!dn.disabled){return acao('dns_trocar',{modo:dn.dataset.dns})}
 const is=e.target.closest('[data-inisw]');if(is){const i=(LST.inicio||[]).find(x=>x.id===is.dataset.inisw);if(i){i.ligado=!i.ligado;pintarInicio();acao('inicio',{id:i.id,ligar:i.ligado})}return}
 if(e.target.closest('#inRe')){LST.inicio=null;return carregarInicio()}
 if(e.target.closest('#apTodos')){(LST.apps||[]).filter(a=>a.risco!=='medio').forEach(a=>SELAPPS.add(a.nome));return pintarApps()}
 if(e.target.closest('#apNenhum')){SELAPPS.clear();return pintarApps()}
 if(e.target.closest('#apRem')){const n=SELAPPS.size;if(!n)return;
  return confirmar(`Remover ${n} app(s)?`,'Os apps marcados serão removidos de todos os usuários deste PC. Para ter um de volta, instale de novo pela Microsoft Store.',()=>{acao('debloat',{pacotes:[...SELAPPS]});SELAPPS.clear();pintarApps()})}
});
document.addEventListener('change',e=>{const c=e.target.closest('[data-app]');if(!c)return;
 c.checked?SELAPPS.add(c.dataset.app):SELAPPS.delete(c.dataset.app);c.closest('.ap').classList.toggle('sel',c.checked);
 if(LST.apps){$('#ct-apps').textContent=`${SELAPPS.size} DE ${LST.apps.length} SELECIONADOS`;$('#apRem').disabled=!SELAPPS.size||!CATWIN}});
/* ===== Otimização Extrema e Suprema ===== */
const XPLANO=[
 ['restauracao','Ponto de restauração','Cria um ponto de restauração do Windows antes de mexer em qualquer coisa.'],
 ['processos','Fechando o que pesa em segundo plano','Telemetria, Widgets, Game Bar e outros que ninguém usa.'],
 ['l_temp','Limpeza: arquivos temporários','Temporários do usuário e do Windows, cache de internet e de apps da Loja.'],
 ['l_nav','Limpeza: navegadores','Só o cache de Chrome, Edge, Firefox, Brave, Opera e Vivaldi. Senhas e histórico ficam.'],
 ['l_apps','Limpeza: caches de programas','Discord, Teams, Slack, VS Code, Steam, Epic Games e restos do instalador da NVIDIA.'],
 ['l_win','Limpeza: lixo do Windows','Atualizações já baixadas, relatórios de erro, despejos de falha e registros antigos.'],
 ['lixeira','Esvaziando a lixeira','Apaga de forma definitiva.'],
 ['winold','Removendo o Windows.old','Apaga a pasta que sobra da atualização do Windows. Não dá para voltar atrás.','winold'],
 ['dism','Componentes antigos do Windows','Remove versões antigas de componentes do Windows. Demora alguns minutos.','dism'],
 ['aj_windows','Ajustes do Windows','Efeitos visuais leves, Game DVR, apps parados em segundo plano, menos gravações no disco.'],
 ['aj_mouse','Mouse e teclado','Sem aceleração do ponteiro e sem avisos de acessibilidade no meio do jogo.'],
 ['aj_servicos','Serviços desnecessários','Telemetria, fax, mapas, entrega de atualizações para outros PCs e outros.'],
 ['aj_privacidade','Privacidade e telemetria','Menos coleta de dados, menos anúncios e sem tarefas de telemetria.'],
 ['aj_rede','Rede e latência','Sem limite de rede para multimídia e menos atraso em jogos online.'],
 ['aj_jogos','Ajustes de FPS para jogos','Game DVR, Game Bar, prioridade de jogos, mouse sem aceleração e rede sem atraso.'],
 ['inicio','Programas que abrem com o Windows','Launchers e atualizadores que abrem sozinhos (Discord, Steam, Teams...).'],
 ['gpu','Seus jogos usam a placa de vídeo forte','Diz ao Windows para usar a placa de vídeo de alto desempenho nos jogos da sua biblioteca.','sup'],
 ['energia','Plano de energia Extremo','Plano de máximo desempenho só na tomada; hibernação desligada em PC de mesa.'],
 ['disco','Disco: manutenção do SSD','TRIM no SSD. Em HD mecânico esta parte é pulada.'],
 ['apps','Removendo apps inúteis do Windows','Candy Crush, TikTok, Netflix e outros pré-instalados. Só voltam pela Loja.','apps'],
 ['dns','Rede: limpando o DNS','Limpa o cache de endereços da rede.'],
 ['ram','Liberando a RAM','Esvazia a memória dos programas e, como Administrador, o cache do sistema.']];
const XOPC={dism:true,apps:false,busca:false,winold:false};
try{const o=JSON.parse(localStorage.getItem('thboost-xopc')||'{}');Object.keys(XOPC).forEach(k=>{if(typeof o[k]==='boolean')XOPC[k]=o[k]})}catch(e){}
const X={fase:'idle',fim:null,analisadoEm:0,sigLado:'',mode:'',rodando:'',nivel:'extrema',segNivel:''};
try{const n=localStorage.getItem('thboost-xnivel');if(n==='suprema'||n==='extrema')X.nivel=n}catch(e){}
const fmtMB=(mb)=>mb>=1024?(mb/1024).toFixed(1).replace('.',',')+' GB':Math.round(mb)+' MB';
const fmtGB=(g)=>g==null?'--':g.toFixed(1).replace('.',',')+' GB';
const fmtB=(b)=>fmtMB(b/1048576);
const inteiro=(v)=>String(Math.round(v));
const XSEG=(nv)=>[
 '<b>Ponto de restauração</b> do Windows antes de qualquer mudança (quando o Windows permite criar).',
 '<b>Desfazer em um clique:</b> ajustes, plano de energia e programas da inicialização voltam como estavam.',
 'Só apaga <b>cache e lixo</b>. Senhas, cookies, históricos, documentos e jogos nunca são tocados.',
 '<b>Fica de fora de propósito:</b> drivers, antivírus, “limpador de registro”, Prefetch e cache de shaders (apagar isso deixa o PC mais lento, não mais rápido).',
 'Os ajustes de <b>risco médio</b> (impressão, Bluetooth, Xbox, VBS e outros) continuam desligados. Você liga um a um nas páginas deles.',
 nv==='suprema'?'Em notebook, o plano de energia máximo e os ajustes só de PC de mesa valem <b>só na tomada</b> ou são pulados. Na bateria nada muda.':'Em notebook, o plano de energia máximo vale <b>só na tomada</b>. Na bateria nada muda.'
].map(t=>`<li>${ico('check')}<span>${t}</span></li>`).join('');
$('#xCards').innerHTML=[1,2,3,4].map(i=>`<div class="cd led" style="--i:${i}"><h3 id="xt${i}">--</h3><div class="nm" id="xn${i}">--</div><p id="xs${i}"></p></div>`).join('');

function pendentesAj(){if(!CAT||!S||!S.aj)return null;const sup=X.nivel==='suprema';return CAT.filter(a=>(a.rec||a.ext||(sup&&a.sup))&&a.risco!=='medio'&&S.aj[a.id]===false).length}
function xcard(i,titulo,valor,fmt,sub,vivo){
 $('#xt'+i).textContent=titulo;const n=$('#xn'+i);
 if(valor==null){n._alvo=undefined;n.innerHTML='<div class="xsk" style="width:60%;margin:8px 0 0"></div>'}
 else{if(n.firstElementChild)n.textContent='';tween(n,valor,fmt)}
 $('#xs'+i).innerHTML=sub||'';n.closest('.cd').classList.toggle('vivo',!!vivo)}
function xlista(){
 const sup=X.nivel==='suprema',a=S&&S.ext?S.ext.analise:null;
 return XPLANO.filter(p=>{const o=p[3];if(o==='sup')return sup;if(!o)return true;if(o==='winold')return !!XOPC.winold&&!!a&&a.winold_gb>0;return !!XOPC[o]})
  .map(p=>{let n=p[1],d=p[2];
   if(sup&&p[0]==='energia'){n='Plano de energia Suprema';d='Processador sempre no máximo, turbo agressivo, placa de vídeo e USB sem economia. Só na tomada; hibernação desligada em PC de mesa.'}
   if(sup&&p[0]==='aj_windows'){d='Visual do Windows no modo desempenho, Game DVR, apps parados em segundo plano, menos gravações no disco e, com 16 GB de RAM ou mais, compressão de memória desligada.'}
   if(sup&&p[0]==='aj_servicos'){d='Telemetria, fax, mapas e, na Suprema, também os serviços que quase ninguém usa e os de sincronização por usuário.'}
   if(sup&&p[0]==='l_win'){d='Atualizações já baixadas, relatórios de erro, despejos de falha e registros do Windows com mais de 30 dias.'}
   if(sup&&p[0]==='l_apps'){d='Caches de programas, pacotes de driver já instalados (NVIDIA e AMD), cache da Loja, da Adobe e logs do OneDrive.'}
   if(sup&&p[0]==='inicio'){d='Launchers e atualizadores que abrem sozinhos, mais atualizadores do Google, Edge e Java e programas de fabricante.'}
   return {id:p[0],nome:n,estado:'pendente',texto:d,mb:0,plano:1}})}

function pintarExtremo(s){
 const e=s.ext;if(!e)return;
 const fase=e.ativo?'run':(e.resumo?'done':(e.analise.estado==='rodando'?'scan':'idle'));
 const mudou=X.fase!==fase;X.fase=fase;
 document.body.classList.toggle('xrun',!!e.ativo);
 if(X.fim===null)X.fim=e.fim;
 else if(e.fim>X.fim){X.fim=e.fim;if(atual==='extremo'){XP.burst=true;xpIniciar()}}
 if(atual!=='extremo')return;
 const nv=(fase==='run'||fase==='done')&&e.opcoes&&e.opcoes.nivel?e.opcoes.nivel:X.nivel,sup=nv==='suprema';
 const h=$('#xHero');h.className='xhero fase-'+fase+(sup?' sup':'');
 $('#xNome').textContent=sup?'SUPREMA':'Extrema';$('#xTagT').textContent=sup?'MODO SUPREMO':'MODO MÁXIMO';
 $$('#xNivel button').forEach(b=>{b.classList.toggle('on',b.dataset.nivel===nv);b.disabled=fase==='run'||fase==='scan'});
 const circ=653.45,fr=fase==='run'?e.fracao:(fase==='done'?1:0);
 $('#xProg').style.strokeDashoffset=circ*(1-fr);
 const pct=$('#xPct'),modo=fase==='run'?'n':(fase==='done'?'ok':'ic');
 if(X.mode!==modo){X.mode=modo;pct._alvo=undefined;pct._v=undefined;pct.innerHTML=modo==='ok'?ico('check'):(modo==='ic'?ico('extremo'):'0%')}
 if(modo==='n')tween(pct,Math.round(fr*100),v=>Math.round(v)+'%');
 $('#xFase').textContent={idle:'PRONTO',scan:'ANALISANDO',run:'OTIMIZANDO',done:'CONCLUÍDO'}[fase];
 const st=$('#xStatus'),sub=$('#xSub'),r=e.resumo,a=e.analise;
 const nome=sup?'Otimização Suprema':'Otimização Extrema';
 if(fase==='run'){st.textContent=e.parando?'Parando...':(e.passo||'Trabalhando...');sub.textContent='Você pode continuar usando o PC. Alguns programas escondidos em segundo plano serão fechados e o Th Boost fica à frente até terminar.'}
 else if(fase==='done'){st.textContent=nome+' concluída';sub.textContent=`Apaguei ${fmtMB(r.limpo_mb)} de lixo e apliquei ${r.ajustes} ajuste(s).`+(r.reiniciar?' Reinicie o PC para terminar de aplicar tudo.':'')}
 else{st.textContent=fase==='scan'?'Procurando lixo no seu PC...':'Pronta para começar';
  sub.textContent=sup?'O nível mais forte: tudo da Extrema, mais limpeza mais funda, serviços raros desligados, visual no modo desempenho, plano de energia no máximo e seus jogos na placa de vídeo forte. Com ponto de restauração e botão de desfazer.'
   :'Limpeza profunda, ajustes de desempenho, inicialização enxuta e plano de energia máximo. Tudo de uma vez, com ponto de restauração e botão de desfazer.'}
 const go=$('#xGo');go.disabled=fase==='run'||!CATWIN;go.querySelector('span').textContent=fase==='run'?'Otimizando...':(fase==='done'?'Fazer de novo':'Ativar '+(sup?'a Suprema':'Otimização Extrema'));
 const pa=$('#xParar');pa.hidden=fase!=='run';pa.textContent=e.parando?'Parando...':'Parar';pa.disabled=!!e.parando;
 const rein=$('#xRein');
 if(e.reinicio>0){rein.hidden=false;rein.innerHTML=`${ico('info')}<span>O PC reinicia em ${e.reinicio} s.</span><button class="bt g" data-a="reiniciar_cancelar">Cancelar reinício</button>`}else rein.hidden=true;
 const av=$('#xAdm');
 if(!CATWIN){av.hidden=false;av.innerHTML=ico('info')+'<span>A Otimização Extrema só funciona no Windows. Aqui você vê apenas uma prévia.</span>'}
 else if(!s.admin){av.hidden=false;av.innerHTML=ico('info')+'<span>Você abriu o Th Boost <b>sem Administrador</b>. A Otimização fará só uma parte (limpeza e ajustes do seu usuário). Para o máximo, feche e abra pelo atalho da área de trabalho.</span>'}
 else av.hidden=true;
 if(X.segNivel!==nv){X.segNivel=nv;$('#xSeg').innerHTML=XSEG(nv)}
 if(fase==='idle'&&a.estado==='pronto'&&a.nivel!==X.nivel&&Date.now()-X.analisadoEm>4000){X.analisadoEm=Date.now();acao('extremo_analisar',{nivel:X.nivel})}
 /* cartões de números */
 const an=e.antes,de=e.depois;
 if(fase==='run')xcard(1,'LIXO APAGADO',e.mb,fmtMB,'até agora',true);
 else if(fase==='done')xcard(1,'LIXO APAGADO',r.limpo_mb,fmtMB,'nesta rodada',true);
 else xcard(1,'LIXO ENCONTRADO',a.estado==='pronto'?a.total_mb:null,fmtMB,a.estado==='pronto'?'pronto para limpar':(a.estado==='erro'?'não consegui medir':'analisando...'));
 if(fase==='run'){const f=e.passos.filter(p=>p.estado!=='pendente'&&p.estado!=='rodando').length;xcard(2,'PASSOS CONCLUÍDOS',f,inteiro,`de ${e.passos.length}`,true)}
 else if(fase==='done')xcard(2,'AJUSTES APLICADOS',r.ajustes,inteiro,`${r.servicos} serviço(s) · ${r.inicio} fora da inicialização`,true);
 else{const p=pendentesAj();xcard(2,'AJUSTES A APLICAR',p,inteiro,'desempenho, serviços, privacidade, rede e jogos')}
 if(fase==='done'&&an&&de)xcard(3,'RAM LIVRE',de.ram_livre,fmtGB,`antes ${fmtGB(an.ram_livre)}`+(r.ram_gb>0.04?` · <span class="xd">+${fmtGB(r.ram_gb)}</span>`:''),true);
 else xcard(3,'RAM LIVRE',s.ram_livre,fmtGB,`de ${Math.round(s.ram_total)} GB`,fase==='run');
 if(fase==='done'&&an&&de&&an.disco_livre!=null&&de.disco_livre!=null){const g=de.disco_livre-an.disco_livre;xcard(4,'ESPAÇO LIVRE',de.disco_livre,fmtGB,`antes ${fmtGB(an.disco_livre)}`+(g>0.04?` · <span class="xd">+${fmtGB(g)}</span>`:''),true)}
 else{xcard(4,'ESPAÇO LIVRE',s.disco?s.disco.livre:null,fmtGB,s.disco?`de ${Math.round(s.disco.total)} GB`:'não foi possível ler',fase==='run');if(!s.disco){const n=$('#xn4');n._alvo=undefined;n.textContent='--'}}
 /* passos */
 const lista=(fase==='run'||fase==='done')?e.passos:xlista();
 pintarPassosX(lista,fase);
 pintarLadoX(e,fase,s);
 if(mudou)xpIniciar();
}
function pintarPassosX(lista,fase){
 const c=$('#xPassos');const vivos=new Set(lista.map(p=>p.id));
 [...c.children].forEach(n=>{if(!vivos.has(n.dataset.id))n.remove()});
 let rodando=null;
 lista.forEach((p,i)=>{
  let n=c.querySelector(`[data-id="${p.id}"]`);
  if(!n){n=document.createElement('div');n.dataset.id=p.id;n.innerHTML=`<span class="pi"></span><div><b></b><small></small></div>`;n.querySelector('.pi').innerHTML=ico('check')}
  if(c.children[i]!==n)c.insertBefore(n,c.children[i]||null);
  const cls='ps '+p.estado;if(n.className!==cls){n.className=cls;n.querySelector('.pi').innerHTML=ico(p.estado==='pulado'?'traco':(p.estado==='erro'?'x':'check'))}
  const b=n.querySelector('b'),sm=n.querySelector('small');
  if(b.textContent!==p.nome)b.textContent=p.nome;
  const txt=p.texto||(p.estado==='rodando'?'Em andamento...':(p.estado==='pendente'?'Aguardando':''));
  if(sm.textContent!==txt)sm.textContent=txt;
  let chip=n.querySelector('.mb');
  if(p.mb>=0.1){if(!chip){chip=document.createElement('span');chip.className='mb';n.appendChild(chip)}const t=fmtMB(p.mb);if(chip.textContent!==t)chip.textContent=t}
  else if(chip)chip.remove();
  if(p.estado==='rodando')rodando=n});
 if(fase==='run'&&rodando&&X.rodando!==rodando.dataset.id){X.rodando=rodando.dataset.id;c.scrollTo({top:Math.max(0,rodando.offsetTop-c.clientHeight/2+rodando.clientHeight/2),behavior:fx()?'smooth':'auto'})}
 if(fase!=='run')X.rodando=''}
function barraLixo(it,max){return `<div class="xb"><span title="${esc(it.nome)}">${esc(it.nome)}</span><div class="tr"><i style="width:${Math.max(3,it.mb/max*100)}%"></i></div><b>${fmtMB(it.mb)}</b></div>`}
const WO_TXT={ok:['Windows.old','removido (não dá mais para voltar à versão anterior do Windows)'],parcial:['Windows.old','removido em parte: o que estava em uso ficou'],adiado:['Windows.old','adiado: reinicie o PC e rode de novo']};
function pintarLadoX(e,fase,s){
 const box=$('#xLado'),a=e.analise,r=e.resumo;
 if(fase==='run'){
  if(X.sigLado!=='run'){X.sigLado='run';box.innerHTML=`<div class="cd xlive"><h3>Ao vivo</h3><div class="big" id="xBig">0 MB</div><p>de lixo apagados até agora</p><div class="xtick" id="xTick"></div><div class="linha" id="xPula" style="margin-top:14px" hidden><button class="bt g" data-a="extremo_pular">Pular esta parte</button></div></div>`}
  tween($('#xBig'),e.mb,fmtMB);
  const feitos=e.passos.filter(p=>p.estado!=='pendente'&&p.estado!=='rodando'&&p.texto).slice(-4),ativo=e.passos.find(p=>p.estado==='rodando');
  const linhas=feitos.map(p=>p.texto).concat(ativo?[ativo.nome+'...']:[]);
  const sig=linhas.join('|');const tk=$('#xTick');
  if(tk.dataset.s!==sig){tk.dataset.s=sig;tk.innerHTML=linhas.map(t=>`<div>${esc(t)}</div>`).join('')}
  $('#xPula').hidden=!(ativo&&(ativo.id==='dism'||ativo.id==='winold'));
  return}
 if(fase==='done'&&r){
  const sig='done'+e.fim+(s.admin?1:0);
  if(X.sigLado!==sig){X.sigLado=sig;
   const linhas=[];
   linhas.push(['lixo',fmtMB(r.limpo_mb),'de lixo e cache apagados']);
   if(r.ram_gb>0.04)linhas.push(['ram','+'+fmtGB(r.ram_gb),'de memória RAM livre a mais']);
   linhas.push(['servicos',String(r.ajustes),`ajuste(s) aplicado(s)${r.servicos?` · ${r.servicos} serviço(s) desligado(s)`:''}`]);
   if(r.inicio)linhas.push(['inicializacao',String(r.inicio),'programa(s) fora da inicialização do Windows']);
   if(r.processos&&r.processos[0]!=null&&r.processos[1]!=null&&r.processos[1]<r.processos[0])linhas.push(['processos',`${r.processos[0]} → ${r.processos[1]}`,'processos rodando (os serviços só diminuem de vez depois de reiniciar)']);
   if(r.plano)linhas.push(['plano',r.nivel==='suprema'?'Suprema':'Extremo','plano de energia de máximo desempenho ativo'+(r.hibernacao?' · hibernação desligada':'')]);
   if(r.gpu)linhas.push(['gpu',String(r.gpu),'programa(s) de jogo usando a placa de vídeo forte']);
   if(r.trim)linhas.push(['disco','TRIM','enviado ao SSD']);
   if(r.dism==='ok')linhas.push(['windows','Windows','componentes antigos removidos']);
   else if(r.dism==='adiado')linhas.push(['info','Adiado','limpeza de componentes: reinicie o PC e rode de novo']);
   if(WO_TXT[r.winold])linhas.push(['disco',WO_TXT[r.winold][0],WO_TXT[r.winold][1]]);
   if(r.apps)linhas.push(['debloat',String(r.apps),'app(s) inútil(eis) removido(s)']);
   if(r.fechados&&r.fechados.length)linhas.push(['x','Fechados','programas escondidos: '+r.fechados.join(', ')]);
   box.innerHTML=`<div class="cd led xres"><h3>Resultado</h3>${linhas.map((l,k)=>`<div class="rl" style="--k:${k}"><span class="ri">${ico(l[0])}</span><div><b>${esc(l[1])}</b><span>${esc(l[2])}</span></div></div>`).join('')}<div class="linha">${r.reiniciar?`<button class="bt p" data-c="reiniciar_pc" data-ct="Reiniciar o PC agora?" data-cp="Salve o que estiver aberto. O PC reinicia em 20 segundos e você pode cancelar aqui. O reinício termina de aplicar os ajustes.">${ico('ip')}<span>Reiniciar agora</span></button>`:''}${e.desfazer?`<button class="bt" data-c="extremo_desfazer" data-ct="Desfazer a otimização?" data-cp="Os ajustes, o plano de energia e os programas da inicialização voltam como estavam antes. Arquivos apagados, Windows.old e apps removidos não voltam.">${ico('desfazer')}<span>Desfazer tudo</span></button>`:''}</div></div>`}
  return}
 /* parado ou analisando */
 const sup=X.nivel==='suprema';
 const sig=['i',a.estado,a.total_mb,a.itens.map(i=>i.nome+i.mb).join(','),JSON.stringify(XOPC),a.winold_gb,X.nivel,e.desfazer].join('|');
 if(X.sigLado===sig)return;X.sigLado=sig;
 let bars;
 if(a.estado==='rodando'||a.estado==='nenhuma')bars='<div class="xsk"></div><div class="xsk" style="width:84%"></div><div class="xsk" style="width:66%"></div><div class="xsk" style="width:48%"></div>';
 else if(a.estado==='erro')bars='<p>Não consegui medir agora. Tente analisar de novo.</p>';
 else if(!a.itens.length)bars='<p>Nada de lixo relevante por aqui. Seu PC já está limpo.</p>';
 else{const mx=Math.max(...a.itens.map(i=>i.mb));bars=a.itens.slice(0,6).map(i=>barraLixo(i,mx)).join('')}
 const opc=(k,t,d,rk)=>`<div class="xo"><div><b>${t}${rk?` <span class="rk ${rk[0]}">${rk[1]}</span>`:''}</b><small>${d}</small></div><button class="sw ${XOPC[k]?'on':''}" data-xopc="${k}" aria-pressed="${XOPC[k]}" aria-label="${t}"><i></i></button></div>`;
 const wo=a.estado==='pronto'&&a.winold_gb>0?opc('winold',`Remover o Windows.old (${fmtGB(a.winold_gb)})`,'Pasta que sobra da atualização do Windows. Libera bastante espaço, mas depois você não consegue voltar à versão anterior do Windows. Não dá para desfazer.',['medio','NÃO DESFAZ']):'';
 box.innerHTML=`<div class="cd led"><h3>Maiores lixeiras encontradas</h3>${bars}<div class="linha" style="margin-top:12px"><button class="bt g" data-act="x_analisar" ${a.estado==='rodando'?'disabled':''}>Analisar de novo</button></div></div>`+
  `<div class="cd"><h3>Opções</h3>${opc('dism','Limpar componentes antigos do Windows','Libera vários GB, mas demora alguns minutos. Dá para pular durante a execução.')}${opc('apps','Remover apps inúteis do Windows','Candy Crush, TikTok, Netflix e outros pré-instalados. Só voltam pela Microsoft Store.')}${opc('busca','Desligar a indexação de arquivos do Windows','A busca do menu Iniciar fica mais lenta, em troca de menos uso do disco. Só vale a pena em HD ou PC fraco.',['medio','RISCO MÉDIO'])}${wo}</div>`+
  (sup?`<div class="cd"><h3>O que a Suprema acrescenta</h3><ul class="xseg" style="grid-template-columns:1fr">`+[
   '<b>Limpeza mais funda:</b> registros do Windows com mais de 30 dias, pacotes de driver já instalados (NVIDIA e AMD), cache da Loja, da Adobe e do OneDrive.',
   '<b>Serviços que quase ninguém usa</b> desligados: telefone, carteira digital, registro remoto, sincronização por usuário e descoberta UPnP.',
   '<b>Visual do Windows no modo desempenho</b> e, com 16 GB de RAM ou mais, compressão de memória desligada.',
   '<b>Plano de energia no máximo</b> (turbo, todos os núcleos, USB e placa de vídeo sem economia) e <b>seus jogos na placa de vídeo forte</b>.',
   'Muita coisa só aparece depois de <b>reiniciar o PC</b>. O ganho varia de PC para PC: é maior em máquina cheia de programas e menor em PC já enxuto.'
  ].map(t=>`<li>${ico('check')}<span>${t}</span></li>`).join('')+`</ul></div>`:'')+
  (e.desfazer?`<div class="cd"><h3>Última otimização</h3><p>Os ajustes, o plano de energia e a inicialização ainda estão no modo extremo. Você pode devolver tudo ao que era antes.</p><div class="linha" style="margin-top:12px"><button class="bt g" data-c="extremo_desfazer" data-ct="Desfazer a otimização?" data-cp="Os ajustes, o plano de energia e os programas da inicialização voltam como estavam antes. Arquivos apagados, Windows.old e apps removidos não voltam.">${ico('desfazer')}<span>Desfazer tudo</span></button></div></div>`:'')}

document.addEventListener('click',ev=>{
 const o=ev.target.closest('[data-xopc]');if(o){const k=o.dataset.xopc;XOPC[k]=!XOPC[k];try{localStorage.setItem('thboost-xopc',JSON.stringify(XOPC))}catch(e){}X.sigLado='';if(S)pintarExtremo(S);return}
 const nv=ev.target.closest('#xNivel [data-nivel]');if(nv){if(nv.disabled||nv.dataset.nivel===X.nivel)return;X.nivel=nv.dataset.nivel;try{localStorage.setItem('thboost-xnivel',X.nivel)}catch(e){}X.sigLado='';X.analisadoEm=0;if(S)pintarExtremo(S);return}
 if(ev.target.closest('#xGo')){const b=$('#xGo');if(b.disabled)return;
  const sup=X.nivel==='suprema',a=S.ext.analise,wo=XOPC.winold&&a.winold_gb>0;
  const base=sup?'Vou criar um ponto de restauração e fazer tudo o que a Otimização Extrema faz, mais: limpeza mais funda (registros antigos, caches de driver, da Loja e da Adobe), serviços que quase ninguém usa desligados, visual do Windows no modo desempenho, plano de energia no máximo e seus jogos na placa de vídeo forte.'
   :'Vou criar um ponto de restauração, limpar lixo e caches, aplicar ajustes de desempenho, tirar launchers pesados da inicialização e ativar um plano de energia de máximo desempenho.';
  const extra=[XOPC.apps?'os apps inúteis do Windows que você marcou (só voltam pela Microsoft Store)':'',wo?`a pasta Windows.old (${fmtGB(a.winold_gb)}), que não volta e impede voltar à versão anterior do Windows`:''].filter(Boolean);
  return confirmar(sup?'Ativar a Otimização Suprema?':'Ativar a Otimização Extrema?',base+' Alguns programas escondidos em segundo plano serão fechados. Nada é desinstalado'+(extra.length?', exceto '+extra.join(' e '):'')+'. Os ajustes podem ser desfeitos aqui mesmo.',()=>{X.sigLado='';acao('extremo',{opcoes:{dism:XOPC.dism,apps:XOPC.apps,busca:XOPC.busca,winold:!!wo,nivel:X.nivel}})})}
 if(ev.target.closest('#xParar')){const b=$('#xParar');if(!b.disabled)acao('extremo_parar')}
});
function entrarExtremo(){
 X.sigLado='';X.fase='';
 if(S&&S.ext&&!S.ext.ativo&&S.ext.analise.estado!=='rodando'&&(Date.now()-X.analisadoEm>300000||S.ext.analise.nivel!==X.nivel)){X.analisadoEm=Date.now();acao('extremo_analisar',{nivel:X.nivel})}
 if(S)pintarExtremo(S);xpIniciar()}

/* partículas do painel (somem no modo leve e quando a janela não está à vista) */
const XP={ps:[],raf:0,t:0,burst:false};
const XPAL={idle:['#80a0ff','#3b88ff','#99a3ff'],scan:['#99a3ff','#6b9cff','#ffffff'],run:['#99a3ff','#3b88ff','#493dff','#ffffff'],done:['#4ade80','#86efac','#ffffff','#22d3ee'],burst:['#4ade80','#86efac','#ffffff','#22d3ee','#ffb36b']};
const rnd=(a,b)=>a+Math.random()*(b-a),pick=(l)=>l[Math.floor(Math.random()*l.length)];
function novaP(tipo,cx,cy,R,w,h){
 const cor=tom(pick(XPAL[tipo==='burst'?'burst':X.fase]||XPAL.idle));
 if(tipo==='burst'){const an=rnd(0,6.283),v=rnd(160,460);return {tipo,x:cx,y:cy,px:cx,py:cy,vx:Math.cos(an)*v,vy:Math.sin(an)*v,t:0,vida:rnd(1.1,2.1),r:rnd(1.2,3.2),cor}}
 if(tipo==='run'){const an=rnd(0,6.283),d=R*rnd(1.7,3.2);return {tipo,x:cx+Math.cos(an)*d,y:cy+Math.sin(an)*d*0.8,px:0,py:0,cx,cy,v:rnd(150,330),t:0,vida:5,r:rnd(1,2.6),cor}}
 if(tipo==='scan'){const an=rnd(0,6.283);return {tipo,an,rad:R*rnd(1.02,1.3),w:rnd(.6,1.6),x:cx,y:cy,px:cx,py:cy,cx,cy,t:0,vida:rnd(1.5,3),r:rnd(1,2.2),cor}}
 return {tipo:'flut',x:rnd(0,w),y:rnd(h*.2,h),px:0,py:0,vx:rnd(-6,6),vy:-rnd(10,34),t:0,vida:rnd(3,6.5),r:rnd(.8,2.2),cor}}
function xpIniciar(){if(!XP.raf&&atual==='extremo'&&fx()&&!document.hidden)XP.raf=requestAnimationFrame(xpQuadro)}
document.addEventListener('visibilitychange',xpIniciar);
function xpQuadro(t){
 XP.raf=0;if(atual!=='extremo'||!fx()||document.hidden){XP.ps=[];return}
 XP.raf=requestAnimationFrame(xpQuadro);
 if(t-XP.t<32)return;const dt=Math.min(.07,(t-XP.t)/1000);XP.t=t;
 const cv=$('#xPart'),hero=$('#xHero'),rea=$('#xReator');if(!cv||!hero||!rea)return;
 const w=hero.clientWidth,h=hero.clientHeight,dpr=Math.min(2,devicePixelRatio||1);
 if(cv.width!==Math.round(w*dpr)||cv.height!==Math.round(h*dpr)){cv.width=Math.round(w*dpr);cv.height=Math.round(h*dpr)}
 const c=cv.getContext('2d');c.setTransform(dpr,0,0,dpr,0,0);c.clearRect(0,0,w,h);
 const rr=rea.getBoundingClientRect(),hr=hero.getBoundingClientRect(),cx=rr.left-hr.left+rr.width/2,cy=rr.top-hr.top+rr.height/2,R=rr.width/2;
 const f=X.fase,alvo={run:90,scan:46,done:26,idle:26}[f]||26,tipo={run:'run',scan:'scan'}[f]||'flut';
 let n=XP.ps.filter(p=>p.tipo!=='burst').length;
 while(n<alvo&&XP.ps.length<150){XP.ps.push(novaP(tipo,cx,cy,R,w,h));n++}
 if(XP.burst){XP.burst=false;for(let i=0;i<80;i++)XP.ps.push(novaP('burst',cx,cy,R,w,h))}
 c.globalCompositeOperation='lighter';c.lineCap='round';
 XP.ps=XP.ps.filter(p=>{
  p.t+=dt;p.px=p.x;p.py=p.y;
  if(p.tipo==='run'){const dx=p.cx-p.x,dy=p.cy-p.y,d=Math.hypot(dx,dy)||1;p.x+=dx/d*p.v*dt;p.y+=dy/d*p.v*dt;p.v*=1.012;if(d<R*.62)return false}
  else if(p.tipo==='scan'){p.an+=p.w*dt*(1+p.t*.3);p.x=p.cx+Math.cos(p.an)*p.rad;p.y=p.cy+Math.sin(p.an)*p.rad}
  else if(p.tipo==='burst'){p.x+=p.vx*dt;p.y+=p.vy*dt;p.vx*=.955;p.vy=p.vy*.955+22*dt}
  else{p.x+=p.vx*dt;p.y+=p.vy*dt}
  if(p.t>p.vida)return false;
  const k=p.tipo==='run'?Math.min(1,p.t*3):Math.sin(Math.min(1,p.t/p.vida)*Math.PI);
  c.globalAlpha=Math.max(0,Math.min(1,k))*(p.tipo==='flut'?.55:.9);c.strokeStyle=p.cor;c.fillStyle=p.cor;
  if(p.tipo==='run'||p.tipo==='burst'){c.lineWidth=p.r;c.beginPath();c.moveTo(p.px+(p.px-p.x)*2,p.py+(p.py-p.y)*2);c.lineTo(p.x,p.y);c.stroke()}
  else{c.beginPath();c.arc(p.x,p.y,p.r,0,6.283);c.fill()}
  return true});
 c.globalAlpha=1}

/* ===================================================================
   v8.0: tarefas com passos, Dashboard, Processos, Jogos, Correções, Backup e Ferramentas
   =================================================================== */
const DISM={};
const TRABNOME={ok:'Concluído',pulado:'Concluído com avisos',erro:'Terminou com erro'};
const ocupado=(s)=>!!(s.otim.ativo||s.ext.ativo||s.pre.ativo||s.trab.correcao.ativo||s.trab.processos.ativo);
const REINICIAR=`<div class="linha" style="margin-top:14px"><button class="bt p" data-c="reiniciar_pc" data-ct="Reiniciar o PC agora?" data-cp="Salve o que estiver aberto. O PC reinicia em 20 segundos e você pode cancelar. O reinício termina de aplicar as mudanças.">${ico('ip')}<span>Reiniciar agora</span></button></div>`;
const semAdm=(id,txt)=>{const av=$('#'+id);if(!av)return;
 if(!CATWIN){av.hidden=false;av.innerHTML=ico('info')+'<span>Esta página só funciona no Windows. Aqui você vê apenas uma prévia.</span>'}
 else if(S&&!S.admin){av.hidden=false;av.innerHTML=ico('info')+'<span>'+txt+'</span>'}
 else av.hidden=true};
const NOADM=' Feche e abra o Th Boost pelo atalho da área de trabalho para ter Administrador.';
const dataNum=(t)=>{const m=/(\d+)\/(\d+)\/(\d+)/.exec(t||'');return m?(+m[3])*10000+(+m[2])*100+(+m[1]):0};

/* painel genérico de uma tarefa com passos (correções, backup, processos, espaço) */
function painelTrab(boxId,chave,extra){
 const box=$('#'+boxId);if(!box||!S||!S.trab)return;
 const T=S.trab[chave];
 const mostrar=T.ativo||((T.resumo||T.passos.length)&&DISM[chave]!==T.fim);
 box.hidden=!mostrar;if(!mostrar){box.dataset.s='';return}
 const sig=JSON.stringify([T.ativo,T.parando,Math.round(T.fracao*100),T.passo,T.fim,T.titulo,T.passos.map(p=>p.estado+'|'+p.texto)]);
 if(box.dataset.s===sig)return;box.dataset.s=sig;
 const r=T.resumo;let cab,cls;
 if(T.ativo){cab=T.parando?'Parando...':(T.passo||'Trabalhando...');cls='run'}
 else if(r){cab=r.interrompido?'Interrompido por você':(TRABNOME[r.estado]||'Concluído');cls=r.interrompido?'pulado':r.estado}
 else{cab='';cls=''}
 const ps=T.passos.map(p=>`<div class="ps ${p.estado}"><span class="pi">${ico(p.estado==='pulado'?'traco':(p.estado==='erro'?'x':'check'))}</span><div><b>${esc(p.nome)}</b><small>${esc(p.texto||(p.estado==='rodando'?'Em andamento...':(p.estado==='pendente'?'Aguardando':'')))}</small></div></div>`).join('');
 box.innerHTML=`<div class="jph"><div><h3>${esc(T.titulo)}</h3><b class="jst ${cls}">${esc(cab)}</b></div><div class="linha">${T.ativo?`<button class="bt g" data-act="trab_parar" data-id="${chave}" ${T.parando?'disabled':''}>${T.parando?'Parando...':'Parar'}</button>`:`<button class="bt g" data-act="trab_fechar" data-id="${chave}">Fechar</button>`}</div></div>`+
  `<div class="jbar"><i style="width:${Math.round((T.ativo?T.fracao:1)*100)}%"></i></div><div class="passos jps">${ps}</div>`+
  (!T.ativo&&r?`${extra?extra(r):''}${r.reiniciar?REINICIAR:''}`:'')}

/* barra de sessão de jogo (todas as páginas) */
function pintarSess(s){
 const b=$('#sessB'),x=s.sessao;
 if(!x){b.hidden=true;b.dataset.s='';return}
 const min=Math.floor(x.desde/60),quando=x.aguardando?'esperando o jogo abrir':`há ${min<1?'menos de 1 minuto':min+' min'}`;
 const sig=[x.jogo,x.aguardando,min].join('|');if(b.dataset.s===sig)return;b.dataset.s=sig;b.hidden=false;
 b.innerHTML=`<i></i><span><b>Sessão de jogo ativa</b>${x.jogo?' · '+esc(x.jogo):''} · ${quando}. Ao terminar, o Th Boost devolve o plano de energia, os serviços e as prioridades ao normal.</span><button class="bt g" data-act="sessao_fim">Terminar sessão</button>`}

/* ===================== PROCESSADOR ===================== */
const CPF={d:null,t:0,busy:false,sig:''};
function entrarCpf(){CPF.t=0;CPF.sig='';carregarCpf()}
async function carregarCpf(){
 if(CPF.busy)return;CPF.busy=true;
 try{CPF.d=await pegar('cpu_perfil');CPF.t=Date.now();pintarCpf()}catch(e){CPF.t=Date.now()}
 CPF.busy=false}
const CPF_TURBO={0:'Desligado',1:'Ligado',2:'Agressivo',3:'Eficiente',4:'Eficiente agressivo',5:'Agressivo garantido',6:'Eficiente garantido'};
function cpfFmt(k,v){if(v==null)return '—';if(k==='turbo')return CPF_TURBO[v]||String(v);if(k==='ventoinha')return v?'Ativa':'Passiva';return v+'%'}
function pintarCpf(){
 const d=CPF.d;if(!d||atual!=='cpu')return;
 const sig=JSON.stringify([d,S&&S.admin]);if(CPF.sig===sig)return;CPF.sig=sig;
 semAdm('cpAdm','Sem Administrador, os perfis não conseguem mudar o plano de energia.'+NOADM);
 if(!d.windows){$('#cpHero').innerHTML=vazio('info','Só no Windows','Os perfis de desempenho da CPU mudam o plano de energia do Windows.');$('#cpPerfis').innerHTML='';$('#cpAgora').innerHTML='';$('#cpBios').innerHTML='';return}
 const nomes={padrao:'Padrão do Windows',desempenho:'Desempenho',maximo:'Máximo',fresco:'Fresco (página Resfriamento)',gelado:'Gelado (página Resfriamento)'};
 const chip=t=>`<span class="chip on" style="cursor:default">${esc(t)}</span>`;
 const resumo=d.atual==='padrao'?`Hoje o processador usa o comportamento normal do plano de energia “${esc(d.plano||'ativo')}”. Escolha um perfil abaixo para liberar mais desempenho. Dá para voltar ao padrão a qualquer momento.`
  :(d.aplicado?`O perfil “${nomes[d.atual]}” está ligado pelo Th Boost. Para desfazer, escolha Padrão do Windows.`:`O plano “${esc(d.plano||'ativo')}” já está parecido com o perfil “${nomes[d.atual]}” (não foi o Th Boost que mudou).`);
 $('#cpHero').innerHTML=`<div><h3 class="mmk">SEU PROCESSADOR</h3><h2 style="font-size:30px;line-height:1.15">${esc(d.cpu||'Processador')}</h2>
  <div class="chips" style="margin:10px 0 12px">${d.fisicos?chip(d.fisicos+' núcleos · '+d.logicos+' threads'):chip(d.logicos+' threads')}${d.mhz?chip('Agora '+d.mhz+' MHz'):''}${d.mhz_max?chip('Máx. '+d.mhz_max+' MHz'):''}${chip('Perfil: '+nomes[d.atual])}</div>
  <p class="sub2">${resumo}</p></div>`;
 $('#cpPerfis').innerHTML=d.perfis.map(p=>{const at=d.atual===p.id,vazioP=p.id==='padrao'&&!d.guardado;
  const bt=at?`<button class="bt" disabled>Perfil atual</button>`:(p.id==='padrao'&&!d.guardado?`<button class="bt" disabled>Já está no padrão</button>`:`<button class="bt ${p.id==='padrao'?'':'p'}" data-act="cp_perfil" data-id="${p.id}" ${S&&S.admin?'':'disabled'}>${p.id==='padrao'?'Voltar ao padrão':'Usar este perfil'}</button>`);
  return `<div class="cd cpc ${at?'sel':''}"><span class="tg">${at?'ATIVO':esc(p.tag)}</span><h3>${esc(p.titulo)}</h3><p>${esc(p.texto)}</p><ul>${p.itens.map(i=>`<li>${esc(i)}</li>`).join('')}</ul>${bt}</div>`}).join('');
 $('#cpAgora').innerHTML=`<h3>Como está agora (na tomada)</h3><p class="sub2" style="margin:0 0 6px">Plano de energia: <b>${esc(d.plano||'—')}</b>. Em notebook, na bateria nada muda.</p>`+Object.keys(d.rotulos).map(k=>`<div class="cpv"><span>${esc(d.rotulos[k])}</span><b>${esc(cpfFmt(k,d.valores[k]))}</b></div>`).join('');
 $('#cpBios').innerHTML=`<h3>E o overclock de verdade da CPU?</h3><p>O clock fixo (multiplicador) do processador só pode ser mudado na <b>BIOS</b> da placa-mãe, e só em processadores destravados (Intel com final K, AMD Ryzen). Nenhum programa do Windows faz isso com segurança, por isso o Th Boost não mexe nisso: os perfis ao lado mudam como o Windows usa o processador (turbo, núcleos e velocidade), sem gravar nada na BIOS.</p>
  <p class="sub2" style="margin:12px 0 0">Se for mexer na BIOS por conta própria, vá em passos pequenos e acompanhe a temperatura. Se o PC não ligar, entre na BIOS de novo e volte para <b>Auto</b> (ou limpe a CMOS). A página Memória RAM tem o botão que reinicia direto na BIOS.</p>`}


/* ===================== RESFRIAMENTO (v8.8) ===================== */
const RF={d:null,t:0,busy:false,sig:'',sel:null};
const RF_ORD=['padrao','fresco','gelado'];
function entrarRf(){RF.t=0;RF.sig='';RF.sel=null;carregarRf()}
async function carregarRf(){
 if(RF.busy)return;RF.busy=true;
 try{RF.d=await pegar('cpu_perfil');RF.t=Date.now();pintarRf(S)}catch(e){RF.t=Date.now()}
 RF.busy=false}
function rfZona(t){return t==null?null:(t<70?['rf-ok','tranquila']:(t<85?['rf-qt','quente']:['rf-mq','muito quente']))}
function rfCard(p,i){
 if(!p)return '';
 return `<span class="tg">${esc(p.tag)}</span><h3>${esc(p.titulo)}</h3><p>${esc(p.texto)}</p><ul>${p.itens.map(x=>`<li>${esc(x)}</li>`).join('')}</ul>`}
function rfAgora(s){
 const d=RF.d;if(!d||!d.windows)return;
 const tc=s&&s.tcpu!=null?s.tcpu:null,tg=s&&s.tgpu!=null?s.tgpu:null,tz=tc==null&&d.temp!=null?d.temp:null,t=tc!=null?tc:tz;
 const z=rfZona(t),lin=(a,b)=>`<div class="cpv"><span>${a}</span><b>${b}</b></div>`,nomes={padrao:'Normal',fresco:'Fresco',gelado:'Gelado',desempenho:'Desempenho (página Processador)',maximo:'Máximo (página Processador)'};
 const zg=rfZona(tg);
 let h='<h3>Como está agora</h3>';
 h+=lin('Temperatura do processador',t!=null?`<span class="${z[0]}">${tc!=null?Math.round(tc):'≈ '+tz} °C · ${z[1]}</span>`:'Indisponível');
 if(tg!=null)h+=lin('Temperatura da placa de vídeo',`<span class="${zg[0]}">${Math.round(tg)} °C · ${zg[1]}</span>`);
 h+=lin('Uso do processador',s&&s.cpu!=null?Math.round(s.cpu)+'%':(d.uso!=null?d.uso+'%':'—'));
 h+=lin('Velocidade agora',d.mhz?d.mhz+' MHz':'—');
 h+=lin('Nível de resfriamento',nomes[d.atual]||'—');
 if(tz!=null)h+='<p class="rf-aviso">Temperatura aproximada, lida da zona térmica que o Windows informa. Em alguns computadores esse número acompanha o processador; em outros fica parado.</p>';
 else if(t==null)h+='<p class="rf-aviso">O Windows nem sempre informa a temperatura. Abrir o Th Boost como Administrador ajuda, mas alguns computadores simplesmente não mostram.</p>';
 else if(t>=85)h+='<p class="rf-av">Está muito quente. Escolha o nível Fresco ou Gelado, feche programas pesados e deixe as saídas de ar livres.</p>';
 const el=$('#rfAgora');if(el.dataset.h!==h){el.dataset.h=h;el.innerHTML=h}}
function pintarRf(s){
 const d=RF.d;if(!d||atual!=='resfriamento')return;
 if(!d.windows){$('#rfHero').innerHTML=vazio('info','Só no Windows','O resfriamento muda o plano de energia do Windows. Aqui você vê apenas uma prévia.');$('#rfBarra').innerHTML='';$('#rfAgora').innerHTML='';$('#rfDicas').innerHTML='';return}
 if(RF.sel!=null&&RF_ORD[RF.sel]===d.atual)RF.sel=null;
 const idx=RF.sel!=null?RF.sel:Math.max(0,RF_ORD.indexOf(d.atual));
 semAdm('rfAdm','Sem Administrador, a barra não consegue mudar o plano de energia.'+NOADM);
 const sig=JSON.stringify([d.atual,d.aplicado,d.guardado,d.plano,S&&S.admin,d.cpu]);
 if(sig!==RF.sig){RF.sig=sig;
  const fr=d.frios||[],atNome={padrao:'Normal',fresco:'Fresco',gelado:'Gelado',desempenho:'Desempenho',maximo:'Máximo'}[d.atual]||d.atual;
  const aviso=(d.atual==='desempenho'||d.atual==='maximo')?` O processador está no perfil “${atNome}”, da página Processador. Escolher um nível aqui troca esse perfil.`:'';
  $('#rfHero').innerHTML=`<div><h3 class="mmk">ESFRIAR O PC OU O NOTEBOOK</h3><h2 style="font-size:30px;line-height:1.15">${esc(d.cpu||'Seu computador')}</h2>
   <div class="chips" style="margin:10px 0 12px"><span class="chip on" style="cursor:default">Nível: ${esc(atNome)}</span>${d.fisicos?`<span class="chip on" style="cursor:default">${d.fisicos} núcleos · ${d.logicos} threads</span>`:''}</div>
   <p class="sub2">Esta barra faz o processador gerar menos calor: ele não passa de uma velocidade máxima e o turbo (a velocidade extra, que é o que mais esquenta) fica desligado. O Windows aumenta a ventoinha sozinho antes de reduzir a velocidade.${esc(aviso)}</p></div>`;
  const mudou=RF_ORD[idx]!==d.atual,adm=!!(S&&S.admin);
  $('#rfBarra').innerHTML=`<div class="rf-t"><h2>Barra de resfriamento</h2><span class="sub2">Arraste e depois aperte Aplicar</span></div>
   <div><input type="range" id="rfRg" min="0" max="2" step="1" value="${idx}" ${adm?'':'disabled'} aria-label="Nível de resfriamento" style="--p:${idx*50}%"><div class="rf-pe" id="rfPe"><span class="${idx===0?'on':''}">Normal</span><span class="${idx===1?'on':''}">Fresco</span><span class="${idx===2?'on':''}">Gelado</span></div></div>
   <div class="rf-card" id="rfCard">${rfCard(fr.find(p=>p.id===RF_ORD[idx]))}</div>
   <div class="linha"><button class="bt p" id="rfAplicar" type="button" ${adm&&mudou?'':'disabled'}>${mudou?(idx===0?'Voltar ao Normal':'Aplicar este nível'):'Nível em uso'}</button></div>`;
  const dicas=[
   'Notebook: apoie numa base com ventoinhas (cooler) ou deixe levantado numa superfície dura. Cama, sofá e colo tapam as entradas de ar e esquentam muito.',
   'Limpe a poeira das saídas de ar e das ventoinhas, com o PC desligado. Poeira acumulada é a causa mais comum de superaquecimento.',
   'Se esquenta muito mesmo limpo e já tem alguns anos, a pasta térmica pode estar seca: uma assistência técnica troca.',
   'Nos jogos, limite o FPS (60, por exemplo): o processador e a placa de vídeo trabalham menos e esquentam menos.'];
  $('#rfDicas').innerHTML=`<h3>Para esfriar de verdade</h3><div class="rf-dicas">${dicas.map(t=>`<div class="rf-dica"><span>${esc(t)}</span></div>`).join('')}<div class="rf-dica"><span>Feche o que está pesando no segundo plano: menos programas rodando, menos calor.</span><button class="bt" type="button" data-ir="processos">Ver processos</button></div></div>
   <p class="rf-aviso">O Th Boost não liga nem controla a ventoinha (isso é do Windows e do fabricante do aparelho). Ele diminui o calor que o processador produz. Vale na tomada; na bateria nada muda.</p>`}
 rfAgora(s)}
document.addEventListener('input',e=>{
 if(e.target.id!=='rfRg')return;
 const d=RF.d;if(!d)return;const i=+e.target.value,fr=d.frios||[];RF.sel=i;
 e.target.style.setProperty('--p',(i*50)+'%');
 $$('#rfPe span').forEach((x,k)=>x.classList.toggle('on',k===i));
 $('#rfCard').innerHTML=rfCard(fr.find(p=>p.id===RF_ORD[i]));
 const mudou=RF_ORD[i]!==d.atual,b=$('#rfAplicar');b.disabled=!mudou||!(S&&S.admin);b.textContent=mudou?(i===0?'Voltar ao Normal':'Aplicar este nível'):'Nível em uso'});
document.addEventListener('click',e=>{
 const b=e.target.closest('#rfAplicar');if(!b||b.disabled)return;
 const d=RF.d;if(!d||RF.sel==null)return;const id=RF_ORD[RF.sel];
 const ir=()=>{acao('cpu_perfil',{perfil:id});[2200,5000].forEach(t=>setTimeout(()=>{RF.sig='';CPF.sig='';RF.t=0;carregarRf()},t))};
 if(id==='gelado')confirmar('Usar o nível Gelado?','O processador não passa de 70% e fica sem turbo. Esfria bastante, mas o PC fica mais lento em tarefas pesadas e em jogos. Para desfazer, volte a barra para Normal.',ir);
 else ir()});

/* ===================== MEMÓRIA RAM ===================== */
const MM={d:null,t:0,busy:false,sig:'',pend:0};
function entrarMemoria(){MM.t=0;MM.sig='';carregarMem(true)}
async function carregarMem(forcar){
 if(MM.busy)return;MM.busy=true;
 try{if(forcar)await acao('memoria_ler');MM.d=await pegar('memoria');MM.t=Date.now();pintarMem()}catch(e){MM.t=Date.now()}
 MM.busy=false}
function pintarMem(){
 const r=MM.d;if(!r||atual!=='memoria')return;
 if(MM.pend&&Date.now()>MM.pend){MM.pend=0;MM.sig=''}
 const sig=JSON.stringify([r.estado,r.dados,r.admin,MM.pend>0]);if(MM.sig===sig)return;MM.sig=sig;
 semAdm('mmAdm','Sem Administrador, o botão que reinicia direto na BIOS não funciona. O resto da página funciona.'+NOADM);
 const d=r.dados;
 if(!d){
  const txt=r.estado==='lendo'||r.estado==='nenhum'?'<div class="sk fino"></div>':vazio('info','Não consegui ler a memória','Este PC não respondeu à leitura dos pentes de memória. Tente de novo em instantes.');
  $('#mmHero').innerHTML=txt;$('#mmAch').innerHTML='<h3>Diagnóstico</h3>'+txt;$('#mmGuia').innerHTML='';$('#mmPentes').innerHTML='';$('#mmFaz').innerHTML='';return}
 const chip=(t,c)=>`<span class="chip on ${c||''}" style="cursor:default">${esc(t)}</span>`;
 const resumo=d.abaixo?`Está abaixo do que o kit entrega (${d.vel_kit} MHz). Ativar o perfil ${esc(d.perfil)} na BIOS libera o resto, sem custo.`:(d.canal==='unico'?'Funciona, mas com 1 pente só (canal único). Um segundo pente igual deixaria a memória bem mais rápida em jogos.':(d.canal==='mesmo'?'Os pentes parecem estar no mesmo canal. Veja no manual da placa-mãe quais slots usar para o canal duplo (geralmente o 2º e o 4º, contando a partir do processador).':'A memória está na velocidade do kit. Não há ajuste de velocidade pendente.'));
 const pentes=d.modulos.map(m=>`<div class="mms"><div><b>${m.gb} GB</b><small>${esc(m.tipo||'')} ${m.mhz_atual||m.mhz_spd||'?'} MHz</small></div><small>${esc(m.slot||'')}</small></div>`).join('');
 $('#mmHero').innerHTML=`<div><h3 class="mmk">SUA MEMÓRIA RAM</h3><h2>${d.total_gb} GB<small>${esc(d.tipo||'')}${d.vel_atual?' · '+d.vel_atual+' MHz':''}</small></h2><p class="sub2">${resumo}</p>
  <div class="chips" style="margin:10px 0 14px">${chip(d.canal==='duplo'?'Canal duplo':(d.canal==='provavel'?'Canal duplo (provável)':(d.canal==='unico'?'Canal único':(d.canal==='mesmo'?'Mesmo canal':'Canal ?'))),(d.canal==='unico'||d.canal==='mesmo')?'am':'')}${d.vel_kit?chip('Kit de '+d.vel_kit+' MHz'):''}${d.slots?chip(d.modulos.length+' de '+d.slots+' slots'):''}${d.placa?chip(d.placa):''}</div>
  <div class="linha"><button class="bt p" data-act="mm_atualizar">${ico('ip')}<span>Ler de novo</span></button><button class="bt" data-act="mm_testar">Testar a memória</button><button class="bt" data-a="ram">Liberar a RAM agora</button></div></div><div class="mmp">${pentes}</div>`;
 $('#mmAch').innerHTML='<h3>Diagnóstico</h3>'+d.achados.map(a=>`<div class="ac ${a.nivel}"><span class="pt"></span><div><b>${esc(a.titulo)}</b><span>${esc(a.texto)}</span></div></div>`).join('');
 const bios=MM.pend>Date.now();
 $('#mmGuia').innerHTML=`<h3>Ativar o perfil de velocidade (${esc(d.perfil)})</h3><p>O clock da memória só pode ser mudado na <b>BIOS</b> da placa-mãe: programas do Windows não conseguem mudar isso com segurança, por isso o Th Boost leva você até lá. É o perfil que o próprio fabricante da memória garante, não um overclock manual.</p>
  <ol class="mmo"><li><span>Salve o que estiver aberto e clique em <b>Reiniciar e abrir a BIOS</b>. Se não funcionar, reinicie o PC e aperte <b>${esc(d.tecla)}</b> várias vezes assim que ele ligar.</span></li>
  <li><span>Procure a opção <b>${esc(d.perfil)}</b> (costuma ficar em “Ai Tweaker”, “Extreme Tweaker”, “OC”, “Overclocking” ou “Memory”).</span></li>
  <li><span>Escolha o <b>Perfil 1</b> (Profile 1), salve e saia (normalmente F10).</span></li>
  <li><span>Quando o Windows abrir, volte aqui e aperte <b>Ler de novo</b>: a velocidade deve ter subido.</span></li></ol>
  <div class="linha" style="margin-top:14px"><button class="bt p" data-act="mm_bios" ${CATWIN&&S&&S.admin?'':'disabled'}>${ico('ip')}<span>Reiniciar e abrir a BIOS</span></button>${bios?'<button class="bt" data-act="mm_cancelar">Cancelar o reinício</button>':''}</div>
  <p class="sub2" style="margin:12px 0 0">Se o PC não ligar ou der tela azul depois, entre na BIOS de novo e volte para <b>Auto</b> (ou limpe a CMOS). ${d.notebook?'Em notebook a BIOS quase nunca mostra essa opção.':''}</p>`;
 $('#mmPentes').innerHTML='<h3>Pentes de memória</h3>'+d.modulos.map(m=>`<div class="pt-l"><div><b>${m.gb} GB ${esc(m.tipo||'')} · ${esc(m.slot||'')}</b><small>${esc([m.fab,m.peca].filter(Boolean).join(' · ')||'sem detalhes do fabricante')}</small></div><time>${m.mhz_atual||m.mhz_spd||'?'}${m.mhz_spd&&m.mhz_atual&&m.mhz_spd>m.mhz_atual?' / '+m.mhz_spd:''} MHz</time></div>`).join('')+'<p class="sub2" style="margin:10px 0 0">Velocidade atual / velocidade do kit. Os MHz são os mesmos escritos na caixa da memória.</p>';
 $('#mmFaz').innerHTML=`<h3>O que o Th Boost já faz pela memória</h3>
  <div class="xo"><div><b>Liberar a RAM</b><small>Só age quando a memória está apertada (menos de 25% livre): esvazia programas parados em segundo plano, nunca o jogo nem o que você está usando.</small></div><button class="bt g" data-a="ram">Liberar</button></div>
  <div class="xo"><div><b>Reduzir processos</b><small>Fecha ajudantes e junta os serviços do Windows em menos processos: menos memória ocupada à toa.</small></div><button class="bt g" data-ir="processos">Abrir</button></div>
  <div class="xo"><div><b>Otimizar antes de jogar</b><small>Libera a RAM e fecha o que pesa antes do jogo abrir.</small></div><button class="bt g" data-ir="jogos">Abrir</button></div>
  <div class="xo"><div><b>Otimização Suprema</b><small>Com 16 GB ou mais, desliga a compressão de memória do Windows (ganha processador).</small></div><button class="bt g" data-ir="extremo">Abrir</button></div>`}

/* ===================== DASHBOARD ===================== */
const DASH={d:null,t:0,busy:false};
const NOTAS=[[85,'Excelente','Seu PC está muito bem ajustado. Continue assim.'],[65,'Bom','Está bom, mas ainda dá para ganhar desempenho. Veja a lista abaixo.'],[40,'Pode melhorar','Há pontos fáceis de melhorar. Comece pelo que aparece na lista abaixo.'],[0,'Precisa de atenção','Seu PC está longe do que poderia ser. Comece pelo que aparece em vermelho.']];
const TIPOS={normal:'Otimizar tudo',extrema:'Otimização Extrema',suprema:'Otimização Suprema'};
const corNota=(v)=>v==null?'sc-nd':v>=80?'sc-bom':v>=55?'sc-ok':v>=35?'sc-med':'sc-ruim';
async function carregarDash(){
 if(DASH.busy)return;DASH.busy=true;
 try{DASH.d=await pegar('dashboard');DASH.t=Date.now();pintarDash()}catch(e){DASH.t=Date.now()-10000}
 DASH.busy=false;
 if(DASH.d&&DASH.d.lendo&&atual==='dashboard')setTimeout(carregarDash,3000)}
function pintarDash(){
 const d=DASH.d;if(!d||atual!=='dashboard')return;
 const sc=d.score,nt=sc==null?null:NOTAS.find(n=>sc>=n[0]);
 $('#dHero').className='cd led dh '+corNota(sc);
 anel('vlDash','nDash',sc,'--');
 $('#dTit').textContent=nt?nt[1]:'Lendo o seu PC...';$('#dTxt').textContent=nt?nt[2]:'Estou medindo desempenho, inicialização, espaço, memória, energia, processos, jogos e segurança dos dados.';
 $('#dLendo').hidden=!d.lendo;
 const st=d.stats||{},tot=(st.otimizacoes||0)+(st.extremas||0)+(st.supremas||0);
 $('#dStats').innerHTML=[[fmtMB(st.mb||0),'de lixo apagado no total'],[String(tot),'otimizações feitas'],[String(st.procs||0),'processos fechados'],[String(st.correcoes||0),'correções feitas']].map(x=>`<div class="st1"><b>${x[0]}</b><span>${x[1]}</span></div>`).join('')+
  (st.ultima?`<div class="st1" style="grid-column:1/-1"><b style="font-size:15px">${esc(st.ultima)}</b><span>última otimização${TIPOS[st.ultima_tipo]?' ('+TIPOS[st.ultima_tipo]+')':''}</span></div>`:'');
 const sigC=JSON.stringify(d.categorias);const cb=$('#dCats');
 if(cb.dataset.s!==sigC){cb.dataset.s=sigC;
  cb.innerHTML=d.categorias.map(c=>`<button class="ctg ${corNota(c.valor)}" data-ir="${esc(c.ir)}"><div class="tp"><b>${esc(c.nome)}</b><span class="vn">${c.valor==null?'--':c.valor}</span></div><div class="tr"><i data-w="${c.valor||0}"></i></div><small>${esc(c.dica)}</small></button>`).join('');
  requestAnimationFrame(()=>requestAnimationFrame(()=>$$('#dCats .tr i').forEach(i=>{i.style.width=i.dataset.w+'%'})))}
 const ach=$('#aaddddh'),sigA=JSON.stringify(d.achados);
 if(ach.dataset.s!==sigA){ach.dataset.s=sigA;
  ach.innerHTML=d.achados.length?d.achados.map(a=>`<div class="ac ${a.nivel}"><span class="pt"></span><div><b>${esc(a.titulo)}</b><span>${esc(a.texto)}</span></div>${a.rotulo?(a.ir?`<button class="bt g" data-ir="${esc(a.ir)}">${esc(a.rotulo)}</button>`:(a.acao?`<button class="bt g" data-a="${esc(a.acao)}">${esc(a.rotulo)}</button>`:'')):''}</div>`).join(''):
   `<div class="vz" style="padding:26px"><div class="ic">${ico('check')}</div><b>Nada urgente</b><span>Não achei nenhum problema agora. Volte aqui de vez em quando.</span></div>`}
 const sy=d.sistema||{},lig=sy.ligado_h;
 $('#dSis').innerHTML=[['Processador',sy.cpu||'--'],['Núcleos lógicos',sy.nucleos||'--'],['Memória RAM',sy.ram_gb?sy.ram_gb+' GB':'--'],['Placa de vídeo',sy.gpu||'--'],
  ['Monitor',sy.monitor?`${sy.monitor.res} · ${sy.monitor.hz} Hz`+(sy.monitor.hz_max>sy.monitor.hz+5?` (aceita ${sy.monitor.hz_max} Hz)`:''):'--'],['Plano de energia',sy.plano||'--'],['Processos rodando',sy.processos||'--'],
  ['Ligado há',lig?(lig>=48?Math.round(lig/24)+' dias':Math.round(lig)+' h'):'--']].map(r=>`<div><span>${r[0]}</span><b><span style="color:inherit;max-width:260px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">${esc(r[1])}</span></b></div>`).join('')}

/* ===================== PROCESSOS ===================== */
const PR={d:null,t:0,busy:false,filtro:'todos',s3:null,s3t:0,fim:-1,sigL:'',sigO:'',sigS:'',forcar:false};
const CPUS={pct:null,ate:0};/* a barrinha de CPU: valor que a pessoa escolheu, mantido por alguns segundos até o programa confirmar */
const PRO={raros:null,svchost:null,launchers:null,chats:null};/* null = ainda não escolheu: começa com o padrão abaixo (ligado derruba o número de processos; chats começa desligado porque pode ter uma chamada de voz aberta) */
const PRO_PADRAO={raros:true,svchost:true,launchers:true,chats:false};
try{const o=JSON.parse(localStorage.getItem('thboost-proc')||'{}');for(const k of Object.keys(PRO))if(typeof o[k]==='boolean')PRO[k]=o[k]}catch(e){}
const proOn=k=>PRO[k]===null?PRO_PADRAO[k]:PRO[k];
const CATP={dispensavel:['Ajudante do Windows','am'],atualizador:['Atualizador','az'],launcher:['Launcher de jogos','vl2'],chat:['Chat e reunião','vl2'],nuvem:['Nuvem','az'],outro:['Programa','cz'],windows:['Windows','cz'],seguranca:['Proteção','vd'],hardware:['Driver / hardware','cz'],navegador:['Navegador','cz'],eu:['Th Boost','cz']};
const CATBAR=[['windows','Windows'],['outro','Programas'],['navegador','Navegadores'],['hardware','Drivers e hardware'],['seguranca','Proteção do PC'],['launcher','Launchers de jogos'],['chat','Chat e reuniões'],['nuvem','Nuvem'],['atualizador','Atualizadores'],['dispensavel','Ajudantes dispensáveis'],['eu','Th Boost']];
const FILTROS=[['todos','Todos'],['fecha','Posso fechar'],['aux','Ajudantes e atualizadores'],['trava','Travados']];
function entrarProc(){PR.t=0;PR.s3t=0;PR.sigL='';carregarProc();carregarSvc3()}
async function carregarProc(){
 if(PR.busy)return;PR.busy=true;
 try{PR.d=await pegar('processos');PR.t=Date.now();const f=PR.forcar;PR.forcar=false;pintarProc(f)}catch(e){PR.t=Date.now()}
 PR.busy=false}
async function carregarSvc3(){
 try{PR.s3=await pegar('svc3');PR.s3t=Date.now();pintarSvc3()}catch(e){PR.s3t=Date.now()}}
function pintarProcTick(s){
 if(Date.now()-PR.t>4000)carregarProc();
 if(Date.now()-PR.s3t>20000)carregarSvc3();
 const T=s.trab.processos;
 if(PR.fim!==T.fim){const antes=PR.fim;PR.fim=T.fim;if(antes>=0||T.fim>0){PR.t=0;PR.s3t=0;PR.sigL='';PR.sigO='';PR.forcar=true}}
 pintarProc(false)}
/* resultado de verdade: quantos processos havia na primeira vez e quantos tem agora (vale também depois de reiniciar) */
function pintarBase(d){
 const b=d.base,m=$('#prBase');if(!m)return;
 if(!b){m.hidden=true;m.dataset.s='';return}
 const junto=d.svchost_junto===true,falta=junto&&!b.reiniciou,dif=b.n-d.total;
 let t=dif>0?`Resultado até agora: você tinha <b>${b.n}</b> processos na primeira vez; hoje tem <b>${d.total}</b> (<b>−${dif}</b>).`:`Na primeira vez você tinha <b>${b.n}</b> processos; hoje tem <b>${d.total}</b>.`;
 if(falta)t+=' <b>Falta reiniciar o PC:</b> é só depois do reinício que o Windows passa a juntar os serviços em menos processos, e aí o número cai de verdade.';
 else if(junto&&b.reiniciou&&dif<=0)t+=' O PC já reiniciou; o que ficou aberto foram programas seus. Feche o que não usa e use “Reduzir processos” de novo.';
 const sig=t+'|'+falta;if(m.dataset.s!==sig){m.dataset.s=sig;m.innerHTML=`<p>${t}</p>${falta?REINICIAR:''}`}
 m.hidden=false}
/* a barrinha de CPU dos programas em segundo plano */
function cpuFill(r){r.style.setProperty('--p',((r.value-r.min)/(r.max-r.min)*100)+'%')}
function pintarCpu(d,busy){
 const c=d.cpu,el=$('#prCpu');if(!el)return;
 if(!c){el.hidden=true;return}
 el.hidden=false;
 if(!el.dataset.ok){el.dataset.ok='1';
  el.innerHTML=`<div class="cpuh"><div><h3>Limite de CPU dos programas em segundo plano</h3><p class="sub2">Escolha até quanto da CPU o navegador, a nuvem, os atualizadores e os ajudantes dispensáveis que ficam abertos <b>em segundo plano</b> podem usar, <b>todos juntos</b>. É um limite do próprio Windows: o número que você escolhe é o máximo, e o resto da CPU sobra para o jogo e para o que você está usando.</p></div><button class="sw" id="cpuSw" data-act="cpu_sw" aria-pressed="false" aria-label="Ligar o limite de CPU"><i></i></button></div>
  <div class="cpur"><div class="cpuv"><b id="cpuV">40%</b><small>da CPU, no máximo</small></div><div class="cpub"><input type="range" id="cpuR" min="${c.min}" max="${c.max}" step="5" value="${c.pct}" aria-label="Limite de CPU dos programas em segundo plano"><div class="cpue"><span>${c.min}% · limite forte</span><span>${c.max}% · limite fraco</span></div></div></div>
  <p class="sub2" id="cpuInfo" style="margin:12px 0 0"></p>
  <p class="sub2" style="margin:8px 0 0">Ficam sempre de fora: o programa que você está usando, jogos, launchers de jogos (e tudo o que eles abrem), Windows, antivírus, drivers, chat e reuniões. Se algo em segundo plano estiver baixando ou convertendo, vai demorar mais. Dá para desligar quando quiser; ao fechar o Th Boost o limite também sai.</p>`}
 const r=$('#cpuR'),sw=$('#cpuSw'),alvo=(CPUS.pct!=null&&Date.now()<CPUS.ate)?CPUS.pct:c.pct;
 if(document.activeElement!==r)r.value=alvo;
 cpuFill(r);$('#cpuV').textContent=r.value+'%';
 sw.classList.toggle('on',!!c.ligado);sw.setAttribute('aria-pressed',String(!!c.ligado));
 const off=!c.disponivel||!CATWIN;sw.disabled=off;r.disabled=off;
 let t;
 if(!c.disponivel)t='O limite de CPU precisa do Windows 8 ou mais novo.';
 else if(!c.ligado)t='Desligado. Ligue para limitar o que está em segundo plano e deixar a CPU livre para o jogo.';
 else{
  const q=(c.nomes||[]).map(x=>`${esc(x.nome)}${x.qtd>1?' ×'+x.qtd:''}`).join(', ');
  t=c.n?`Limitando <b>${c.n}</b> processo(s)${q?`: ${q}`:''}.${c.uso!=null?` Eles usam <b>${c.uso}%</b> da CPU agora (limite ${c.pct}%).`:''}`:'Ligado. Não há nada em segundo plano para limitar agora; o que abrir depois entra sozinho.';
  if(c.liberado)t+=' <b>Você está usando um deles agora, então o limite fica em pausa até você trocar de janela.</b>';
  if(c.falhas)t+=` ${c.falhas} processo(s) são protegidos pelo próprio programa e não aceitam limite; ficaram só com prioridade baixa.`;
  if(c.erro)t+=' '+esc(c.erro)}
 const i=$('#cpuInfo');if(i.dataset.s!==t){i.dataset.s=t;i.innerHTML=t}}
function pintarProc(forcar){
 const d=PR.d;if(!d||!S||atual!=='processos')return;
 semAdm('prAdm','Sem Administrador, o Reduzir processos fecha ajudantes e apps, mas <b>não consegue desligar serviços do Windows</b>.'+NOADM);
 tween($('#prN'),d.total,inteiro);$('#prMb').textContent=fmtMB(d.mb)+' de memória';
 const dp=d.dispensaveis||{qtd:0,mb:0};
 const op0=d.opcionais||{},opN=(proOn('launchers')?(op0.launchers||{qtd:0}).qtd:0)+(proOn('chats')?(op0.chats||{qtd:0}).qtd:0);
 $('#prSub').textContent=(dp.qtd||opN)?`${dp.qtd+opN} processo(s) de ajudantes, atualizadores${opN?', launchers, nuvem ou chats':''} estão abertos agora e o botão fecha. Ele também desliga serviços que pesam e apps em segundo plano.`:'Nenhum ajudante nem launcher aberto agora. O botão ainda desliga serviços que pesam e apps em segundo plano. Quanto menos processos, menos memória e processador ocupados à toa.';
 /* meta: quanto deve cair (hoje e depois de reiniciar) */
 {const sv=d.svchost||0,junto=d.svchost_junto===true,eco=(!junto&&proOn('svchost')&&S.admin&&(d.ram_gb||0)>=3.6&&(d.win_build==null||d.win_build>=15063))?Math.max(0,sv-14):0,est=Math.max(1,d.total-dp.qtd-opN-eco),m=$('#prMeta');
  m.hidden=!(est<d.total);
  if(!m.hidden){const t=`Meta: depois de reduzir e <b>reiniciar</b>, cerca de <b>${est}</b> processos (hoje ${d.total}). ${sv?`${sv} deles são “Host de Serviço” do Windows (svchost.exe)`:''}${eco?`; juntando eles em menos processos, o Windows mostra uns ${eco} a menos.`:'.'} É uma estimativa: depende dos programas que você deixar abertos.`;if(m.dataset.s!==t){m.dataset.s=t;m.innerHTML=t}}}
 const busy=ocupado(S),go=$('#prGo');go.disabled=busy||!CATWIN;go.querySelector('span').textContent=S.trab.processos.ativo?'Reduzindo...':'Reduzir processos';
 const des=$('#prDes');des.hidden=!(d.ids_ligados&&d.ids_ligados.length);des.disabled=busy||!CATWIN;
 painelTrab('prJob','processos',r=>{const x=r.dados||{};if(x.antes_n==null||x.depois_n==null)return '';
  return `<div class="jres ant"><div class="gr2">${x.antes_n}<small>processos antes</small></div><span>→</span><div class="gr2 sa">${x.depois_n}<small>processos agora</small></div><div class="gr2">${fmtMB(x.antes_mb)} → ${fmtMB(x.depois_mb)}<small>memória usada pelos processos</small></div></div>${x.depois_reiniciar!=null&&x.depois_reiniciar<x.depois_n?`<p class="sub2" style="margin:10px 0 0">Depois de <b>reiniciar o PC</b>, a estimativa é cair para cerca de <b>${x.depois_reiniciar}</b> processos (os serviços do Windows passam a dividir menos processos).</p>`:(x.reiniciar?'<p class="sub2" style="margin:10px 0 0">Os serviços e processos por usuário só somem de vez depois de reiniciar o PC.</p>':'')}${(x.fechou&&x.fechou.length)?`<p class="sub2" style="margin:10px 0 0"><b>Fechei:</b> ${x.fechou.map(esc).join(', ')}.</p>`:''}${(x.poupados&&x.poupados.length)?`<p class="sub2" style="margin:6px 0 0"><b>Deixei abertos de propósito:</b> ${x.poupados.map(esc).join('; ')}.</p>`:''}${x.ponto?'<p class="sub2" style="margin:6px 0 0">O “antes” foi contado depois do ponto de restauração do Windows (ele abre alguns processos temporários), para a comparação ser justa.</p>':''}${(x.motivos&&x.motivos.length)?`<div class="mot"><b>${x.depois_n<x.antes_n?'Para cair ainda mais':'Por que o número não caiu'}</b><ul>${x.motivos.map(m=>`<li>${esc(m)}</li>`).join('')}</ul></div>`:''}`});
 pintarBase(d);pintarCpu(d,busy);
 /* categorias */
 const sigC=JSON.stringify(d.por_cat);
 if($('#prCat').dataset.s!==sigC){$('#prCat').dataset.s=sigC;
  const itens=CATBAR.map(c=>[c[1],d.por_cat[c[0]]]).filter(x=>x[1]&&x[1].qtd).sort((a,b)=>b[1].mb-a[1].mb),mx=Math.max(1,...itens.map(x=>x[1].mb));
  $('#prCat').innerHTML='<h3 style="margin:0 0 4px;font-size:11.5px;letter-spacing:.14em;color:oklch(0.8224 calc(0.0870 * var(--tc)) calc(255.07deg + var(--tr)));font-weight:800">ONDE ESTÁ A MEMÓRIA</h3>'+itens.map(x=>`<div class="xb"><span title="${esc(x[0])}">${esc(x[0])}</span><div class="tr"><i style="width:${Math.max(3,x[1].mb/mx*100)}%"></i></div><b>${x[1].qtd} · ${fmtMB(x[1].mb)}</b></div>`).join('')}
 /* opções */
 const sigO=[proOn('raros'),proOn('svchost'),proOn('launchers'),proOn('chats'),busy].join('|');
 if(PR.sigO!==sigO){PR.sigO=sigO;
  const op=(k,t,dsc,rk)=>`<div class="xo"><div><b>${t}${rk?` <span class="rk ${rk[0]}">${rk[1]}</span>`:''}</b><small>${dsc}</small></div><button class="sw ${proOn(k)?'on':''}" data-act="proc_opc" data-id="${k}" aria-pressed="${proOn(k)}" aria-label="${t}"><i></i></button></div>`;
  $('#prOpc').innerHTML=`<h3>O que o botão faz</h3><ul class="xseg" style="grid-template-columns:1fr;margin:8px 0 6px">`+[
   '<b>Cria um ponto de restauração</b> do Windows antes de começar.',
   '<b>Fecha ajudantes e atualizadores</b> que ninguém usa direto (Google Update, Java, Adobe, suporte do fabricante...).',
   '<b>Conta os processos depois do ponto de restauração</b>, para o “antes” e o “agora” serem comparados nas mesmas condições.',
   '<b>Para apps em segundo plano</b> do Windows e <b>desliga serviços que pesam</b> (telemetria, mapas, fax e outros de baixo risco).',
   'Antivírus, drivers, navegadores e o próprio Windows <b>nunca são fechados</b>.'].map(t=>`<li>${ico('check')}<span>${t}</span></li>`).join('')+`</ul><h3 style="margin-top:14px">Extras</h3>`+
   op('launchers','Fechar launchers e nuvem que estão abertos','Steam, Epic, Battle.net, EA, Ubisoft, GOG, Riot Client, OneDrive, Dropbox e parecidos. Cada um costuma ter de 3 a 10 processos. Fica de fora o que você está usando agora e qualquer launcher com jogo aberto. Você abre de novo quando quiser.',['baixo','BAIXO RISCO'])+
   op('chats','Fechar também chats e músicas abertos','Discord, Spotify, Teams, Telegram, WhatsApp, Zoom e parecidos. Começa desligado: se você estiver numa chamada de voz ou reunião, ela cai.',['medio','AVISO'])+
   op('raros','Desligar também serviços que quase ninguém usa','Telefone, carteira digital, registro remoto, sincronização de contatos por usuário e descoberta UPnP. Só somem de vez depois de reiniciar.',['baixo','BAIXO RISCO'])+
   op('svchost','Juntar os serviços do Windows em menos processos','É o que mais derruba o número de processos: faz o Windows agrupar os serviços e reduz a lista de “Host de Serviço” (svchost) no Gerenciador de Tarefas. Só vale depois de reiniciar. Se um serviço travar, pode derrubar outros do mesmo grupo. Dá para desfazer.',['medio','RISCO MÉDIO'])}
 /* serviços */
 const sigS=[d.servicos_rodando,d.servicos_total].join('|');
 if(PR.sigS!==sigS){PR.sigS=sigS;
  $('#prSvc').innerHTML=`<h3>Serviços do Windows</h3><div class="nm">${d.servicos_rodando==null?'--':d.servicos_rodando}${d.servicos_total?`<small> de ${d.servicos_total} em execução</small>`:''}</div><p>Serviços são programas que o Windows mantém rodando por trás. Cada um ocupa memória e processador. Aqui você escolhe um a um quais desligar, com a descrição e o nível de risco de cada.</p><div class="linha" style="margin-top:14px"><button class="bt p g" data-ir="servicos">Escolher serviços</button><button class="bt g" data-ir="inicializacao">Programas da inicialização</button></div>`}
 /* lista de programas rodando */
 const lista=d.grupos.filter(g=>PR.filtro==='todos'||(PR.filtro==='fecha'&&g.fechavel)||(PR.filtro==='aux'&&g.auto&&g.fechavel)||(PR.filtro==='trava'&&!g.fechavel));
 const cnt={todos:d.grupos.length,fecha:d.grupos.filter(g=>g.fechavel).length,aux:d.grupos.filter(g=>g.auto&&g.fechavel).length,trava:d.grupos.filter(g=>!g.fechavel).length};
 $('#prChips').innerHTML=FILTROS.map(f=>`<button class="chip ${PR.filtro===f[0]?'on':''}" data-act="proc_filtro" data-id="${f[0]}">${f[1]}<small>${cnt[f[0]]}</small></button>`).join('');
 const box=$('#prLista'),sig=PR.filtro+'|'+busy+'|'+lista.map(g=>g.nome+g.qtd+Math.round(g.mb/5)).join(',');
 if(PR.sigL===sig)return;
 if(!forcar&&box.matches(':hover')&&box.dataset.ok)return;
 PR.sigL=sig;box.dataset.ok=1;
 box.innerHTML=lista.length?lista.map(g=>{const c=CATP[g.cat]||CATP.outro;
  return `<div class="lr ${g.fechavel?'':'fixo'}"><div><b title="${esc(g.rotulo)}">${esc(g.rotulo)}</b><small>${esc(g.exe)} · ${g.qtd} ${g.qtd===1?'processo':'processos'}</small></div><span class="rk ${c[1]}">${c[0].toUpperCase()}</span><span class="n">${fmtMB(g.mb)}</span>${g.fechavel?`<button class="bt g" data-act="proc_fechar" data-id="${esc(g.nome)}" data-rot="${esc(g.rotulo)}" ${busy||!CATWIN?'disabled':''}>Fechar</button>`:'<span class="rk cz" title="Esse programa não pode ser fechado por aqui">TRAVADO</span>'}</div>`}).join('')
  :vazio('check','Nada por aqui','Nenhum programa nesta lista agora.')}
function pintarSvc3(){
 const j=PR.s3;if(!j||atual!=='processos')return;
 const box=$('#prSvc3'),busy=S?ocupado(S):false,sig=JSON.stringify(j)+busy;
 if(box.dataset.s===sig)return;box.dataset.s=sig;
 let h='';
 if(!j.itens.length&&!j.feitos.length)h=`<p>Nenhum serviço de programa instalado está iniciando sozinho com o Windows${CATWIN?'':' (só funciona no Windows)'}.</p>`;
 else{
  h+=j.itens.map(i=>`<div class="lr"><div><b title="${esc(i.exibicao)}">${esc(i.exibicao)}</b><small>${esc(i.programa)} · ${i.estado==='running'?'rodando agora':'parado'}</small></div><span class="rk ${i.estado==='running'?'vd':'cz'}">${i.estado==='running'?'RODANDO':'PARADO'}</span><span class="n">${i.mb?fmtMB(i.mb):'--'}</span><button class="bt g" data-act="svc3" data-id="${esc(i.nome)}" data-nome="${esc(i.exibicao)}" data-man="1" ${busy||!CATWIN||!S.admin?'disabled':''}>Deixar manual</button></div>`).join('');
  if(j.feitos.length)h+=`<h3 style="margin:18px 0 6px;font-size:11.5px;letter-spacing:.14em;color:var(--m);font-weight:800">JÁ DEIXADOS EM MANUAL POR VOCÊ</h3>`+j.feitos.map(i=>`<div class="lr p3"><div><b title="${esc(i.exibicao)}">${esc(i.exibicao)}</b><small>Só inicia quando o programa precisar</small></div><span class="rk az">MANUAL</span><button class="bt g" data-act="svc3" data-id="${esc(i.nome)}" data-nome="${esc(i.exibicao)}" data-man="0" ${!CATWIN||!S.admin?'disabled':''}>Voltar ao automático</button></div>`).join('');
  if(S&&!S.admin)h+=`<p class="sub2" style="margin-top:10px">Mudar serviços precisa de Administrador.${NOADM}</p>`}
 box.innerHTML=h}

/* ===================== JOGOS ===================== */
const JOGO_OPC=[
 ['fechar','Fechar o que pesa em segundo plano','Telemetria, Widgets, Game Bar e outros ajudantes que ninguém usa.'],
 ['ram','Liberar a memória RAM','Esvazia a memória dos programas parados.'],
 ['energia','Plano de energia de desempenho','Volta ao plano de antes quando a sessão terminar.'],
 ['ajustes','Ligar os ajustes de FPS do Windows','Game DVR, Game Bar, prioridade de jogos, mouse e rede. Ficam ligados depois; dá para desligar na lista mais abaixo.'],
 ['gpu','Usar a placa de vídeo forte no jogo','Faz diferença em notebook com duas placas. Vale só para jogos escolhidos na lista.'],
 ['pausar','Pausar Windows Update e indexação','Voltam sozinhos quando a sessão terminar. Precisa de Administrador.'],
 ['leve','Dar prioridade ao jogo','Os outros programas ficam com prioridade menor (Modo Leve).'],
 ['fso','Desligar a otimização de tela cheia do jogo','Em alguns jogos reduz o atraso; em outros piora. Desligado por padrão.'],
 ['abrir','Abrir o jogo depois de otimizar','Vale para o botão “Otimizar e jogar”.']];
const FPS_IDS=['modo_jogo','game_dvr','fps_dvr_politica','fps_gamebar','fps_janela','prioridade_jogos','mouse_acel','do_p2p','rede_throttle','rede_nagle','fps_energia_throttle','hags','fps_vbs'];
const FROW={},JPEND={};
let JDISM=-1,JSIG='';
const optJ=(s,k)=>{const p=JPEND[k];return p&&Date.now()-p.t<3000?p.v:!!s.pre.opcoes[k]};
function montarFps(){
 const box=$('#lsFps');if(!box||!CAT)return;
 const itens=FPS_IDS.map(id=>POR[id]).filter(Boolean);
 if(!itens.length){box.innerHTML=vazio('info','Nada disponível','Este computador não tem esses ajustes.');return}
 box.innerHTML=itens.map(a=>`<div class="aj" data-fps="${esc(a.id)}"><div><b>${esc(a.titulo)}</b><span class="rk ${a.risco==='medio'?'medio">RISCO MÉDIO':'baixo">BAIXO RISCO'}</span></div><button class="sw" data-ajsw="${esc(a.id)}" aria-label="${esc(a.titulo)}"><i></i></button><p>${esc(a.desc)}</p>${a.nota?`<p class="nt">${ico('info')}${esc(a.nota)}</p>`:''}<p class="av" hidden>Precisa de Administrador.${NOADM}</p></div>`).join('');
 itens.forEach(a=>{FROW[a.id]=box.querySelector(`[data-fps="${a.id}"]`)});
 if(S)pintarFpsAj()}
function pintarFpsAj(){
 if(!S||!CAT)return;let lig=0,tot=0;
 FPS_IDS.forEach(id=>{const a=POR[id],row=FROW[id];if(!a||!row)return;
  const v=valorAj(id),falta=CATWIN&&a.admin&&!S.admin;tot++;if(v===true)lig++;
  row.classList.toggle('on',v===true);row.classList.toggle('nd',v===null||!CATWIN);row.classList.toggle('pd',!!pend[id]);
  const sw=row.querySelector('.sw');sw.classList.toggle('on',v===true);sw.disabled=v===null||!CATWIN||falta;sw.setAttribute('aria-pressed',v===true);
  row.querySelector('.av').hidden=!falta});
 $('#ctFps').textContent=CATWIN?`${lig} DE ${tot} LIGADOS`:'PRÉVIA'}
function entrarJogos(){JSIG='';JM.tries=0;carregarMonJogo();carregarPerf()}
const JM={d:null,tries:0,p:null};
async function carregarMonJogo(){
 try{JM.d=await pegar('monitor');pintarMonJogo();
  if((JM.d.estado==='lendo'||JM.d.estado==='nenhum')&&JM.tries++<8&&atual==='jogos')setTimeout(carregarMonJogo,1800)}
 catch(e){$('#jMon').innerHTML='<h3>Monitor</h3><p>Não consegui ler o monitor agora.</p>'}}
function pintarMonJogo(){
 const j=JM.d;if(!j)return;const d=j.dados;let h='<h3>Monitor</h3>';
 if(j.estado==='pronto'&&d){const baixo=d.hz_max>d.hz+5;
  h+=`<div class="nm" style="font-size:28px">${esc(d.res)} <small>· ${d.hz} Hz</small></div><p>${esc((d.placas||[]).join(' · '))}</p>`+
   (baixo?`<div class="avs" style="margin:14px 0 0">${ico('info')}<span>Seu monitor aceita até <b>${d.hz_max} Hz</b>, mas está a ${d.hz} Hz. Mais Hz deixa tudo mais fluido, mesmo com o mesmo FPS. Troque em Configurações de tela → Taxa de atualização.</span></div><div class="linha" style="margin-top:12px"><button class="bt g" data-act="atalho" data-id="tela">Abrir configurações da tela</button></div>`
        :`<p style="margin-top:8px">${ico('check','ok')} <span class="ok">Taxa de atualização no máximo que o monitor aceita.</span></p>`)}
 else if(j.estado==='pronto'||j.estado==='erro')h+='<p>Não consegui ler o monitor. Essa leitura só funciona no Windows.</p>';
 else h+='<div class="sk fino"></div>';
 $('#jMon').innerHTML=h}
async function carregarPerf(){
 try{JM.p=await pegar('perfis');pintarPerf()}catch(e){}}
function pintarPerf(){
 const p=JM.p;if(!p)return;const tem=p.gpu+p.fso>0;
 $('#jPerf').innerHTML=`<h3>Perfis por jogo</h3><p>Quando você otimiza um jogo da lista, o Th Boost marca o programa dele para usar a placa de vídeo de alto desempenho e, se você ligar a opção, desliga a otimização de tela cheia dele. Isso fica registrado por jogo.</p><div class="nm" style="font-size:24px">${p.gpu} <small>com placa forte</small> · ${p.fso} <small>com tela cheia ajustada</small></div><div class="linha" style="margin-top:12px"><button class="bt g" data-act="perfis_desfazer" ${tem&&S&&!ocupado(S)?'':'disabled'}>Desfazer todos os perfis</button></div>`}
function pintarJogos(s){
 const p=s.pre,sess=s.sessao,busy=ocupado(s);
 semAdm('jAdm','Sem Administrador, alguns passos serão pulados (pausar o Windows Update, parte dos ajustes de FPS e o plano de energia).'+NOADM);
 $('#jHero').classList.toggle('run',p.ativo);
 $('#jSub').textContent=sess?'Sua sessão de jogo está ativa. Quando você terminar, o plano de energia, os serviços pausados e as prioridades voltam ao normal.':'Fecha o que pesa, libera a memória, liga o plano de energia de desempenho, aplica os ajustes de FPS e dá prioridade ao jogo. Quando a sessão acaba, o Th Boost devolve o que dá para devolver.';
 $('#jStatus').textContent=p.ativo?(p.passo||'Otimizando...'):(sess?'Sessão ativa'+(sess.jogo?': '+sess.jogo:''):'Pronto para otimizar');
 const go=$('#jGo');go.classList.toggle('fim',!!sess&&!p.ativo);go.disabled=p.ativo||s.ext.ativo||s.otim.ativo||!CATWIN;
 go.dataset.act=sess?'sessao_fim':'jogo_pc';go.querySelector('span').textContent=p.ativo?'Otimizando...':(sess?'Terminar sessão':'Otimizar meu PC para jogar');
 /* coluna da direita */
 const modo=p.ativo?'run':(p.resumo&&JDISM!==p.fim?'done':'opc');
 const sig=modo+'|'+(modo==='run'?Math.round(p.fracao*100)+JSON.stringify(p.passos.map(x=>x.estado+x.texto)):modo==='done'?p.fim:JOGO_OPC.map(o=>optJ(s,o[0])).join(''));
 if(sig!==JSIG){JSIG=sig;const lado=$('#jLado');
  if(modo==='run'){lado.innerHTML=`<h3 style="margin:0 0 10px;font-size:11.5px;letter-spacing:.14em;color:#8fd9c0;font-weight:800">${esc(p.jogo?'OTIMIZANDO '+p.jogo.toUpperCase():'OTIMIZANDO O PC')}</h3>`+p.passos.map(x=>`<div class="ps ${x.estado}"><span class="pi">${ico(x.estado==='pulado'?'traco':(x.estado==='erro'?'x':'check'))}</span><div><b>${esc(x.nome)}</b><small>${esc(x.texto||(x.estado==='rodando'?'Em andamento...':'Aguardando'))}</small></div></div>`).join('')}
  else if(modo==='done'){const r=p.resumo,L=[];
   if(r.ajustes)L.push(['servicos',String(r.ajustes),'ajuste(s) de FPS ligado(s) agora']);
   if(r.fechados&&r.fechados.length)L.push(['x',String(r.fechados.length),'programa(s) escondido(s) fechado(s): '+r.fechados.slice(0,4).join(', ')]);
   if(r.ram_gb>0.04)L.push(['ram','+'+fmtGB(r.ram_gb),'de memória RAM livre a mais']);
   if(r.processos&&r.processos[0]!=null&&r.processos[1]!=null&&r.processos[1]<r.processos[0])L.push(['processos',`${r.processos[0]} → ${r.processos[1]}`,'processos rodando']);
   if(r.plano)L.push(['plano','Desempenho','plano de energia ativo (volta ao normal quando a sessão terminar)']);
   if(r.pausados&&r.pausados.length)L.push(['servicos',String(r.pausados.length),'serviço(s) pausado(s): '+r.pausados.join(', ')+' (voltam quando a sessão terminar)']);
   if(r.gpu)L.push(['gpu',String(r.gpu),'programa(s) do jogo na placa de vídeo forte']);
   if(!L.length)L.push(['check','Tudo pronto','Seu PC já estava ajustado para jogar.']);
   lado.innerHTML=`<h3 style="margin:0 0 6px;font-size:11.5px;letter-spacing:.14em;color:#8fd9c0;font-weight:800">${esc(r.jogo?'PRONTO PARA JOGAR '+r.jogo.toUpperCase():'PRONTO PARA JOGAR')}</h3>`+L.map(l=>`<div class="rl"><span class="ri">${ico(l[0])}</span><div><b>${esc(l[1])}</b><span>${esc(l[2])}</span></div></div>`).join('')+`<div class="linha" style="margin-top:14px"><button class="bt g" data-act="jogo_opcoes">Mudar o que é feito</button></div>`}
  else lado.innerHTML=`<h3 style="margin:0 0 4px;font-size:11.5px;letter-spacing:.14em;color:#8fd9c0;font-weight:800">O QUE O TH BOOST FAZ</h3>`+JOGO_OPC.map(o=>`<div class="xo"><div><b>${o[1]}</b><small>${o[2]}</small></div><button class="sw ${optJ(s,o[0])?'on':''}" data-act="pre_opc" data-id="${o[0]}" aria-pressed="${optJ(s,o[0])}" aria-label="${o[1]}"><i></i></button></div>`).join('')}
 /* modo automático */
 const au=!!s.auto_jogo;$('#swAuto').classList.toggle('on',au);$('#swAuto').setAttribute('aria-pressed',au);$('#stAuto').textContent=au?'LIGADO':'DESLIGADO';$('#stAuto').style.color=au?'#ffffff':'';
 /* botões dos jogos */
 $$('#jogosBox [data-a="jogo_otimizar"]').forEach(b=>{b.disabled=!!sess||busy||!CATWIN});
 pintarFpsAj();
 const pf=$('#jPerf button');if(pf&&JM.p)pf.disabled=!(JM.p.gpu+JM.p.fso>0)||busy}
$('#swAuto').onclick=()=>acao('auto_jogo',{ligar:!$('#swAuto').classList.contains('on')});

/* ===================== CORREÇÕES ===================== */
async function carregarCorr(){
 try{LST.corr=await pegar('correcoes');$('#crLista').dataset.s='';pintarCorr()}catch(e){$('#crLista').innerHTML=vazio('info','Não consegui ler a lista','Tente de novo em alguns segundos.')}}
function pintarCorr(){
 if(!LST.corr||!S)return;
 semAdm('crAdm','Sem Administrador, a maioria das correções não funciona.'+NOADM);
 painelTrab('crJob','correcao');
 const busy=ocupado(S),box=$('#crLista'),sig=JSON.stringify([busy,S.admin,CATWIN]);
 if(box.dataset.s===sig)return;box.dataset.s=sig;
 box.innerHTML=LST.corr.itens.map(c=>{const falta=c.admin&&!S.admin;
  return `<div class="cd cr"><div class="crt"><span class="ti2">${ico('correcoes')}</span><div><b>${esc(c.nome)}</b>${c.admin?'<span class="rk az">ADMINISTRADOR</span>':''}<span class="rk cz">${esc(c.demora.toUpperCase())}</span>${c.reinicia?'<span class="rk am">PEDE REINICIAR</span>':''}</div></div><p>${esc(c.desc)}</p><div class="linha"><button class="bt ${falta?'':'p'} g" data-act="corrigir" data-id="${esc(c.id)}" ${busy||!CATWIN||falta?'disabled':''}>${falta?'Precisa de Administrador':'Corrigir'}</button></div></div>`}).join('');
 $('#crLinks').innerHTML=LST.corr.links.map(l=>`<button class="bt g" data-act="link" data-id="${esc(l.id)}">${esc(l.nome)}</button>`).join('')}

/* ===================== BACKUP ===================== */
const BK={d:null,busy:false,sig:'',fim:-1};
async function carregarBk(){
 if(BK.busy)return;BK.busy=true;
 try{BK.d=await pegar('backup');BK.sig='';pintarBk()}catch(e){$('#bkArq').innerHTML=vazio('info','Não consegui ler o backup','Tente de novo em alguns segundos.')}
 BK.busy=false;
 if(BK.d&&BK.d.pontos.estado==='lendo'&&atual==='backup')setTimeout(carregarBk,2000)}
function tickBk(s){
 const T=s.trab.backup;
 if(BK.fim!==T.fim){const antes=BK.fim;BK.fim=T.fim;if(antes>=0)carregarBk()}
 pintarBk()}
function pintarBk(){
 const d=BK.d;if(!d||!S||atual!=='backup')return;
 semAdm('bkAdm','Sem Administrador, o ponto de restauração, a Proteção do Sistema e a cópia dos drivers não funcionam.'+NOADM);
 painelTrab('bkJob','backup',r=>{const x=r.dados||{};return x.quando?`<div class="jres"><b>${x.arquivos}</b> arquivo(s) copiado(s) · <b>${fmtMB(x.mb)}</b>${x.parcial?' · backup parcial, rode de novo para continuar':''}<br><span class="sub2">${esc(x.quando)}</span></div>`:''});
 const ativo=S.trab.backup.ativo,cfg=d.config,sig=JSON.stringify([d,ativo,S.admin,CATWIN]);
 if(BK.sig===sig)return;BK.sig=sig;
 const ult=cfg.ultimo;
 const dest=d.destinos.length?d.destinos.map(x=>{const sel=cfg.destino===x.id;
  return `<button class="pc ${sel?'on sel':''}" data-act="bk_dest" data-id="${esc(x.id)}"><span class="pi2">${ico('disco')}</span><b>${esc(x.id)} · ${x.livre_gb.toFixed(0)} GB livres</b><small>de ${x.total_gb.toFixed(0)} GB · ${x.removivel?'pendrive ou HD externo':'disco fixo'}</small>${x.sistema?'<span class="rk am" style="margin-top:4px">MESMO DISCO DO WINDOWS</span>':''}${sel?'<span class="tg">ESCOLHIDO</span>':''}</button>`}).join('')
  :`<p style="grid-column:1/-1">Não achei nenhuma unidade para guardar o backup. Conecte um pendrive ou HD externo.</p>`;
 const pastas=d.pastas.map(p=>`<label class="ap ${p.marcada&&p.existe?'sel':''}"><input type="checkbox" data-bkp="${esc(p.id)}" ${p.marcada&&p.existe?'checked':''} ${p.existe?'':'disabled'}><span class="ck">${ico('check')}</span><div><b>${esc(p.nome)}</b><small>${p.existe?esc(p.caminho):'pasta não encontrada'}</small></div></label>`).join('');
 const sem=!cfg.destino||!cfg.pastas.length||ativo||!CATWIN;
 $('#bkArq').innerHTML=`<h2 style="margin:0;font-size:21px">Backup dos seus arquivos</h2><p>Copia as pastas marcadas para um pendrive, HD externo ou outro disco. Só copia o que mudou desde o último backup e nunca apaga nada no destino.</p><div class="ctr">${ult?`ÚLTIMO BACKUP: ${esc(ult.quando)} · ${ult.arquivos} ARQUIVOS · ${fmtMB(ult.mb)}`:'VOCÊ AINDA NÃO FEZ BACKUP DOS ARQUIVOS'}</div>`+
  `<h3 style="margin:18px 0 0">1. Onde guardar</h3><div class="pl dest">${dest}</div><h3 style="margin:18px 0 0">2. O que copiar</h3><div class="apg" style="margin-top:10px">${pastas}</div>`+
  `<div class="linha" style="margin-top:6px"><button class="bt p grande" data-act="bk_go" ${sem?'disabled':''}>${ico('backup')}<span>Fazer backup agora</span></button><button class="bt" data-act="bk_rest" ${!d.tem_backup||ativo||!CATWIN?'disabled':''}>Restaurar do backup</button><button class="bt" data-act="bk_abrir" ${!d.tem_backup?'disabled':''}>Abrir a pasta do backup</button></div>`+
  `<p class="sub2" style="margin-top:12px">Se o PC estragar ou for formatado, os arquivos copiados continuam no destino. Um backup no mesmo disco do Windows não protege contra defeito do disco: prefira um pendrive ou HD externo.</p>`;
 /* pontos de restauração */
 const pt=d.pontos;let ph;
 if(pt.estado==='lendo'||pt.estado==='nenhum')ph='<span class="lendo">Lendo os pontos de restauração...</span>';
 else if(pt.estado==='erro')ph='<p>Não consegui ler os pontos de restauração.</p>';
 else if(!pt.itens.length)ph=`<p>${CATWIN?'Nenhum ponto de restauração encontrado. A Proteção do Sistema pode estar desligada: ligue abaixo.':'Só funciona no Windows.'}</p>`;
 else ph=[...pt.itens].sort((a,b)=>b.ts-a.ts).slice(0,6).map(x=>`<div class="pt-l"><div><b>${esc(x.nome||'Ponto de restauração')}</b></div><time>${esc(x.quando)}</time></div>`).join('');
 $('#bkPontos').innerHTML=`<h3>Pontos de restauração</h3><p>Um ponto de restauração é uma “foto” das configurações do Windows. Se algo der errado depois de instalar ou mudar alguma coisa, dá para voltar a ele: Painel de Controle → Recuperação → Abrir Restauração do Sistema. Não substitui o backup dos seus arquivos.</p><div style="margin:10px 0 14px">${ph}</div><div class="linha"><button class="bt p g" data-act="bk_ponto" ${ativo||!CATWIN?'disabled':''}>Criar um ponto agora</button><button class="bt g" data-act="bk_prot" ${ativo||!CATWIN?'disabled':''}>Ligar a Proteção do Sistema</button></div>`;
 $('#bkDrv').innerHTML=`<h3>Drivers</h3><p>Guarda uma cópia dos drivers instalados no destino do backup. Depois de formatar o Windows, você pode apontar o Windows para essa pasta e reinstalar os drivers sem baixar nada.</p><div class="linha" style="margin-top:12px"><button class="bt g" data-act="bk_drv" ${!cfg.destino||ativo||!CATWIN?'disabled':''}>Guardar cópia dos drivers</button></div>${cfg.destino?'':'<p class="sub2" style="margin-top:8px">Escolha primeiro onde guardar, no cartão de cima.</p>'}`;
 $('#bkAj').innerHTML=`<h3>Configurações do Th Boost</h3><p>Guarda o registro de como o Windows era antes dos ajustes do Th Boost. Serve para os botões de desfazer continuarem funcionando se você mudar de PC ou apagar a pasta do programa.</p><div class="linha" style="margin-top:12px"><button class="bt g" data-act="bk_aj" ${ativo?'disabled':''}>Guardar configurações agora</button></div>`+
  (d.ajustes.length?`<div style="margin-top:12px">`+d.ajustes.map(x=>`<div class="pt-l"><div><b>${esc(x.quando)}</b><small>${x.kb} KB</small></div><button class="bt g" data-act="bk_imp" data-id="${esc(x.nome)}" ${ativo?'disabled':''}>Importar</button></div>`).join('')+`</div>`:'')}

/* ===================== FERRAMENTAS ===================== */
const FT={aba:'programas',prog:null,ord:'nome',busca:'',esp:null,alvo:'',at:null,esFim:-1};
function entrarFerr(){trocarAba(FT.aba)}
function trocarAba(a){
 FT.aba=a;$$('#ftTabs button').forEach(b=>b.classList.toggle('on',b.dataset.id===a));
 ['programas','espaco','atalhos'].forEach(k=>{$('#ft-'+k).hidden=k!==a});
 if(a==='programas')carregarProg();else if(a==='espaco')carregarEsp();else carregarAt()}
function tickFerr(s){
 if(FT.aba==='espaco'){painelTrab('esJob','espaco');
  if(FT.esFim!==s.trab.espaco.fim){FT.esFim=s.trab.espaco.fim;if(FT.esp)carregarEsp()}
  const go=$('#esGo');go.disabled=s.trab.espaco.ativo||!CATWIN}}
async function carregarProg(){
 if(!FT.prog)$('#prgLista').innerHTML='<div class="sk fino"></div><div class="sk fino"></div><div class="sk fino"></div>';
 try{FT.prog=(await pegar('programas')).itens;pintarProg()}catch(e){$('#prgLista').innerHTML=vazio('info','Não consegui ler a lista','Tente de novo em alguns segundos.')}}
function pintarProg(){
 const it=FT.prog;if(!it)return;
 const q=FT.busca.trim().toLowerCase();
 let l=it.filter(p=>!q||p.nome.toLowerCase().includes(q)||p.editora.toLowerCase().includes(q));
 l.sort({nome:(a,b)=>a.nome.localeCompare(b.nome,'pt-BR'),mb:(a,b)=>b.mb-a.mb,data:(a,b)=>dataNum(b.data)-dataNum(a.data)}[FT.ord]);
 $('#ctProg').textContent=it.length?`${l.length} DE ${it.length} PROGRAMAS`:'';
 $$('#prOrd .chip').forEach(c=>c.classList.toggle('on',c.dataset.id===FT.ord));
 const busy=S?ocupado(S):false;
 $('#prgLista').innerHTML=l.length?l.slice(0,300).map(p=>`<div class="lr p3"><div><b title="${esc(p.nome)}">${esc(p.nome)}</b><small>${esc([p.editora,p.versao&&('versão '+p.versao),p.data&&('instalado em '+p.data)].filter(Boolean).join(' · '))}</small></div><span class="n">${p.mb?fmtMB(p.mb):'--'}</span>${p.protegido?'<span class="rk cz" title="Peça do Windows, driver ou segurança">PROTEGIDO</span>':`<button class="bt g" data-act="prog_des" data-id="${esc(p.id)}" data-nome="${esc(p.nome)}" ${busy||!CATWIN?'disabled':''}>Desinstalar</button>`}</div>`).join('')+(l.length>300?`<p class="sub2" style="margin:10px 4px">Mostrando 300 de ${l.length}. Use a busca para achar os outros.</p>`:''):
  (it.length?vazio('busca','Nenhum programa com esse nome','Tente outra palavra.'):vazio('info',CATWIN?'Nenhum programa encontrado':'Prévia',CATWIN?'Não achei programas instalados.':'Esta lista só funciona no Windows.'))}
$('#prBusca').addEventListener('input',e=>{FT.busca=e.target.value;pintarProg()});
async function carregarEsp(){
 try{FT.esp=await pegar('espaco');if(!FT.alvo||!FT.esp.alvos.some(a=>a.id===FT.alvo))FT.alvo=(FT.esp.alvos[0]||{}).id||'';pintarEsp()}catch(e){$('#esRes').innerHTML=vazio('info','Não consegui ler','Tente de novo em alguns segundos.')}}
function pintarEsp(){
 const j=FT.esp;if(!j)return;
 $('#esAlvos').innerHTML=j.alvos.length?j.alvos.map(a=>`<button class="chip ${a.id===FT.alvo?'on':''}" data-act="es_alvo" data-id="${esc(a.id)}">${esc(a.nome)}</button>`).join(''):'<span class="sub2">Nenhuma pasta encontrada.</span>';
 painelTrab('esJob','espaco');
 const box=$('#esRes');
 if(!j.pastas||!j.pastas.length){box.innerHTML='';return}
 const mx=Math.max(1,...j.pastas.map(p=>p.bytes));
 box.innerHTML=`<div class="cd led" style="margin-bottom:16px"><h3>${esc(j.nome||'Análise')} · ${fmtB(j.total)}</h3><p>${j.arquivos_lidos} arquivos lidos em ${esc(j.quando||'')}${j.parcial?'. Análise parcial: a pasta é muito grande ou foi interrompida':''}.</p><div style="margin-top:10px">${j.pastas.map(p=>`<div class="xb"><span title="${esc(p.nome)}">${esc(p.nome)}</span><div class="tr"><i style="width:${Math.max(3,p.bytes/mx*100)}%"></i></div><b>${fmtB(p.bytes)}</b></div>`).join('')}</div></div>`+
  (j.arquivos&&j.arquivos.length?`<div class="cd"><h3>Maiores arquivos</h3><p>Abra a pasta e decida você mesmo o que apagar. O Th Boost não apaga nada aqui.</p><div class="lrs" style="margin-top:10px;max-height:none">${j.arquivos.map(a=>`<div class="lr p3"><div><b title="${esc(a.nome)}">${esc(a.nome)}</b><small>${esc(a.pasta)} · ${esc(a.quando)}</small></div><span class="n">${fmtB(a.bytes)}</span><button class="bt g" data-act="es_mostrar" data-id="${a.i}">Mostrar</button></div>`).join('')}</div></div>`:'')}
async function carregarAt(){
 try{if(!FT.at)FT.at=(await pegar('atalhos')).itens;
  const gr={};FT.at.forEach(a=>{(gr[a.grupo]=gr[a.grupo]||[]).push(a)});
  $('#atGrade').innerHTML=Object.keys(gr).map(g=>`<div class="cd" style="grid-column:1/-1;padding:0;background:none;border:0;box-shadow:none"><h3 style="margin:8px 4px 0">${esc(g)}</h3></div>`+gr[g].map(a=>`<div class="cd atg"><b>${esc(a.nome)}</b><p>${esc(a.desc)}</p><div class="linha"><button class="bt g" data-act="atalho" data-id="${esc(a.id)}" ${CATWIN?'':'disabled'}>Abrir</button></div></div>`).join('')).join('')}
 catch(e){$('#atGrade').innerHTML=vazio('info','Não consegui ler','Tente de novo em alguns segundos.')}}

/* ===================== cliques das páginas novas ===================== */
document.addEventListener('click',e=>{
 const b=e.target.closest('[data-act]');if(!b||b.disabled)return;
 const d=b.dataset;
 switch(d.act){
  case 'trab_parar':acao('trab_parar',{chave:d.id});break;
  case 'trab_fechar':DISM[d.id]=S.trab[d.id].fim;$$('.jp').forEach(x=>x.dataset.s='');if(atual==='correcoes')pintarCorr();else if(atual==='backup')pintarBk();else if(atual==='processos')pintarProc(true);else if(atual==='ferramentas')pintarEsp();break;
  case 'sessao_fim':confirmar('Terminar a sessão de jogo?','O plano de energia, os serviços pausados e as prioridades voltam ao normal agora.',()=>acao('sessao_fim'));break;
  case 'x_analisar':acao('extremo_analisar',{nivel:X.nivel});break;
  case 'dash_atualizar':DASH.t=0;carregarDash();break;
  /* jogos */
  case 'jogo_pc':confirmar('Otimizar o PC para jogar?','Vou fechar o que pesa em segundo plano, liberar a RAM e aplicar o que está marcado ao lado. Nada é desinstalado. Quando você terminar a sessão, o plano de energia, os serviços pausados e as prioridades voltam ao normal. Os ajustes de FPS do Windows ficam ligados e podem ser desligados na lista mais abaixo.',()=>acao('jogo_otimizar',{i:null}));break;
  case 'pre_opc':{const v=!optJ(S,d.id);JPEND[d.id]={v,t:Date.now()};S.pre.opcoes[d.id]=v;JSIG='';pintarJogos(S);acao('pre_opcoes',{opcoes:{[d.id]:v}});break}
  case 'jogo_opcoes':JDISM=S.pre.fim;JSIG='';pintarJogos(S);break;
  case 'perfis_desfazer':confirmar('Desfazer os perfis dos jogos?','Os jogos deixam de ser marcados para usar a placa de vídeo forte e a otimização de tela cheia volta ao que era. Os jogos continuam instalados e funcionando.',()=>{acao('jogos_desfazer_perfis');setTimeout(carregarPerf,1500)});break;
  case 'atalho':acao('atalho',{id:d.id});break;
  case 'mm_atualizar':MM.sig='';carregarMem(true);break;
  case 'mm_testar':acao('atalho',{id:'memdiag'});break;
  case 'mm_bios':confirmar('Reiniciar agora na BIOS?','O PC vai reiniciar em 30 segundos direto na tela da BIOS. Salve tudo antes. Lá você ativa o perfil da memória, salva (F10) e o PC volta para o Windows. Dá para cancelar aqui por 30 segundos.',()=>{acao('memoria_bios');MM.pend=Date.now()+30000;MM.sig='';pintarMem()});break;
  case 'mm_cancelar':acao('memoria_bios_cancelar');MM.pend=0;MM.sig='';pintarMem();break;
  case 'cp_perfil':{const id=d.id,ir=()=>{acao('cpu_perfil',{perfil:id});[2200,5000].forEach(t=>setTimeout(()=>{CPF.sig='';carregarCpf()},t))};
   if(id==='maximo')confirmar('Perfil Máximo da CPU','O processador fica sempre em velocidade alta: mais calor, ventoinha mais alta e mais consumo. Dá para voltar ao padrão aqui mesmo. Continuar?',ir);else ir();break}
  /* processos */
  case 'proc_filtro':PR.filtro=d.id;PR.sigL='';pintarProc(true);break;
  case 'cpu_sw':{const c=(PR.d||{}).cpu;if(!c)break;const lig=!c.ligado,p=+$('#cpuR').value;CPUS.pct=p;CPUS.ate=Date.now()+8000;acao('cpu_limite',{ligar:lig,pct:p});c.ligado=lig;PR.t=0;PR.forcar=true;pintarCpu(PR.d);break}
  case 'proc_opc':PRO[d.id]=!proOn(d.id);try{localStorage.setItem('thboost-proc',JSON.stringify(PRO))}catch(x){}PR.sigO='';pintarProc(false);break;
  case 'proc_reduzir':{const r=proOn('raros'),j=proOn('svchost'),l=proOn('launchers'),c=proOn('chats');confirmar('Reduzir os processos?','Vou criar um ponto de restauração, fechar ajudantes e atualizadores que ninguém usa, parar apps em segundo plano do Windows e desligar serviços que pesam (telemetria, mapas, fax e outros de baixo risco).'+(l?' Também fecho launchers de jogos e programas de nuvem que estiverem abertos (menos o que você está usando e qualquer launcher com jogo aberto).':'')+(c?' E fecho chats e músicas (Discord, Spotify...): uma chamada de voz em andamento vai cair.':'')+(r?' Também desligo serviços que quase ninguém usa.':'')+(j?' E junto os serviços do Windows em menos processos: isso só aparece depois de reiniciar o PC.':'')+' Nada é desinstalado e os serviços dá para desfazer pelo botão “Desfazer”; os programas fechados você abre de novo normalmente. Salve o que estiver aberto: programas fechados perdem o que não foi salvo.',()=>acao('proc_reduzir',{opcoes:{raros:r,svchost:j,launchers:l,chats:c}}));break}
  case 'proc_desfazer':confirmar('Desfazer o Reduzir processos?','Os serviços e ajustes que o Reduzir processos desligou voltam como estavam. Programas que ele fechou não voltam sozinhos: é só abrir de novo.',()=>acao('proc_desfazer'));break;
  case 'proc_fechar':confirmar(`Fechar ${d.rot}?`,'Todos os processos desse programa serão encerrados. O que não estiver salvo nele será perdido.',()=>{acao('proc_fechar',{nome:d.id});setTimeout(()=>{PR.t=0;PR.sigL='';PR.forcar=true},1200)});break;
  case 'svc3':confirmar(d.man==='1'?`Deixar “${d.nome}” em manual?`:`Voltar “${d.nome}” ao automático?`,d.man==='1'?'O serviço deixa de iniciar sozinho com o Windows e só roda quando o programa precisar. O programa continua instalado. Se algo parar de funcionar, volte aqui e escolha “Voltar ao automático”.':'O serviço volta a iniciar sozinho com o Windows, como antes.',()=>{acao('svc3',{nome:d.id,manual:d.man==='1'});setTimeout(()=>{PR.s3t=0},1200)});break;
  /* correções */
  case 'corrigir':{const c=((LST.corr||{}).itens||[]).find(x=>x.id===d.id);if(!c)break;const go=()=>acao('correcao',{id:c.id});c.conf?confirmar(c.conf[0],c.conf[1],go):go();break}
  case 'link':acao('link',{id:d.id});break;
  /* backup */
  case 'bk_dest':{if(!BK.d)break;BK.d.config.destino=d.id;BK.sig='';pintarBk();acao('bk_config',{destino:d.id,pastas:BK.d.config.pastas});break}
  case 'bk_go':acao('bk_arquivos');break;
  case 'bk_rest':confirmar('Restaurar do backup?','Os arquivos que estão no backup e faltam no seu PC serão copiados de volta para as pastas de origem. Nada que já existe é sobrescrito.',()=>acao('bk_restaurar'));break;
  case 'bk_abrir':acao('bk_abrir');break;
  case 'bk_ponto':acao('bk_ponto');break;
  case 'bk_prot':confirmar('Ligar a Proteção do Sistema?','O Windows passa a guardar pontos de restauração no disco do sistema, usando um espaço reservado de alguns GB. Precisa de Administrador.',()=>acao('bk_protecao'));break;
  case 'bk_drv':acao('bk_drivers');break;
  case 'bk_aj':acao('bk_ajustes');break;
  case 'bk_imp':confirmar('Importar estas configurações?','Isto devolve ao Th Boost o registro de como o Windows era antes dos ajustes, para os botões de desfazer funcionarem como na data deste arquivo. Não liga nem desliga nenhum ajuste por si só. O registro atual é guardado com a extensão .antes.',()=>acao('bk_importar',{nome:d.id}));break;
  /* ferramentas */
  case 'ft_aba':trocarAba(d.id);break;
  case 'prog_ord':FT.ord=d.id;pintarProg();break;
  case 'prog_des':confirmar(`Desinstalar ${d.nome}?`,'Vou abrir o desinstalador do próprio programa. Ele pode pedir a sua confirmação e, às vezes, permissão de Administrador. Depois de desinstalado, o programa só volta instalando de novo.',()=>{acao('programa_desinstalar',{id:d.id});setTimeout(()=>{FT.prog=null;carregarProg()},8000)});break;
  case 'es_alvo':FT.alvo=d.id;pintarEsp();break;
  case 'espaco_go':if(FT.alvo)acao('espaco_iniciar',{alvo:FT.alvo});break;
  case 'es_mostrar':acao('espaco_mostrar',{i:+d.id});break;
 }
});
document.addEventListener('input',e=>{if(e.target.id!=='cpuR')return;cpuFill(e.target);$('#cpuV').textContent=e.target.value+'%'});
document.addEventListener('change',e=>{if(e.target.id!=='cpuR')return;const c=(PR.d||{}).cpu;if(!c)return;CPUS.pct=+e.target.value;CPUS.ate=Date.now()+8000;if(c.ligado){acao('cpu_limite',{ligar:true,pct:CPUS.pct});PR.t=0;PR.forcar=true}});
document.addEventListener('change',e=>{
 const c=e.target.closest('[data-bkp]');if(!c||!BK.d)return;
 const cfg=BK.d.config,set=new Set(cfg.pastas);c.checked?set.add(c.dataset.bkp):set.delete(c.dataset.bkp);
 cfg.pastas=[...set];BK.d.pastas.forEach(p=>{p.marcada=set.has(p.id)});BK.sig='';pintarBk();
 acao('bk_config',{destino:cfg.destino||'',pastas:cfg.pastas})});

function pintarNovas(s){
 pintarSess(s);
 if(atual==='jogos')pintarJogos(s);
 else if(atual==='processos')pintarProcTick(s);
 else if(atual==='correcoes')pintarCorr();
 else if(atual==='backup')tickBk(s);
 else if(atual==='ferramentas')tickFerr(s);
 else if(atual==='dashboard'){if(Date.now()-DASH.t>15000)carregarDash()}
 else if(atual==='cpu'){if(Date.now()-CPF.t>15000)carregarCpf()}
 else if(atual==='resfriamento'){pintarRf(s);if(Date.now()-RF.t>15000)carregarRf()}
 else if(atual==='memoria'){if(Date.now()-MM.t>((MM.d&&MM.d.estado==='lendo')?1500:30000))carregarMem(false);else if(MM.pend&&Date.now()>MM.pend){MM.pend=0;MM.sig='';pintarMem()}}
 else if(atual==='inicio'){if(Date.now()-DASH.t>60000)carregarDash()}
}

carregarCatalogo();

/* relógio */
setInterval(()=>{$('#rel').textContent=new Date().toLocaleTimeString('pt-BR')},500);

/* conexão com o programa */
let falhas=0;
function conectar(){const es=new EventSource('/api/fluxo?k='+K);
 es.onmessage=(e)=>{falhas=0;S=JSON.parse(e.data);atualizar(S)};
 es.onerror=()=>{falhas++;if(falhas>=4&&!atuReinicio){es.close();$('#icOff').innerHTML=ico('x');$('#off').classList.add('on')}}}
conectar();

/* entrada */
ir((()=>{try{return sessionStorage.getItem('thboost-pag')}catch(e){return null}})()||'inicio');
setFx(fx(),false);
setTimeout(()=>{$('#boot').classList.add('some');setTimeout(()=>$('#boot').remove(),800);posPil()},1600);
/* se o aparelho estiver lento, liga o modo leve sozinho (só se a pessoa nunca escolheu) */
(function(){let v=null;try{v=localStorage.getItem('thboost-leve')}catch(e){}if(v!==null||!fx())return;
 setTimeout(()=>{let n=0,t0=0;const q=(t)=>{if(!t0)t0=t;n++;if(t-t0<2500)requestAnimationFrame(q);else if(n/((t-t0)/1000)<35&&!document.hidden){setFx(false,false);try{localStorage.setItem('thboost-leve','a')}catch(e){}toast('Efeitos leves ligados automaticamente. Você pode mudar em Configurações.')}};requestAnimationFrame(q)},5000)})();
</script>
</body>
</html>
"""


if __name__ == "__main__":
    principal()
