@echo off
setlocal
title Encerrar Th Boost
cd /d "%~dp0"

rem Fecha o Th Boost que ficou rodando em segundo plano (nao precisa de Administrador)
if exist "%~dp0Th Boost.exe" (
  "%~dp0Th Boost.exe" --encerrar
  goto :fim
)

rem Procura um Python que funcione de verdade (o "python" falso da Microsoft Store nao conta)
set "PY="
py -3 -c "import sys" >nul 2>&1 && set "PY=py -3"
if not defined PY python -c "import sys" >nul 2>&1 && set "PY=python"
if not defined PY (
  echo.
  echo  Python nao encontrado neste computador.
  echo.
  echo  Como resolver ^(2 minutos^):
  echo    1^) Abra https://www.python.org/downloads/ e baixe o Python.
  echo    2^) No instalador, MARQUE a caixa "Add python.exe to PATH" e clique em Install Now.
  echo    3^) Feche esta janela e abra este arquivo de novo.
  echo.
  echo  Se o Windows falou "Python nao foi encontrado" ou abriu a Microsoft Store, e normal:
  echo  e so um atalho falso. Depois de instalar pelo site, ele passa a funcionar.
  echo.
  pause
  exit /b 1
)

%PY% "%~dp0th_boost.py" --encerrar

:fim
echo.
echo  Pronto. Se o Th Boost estava rodando em segundo plano, ele foi encerrado.
echo  ^(O icone perto do relogio some em alguns segundos.^)
echo.
timeout /t 4 >nul
exit /b 0
